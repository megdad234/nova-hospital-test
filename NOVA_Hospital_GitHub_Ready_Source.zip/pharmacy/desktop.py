"""Offline Windows desktop app. The server location can be changed without reinstalling clients.
LAN remote service should be TLS secured. Local mode binds strictly to 127.0.0.1.
"""
from __future__ import annotations
import json, os, sys, threading
from pathlib import Path
from urllib.parse import urlsplit

CONFIG_NAME='client-config.json'

def app_data_dir():
    return Path(os.environ.get('LOCALAPPDATA') or (Path.home()/'AppData'/'Local'))/'HospitalPharmacyERP'

def validate_server_url(value):
    if not value:return ''
    if not isinstance(value,str):raise ValueError('Server address must be a string')
    u=urlsplit(value)
    if u.username or u.password or u.query or u.fragment or u.path not in ('','/'):
        raise ValueError('Server address must not include paths, secrets or query parameters')
    if u.scheme!='https' and not (u.scheme=='http' and u.hostname in ('localhost','127.0.0.1')):
        raise ValueError('A network server must use HTTPS; plain HTTP is allowed on loopback only')
    if not u.hostname or not u.port or not (1 <= u.port <= 65535):
        raise ValueError('Use full server address and port, for example https://hospital-server.local:8443')
    return value.rstrip('/')

def read_config():
    p=app_data_dir()/CONFIG_NAME
    try:
        return validate_server_url(json.loads(p.read_text(encoding='utf-8')).get('server_url',''))
    except FileNotFoundError: return ''

class WorkstationAPI:
    def __init__(self):
        from device_services import NativeAPI
        self.devices=NativeAPI()
    def get_devices(self):return self.devices.get_devices()
    def set_printer_settings(self,paper,printer=''):
        return self.devices.set_printer_settings(paper,printer)
    def export_backup(self,folder):
        import recovery, app
        from datetime import datetime
        path=Path(str(folder or '').strip())
        if not str(folder or '').strip() or not path.is_dir():
            raise ValueError('اختر مجلداً موجوداً على USB أو قرص خارجي')
        local=app_data_dir().resolve()
        if path.resolve()==local or local in path.resolve().parents:
            raise ValueError('اختر موقعاً خارج مجلد بيانات البرنامج للنسخة الإضافية')
        filename=path/('Pharmacy-Backup-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.sqlite3')
        result=recovery.copy_verified(app.DB,filename)
        config=app.DATA/'external_backup.json'
        config.parent.mkdir(parents=True,exist_ok=True)
        temp=config.with_suffix('.tmp')
        temp.write_text(json.dumps({'folder':str(path.resolve())},ensure_ascii=False),encoding='utf-8')
        os.replace(temp,config)
        return result
    def verify_backup(self,path):
        import recovery
        return recovery.validate_backup(path)
    def get_server_info(self):
        return {'server_url':read_config(),'mode':'hospital-server' if read_config() else 'single-computer'}
    def save_server_info(self,server_url):
        url=validate_server_url(server_url)
        root=app_data_dir();root.mkdir(parents=True,exist_ok=True)
        target=root/CONFIG_NAME;tmp=target.with_suffix('.tmp')
        tmp.write_text(json.dumps({'server_url':url},indent=2),encoding='utf-8')
        os.replace(tmp,target)
        return {'server_url':url,'restart_required':True}

def main():
    import webview
    desktop_mutex=None
    if os.name=='nt':
        import ctypes
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.CreateMutexW.argtypes=(ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p)
        kernel.CreateMutexW.restype=ctypes.c_void_p
        kernel.CloseHandle.argtypes=(ctypes.c_void_p,)
        desktop_mutex=kernel.CreateMutexW(None,False,'Local\\HospitalPharmacyERP-Desktop')
        if not desktop_mutex:raise OSError(ctypes.get_last_error(),'تعذر إنشاء قفل تشغيل التطبيق')
        if ctypes.get_last_error()==183:
            ctypes.windll.user32.MessageBoxW(None,'برنامج الصيدلية مفتوح بالفعل','مدار | MADAR',0x40)
            kernel.CloseHandle(desktop_mutex)
            return
    target=read_config()
    server=None
    if not target:
        import app
        local=app_data_dir();local.mkdir(parents=True,exist_ok=True)
        app.ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
        app.DATA=local/'data';app.DB=app.DATA/'pharmacy.sqlite3'
        app.init_db(preload_catalog=True);app.start_automatic_backups()
        server=app.ThreadServer(('127.0.0.1',0),app.Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        target='http://127.0.0.1:'+str(server.server_address[1])
    try:
        window=webview.create_window('مدار | MADAR — وحدة الصيدلية',target,
            width=1400,height=900,min_size=(990,640),background_color='#f3f8f6',
            js_api=WorkstationAPI())
        webview.start(gui='edgechromium',debug=False,private_mode=False)
    finally:
        if server:
            server.shutdown();server.server_close()
        if desktop_mutex:
            kernel.CloseHandle(desktop_mutex)

if __name__=='__main__':main()
