# Add-on operational workflows. Every mutation uses one SQLite transaction.
def recurring_list(c):
    plans=query(c,"""SELECT r.*,p.name AS customer, pr.name AS product,pk.unit_name,pk.factor,
      (SELECT COALESCE(SUM(l.qty_base),0) FROM lots l WHERE l.product_id=pk.product_id AND l.status='sellable' AND (l.expiry='' OR l.expiry>=date('now'))) AS available_base
      FROM recurring_plans r JOIN partners p ON p.id=r.partner_id JOIN packages pk ON pk.id=r.package_id JOIN products pr ON pr.id=pk.product_id
      ORDER BY r.active DESC,r.next_due,r.id""")
    for x in plans:
        x['required_base']=x['qty']*x['factor']
        x['shortage_base']=max(0,x['required_base']-x['available_base'])
    return plans

def recurring_create(c,p,uid):
    partner=posint(p.get('partner_id'),'العميل');package=posint(p.get('package_id'),'العبوة')
    qty=posint(p.get('qty'),'الكمية');days=posint(p.get('interval_days',30),'الدورية')
    if days>365:raise ValueError('الدورية القصوى 365 يوماً')
    due=textv(p,'next_due',10,True);date.fromisoformat(due)
    if not one(c,"SELECT id FROM partners WHERE id=? AND kind IN ('customer','pharmacy') AND active=1",(partner,)):raise ValueError('حساب العميل غير موجود')
    if not one(c,'SELECT id FROM packages WHERE id=?',(package,)):raise ValueError('العبوة غير موجودة')
    begin(c)
    try:
        id=c.execute('INSERT INTO recurring_plans(partner_id,package_id,qty,interval_days,next_due,notes,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',(partner,package,qty,days,due,textv(p,'notes',300),now(),uid)).lastrowid
        audit(c,uid,'create_refill',{'id':id,'partner':partner,'package':package})
        finish(c)
    except:rollback(c);raise
    return {'id':id,'stock_reserved':False}

def recurring_dispensed(c,p,uid):
    planid=posint(p.get('plan_id'),'خطة الدواء');saleid=posint(p.get('sale_id'),'فاتورة البيع')
    begin(c)
    try:
        plan=one(c,'SELECT * FROM recurring_plans WHERE id=? AND active=1',(planid,))
        if not plan:raise ValueError('الخطة غير نشطة')
        if plan['last_sale_id']==saleid:raise ValueError('تم ربط الفاتورة بهذه الخطة مسبقاً')
        sale=one(c,'SELECT * FROM sales WHERE id=? AND partner_id=?',(saleid,plan['partner_id']))
        if not sale:raise ValueError('الفاتورة غير مرتبطة بنفس المستفيد')
        line=one(c,'SELECT COALESCE(SUM(qty),0) AS qty FROM sale_lines WHERE sale_id=? AND package_id=?',(saleid,plan['package_id']))
        if line['qty']<plan['qty']:raise ValueError('الفاتورة لا تحتوي على الكمية المتكررة المحددة')
        nextdate=(date.today()+timedelta(days=plan['interval_days'])).isoformat()
        c.execute('UPDATE recurring_plans SET next_due=?,last_sale_id=? WHERE id=?',(nextdate,saleid,planid))
        audit(c,uid,'refill_dispensed',{'id':planid,'sale_id':saleid,'next_due':nextdate})
        finish(c)
    except:rollback(c);raise
    return {'id':planid,'next_due':nextdate,'reserved':False}

def recurring_deactivate(c,p,uid):
    id=posint(p.get('plan_id'),'الخطة');begin(c)
    try:
        c.execute('UPDATE recurring_plans SET active=0 WHERE id=?',(id,))
        if not c.execute('SELECT changes()').fetchone()[0]:raise ValueError('الخطة غير موجودة')
        audit(c,uid,'stop_refill',{'id':id});finish(c)
    except:rollback(c);raise
    return {'id':id,'active':False}

def expense_create(c,p,uid):
    category=textv(p,'category',60,True);description=textv(p,'description',300,True)
    amount=posint(p.get('amount'),'المصروف');method=textv(p,'method',12,True)
    if method not in ('cash','bank'):raise ValueError('اختار كاش أو تحويل بنكي')
    bank_ref=textv(p,'bank_ref',90)
    if method=='bank' and not bank_ref:raise ValueError('رقم عملية التحويل مطلوب')
    begin(c)
    try:
        id=c.execute('INSERT INTO expenses(category,description,amount,method,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(category,description,amount,method,bank_ref,now(),uid)).lastrowid
        journal(c,'EXP-'+str(id),[('EXPENSES',amount,0),('CASH' if method=='cash' else 'BANK_PENDING',0,amount)])
        if method=='bank':
            c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('expense',0,'EXP-'+str(id),method,amount,bank_ref,now(),uid))
        audit(c,uid,'expense',{'id':id,'amount':amount,'category':category})
        finish(c)
    except:rollback(c);raise
    return {'id':id,'amount':amount}

def shift_open(c,p,uid):
    opening=amt(p.get('opening_cash',0),'رصيد افتتاح الكاش');begin(c)
    try:
        if one(c,'SELECT id FROM cash_shifts WHERE user_id=? AND closed_at IS NULL',(uid,)):raise ValueError('عندك وردية مفتوحة بالفعل')
        id=c.execute('INSERT INTO cash_shifts(user_id,opened_at,opening_cash) VALUES(?,?,?)',(uid,now(),opening)).lastrowid
        audit(c,uid,'shift_open',{'id':id,'opening_cash':opening});finish(c)
    except:rollback(c);raise
    return {'id':id}

def shift_expected(c,row,closed_at):
    uid=row['user_id'];start=row['opened_at'];end=closed_at
    # Single responsible cashier: count cash movements created by this user inside the shift.
    received=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=? AND method='cash' AND party_kind='customer' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    authority_cash=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=? AND method='cash' AND party_kind='authority' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    supplier_cash=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=? AND method='cash' AND party_kind='supplier' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    refunds=c.execute("SELECT COALESCE(SUM(amount-covered),0) FROM sale_returns WHERE user_id=? AND refund_method='cash' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    expenses=c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND method='cash' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    return row['opening_cash']+received+authority_cash-supplier_cash-refunds-expenses

def shift_close(c,p,uid):
    actual=amt(p.get('actual_cash'),'المبلغ المعدود');notes=textv(p,'notes',300)
    begin(c)
    try:
        row=one(c,'SELECT * FROM cash_shifts WHERE user_id=? AND closed_at IS NULL',(uid,))
        if not row:raise ValueError('لا توجد وردية مفتوحة')
        end=now();expected=shift_expected(c,row,end);diff=actual-expected
        c.execute('UPDATE cash_shifts SET closed_at=?,closing_cash=?,expected_cash=?,variance=?,notes=? WHERE id=?',(end,actual,expected,diff,notes,row['id']))
        audit(c,uid,'shift_close',{'id':row['id'],'expected':expected,'counted':actual,'variance':diff})
        finish(c)
    except:rollback(c);raise
    return {'id':row['id'],'expected_cash':expected,'counted':actual,'variance':diff}

def customer_payment(c,p,uid):
    sid=posint(p.get('sale_id'),'فاتورة العميل');value=posint(p.get('amount'),'السداد');method=textv(p,'method',12)
    if method not in ('cash','bank'):raise ValueError('اختر كاش أو تحويل بنكي')
    ref=textv(p,'bank_ref',90)
    if method=='bank' and not ref:raise ValueError('مرجع التحويل مطلوب')
    begin(c)
    try:
        sale=one(c,'SELECT * FROM sales WHERE id=?',(sid,))
        if not sale or not sale['partner_id']:raise ValueError('الفاتورة غير مرتبطة بحساب عميل')
        previously=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE doc=? AND party_kind='customer'",(sale['ref'],)).fetchone()[0]
        reduced=c.execute("SELECT COALESCE(SUM(amount-covered),0) FROM sale_returns WHERE sale_id=? AND refund_method='credit'",(sid,)).fetchone()[0]
        changes=c.execute('SELECT COALESCE(SUM(delta_covered),0) FROM coverage_adjustments WHERE sale_id=?',(sid,)).fetchone()[0]
        remaining=sale['due']-previously-reduced-changes
        if value>remaining:raise ValueError('السداد أكبر من الرصيد المستحق على العميل')
        journal(c,'CPAY-'+uuid.uuid4().hex[:12],[('CASH' if method=='cash' else 'BANK_PENDING',value,0),('AR_CUSTOMER',0,value)])
        c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('customer',sale['partner_id'],sale['ref'],method,value,ref,now(),uid))
        audit(c,uid,'customer_payment',{'sale':sid,'amount':value})
        finish(c)
    except:rollback(c);raise
    return {'sale_id':sid,'paid':value,'remaining':remaining-value}

def quote_preview(c,p):
    barcode=textv(p,'barcode',80);packageid=p.get('package_id')
    if packageid:pk=one(c,'SELECT * FROM packages WHERE id=?',(posint(packageid,'العبوة'),))
    else:pk=one(c,'SELECT * FROM packages WHERE barcode=?',(barcode,)) if barcode else None
    if not pk:return {'matched':False,'question':'الصنف أو الباركود غير معروف. حدد الصنف والعبوة يدوياً، ولا يتم اعتماد سعر تلقائياً.'}
    factor=posint(p.get('supplier_pack_factor',pk['factor']),'حجم عبوة المورد');cost=amt(p.get('supplier_price'),'السعر')
    supplierid=p.get('supplier_id')
    prev=one(c,'SELECT * FROM price_quotes WHERE supplier_id=? AND package_id=? ORDER BY id DESC LIMIT 1',(supplierid,pk['id'])) if supplierid else None
    normalized=cost*1000//factor
    old=prev['unit_base_milli'] if prev else None
    anomalous=bool(old is not None and old>0 and abs(normalized-old)*100>40*old)
    ambiguity=factor!=pk['factor']
    return {'matched':True,'package_id':pk['id'],'unit_name':pk['unit_name'],'package_factor':pk['factor'],'supplier_factor':factor,'supplier_price':cost,'price_per_base_milli':normalized,'previous_per_base_milli':old,'different':(old is None or normalized!=old),'anomaly':anomalous,'unit_mismatch':ambiguity,'requires_review':anomalous or ambiguity}

def quote_save(c,p,uid):
    supplier=posint(p.get('supplier_id'),'المورد')
    if not one(c,'SELECT id FROM suppliers WHERE id=?',(supplier,)):raise ValueError('المورد غير موجود')
    preview=quote_preview(c,p)
    if not preview['matched']:raise ValueError('يجب مطابقة الصنف والعبوة أولاً')
    if preview['requires_review'] and not p.get('confirmed_review'):raise ValueError('العبوة أو السعر يحتاج تأكيد المراجعة قبل الحفظ')
    begin(c)
    try:
        row=c.execute('INSERT INTO price_quotes(supplier_id,package_id,supplier_pack_factor,supplier_price,unit_base_milli,source_file,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',(supplier,preview['package_id'],preview['supplier_factor'],preview['supplier_price'],preview['price_per_base_milli'],textv(p,'source_file',150),now(),uid))
        audit(c,uid,'supplier_quote',{'id':row.lastrowid,'anomaly':preview['anomaly'],'unit_mismatch':preview['unit_mismatch']})
        finish(c)
    except:rollback(c);raise
    return {'id':row.lastrowid,'preview':preview,'inventory_modified':False,'selling_prices_modified':False}

def coverage_correct(c,p,uid):
    sid=posint(p.get('sale_id'),'الفاتورة');new=amt(p.get('coverage'),'نسبة تغطية الجهة');reason=textv(p,'reason',300,True)
    if new>100:raise ValueError('النسبة من 0 إلى 100 فقط')
    begin(c)
    try:
        sale=one(c,'SELECT * FROM sales WHERE id=?',(sid,))
        if not sale or not sale['authority_id']:raise ValueError('لا توجد جهة مرتبطة بالفاتورة')
        oldcov=sale['covered'];newcov=(sale['total']*new+50)//100
        refunded=c.execute("SELECT COALESCE(SUM(covered),0) FROM sale_returns WHERE sale_id=?",(sid,)).fetchone()[0]
        if refunded:raise ValueError('الفاتورة فيها مرتجع، تحتاج معالجة تسوية مفصلة قبل تغيير التغطية')
        paid=sale['cash_paid']+sale['bank_paid']+c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE doc=? AND party_kind='customer'",(sale['ref'],)).fetchone()[0]-sale['cash_paid']-sale['bank_paid']
        if paid>sale['total']-newcov:raise ValueError('التغطية الجديدة تستوجب رد مبلغ للعميل؛ نفّذ تسوية استرداد معتمدة أولاً')
        delta=newcov-oldcov
        if not delta:finish(c);return {'id':sid,'changed':False}
        old= sale['coverage']
        c.execute('UPDATE sales SET coverage=?,covered=?,due=? WHERE id=?',(new,newcov,sale['total']-newcov,sid))
        a=c.execute('INSERT INTO coverage_adjustments(sale_id,old_coverage,new_coverage,delta_covered,reason,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(sid,old,new,delta,reason,now(),uid)).lastrowid
        if delta>0:journal(c,'COV-'+str(a),[('AR_AUTH',delta,0),('AR_CUSTOMER',0,delta)])
        else:journal(c,'COV-'+str(a),[('AR_CUSTOMER',-delta,0),('AR_AUTH',0,-delta)])
        audit(c,uid,'coverage_correction',{'sale_id':sid,'before':old,'after':new,'delta':delta})
        finish(c)
    except:rollback(c);raise
    return {'id':a,'sale_id':sid,'covered_adjustment':delta,'claim_already_created':bool(one(c,'SELECT 1 AS yes FROM claim_sales WHERE sale_id=?',(sid,))),'requires_claim_settlement':bool(one(c,'SELECT 1 AS yes FROM claim_sales WHERE sale_id=?',(sid,)))}

def bank_verify(c,p,uid):
    payment=posint(p.get('payment_id'),'الدفعة');note=textv(p,'note',300,True)
    begin(c)
    try:
        row=one(c,"SELECT * FROM payments WHERE id=? AND method='bank'",(payment,))
        if not row or not row['bank_ref']:raise ValueError('عملية تحويل غير موجودة أو بلا مرجع')
        id=c.execute('INSERT INTO bank_checks(payment_id,verified_at,verified_by,note) VALUES(?,?,?,?)',(payment,now(),uid,note)).lastrowid
        if row['party_kind'] in ('supplier','expense','refund'):
            journal(c,'BANK-CHECK-'+str(id),[('BANK_PENDING',row['amount'],0),('BANK',0,row['amount'])])
        else:
            journal(c,'BANK-CHECK-'+str(id),[('BANK',row['amount'],0),('BANK_PENDING',0,row['amount'])])
        audit(c,uid,'bank_verified_manually',{'payment_id':payment,'note':note})
        finish(c)
    except:rollback(c);raise
    return {'id':id,'status':'verified_manually_not_via_bank'}
