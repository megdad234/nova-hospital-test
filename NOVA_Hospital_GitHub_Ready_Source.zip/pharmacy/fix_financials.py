from pathlib import Path
p=Path(__file__).parent/'app.py';s=p.read_text()
# Better ordering for shift boundaries and log timestamps
s=s.replace("def now(): return datetime.now().isoformat(timespec='seconds')","def now(): return datetime.now().isoformat(timespec='microseconds')")
# Supplier outstanding subtract supplier credits (purchase returns), using locked transaction balance
s=s.replace("balance=(c.execute('SELECT COALESCE(SUM(total),0) FROM purchases WHERE supplier_id=?',(supplier,)).fetchone()[0]-c.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE party_kind=? AND party_id=?',('supplier',supplier)).fetchone()[0])", "balance=(c.execute('SELECT COALESCE(SUM(total),0) FROM purchases WHERE supplier_id=?',(supplier,)).fetchone()[0]-c.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE party_kind=? AND party_id=?',('supplier',supplier)).fetchone()[0]-c.execute('SELECT COALESCE(SUM(r.amount),0) FROM purchase_returns r JOIN purchase_lines l ON l.id=r.purchase_line_id JOIN purchases p ON p.id=l.purchase_id WHERE p.supplier_id=?',(supplier,)).fetchone()[0])")
start=s.index('def supplier_balances(c):');end=s.index('def report(c):',start)
s=s[:start]+'''def supplier_balances(c):
    return query(c,"""SELECT su.*,
        COALESCE((SELECT SUM(total) FROM purchases pu WHERE pu.supplier_id=su.id),0)
        - COALESCE((SELECT SUM(amount) FROM payments p WHERE p.party_kind='supplier' AND p.party_id=su.id),0)
        - COALESCE((SELECT SUM(pr.amount) FROM purchase_returns pr JOIN purchase_lines pl ON pl.id=pr.purchase_line_id JOIN purchases pu ON pu.id=pl.purchase_id WHERE pu.supplier_id=su.id),0)
        AS balance FROM suppliers su ORDER BY name""")

'''+s[end:]
# Bank claim payment must include transfer reference
needle="""    if method not in ('cash','bank'):raise ValueError('طريقة السداد غير صحيحة')
    begin(c)"""
repl="""    if method not in ('cash','bank'):raise ValueError('طريقة السداد غير صحيحة')
    if method=='bank' and not textv(p,'bank_ref',90):raise ValueError('رقم التحويل مطلوب لتسجيل تحصيل المطالبة')
    begin(c)"""
assert needle in s;s=s.replace(needle,repl)
# remove excessive blocking recurring invoice shared by multiple plans
p2=Path(__file__).parent/'extra_functions.py';other=p2.read_text();old="""        if one(c,'SELECT id FROM recurring_plans WHERE last_sale_id=? AND id<>?',(saleid,planid)):
            raise ValueError('الفاتورة مستخدمة مع خطة أخرى؛ راجع الربط')
"""
assert old in other;other=other.replace(old,'')
# Every bank expense is also in payments to reconcile
old="""        journal(c,'EXP-'+str(id),[('EXPENSES',amount,0),('CASH' if method=='cash' else 'BANK_PENDING',0,amount)])
        audit(c,uid,'expense'"""
new="""        journal(c,'EXP-'+str(id),[('EXPENSES',amount,0),('CASH' if method=='cash' else 'BANK_PENDING',0,amount)])
        if method=='bank':
            c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('expense',0,'EXP-'+str(id),method,amount,bank_ref,now(),uid))
        audit(c,uid,'expense'"""
assert old in other;other=other.replace(old,new)
# actual bank reconciliation posts money from pending to bank account, direction matters
old="""        id=c.execute('INSERT INTO bank_checks(payment_id,verified_at,verified_by,note) VALUES(?,?,?,?)',(payment,now(),uid,note)).lastrowid
        audit(c,uid,'bank_verified_manually'"""
new="""        id=c.execute('INSERT INTO bank_checks(payment_id,verified_at,verified_by,note) VALUES(?,?,?,?)',(payment,now(),uid,note)).lastrowid
        if row['party_kind'] in ('supplier','expense','refund'):
            journal(c,'BANK-CHECK-'+str(id),[('BANK_PENDING',row['amount'],0),('BANK',0,row['amount'])])
        else:
            journal(c,'BANK-CHECK-'+str(id),[('BANK',row['amount'],0),('BANK_PENDING',0,row['amount'])])
        audit(c,uid,'bank_verified_manually'"""
assert old in other;other=other.replace(old,new)
p2.write_text(other)
# add bank refund payment with reference and validate: allow if original amounts were paid at least refund net
needle="""        noncovered=value-covered
        # no automatic cash refund for authority-backed amounts"""
repl="""        noncovered=value-covered
        if refund_method in ('cash','bank') and noncovered:
            all_paid=c.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE party_kind=? AND doc=?',('customer',s['ref'])).fetchone()[0]
            prior_refunds=c.execute("SELECT COALESCE(SUM(amount-covered),0) FROM sale_returns WHERE sale_id=? AND refund_method IN ('cash','bank') AND id<>?",(saleid,rid)).fetchone()[0]
            if prior_refunds+noncovered>all_paid:raise ValueError('الاسترداد النقدي يتجاوز المبالغ المحصلة؛ استخدم تسوية آجل بدلاً منه')
        if refund_method=='bank' and noncovered and not textv(p,'bank_ref',90):raise ValueError('مرجع تحويل المردود مطلوب')
        if refund_method=='bank' and noncovered:
            c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('refund',s['partner_id'] or 0,f'SRET-{rid}','bank',noncovered,textv(p,'bank_ref',90),now(),uid))
        # no automatic cash refund for authority-backed amounts"""
assert needle in s;s=s.replace(needle,repl)
# correct bank verification previous sales returned bank with no ref claim done
p.write_text(s)
