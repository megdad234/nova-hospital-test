from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'app.py'
s=p.read_text(encoding='utf8')
assert "ref=textv(p,'invoice_ref',100,True); dt=textv" in s
s=s.replace("ref=textv(p,'invoice_ref',100,True); dt=textv(p,'invoice_date',20) or today(); date.fromisoformat(dt)","ref=textv(p,'invoice_ref',100) or ('LOCAL-'+datetime.now().strftime('%Y%m%d')+'-'+uuid.uuid4().hex[:12].upper()); dt=textv(p,'invoice_date',20) or today(); date.fromisoformat(dt)")
assert "if received+bonus and not batch:raise ValueError('رقم التشغيلة مطلوب لكل كمية مستلمة')" in s
s=s.replace("        if received+bonus and not batch:raise ValueError('رقم التشغيلة مطلوب لكل كمية مستلمة')\n",'')
assert "old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(pk['product_id'],batch,expiry,'sellable'))" in s
s=s.replace("                old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(pk['product_id'],batch,expiry,'sellable'))", "                # Unknown manufacturer batch must not merge separate physical receipts.\n                # Original batch remains empty in purchase_lines; internal reference is NOT a manufacturer batch.\n                inventory_batch=batch or f'UNRECORDED-PUR-{new}-{lineid}'\n                old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(pk['product_id'],inventory_batch,expiry,'sellable'))")
assert "(pk['product_id'],batch,expiry,'sellable',rec,basecost)" in s
s=s.replace("(pk['product_id'],batch,expiry,'sellable',rec,basecost)","(pk['product_id'],inventory_batch,expiry,'sellable',rec,basecost)")
assert "batch=textv(p,'batch',70,True);expiry=textv(p,'expiry',10,True)" in s
s=s.replace("batch=textv(p,'batch',70,True);expiry=textv(p,'expiry',10,True)","batch=textv(p,'batch',70);expiry=textv(p,'expiry',10,True)",1)
assert "old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(line['product_id'],batch,expiry,'sellable'))" in s
s=s.replace("        old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(line['product_id'],batch,expiry,'sellable'))", "        inventory_batch=batch or ('UNRECORDED-REC-'+uuid.uuid4().hex[:16].upper())\n        old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(line['product_id'],inventory_batch,expiry,'sellable'))",1)
assert "(line['product_id'],batch,expiry,'sellable',base,unit_cost)" in s
s=s.replace("(line['product_id'],batch,expiry,'sellable',base,unit_cost)","(line['product_id'],inventory_batch,expiry,'sellable',base,unit_cost)",1)
p.write_text(s,encoding='utf8')

p=root/'opening_inventory.py'
s=p.read_text(encoding='utf8')
s=s.replace("required=('name','unit_name','factor','quantity','batch','expiry','unit_cost','sale_price')", "required=('name','unit_name','factor','quantity','expiry','unit_cost','sale_price')")
s=s.replace("for field in ('name','unit_name','batch'):", "for field in ('name','unit_name'):")
assert "(pid,row['batch'],row['expiry']))" in s
s=s.replace("            lot=app.one(c,\"SELECT id,qty_base,unit_cost_milli FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status='sellable'\",\n                (pid,row['batch'],row['expiry']))", "            inventory_batch=row['batch'] or f'UNRECORDED-OPEN-{import_id}-ROW-{row[\"source_row\"]}'\n            lot=app.one(c,\"SELECT id,qty_base,unit_cost_milli FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status='sellable'\",\n                (pid,inventory_batch,row['expiry']))")
assert "(pid,row['batch'],row['expiry'],'sellable',row['qty_base'],per_base_milli)" in s
s=s.replace("(pid,row['batch'],row['expiry'],'sellable',row['qty_base'],per_base_milli)","(pid,inventory_batch,row['expiry'],'sellable',row['qty_base'],per_base_milli)")
p.write_text(s,encoding='utf8')

p=root/'static'/'app.js'
s=p.read_text(encoding='utf8')
s=s.replace("${f('رقم فاتورة المورد','buy-ref','text',state.purchaseRef)}", "${f('رقم فاتورة المورد (اختياري؛ ينشئ النظام رقماً داخلياً لو فارغ)','buy-ref','text',state.purchaseRef)}")
s=s.replace("'تشغيلة','الصلاحية','الإجمالي'", "'التشغيلة (اختياري)','الصلاحية (مطلوبة للمستلم)','الإجمالي'")
s=s.replace("<div class=\"panel\"><div class=\"panel-head\"><h2>سطور المشتريات والاستلام</h2><span class=\"tag\">استلم = الكمية المستلمة فعلياً</span></div>", "<div class=\"panel\"><div class=\"panel-head\"><h2>سطور المشتريات والاستلام</h2><span class=\"tag\">استلم = الكمية المستلمة فعلياً</span></div><div class=\"help\">رقم التشغيلة اختياري؛ عند تركه فارغاً ينشئ النظام مرجع تتبع داخلي منفصل لكل استلام، ولا يعتبره رقم المصنع. الصلاحية مطلوبة للأدوية المستلمة حتى لا تُباع أدوية مجهولة الصلاحية.</div>")
s=s.replace("<h3>تحديد أعمدة المورد</h3>", "<h3>تحديد أعمدة المورد</h3>")
s=s.replace("if(!pkg||!Number.isInteger(qty)||qty<=0||!Number.isInteger(price)||price<0||!batch||!expiry)throw Error('راجع بيانات السطر '+(i+1)+'؛ يلزم الصنف والكمية والسعر والتشغيلة والصلاحية');", "if(!pkg||!Number.isInteger(qty)||qty<=0||!Number.isInteger(price)||price<0||!expiry)throw Error('راجع بيانات السطر '+(i+1)+'؛ يلزم الصنف والكمية والسعر والصلاحية فقط؛ التشغيلة اختيارية');")
s=s.replace("${f('رقم التشغيلة','pr-batch','text',x.batch)}", "${f('رقم التشغيلة (اختياري)','pr-batch','text',x.batch)}")
s=s.replace("<td>${esc(l.batch)}</td>","<td>${esc(String(l.batch).startsWith('UNRECORDED-')?'غير مدخل (تتبع داخلي: '+l.batch+')':l.batch)}</td>")
p.write_text(s,encoding='utf8')

p=root/'static'/'opening_inventory.js'
s=p.read_text(encoding='utf8')
s=s.replace('كل سطر يمثل كمية عبوة من تشغيلة محددة، مع تاريخ الصلاحية والباركود وسعر الشراء والبيع.', 'كل سطر يمثل كمية عبوة مع الصلاحية وسعر الشراء والبيع. رقم التشغيلة اختياري؛ إن لم يتوفر ينشئ النظام مرجع تتبع داخلي خاص بالسطر. لا تضع رقم تشغيلة غير حقيقي.')
s=s.replace("const sample=['SKU001','Paracetamol 500mg','6220000000000','شريط','10','حبة','3','LOT-001','2028-12-31'", "const sample=['SKU001','Paracetamol 500mg','6220000000000','شريط','10','حبة','3','','2028-12-31'")
p.write_text(s,encoding='utf8')

print('Applied optional-field patch to app, opening stock and web UI')
