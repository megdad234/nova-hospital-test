from pathlib import Path
p=Path(__file__).parent/'app.py'
s=p.read_text()
s=s.replace("CREATE TABLE IF NOT EXISTS bank_checks(id INTEGER PRIMARY KEY,payment_id INTEGER NOT NULL UNIQUE REFERENCES payments(id),verified_at TEXT NOT NULL,verified_by INTEGER REFERENCES users(id),note TEXT NOT NULL);", "CREATE TABLE IF NOT EXISTS bank_checks(id INTEGER PRIMARY KEY,payment_id INTEGER NOT NULL UNIQUE REFERENCES payments(id),verified_at TEXT NOT NULL,verified_by INTEGER REFERENCES users(id),note TEXT NOT NULL);\nCREATE TABLE IF NOT EXISTS claim_adjustments(id INTEGER PRIMARY KEY,claim_id INTEGER NOT NULL REFERENCES claims(id),coverage_adjustment_id INTEGER NOT NULL UNIQUE REFERENCES coverage_adjustments(id),amount INTEGER NOT NULL);")
needle="""        c.execute('UPDATE claims SET total=? WHERE id=?',(total,doc))
        audit(c,uid,'create_claim',{'id':doc,'period':period,'total':total})"""
replace="""        # Corrections of already claimed invoices are carried into a *new* claim,
        # without mutating the original claim or duplicating the original sale.
        adjustments=query(c,'''SELECT ca.id,ca.delta_covered FROM coverage_adjustments ca
            JOIN claim_sales cs ON cs.sale_id=ca.sale_id
            JOIN claims previous ON previous.id=cs.claim_id
            WHERE previous.authority_id=? AND previous.period<? AND ca.created_at<=? AND NOT EXISTS
            (SELECT 1 FROM claim_adjustments q WHERE q.coverage_adjustment_id=ca.id)''',
            (authority,period,period+'-31T23:59:59'))
        if total+sum(a['delta_covered'] for a in adjustments)<0:
            raise ValueError('تسويات التخفيض أكبر من المطالبة الجديدة: يتطلب إشعار دائن مستقل قبل اعتماد الكشف')
        for a in adjustments:
            c.execute('INSERT INTO claim_adjustments(claim_id,coverage_adjustment_id,amount) VALUES(?,?,?)',(doc,a['id'],a['delta_covered']))
            total+=a['delta_covered']
        c.execute('UPDATE claims SET total=? WHERE id=?',(total,doc))
        audit(c,uid,'create_claim',{'id':doc,'period':period,'total':total,'correction_count':len(adjustments)})"""
assert needle in s;s=s.replace(needle,replace)
s=s.replace("return {'id':doc,'total':total,'invoice_count':len(invoices)}", "return {'id':doc,'total':total,'invoice_count':len(invoices),'prior_claim_corrections':len(adjustments)}")
p.write_text(s)
