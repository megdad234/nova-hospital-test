"""Offline backup validation and guarded restore, no network or Python install required in Windows bundle."""
from __future__ import annotations
import hashlib,os,sqlite3,tempfile
from contextlib import closing
from pathlib import Path
from datetime import datetime

REQUIRED={'users','products','packages','lots','stock_moves','sales','sale_lines','purchases','purchase_lines','journals','settings'}

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
    return h.hexdigest()

def validate_backup(path,max_schema=None):
    if max_schema is None:
        from schema_guard import SCHEMA_VERSION
        max_schema=SCHEMA_VERSION
    path=Path(path)
    if not path.is_file() or path.stat().st_size<4096:raise ValueError('ملف النسخة الاحتياطية غير موجود أو غير صالح')
    check=path.with_name(path.name+'.sha256')
    if check.exists() and check.read_text(encoding='ascii').strip().split()[0].lower()!=sha256(path):
        raise ValueError('بصمة الملف لا تطابق النسخة الأصلية؛ لا تستعد ملفاً معطوباً')
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('فحص سلامة SQLite فشل')
        tables={x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not REQUIRED.issubset(tables):raise ValueError('هذا الملف ليس قاعدة بيانات صيدلية معروفة')
        current=c.execute('PRAGMA user_version').fetchone()[0]
        if current>max_schema:raise ValueError('قاعدة البيانات أحدث من نسخة البرنامج؛ لا يمكن استعادتها')
    return {'size':path.stat().st_size,'schema':current,'sha256':sha256(path)}

def copy_verified(source,target):
    """SQLite Online Backup API: safe on active WAL source; atomic destination replacement."""
    source=Path(source); target=Path(target)
    target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent,prefix='.pharmacy-',suffix='.sqlite3',delete=False) as tmp:
        staging=Path(tmp.name)
    try:
        with closing(sqlite3.connect(source)) as s,closing(sqlite3.connect(staging)) as d:
            s.backup(d)
            if d.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('فشل التحقق من النسخة الجديدة')
        validate_backup(staging)
        os.replace(staging,target)
        digest=sha256(target)
        check=target.with_name(target.name+'.sha256')
        with open(check,'w',encoding='ascii') as f:
            f.write(digest+'  '+target.name+'\n')
            f.flush();os.fsync(f.fileno())
        return {'file':str(target),'size':target.stat().st_size,'sha256':digest,'verified':True}
    finally:
        staging.unlink(missing_ok=True)

def is_desktop_running():
    if os.name!='nt':return False
    import ctypes
    SYNCHRONIZE=0x00100000
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenMutexW.argtypes=(ctypes.c_ulong,ctypes.c_bool,ctypes.c_wchar_p)
    kernel.OpenMutexW.restype=ctypes.c_void_p
    kernel.CloseHandle.argtypes=(ctypes.c_void_p,)
    h=kernel.OpenMutexW(SYNCHRONIZE,False,'Local\\HospitalPharmacyERP-Desktop')
    if h:
        kernel.CloseHandle(h)
        return True
    return False

def restore_backup(backup_file,database_file):
    """Only when the desktop is not running; preserves pre-restore copy and refuses invalid backup."""
    if is_desktop_running():raise RuntimeError('اقفل برنامج الصيدلية بالكامل قبل الاستعادة')
    source=Path(backup_file).resolve(); target=Path(database_file).resolve()
    if source==target:raise ValueError('ملف الاستعادة لا يمكن أن يكون نفس قاعدة البيانات الحالية')
    validate_backup(source)
    target.parent.mkdir(parents=True,exist_ok=True)
    old_copy=None
    if target.exists():
        # The SQLite backup API protects WAL data that might still be in the source database.
        old_copy=target.parent/'pre-restore-backups'/('before-restore-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.sqlite3')
        copy_verified(target,old_copy)
    with tempfile.NamedTemporaryFile(dir=target.parent,prefix='.restore-',suffix='.sqlite3',delete=False) as f:
        tmp=Path(f.name)
    try:
        copy_verified(source,tmp)
        # Remove stale WAL/SHM after making an audited pre-restore snapshot.
        for suffix in ('-wal','-shm'):
            p=Path(str(target)+suffix)
            if p.exists():p.unlink()
        os.replace(tmp,target)
        new_check=target.with_name(target.name+'.sha256')
        os.replace(Path(str(tmp)+'.sha256'),new_check)
        # No need to write to DB here; normal schema migration happens at next launch.
        validate_backup(target)
        return {'database':str(target),'previous_backup':str(old_copy) if old_copy else None,'verified':True}
    finally:
        tmp.unlink(missing_ok=True)
        Path(str(tmp)+'.sha256').unlink(missing_ok=True)

def gui_main():
    import tkinter as tk
    from tkinter import filedialog,messagebox
    root=tk.Tk();root.withdraw()
    if is_desktop_running():
        messagebox.showerror('استعادة الصيدلية','أغلق برنامج الصيدلية أولاً ثم أعد المحاولة')
        return
    path=filedialog.askopenfilename(title='اختيار ملف نسخة الصيدلية',filetypes=[('SQLite backup','*.sqlite3')])
    if not path:return
    target=Path(os.environ.get('LOCALAPPDATA') or (Path.home()/'AppData'/'Local'))/'HospitalPharmacyERP'/'data'/'pharmacy.sqlite3'
    try:
        info=validate_backup(path)
        if not messagebox.askyesno('تأكيد الاستعادة',f'ستستبدل قاعدة البيانات الحالية بنسخة حجمها {info["size"]:,} بايت.\nسوف تُحفظ نسخة من البيانات الحالية أولاً. هل أنت متأكد؟'):
            return
        result=restore_backup(path,target)
        messagebox.showinfo('تمت الاستعادة','تم التحقق والاستعادة بنجاح. يمكنك فتح برنامج الصيدلية الآن.\nالنسخة السابقة: '+str(result['previous_backup'] or 'لم توجد بيانات قديمة'))
    except Exception as e:
        messagebox.showerror('تعذر الاستعادة',str(e))

if __name__=='__main__':gui_main()
