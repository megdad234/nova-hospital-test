"""Future dedicated hospital server launcher. TLS certificate required when binding to a LAN address.
Does NOT claim this SQLite pilot is approved for production multi-workstation deployments.
"""
from __future__ import annotations
import os,ssl,sys
from pathlib import Path
import app

def main():
    host=os.getenv('PHARMACY_BIND','127.0.0.1')
    port=int(os.getenv('PHARMACY_PORT','8443'))
    local=Path(os.getenv('PROGRAMDATA') or (Path.home()/'.hospital-pharmacy'))/'HospitalPharmacyServer'
    local.mkdir(parents=True,exist_ok=True)
    app.ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
    app.DATA=local/'data';app.DB=app.DATA/'pharmacy.sqlite3'
    cert,key=os.getenv('PHARMACY_TLS_CERT'),os.getenv('PHARMACY_TLS_KEY')
    if host not in ('127.0.0.1','localhost','::1') and not (cert and key):
        raise SystemExit('LAN requires a local trusted TLS certificate and key (PHARMACY_TLS_CERT/KEY)')
    app.init_db(preload_catalog=True);app.start_automatic_backups()
    server=app.ThreadServer((host,port),app.Handler)
    if cert and key:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version=ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(cert,key)
        server.socket=ctx.wrap_socket(server.socket,server_side=True)
    print('Hospital Pharmacy server listening on',host,port,flush=True)
    try:server.serve_forever()
    finally:server.server_close()

if __name__=='__main__':main()
