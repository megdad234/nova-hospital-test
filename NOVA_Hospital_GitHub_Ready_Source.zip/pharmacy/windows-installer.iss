#define MyAppName "MADAR - مدار - الصيدلية"
#define MyAppVersion "1.4.0"
#define MyAppExeName "HospitalPharmacyERP.exe"
[Setup]
AppId={{9D2B425C-3AE9-4FCF-B654-A85942C52A11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=MADAR Hospital Systems
DefaultDirName={autopf}\HospitalPharmacyERP
DefaultGroupName=MADAR
PrivilegesRequired=admin
OutputDir=Output
OutputBaseFilename=MADAR-Pharmacy-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=assets\app.ico
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}
[Files]
Source: "dist\HospitalPharmacyERP\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "dist\RestorePharmacyBackup.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "redist\MicrosoftEdgeWebView2RuntimeInstallerX64.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall
[Icons]
Name: "{autoprograms}\MADAR\MADAR Pharmacy"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\MADAR Pharmacy"; Filename: "{app}\{#MyAppExeName}"
Name: "{autoprograms}\مدار - استعادة البيانات"; Filename: "{app}\RestorePharmacyBackup.exe"
[InstallDelete]
Type: files; Name: "{autoprograms}\نواة - استعادة البيانات.lnk"
Type: files; Name: "{autodesktop}\PharmaPlus - فارما بلس.lnk"
Type: files; Name: "{autoprograms}\PharmaPlus - فارما بلس.lnk"
Type: files; Name: "{autoprograms}\PharmaPlus - استعادة البيانات.lnk"
[Run]
Filename: "{tmp}\MicrosoftEdgeWebView2RuntimeInstallerX64.exe"; Parameters: "/silent /install"; Flags: runhidden waituntilterminated; Check: NeedWebView2
Filename: "{app}\{#MyAppExeName}"; Description: "تشغيل مدار — وحدة الصيدلية"; Flags: nowait postinstall skipifsilent
[Code]
function NeedWebView2(): Boolean;
var V: String;
begin
  Result := not (
    RegQueryStringValue(HKLM32, 'Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}', 'pv', V) or
    RegQueryStringValue(HKCU, 'Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}', 'pv', V)
  );
end;
