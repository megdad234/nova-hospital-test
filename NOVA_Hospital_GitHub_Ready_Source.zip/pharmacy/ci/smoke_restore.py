"""Frozen restore-tool smoke hook."""
import os,sys,json,traceback,tempfile
from pathlib import Path
report_path=os.environ.get('PHARMACY_CI_RESTORE_SMOKE_FILE')
if report_path:
    report={'ok':False}
    try:
        import app,recovery
        from contextlib import closing
        with tempfile.TemporaryDirectory(prefix='pharmacy_restore_check_') as td:
            app.DATA=Path(td);app.DB=app.DATA/'pharmacy.sqlite3';app.init_db()
            with closing(app.db_connect()) as c:
                c.execute("INSERT INTO settings(key,value) VALUES('before','true')")
            original=Path(td)/'mybackup.sqlite3'
            recovery.copy_verified(app.DB,original)
            with closing(app.db_connect()) as c:
                c.execute("INSERT INTO settings(key,value) VALUES('after','should_disappear')")
            rec=recovery.restore_backup(original,app.DB)
            with closing(app.db_connect()) as c:
                assert c.execute("SELECT value FROM settings WHERE key='before'").fetchone()[0]=='true'
                assert not c.execute("SELECT value FROM settings WHERE key='after'").fetchone()
            assert Path(rec['previous_backup']).exists()
        report['ok']=True
    except Exception:report['error']=traceback.format_exc()
    Path(report_path).write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    sys.exit(0 if report['ok'] else 60)
