"""Frozen Windows desktop smoke hook: executes only when CI environment flag is present."""
import json,os,sys,tempfile,threading,traceback
from pathlib import Path
from contextlib import closing
from urllib.request import urlopen
report_path=os.environ.get('PHARMACY_CI_SMOKE_FILE')
if report_path:
    checks=[]; report={'ok':False,'checks':checks}
    try:
        import app,webview,opening_inventory,catalog_import,recovery,device_services
        checks.append('All critical backend and native modules imported')
        assert isinstance(device_services.NativeAPI().get_devices(),dict)
        root=Path(getattr(sys,'_MEIPASS',Path(app.__file__).resolve().parent))
        for f in ('index.html','app.js','style.css','v06_extensions.js','opening_inventory.js','workstation_upgrade.js','logo.png'):
            assert (root/'static'/f).is_file(),f'Missing bundled static/{f}'
        checks.append('All embedded user-interface assets bundled')
        with tempfile.TemporaryDirectory(prefix='pharmacy_frozen_check_') as td:
            app.ROOT=root;app.DATA=Path(td)/'data';app.DB=app.DATA/'pharmacy.sqlite3';app.init_db()
            with closing(app.db_connect()) as c:
                assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
                assert c.execute('PRAGMA user_version').fetchone()[0]==9
                app.bootstrap(c,{'username':'owner','full_name':'Owner','password':'NotARealSecret123!456'})
                from datetime import date,timedelta
                exp=(date.today()+timedelta(days=500)).isoformat()
                cols=['sku','name','barcode','unit_name','factor','base_uom','quantity','batch','expiry','unit_cost','sale_price']
                row=['H001','Smoke medicine','SMOKE123456','شريط','10','حبة','2','L1',exp,'2000','3000']
                opening_inventory.import_stock(c,[cols,row],1,'WINDOWSSMOKETEST12345')
                pack=app.one(c,'SELECT id FROM packages LIMIT 1')['id']
                assert app.catalog(c)[0]['available']==20
                app.sell(c,{'idempotency':'WINDOWSSMOKESALE12345','items':[{'package_id':pack,'qty':1}],'payments':[{'method':'cash','amount':3000}]},1)
                assert app.catalog(c)[0]['available']==10
                assert app.integrity_review(c)['passed']
            checks.append('SQLite init, opening stock, sale, accounting and integrity')
            saved=recovery.copy_verified(app.DB,Path(td)/'snapshot.sqlite3')
            assert recovery.validate_backup(saved['file'])['sha256']==saved['sha256']
            checks.append('Online backup with checksum integrity')
            server=app.ThreadServer(('127.0.0.1',0),app.Handler)
            worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
            try:
                base='http://127.0.0.1:'+str(server.server_address[1])
                for resource in ('/','/static/app.js','/static/style.css','/static/v06_extensions.js','/static/opening_inventory.js','/static/workstation_upgrade.js','/static/ux_v14.js','/static/logo.png','/api/v1/status'):
                    with urlopen(base+resource,timeout=10) as response:
                        assert response.status==200 and len(response.read())>10,resource
                checks.append('Embedded local HTTP endpoints and UI assets')
            finally:
                server.shutdown();server.server_close();worker.join(timeout=15)
                assert not worker.is_alive()
        # Separate first-install simulation: preload drug names without creating actual stock.
        with tempfile.TemporaryDirectory(prefix='madar_catalog_boot_') as td:
            app.DATA=Path(td);app.DB=app.DATA/'catalog.sqlite3'
            app.init_db(preload_catalog=True)
            with closing(app.db_connect()) as c:
                assert c.execute('SELECT COUNT(*) FROM products').fetchone()[0]>=1800
                assert c.execute('SELECT COUNT(*) FROM lots').fetchone()[0]==0
                assert c.execute('SELECT COUNT(*) FROM stock_moves').fetchone()[0]==0
                assert c.execute('SELECT COALESCE(SUM(sale_price),0) FROM packages').fetchone()[0]==0
            app.init_db(preload_catalog=True)
            with closing(app.db_connect()) as c:
                assert c.execute('SELECT COUNT(*) FROM prefilled_catalog_versions').fetchone()[0]==1
            checks.append('MADAR bundled medicine dictionary: automatic, zero-stock, idempotent')
        report['ok']=True
    except Exception:
        report['error']=traceback.format_exc()
    Path(report_path).write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    sys.exit(0 if report['ok'] else 59)
