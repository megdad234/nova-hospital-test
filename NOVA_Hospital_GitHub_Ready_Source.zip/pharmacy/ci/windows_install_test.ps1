$ErrorActionPreference = 'Stop'
$setup = Join-Path (Get-Location) 'Output\MADAR-Pharmacy-Setup.exe'
if (!(Test-Path $setup)) { throw 'Setup.exe missing after Inno Setup build' }
$dest = Join-Path $env:RUNNER_TEMP 'HospitalPharmacyERP-Installed-Test'
$log = Join-Path $env:RUNNER_TEMP 'pharmacy-install-log.txt'
$p = Start-Process -FilePath $setup -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART',"/DIR=$dest","/LOG=$log") -Wait -PassThru
if ($p.ExitCode -ne 0) {
  if (Test-Path $log) { Get-Content $log -Tail 75 | Write-Host }
  throw "Silent installation failed with exit code $($p.ExitCode)"
}
if (!(Test-Path (Join-Path $dest 'HospitalPharmacyERP.exe')) -or !(Test-Path (Join-Path $dest 'RestorePharmacyBackup.exe'))) { throw 'Installed desktop or restore EXE missing' }
function RunSmoke($exe,$envvar,$reportname) {
  $path = Join-Path $env:RUNNER_TEMP $reportname
  [Environment]::SetEnvironmentVariable($envvar, $path, 'Process')
  try {
    $process = Start-Process -FilePath $exe -PassThru
    try { Wait-Process -Id $process.Id -Timeout 110 -ErrorAction Stop }
    catch { Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue; throw "Installed EXE hung: $exe" }
    $process.Refresh()
    if (Test-Path $path) { Get-Content $path | Write-Host }
    if ($process.ExitCode -ne 0 -or !(Test-Path $path)) { throw "Installed EXE failed: $exe, exit $($process.ExitCode)" }
    $report = Get-Content $path -Raw | ConvertFrom-Json
    if (-not $report.ok) { throw "Installed EXE self-test failed: $exe" }
  } finally { [Environment]::SetEnvironmentVariable($envvar, $null, 'Process') }
}
RunSmoke (Join-Path $dest 'HospitalPharmacyERP.exe') 'PHARMACY_CI_SMOKE_FILE' 'pharmacy-installed-desktop.json'
RunSmoke (Join-Path $dest 'RestorePharmacyBackup.exe') 'PHARMACY_CI_RESTORE_SMOKE_FILE' 'pharmacy-installed-restore.json'
(Get-FileHash -Algorithm SHA256 $setup) | Format-List | Out-String | Write-Host
