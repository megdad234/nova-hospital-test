$ErrorActionPreference = 'Stop'
$desktop = Join-Path (Get-Location) 'dist\HospitalPharmacyERP\HospitalPharmacyERP.exe'
$restore = Join-Path (Get-Location) 'dist\RestorePharmacyBackup.exe'
if (!(Test-Path $desktop) -or !(Test-Path $restore)) { throw 'Missing compiled Windows desktop or restore executable' }
function RunSmoke($exe,$envvar,$reportname) {
  $path = Join-Path $env:RUNNER_TEMP $reportname
  [Environment]::SetEnvironmentVariable($envvar, $path, 'Process')
  try {
    $process = Start-Process -FilePath $exe -PassThru
    try { Wait-Process -Id $process.Id -Timeout 110 -ErrorAction Stop }
    catch { Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue; throw "Frozen executable did not exit within smoke-test timeout: $exe" }
    $process.Refresh()
    if (Test-Path $path) { Get-Content $path | Write-Host }
    if ($process.ExitCode -ne 0 -or !(Test-Path $path)) { throw "Smoke failed for $exe with exit code $($process.ExitCode)" }
    $result = Get-Content $path -Raw | ConvertFrom-Json
    if (-not $result.ok) { throw "Frozen self-test reported an error: $exe" }
  }
  finally { [Environment]::SetEnvironmentVariable($envvar, $null, 'Process') }
}
RunSmoke $desktop 'PHARMACY_CI_SMOKE_FILE' 'pharmacy-frozen-desktop.json'
RunSmoke $restore 'PHARMACY_CI_RESTORE_SMOKE_FILE' 'pharmacy-frozen-restore.json'
