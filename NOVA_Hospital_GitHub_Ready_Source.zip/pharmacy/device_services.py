"""Native device helpers: Windows spooler enumeration + persistent workstation preferences.
Hardware setup remains the responsibility of Windows and the particular device driver.
"""
from __future__ import annotations
import json, os
from pathlib import Path

SUPPORTED_RECEIPTS = ('thermal80','thermal58','a4')

def settings_path():
    return Path(os.environ.get('LOCALAPPDATA') or (Path.home()/'AppData'/'Local'))/'HospitalPharmacyERP'/'workstation.json'

def load_settings():
    try:
        d=json.loads(settings_path().read_text(encoding='utf-8'))
        return {'paper':d.get('paper') if d.get('paper') in SUPPORTED_RECEIPTS else 'thermal80',
                'printer':str(d.get('printer',''))[:200]}
    except (OSError, ValueError, TypeError):
        return {'paper':'thermal80','printer':''}

def printer_names():
    if os.name!='nt': return {'available': [], 'default': '', 'notice':'Printer enumeration requires Windows.'}
    try:
        import win32print
        flags=win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
        devices=sorted({r[2] for r in win32print.EnumPrinters(flags) if len(r)>2})
        try: default=win32print.GetDefaultPrinter()
        except Exception: default=''
        return {'available':devices,'default':default,'notice':'Install the correct driver in Windows. The print dialog controls the destination printer.'}
    except Exception as exc:
        return {'available':[], 'default':'', 'notice':'Windows printer enumeration unavailable: '+str(exc)[:160]}

def save_settings(paper,printer=''):
    if paper not in SUPPORTED_RECEIPTS: raise ValueError('Invalid print paper choice')
    installed=printer_names()['available']
    if printer and installed and printer not in installed:
        raise ValueError('Printer was not found in Windows')
    data={'paper':paper,'printer':str(printer)[:200]}
    p=settings_path();p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix('.new');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,p)
    return data

class NativeAPI:
    def get_devices(self):
        return {**printer_names(),'settings':load_settings()}
    def set_printer_settings(self,paper,printer=''):
        return save_settings(paper,printer)
