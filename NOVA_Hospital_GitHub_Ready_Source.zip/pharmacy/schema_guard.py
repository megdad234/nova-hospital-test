"""Offline schema upgrades: version checks, atomic DDL, pre-upgrade backup."""
from __future__ import annotations
from contextlib import closing
import sqlite3
import time
from pathlib import Path
SCHEMA_VERSION=9
LEGACY_IDENTITY_TABLES={'users','products','packages','lots','purchases','sales','journals','stock_moves'}

def statements(script):
    chunk=''
    for line in script.splitlines(keepends=True):
        chunk+=line
        if sqlite3.complete_statement(chunk):
            if chunk.strip():yield chunk
            chunk=''
    if chunk.strip():raise ValueError('Incomplete database schema statement')

def run_schema(c,*scripts):
    for script in scripts:
        for stmt in statements(script):c.execute(stmt)

def prepare_upgrade(c,db_path:Path,target=SCHEMA_VERSION):
    current=int(c.execute('PRAGMA user_version').fetchone()[0])
    if current>target:raise RuntimeError(f'Database version {current} is newer than application version {target}; downgrade blocked.')
    if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Database integrity check failed; upgrade blocked.')
    tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
    if current==0 and tables and not LEGACY_IDENTITY_TABLES.issubset(tables):
        raise RuntimeError('Existing file is not a recognized pharmacy database; upgrade blocked.')
    if current==target:return {'upgrade':False,'backup':None}
    backup=None
    if tables:
        folder=db_path.parent/'preupgrade-backups';folder.mkdir(parents=True,exist_ok=True)
        dest=folder/f'preupgrade-v{current}-to-v{target}-{time.time_ns()}.sqlite3'
        try:
            with closing(sqlite3.connect(dest)) as snapshot:
                c.backup(snapshot)
                if snapshot.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise RuntimeError('Pre-upgrade backup integrity check failed.')
            backup=str(dest)
        except BaseException:
            dest.unlink(missing_ok=True)
            raise
    return {'upgrade':True,'backup':backup}

def finish_upgrade(c,target=SCHEMA_VERSION):
    if not c.in_transaction:raise RuntimeError('Schema version update requires active transaction')
    c.execute(f'PRAGMA user_version={int(target)}')
