'use strict';
// MADAR finance desk: separate daily sales, receipts, insurer share, and accounting balances.
// Never label posted bank payments as a verified Bankak account balance.
let madarDailyReceipts=[];
let madarLastSaleId=null;
function dailyFinance(){
 return `<div class="panel madar-day-panel" id="madar-day-panel">
   <div class="panel-head"><h2>تحصيلات اليوم — وحدة الصيدلية</h2><div class="actions"><button class="btn outline" onclick="nav('cashdesk')">الورديات</button><button class="btn outline" onclick="nav('reports')">الحسابات التفصيلية</button></div></div>
   <div class="madar-daily-toolbar"><label class="field">اختر التاريخ <input type="date" id="madar-day" value="${today()}"></label>
     <button class="btn" onclick="loadDailyFinance()">عرض اليوم</button>
     <button class="btn outline" onclick="printDailyFinance()">طباعة ملخص اليوم</button>
     <button class="btn outline" onclick="exportDailyFinance()">تنزيل CSV</button></div>
   <p class="muted-note">ملخص التسجيل الفعلي. مبالغ تحويلات بنكك لا تصبح رصيداً مؤكداً إلا بعد المطابقة بكشف البنك.</p>
   <div id="madar-daily-summary" class="section"><p class="help">جاري تحميل حركات اليوم...</p></div>
   <div class="panel-head section"><h3>فواتير اليوم — عرض وإعادة طباعة</h3><span class="tag">صلاحية المالية للعرض والطباعة فقط</span></div>
   <div id="madar-daily-invoices"><p class="empty">لا توجد فواتير محمّلة</p></div>
 </div>`;
}
async function loadDailyFinance(){
 const container=$('madar-daily-summary');if(!container)return;
 const day=v('madar-day')||today();if(!/^\d{4}-\d{2}-\d{2}$/.test(day))return toast('التاريخ غير صحيح',true);
 container.innerHTML='<p class="help">جارٍ تحديث التحصيلات...</p>';
 try{
  const [r,invoices]=await Promise.all([api('daily-cashdesk?day='+encodeURIComponent(day)),api('finance-receipts?day='+encodeURIComponent(day))]);
  state.madarDailySummary=r;madarDailyReceipts=invoices;
  const s=r.sales, number=x=>Number(x)||0;
  const payment=(kind,method)=>r.payments.filter(x=>x.party_kind===kind&&x.method===method).reduce((a,x)=>a+number(x.amount),0);
  const expense=method=>r.expenses.filter(x=>x.method===method).reduce((a,x)=>a+number(x.amount),0);
  const refunds=method=>r.refunds.filter(x=>x.refund_method===method).reduce((a,x)=>a+number(x.gross)-number(x.covered),0);
  const otherCash=payment('authority','cash')+Math.max(0,payment('customer','cash')-number(s.pos_cash));
  const otherBank=payment('authority','bank')+Math.max(0,payment('customer','bank')-number(s.pos_bank));
  const kpis=[
   ['عدد فواتير البيع',Number(s.invoice_count)||0,'فاتورة'],
   ['إجمالي مبيعات اليوم',fmt(s.gross),'قبل المرتجعات'],
   ['كاش من فواتير اليوم',fmt(s.pos_cash),'مبيعات اليوم فقط'],
   ['تحويلات من فواتير اليوم',fmt(s.pos_bank),'مسجلة وتحتاج مطابقة'],
   ['حصة التأمين اليوم',fmt(s.covered),'ذمم على الجهات'],
   ['آجل العملاء اليوم',fmt(s.credit),'لم يُحصّل من الفواتير'],
  ];
  const card=k=>`<div class="card"><small>${k[0]}</small><strong>${k[1]}</strong><span class="muted">${k[2]}</span></div>`;
  container.innerHTML=`<div class="cards madar-daily-kpis">${kpis.map(card).join('')}</div>
   <div class="grid2 section"><div class="panel"><h3>تحصيلات أخرى وحركات اليوم</h3>
    ${table(['البند','المبلغ'],[
      ['تحصيلات كاش أخرى/جهات',otherCash],['تحويلات أخرى/جهات',otherBank],
      ['مردود كاش',refunds('cash')],['مردود بنكك',refunds('bank')],
      ['مصروفات كاش',expense('cash')],['مصروفات بنكية',expense('bank')],
      ['سداد مورد كاش',payment('supplier','cash')],['سداد مورد بنك',payment('supplier','bank')]
    ].map(x=>`<tr><td>${x[0]}</td><td><b>${fmt(x[1])}</b></td></tr>`))}
    <div class="help">المصروفات والمردود وسداد المورد تُعرض منفصلة، ولا يتم خصمها من مبيعات اليوم لخلط الإيراد بحركة النقد.</div>
    </div><div class="panel"><h3>تحويلات بنكك المسجلة اليوم</h3>
     ${table(['المرجع','القيمة','المطابقة'],r.bank_incoming.map(x=>`<tr><td>${esc(x.bank_ref||x.doc)}</td><td>${fmt(x.amount)}</td><td>${x.verified?'تم التحقق يدوياً':'بانتظار مطابقة'}</td></tr>`))}
     <div class="help">${esc(r.note)}</div>
    </div></div>`;
  $('madar-daily-invoices').innerHTML=table(['رقم الفاتورة','الوقت','الموظف','الإجمالي','التأمين','الكاش','تحويل','إجراء'],invoices.map(x=>`<tr><td>${esc(x.ref)}</td><td>${esc(x.created_at.slice(11,16))}</td><td>${esc(x.employee||'—')}</td><td>${fmt(x.total)}</td><td>${fmt(x.covered)}</td><td>${fmt(x.cash_paid)}</td><td>${fmt(x.bank_paid)}</td><td><button class="btn outline small" onclick="showFinanceReceipt(${x.id})">عرض / طباعة</button></td></tr>`));
 }catch(e){container.innerHTML=`<div class="warnbox">تعذر تحميل البيانات: ${esc(e.message)}</div>`;toast(e.message,true)}
}
function showFinanceReceipt(id){
 const invoice=madarDailyReceipts.find(x=>x.id===id);if(!invoice)return toast('لم يتم العثور على الفاتورة',true);
 madarLastSaleId=id;
 modal('طباعة فاتورة '+invoice.ref,receipt(invoice)+`<div class="actions section"><button class="btn" onclick="printReceipt()">طباعة على الطابعة المحددة في Windows</button><button class="btn outline" onclick="closeModal()">رجوع</button></div>`);
}
function printDailyFinance(){
 if(!state.madarDailySummary){toast('اعرض التقرير أولاً',true);return}
 document.body.classList.add('printing-daily');
 window.addEventListener('afterprint',()=>document.body.classList.remove('printing-daily'),{once:true});
 window.print();setTimeout(()=>document.body.classList.remove('printing-daily'),120000);
}
function exportDailyFinance(){
 const r=state.madarDailySummary;if(!r)return toast('اعرض التقرير أولاً',true);
 const data=[['التاريخ',r.day],['عدد الفواتير',r.sales.invoice_count],['إجمالي البيع',r.sales.gross],['كاش الفواتير',r.sales.pos_cash],['تحويل الفواتير',r.sales.pos_bank],['حصة التأمين',r.sales.covered],['آجل',r.sales.credit]];
 const csv='\ufeff'+data.map(x=>x.map(y=>'"'+String(y??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='MADAR-Daily-'+r.day+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
// The cashier's keyboard first: selection and printing without scrolling to toolbars.
document.addEventListener('keydown',e=>{
 if(e.key==='Escape'&&$('modal')&&!$('modal').hidden){e.preventDefault();closeModal();return}
 if(e.key==='F5'&&$('modal')&&!$('modal').hidden&&$('printable')){e.preventDefault();printReceipt();return}
 if(state.page==='pos'&&$('modal')?.hidden&&e.key==='F3'){e.preventDefault();nav('sales')}
});

function renderRoleMenu(){
 const navEl=$('nav');if(!navEl)return;
 const main=new Set(['dashboard','pos','sales','daily-finance','purchase','stock','catalog','cashdesk']);
 const allowedPages=menu.filter(([id])=>can(perms[id]));
 const link=([id,icon,name])=>`<button data-page="${esc(id)}" onclick="nav('${id}')"><span class="madar-nav-symbol">${icon}</span>${esc(name)}</button>`;
 const quick=allowedPages.filter(([id])=>main.has(id)), other=allowedPages.filter(([id])=>!main.has(id));
 navEl.innerHTML=quick.map(link).join('')+(other.length?`<details class="madar-extra-menu"><summary>المزيد من الأقسام والتقارير</summary>${other.map(link).join('')}</details>`:'');
}
