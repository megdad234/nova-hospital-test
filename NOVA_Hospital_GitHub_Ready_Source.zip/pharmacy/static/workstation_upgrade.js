'use strict';
// Workstation improvements: preserve the API contracts and all previously saved transactions.
const existingCatalog=catalog;
catalog=function(){
  return `<div class="panel toolbar-panel"><div class="panel-head"><div><h2>الأدوية والأصناف</h2><p class="muted-note">إضافة فردية أو رفع قائمة أسعار كاملة؛ الأصناف الجديدة لا تضيف رصيداً للمخزون.</p></div><div class="actions"><button class="btn" onclick="nav('catalog-upload')">⬆ رفع أصناف / برايسات Excel</button><button class="btn outline" onclick="newProduct()">＋ صنف جديد</button></div></div></div>`+existingCatalog();
};
menu.push(['catalog-upload','⬆','استيراد الأصناف والأسعار']);
perms['catalog-upload']='catalog';
const importLink=document.createElement('button');importLink.dataset.page='catalog-upload';
importLink.innerHTML='<span style="font-size:18px;width:24px;text-align:center">⬆</span>استيراد الأصناف والأسعار';
importLink.onclick=()=>nav('catalog-upload');$('nav').appendChild(importLink);
const previousWorkstationNav=nav;
nav=function(page){
  if(page!=='catalog-upload')return previousWorkstationNav(page);
  if(!can('catalog')){toast('مطلوب صلاحية إدارة الأصناف',true);return}
  state.page=page;
  document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  $('page-title').textContent='رفع الأصناف وأسعار الموردين';
  $('page-sub').textContent='إضافة أصناف بدون كميات، مع مراجعة قبل الاستيراد';
  $('content').innerHTML=catalogUploadView();
};
let catalogRaw=null,catalogRequest=null,catalogApproved=false;
function catalogUploadView(){return `<div class="panel"><div class="panel-head"><h2>إنشاء دليل أصناف من برايسات Excel / CSV</h2><button class="btn outline" onclick="catalogTemplate()">تنزيل نموذج جاهز</button></div>
  <div class="help">يمكن رفع اسم الصنف مع الكود والباركود والسعر. <b>سعر المورد يظل سعر شراء مرجعي</b>، ولا يصبح سعر بيع تلقائياً. السعر المسمى «سعر البيع» فقط يُستخدم للبيع عند إنشاء صنف جديد. لن تُضاف أي كميات أو تشغيلات، ولن يُغيّر سعر بيع صنف موجود.</div>
  <div class="formgrid section">${f('مصدر القائمة (اسم المورد أو البرايس)','catalog-source','text','','placeholder="مثلاً: برايس المورد بتاريخ اليوم"')}<div class="field"><label for="catalog-file">الملف (CSV / XLSX)</label><input id="catalog-file" type="file" accept=".csv,.xlsx"></div></div>
  <div class="actions section"><button class="btn" onclick="catalogAnalyze()">معاينة الأصناف والأخطاء</button><button class="btn outline" onclick="nav('opening')">الجرد الافتتاحي بالكميات</button></div>
  <div id="catalog-upload-preview" class="section"></div></div>`}
function catalogTemplate(){
  const rows=[['sku','name','barcode','unit_name','factor','supplier_price','sale_price','generic_name','manufacturer'],
              ['MED001','Paracetamol 500mg','6220000000000','علبة','1','1500','','Paracetamol','']];
  const csv='\ufeff'+rows.map(r=>r.map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='MADAR_Catalog_Template.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2500);
}
async function catalogAnalyze(){
  catalogApproved=false;
  try{
    const file=$('catalog-file')?.files?.[0];if(!file)throw Error('اختر الملف أولاً');
    if(file.size>4*1024*1024)throw Error('قسّم الملف إلى أجزاء أصغر من 4MB');
    const b64=await new Promise((resolve,reject)=>{const rd=new FileReader();rd.onload=()=>resolve(String(rd.result).split(',')[1]);rd.onerror=()=>reject(Error('تعذرت قراءة الملف'));rd.readAsDataURL(file)});
    const parsed=await api('catalog-parse',{name:file.name,data:b64});
    catalogRaw=parsed.rows;catalogRequest=token();
    const review=await api('catalog-preview',{rows:catalogRaw});
    const rows=review.rows;
    $('catalog-upload-preview').innerHTML=`<div class="cards"><div class="card"><small>إجمالي السطور</small><strong>${review.total}</strong></div><div class="card"><small>أصناف جديدة</small><strong>${review.new}</strong></div><div class="card"><small>أصناف موجودة</small><strong>${review.existing}</strong></div><div class="card"><small>تحتاج مراجعة</small><strong>${review.invalid}</strong></div></div>
    ${table(['السطر','الاسم','الكود/الباركود','سعر المورد','سعر البيع','النتيجة'],rows.slice(0,140).map(x=>`<tr><td>${x.row}</td><td><strong>${esc(x.name)}</strong></td><td>${esc(x.sku||x.barcode||'—')}</td><td>${x.supplier_price===null?'—':fmt(x.supplier_price)}</td><td>${x.sale_price===null?'غير محدد':fmt(x.sale_price)}</td><td>${x.errors.length?'<span class="tag bad">'+esc(x.errors.join('؛ '))+'</span>':'<span class="tag good">'+esc(x.status)+'</span>'}</td></tr>`))}
    ${review.total>140?'<p class="help">يعرض الجدول أول 140 صنفاً؛ جرى فحص بقية الملف.</p>':''}
    ${review.invalid?'<div class="warnbox section">صحح الأخطاء وأعد رفع الملف، لن نحفظ جزءاً منه بصورة صامتة.</div>':`<div class="warnbox section">لن يضيف الاستيراد أي كمية مخزنية. تأكد من الباركود والتعبئة والأسعار قبل الاعتماد.</div><button class="btn section" onclick="catalogCommit()">تأكيد استيراد ${review.total} صنف / سعر مرجعي</button>`}`;
    catalogApproved=!review.invalid;
  }catch(e){toast(e.message,true)}
}
async function catalogCommit(){
  if(!catalogApproved||!catalogRaw||!catalogRequest){toast('راجع الملف أولاً',true);return}
  if(!confirm('هل راجعت الأصناف؟ عملية الاستيراد لا تضيف كميات ولا تغيّر أسعار البيع الحالية.'))return;
  catalogApproved=false;
  try{
    const result=await api('catalog-commit',{rows:catalogRaw,source:v('catalog-source')||$('catalog-file')?.files?.[0]?.name,request_id:catalogRequest});
    catalogRaw=null;await refresh();nav('catalog-upload');
    $('catalog-upload-preview').innerHTML=`<div class="help">تم حفظ ${result.new} صنف جديد وربط ${result.existing} صنف موجود بأسعار المورد. أدخل مخزون الأصناف لاحقاً من الجرد الافتتاحي أو المشتريات.</div>`;
    toast('تم الاستيراد بنجاح');
  }catch(e){catalogApproved=true;toast(e.message,true)}
}

// Inventory adjustments are separately privileged: product read access alone never grants write access.
const existingStock=stock;
stock=function(){return existingStock().replace('onclick="stockAdjustModal()"',
    can('stock_adjust')?'onclick="stockAdjustModal()"':'disabled title="تحتاج صلاحية تسوية الكميات من المالك"');};
stockAdjustModal=function(){
  if(!can('stock_adjust')){toast('صلاحية تسوية الكميات غير متاحة',true);return}
  const p=state.products[0];
  modal('زيادة أو خصم كمية من المخزون',`<div class="help">تسوية مخزنية موثقة للفاقد أو التلف أو فروقات الجرد. لا يمكن أن يصبح الرصيد سالباً. كل حركة تظهر في سجل المخزون والحسابات.</div>
   ${sel('الصنف','adj-product',state.products.map(x=>[x.id,x.name]),p?.id,'onchange="adjLoadLots()"')}
   <div id="adj-lot-panel"></div>
   <div class="formgrid">${sel('نوع الحركة','adj-direction',[['-','خصم: تلف / فقد / عجز'],['+','إضافة: فرق جرد / تصحيح'] ],'-')}${f('عدد وحدات المخزون الأساسية','adj-amount','number',1,'min="1" step="1"')}${sel('السبب','adj-reason',[['تلف','تلف'],['فاقد','فاقد'],['انتهاء الصلاحية','انتهاء الصلاحية'],['فرق جرد','فرق جرد'],['تصحيح استلام','تصحيح استلام']],'تلف')}${f('تكلفة الوحدة الأساسية (عند تشغيلة جديدة فقط)','adj-cost','number',0,'min="0"')}</div>
   ${f('ملاحظات إضافية (اختياري)','adj-note')}
   <button class="btn section" onclick="saveAdjustment()">تأكيد التسوية وحفظ أثرها</button>`);
  adjLoadLots();
};
function adjLoadLots(){
  const p=state.products.find(x=>String(x.id)===v('adj-product'));
  const lots=(p?.lots||[]).filter(x=>x.status==='sellable');
  $('adj-lot-panel').innerHTML=`${sel('التشغيلة/الصلاحية الموجودة','adj-lot',[['','تشغيلة جديدة (للإضافة فقط)'],...lots.map(x=>[x.id,`${x.batch} · ${x.expiry} · متاح ${x.qty_base}`])],lots[0]?.id||'','onchange="adjSyncLot()"')}
    <div id="adj-lot-new" class="grid2" hidden>${f('مرجع التشغيلة الجديدة','adj-batch')}${f('الصلاحية','adj-exp','date')}</div>`;
  adjSyncLot();
}
function adjSyncLot(){if($('adj-lot-new'))$('adj-lot-new').hidden=Boolean(v('adj-lot'))}
saveAdjustment=async function(){
  try{
    const prod=state.products.find(x=>String(x.id)===v('adj-product'));
    const lot=prod?.lots.find(x=>String(x.id)===v('adj-lot'));
    const qty=Number(v('adj-amount'));
    if(!Number.isSafeInteger(qty)||qty<=0)throw Error('أدخل كمية صحيحة أكبر من صفر');
    const delta=v('adj-direction')==='-'?-qty:qty;
    if(!lot&&delta<0)throw Error('لا يمكن الخصم من تشغيلة جديدة');
    const body={product_id:prod.id,batch:lot?.batch||v('adj-batch'),expiry:lot?.expiry||v('adj-exp'),
      delta,reason:v('adj-reason')+(v('adj-note')?' — '+v('adj-note'):''),unit_cost:n('adj-cost')};
    if(!confirm(`هل تؤكد ${delta>0?'إضافة':'خصم'} ${qty} وحدة من ${prod.name}؟`))return;
    await api('stock-adjust',body);closeModal();await refresh();redraw();toast('تم تسجيل التسوية مع سجل المراجعة والقيد المالي');
  }catch(e){toast(e.message,true)}
};

const priorReports=reports;
reports=function(){if(!can('finance'))return priorReports();return `<div class="panel"><div class="panel-head"><h2>المالية حسب قنوات التحصيل والورديات</h2><div class="actions"><button class="btn" onclick="loadFinanceDesk()">تحديث المالية</button><button class="btn outline" onclick="window.print()">طباعة التقرير</button></div></div>
 <p class="muted-note">الأرصدة دفترية من عمليات البرنامج؛ لا تحل محل كشف بنكك أو المطابقة البنكية.</p><div id="finance-desk"><div class="help">اضغط «تحديث المالية» لعرض الملخص.</div></div></div>`+priorReports();};
async function loadFinanceDesk(){
  try{
    const r=await api('finance-overview'),s=r.summary;
    $('finance-desk').innerHTML=`<div class="finance-kpis">
      <div class="card"><small>الكاش — رصيد دفتري</small><strong>${fmt(s.cash_ledger)}</strong></div>
      <div class="card"><small>تحويلات بانتظار مطابقة</small><strong>${fmt(s.bank_pending_ledger)}</strong></div>
      <div class="card"><small>حساب البنك الدفتري بعد التحقق</small><strong>${fmt(s.bank_verified_ledger)}</strong></div>
      <div class="card"><small>التأمين — ذمم الجهات</small><strong>${fmt(s.insurance_receivable)}</strong></div>
      <div class="card"><small>ذمم العملاء الآجلة</small><strong>${fmt(s.customer_receivable)}</strong></div>
      <div class="card"><small>مستحقات الموردين</small><strong>${fmt(s.supplier_payable)}</strong></div></div>
      <div class="help section">${esc(r.bank_note)} التحويل المعلّق ليس بالضرورة إيداعاً مؤكداً.</div>
      <div class="grid2 section"><div class="panel"><div class="panel-head"><h3>ورديات مفتوحة</h3><button class="btn outline small" onclick="nav('cashdesk')">دفتر الورديات والمصروفات</button></div>
      ${table(['الموظف','الوردية','الكاش المتوقع الآن'],r.open_shifts.map(x=>`<tr><td>${esc(x.full_name||x.user_id)}</td><td>#${x.id}</td><td>${fmt(x.expected_cash)}</td></tr>`))}</div>
      <div class="panel"><h3>مطالبات التأمين</h3>${table(['الجهة','الفترة','القيمة','المحصّل','المتبقي'],r.claims.slice(0,35).map(x=>`<tr><td>${esc(x.authority)}</td><td>${esc(x.period)}</td><td>${fmt(x.total)}</td><td>${fmt(x.paid)}</td><td>${fmt(x.total-x.paid)}</td></tr>`))}</div></div>
      <div class="panel"><h3>إقفالات الورديات والفروقات</h3>${table(['الموظف','الفتح','الإغلاق','المتوقع','المعدود','الفرق'],r.recent_shifts.slice(0,40).map(x=>`<tr><td>${esc(x.full_name||x.user_id)}</td><td>${esc(x.opened_at)}</td><td>${esc(x.closed_at||'مفتوحة')}</td><td>${x.closed_at?fmt(x.expected_cash):'—'}</td><td>${x.closed_at?fmt(x.closing_cash):'—'}</td><td>${x.closed_at?fmt(x.variance):'—'}</td></tr>`))}</div>
      <div class="actions section"><button class="btn outline" onclick="exportFinanceCsv()">تصدير ملخص المالية CSV</button></div>`;
    state.financeOverview=r;
  }catch(e){toast(e.message,true)}
}
function exportFinanceCsv(){const s=state.financeOverview?.summary;if(!s){toast('حمّل التقرير أولاً',true);return}
  const csv='\ufeff'+Object.entries(s).map(([k,v])=>`"${k}","${v}"`).join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='MADAR_Finance_'+today()+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),2500);
}

const formerCashdesk=cashdesk;
cashdesk=function(){return formerCashdesk() + (can('shift_manage')?`<div class="panel"><div class="panel-head"><h2>إقفال الورديات بواسطة المسؤول المالي</h2><button class="btn outline" onclick="loadSupervisorShifts()">تحديث الورديات المفتوحة</button></div>
   <p class="help">يمكن إقفال وردية واحدة أو الكل، لكن يجب إدخال الكاش المعدود فعلياً لكل وردية؛ لا يُفترض أن الرصيد المتوقع هو الكاش الموجود.</p><div id="supervisor-shifts"></div></div>`:'');};
async function loadSupervisorShifts(){try{
  const x=await api('finance-overview');state.supervisorShifts=x.open_shifts;
  $('supervisor-shifts').innerHTML=table(['الوردية','الموظف','المتوقع','الكاش المعدود فعلياً','إجراء'],x.open_shifts.map(s=>`<tr><td>#${s.id}</td><td>${esc(s.full_name||s.user_id)}</td><td>${fmt(s.expected_cash)}</td><td><input type="number" min="0" id="super-shift-${s.id}" placeholder="أدخل المبلغ"></td><td><button class="btn outline small" onclick="supervisorCloseOne(${s.id})">إقفال هذه</button></td></tr>`))+
    (x.open_shifts.length?'<button class="btn section" onclick="supervisorCloseAll()">إقفال جميع الورديات بعد إدخال كل المبالغ</button>':'<p class="help">لا توجد ورديات مفتوحة.</p>');
}catch(e){toast(e.message,true)}}
function readSupervisorAmount(id){const raw=v('super-shift-'+id);if(raw===''||!/^\d+$/.test(raw))throw Error('أدخل الكاش المعدود الصحيح لوردية '+id);return Number(raw)}
async function supervisorCloseOne(id){try{const counted=readSupervisorAmount(id);if(!confirm('تأكيد إقفال الوردية رقم '+id+'؟'))return;
 const r=await api('shift-close',{shift_id:id,actual_cash:counted,notes:'إقفال المسؤول المالي'});await refresh();nav('cashdesk');await loadSupervisorShifts();toast('تم الإقفال، الفرق '+fmt(r.variance))}catch(e){toast(e.message,true)}}
async function supervisorCloseAll(){try{const counts=(state.supervisorShifts||[]).map(x=>({shift_id:x.id,actual_cash:readSupervisorAmount(x.id)}));
 if(!counts.length)throw Error('لا توجد ورديات مفتوحة');if(!confirm('تأكيد إقفال جميع الورديات المفتوحة بعد عدّ كاش كل وردية؟'))return;
 const r=await api('shift-close-all',{counts,notes:'إقفال مجمع بواسطة المسؤول المالي'});await refresh();nav('cashdesk');await loadSupervisorShifts();toast('تم إقفال '+r.closed+' ورديات وتسجيل فروقاتها')}catch(e){toast(e.message,true)}}

// Distinct approval rights shown in the user's security screen.
permLabels.stock_adjust='تعديل الكميات (+/−) مع تسجيل السبب';
permLabels.shift_manage='إقفال ورديات الموظفين وإقفال الكل';
// Keyboard first: no need for cashier to leave the scanner during frequent POS operations.
document.addEventListener('keydown',e=>{
  if($('modal')&&!$('modal').hidden)return;
  if(state.page!=='pos')return;
  if(e.key==='F2'){e.preventDefault();$('pos-scan')?.focus();$('pos-scan')?.select()}
  if(e.key==='F4'){e.preventDefault();if(state.saleRows.length)confirmSale()}
});

// Large preloaded product dictionary: keyboard search instead of paging through thousands of rows.
const madarMasterCatalogView=catalog;
catalog=function(){
 return `<div class="panel toolbar-panel"><div class="field"><label for="master-product-search">ابحث بسرعة في دليل الأصناف الجاهز</label><input id="master-product-search" oninput="filterMasterProducts()" placeholder="اسم الدواء أو المادة الفعالة أو كود الصنف" autocomplete="off"></div><p class="muted-note">الأسماء مرجع جاهز للشراء والجرد، والكميات مستقلة. يمكن إضافة أي صنف جديد في أي وقت.</p></div>`+madarMasterCatalogView();
};
function filterMasterProducts(){
 const key=v('master-product-search').trim().toLocaleLowerCase();
 document.querySelectorAll('#content .tablewrap tbody tr').forEach(row=>{row.hidden=!!key&&!row.textContent.toLocaleLowerCase().includes(key)});
}
