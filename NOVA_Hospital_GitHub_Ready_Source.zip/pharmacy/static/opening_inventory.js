'use strict';
// One-time opening balance: preflight is read-only; posting is a single audited transaction.
menu.push(['opening','▥','الجرد الافتتاحي من Excel']);
perms.opening='stock';
const openingNavButton=document.createElement('button');
openingNavButton.dataset.page='opening';
openingNavButton.innerHTML='<span style="font-size:18px;width:24px;text-align:center">▥</span>الجرد الافتتاحي من Excel';
openingNavButton.onclick=()=>nav('opening');
$('nav').appendChild(openingNavButton);
const previousNavOpening=nav;
nav=function(page){
  if(page!=='opening')return previousNavOpening(page);
  if(!can('stock')){toast('ليس لديك صلاحية الجرد',true);return}
  state.page=page;
  document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  $('page-title').textContent='الجرد الافتتاحي — إدخال الأدوية';
  $('page-sub').textContent='مراجعة أولاً · حفظ آمن · لا تكرار للملفات';
  $('content').innerHTML=openingScreen();
};
let openingTable=null,openingRequestId=null,openingReady=false;
function openingScreen(){return `<div class="panel"><h2>إدخال جرد الأدوية مرة واحدة قبل التشغيل</h2>
 <p class="help">جهّز Excel أو CSV من الصفوف الموجودة في نموذج الجرد. كل سطر يمثل كمية عبوة مع الصلاحية وسعر الشراء والبيع. رقم التشغيلة اختياري؛ إن لم يتوفر ينشئ النظام مرجع تتبع داخلي خاص بالسطر. لا تضع رقم تشغيلة غير حقيقي. يمكن تكرار كود الصنف لو عنده أكثر من وحدة تعبئة أو تشغيلة.</p>
 <p class="warnbox">تنبيه: الجرد الافتتاحي يزيد المخزون ويُثبت قيمة افتتاحية في المحاسبة. لا ترفع الملف مرتين ولا تستخدمه بدل فاتورة مشتريات بعد بدء التشغيل. سيتم رفض الملف المتكرر تلقائياً.</p>
 <button class="btn outline" onclick="downloadOpeningTemplate()">تنزيل نموذج CSV للجرد</button>
 <div class="field section"><label>ملف الجرد CSV أو Excel بصيغة XLSX (حتى 4MB)</label><input type="file" id="opening-file" accept=".csv,.xlsx"></div>
 <button class="btn" onclick="openingParse()">قراءة الجرد وفحص جميع السطور</button>
 <div id="opening-preview" class="section"></div></div>`}
function downloadOpeningTemplate(){
 const header=['sku','name','barcode','unit_name','factor','base_uom','quantity','batch','expiry','unit_cost','sale_price','generic_name','manufacturer'];
 const sample=['SKU001','Paracetamol 500mg','6220000000000','شريط','10','حبة','3','','2028-12-31','1500','2500','Paracetamol','Company'];
 const csv='\ufeff'+[header,sample].map(row=>row.map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='Pharmacy_Opening_Stock_Template.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),3000);
}
async function openingParse(){
 try{
  const file=$('opening-file')?.files?.[0];if(!file)throw Error('اختر ملف الجرد أولاً');if(file.size>4*1024*1024)throw Error('ملف كبير؛ قسّمه إلى ملفين');
  const b64=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(Error('تعذر قراءة الملف'));r.readAsDataURL(file)});
  const result=await api('opening-parse-file',{name:file.name,data:b64});
  openingTable=result.rows;openingRequestId=token();openingReady=false;
  const review=await api('opening-preview',{rows:openingTable});
  let errors=review.rows.filter(r=>r.errors.length);
  $('opening-preview').innerHTML=`<h3>فحص ${review.rows.length} سطر</h3>
   <p><span class="tag ${errors.length?'warn':'good'}">سليم: ${review.valid} · يحتاج تصحيح: ${review.invalid}</span></p>
   <p><b>قيمة الجرد السليم: ${fmt(review.total_value)}</b></p>
   ${table(['صف','الصنف','الكمية','التشغيلة','الصلاحية','الفحص'],review.rows.slice(0,120).map(r=>`<tr><td>${r.row.source_row}</td><td>${esc(r.row.name)}<small> · ${esc(r.row.sku)}</small></td><td>${esc(r.row.quantity)} ${esc(r.row.unit_name)}</td><td>${esc(r.row.batch)}</td><td>${esc(r.row.expiry)}</td><td>${r.errors.length?'<span class="tag warn">'+esc(r.errors.join('؛ '))+'</span>':'<span class="tag good">سليم</span>'}</td></tr>`))}
   ${review.rows.length>120?'<p class="help">الجدول يعرض أول 120 سطر فقط؛ تم فحص بقية الملف.</p>':''}
   ${errors.length?'<div class="warnbox">لن يتم حفظ الجرد قبل تصحيح جميع الأخطاء وإعادة رفع الملف.</div>':`<div class="warnbox">راجع الكميات والتواريخ والأسعار قبل الاعتماد؛ هذا الإدخال يسجل حركة مالية ومخزنية.</div><button class="btn section" onclick="openingCommit()">اعتماد الجرد وإضافة ${review.valid} سطر للمخزون</button>`}`;
  openingReady=errors.length===0;
 }catch(e){toast(e.message,true);openingReady=false;}
}
async function openingCommit(){
 try{
  if(!openingReady||!openingTable||!openingRequestId)throw Error('راجع ملف الجرد أولاً');
  if(!confirm('هل تأكدت من كل الكميات والأسعار والصلاحيات؟ الحفظ سيضيف المخزون والقيود المحاسبية.'))return;
  openingReady=false;
  const r=await api('opening-commit',{rows:openingTable,request_id:openingRequestId});
  openingTable=null;openingRequestId=null;
  await refresh();nav('opening');
  toast('تم اعتماد '+r.rows+' سطر؛ قيمة الجرد '+fmt(r.total_value));
  $('opening-preview').innerHTML='<div class="help">تم حفظ الجرد بنجاح. الأدوية ظهرت في دليل الأدوية والمخزون ونقطة البيع.</div>';
 }catch(e){openingReady=true;toast(e.message,true)}
}
