'use strict';
// Extended workflows. No automatically applied prices or stock deductions.
const oldNavV06=nav;
menu.push(['advanced','✦','المالية والذكاء والمراجعة']);
perms.advanced='reports';
const linkV06=document.createElement('button');
linkV06.dataset.page='advanced';
linkV06.innerHTML='<span style="font-size:18px;width:24px;text-align:center">✦</span>المالية والذكاء والمراجعة';
linkV06.onclick=()=>nav('advanced');
$('nav').appendChild(linkV06);
nav=function(page){
  if(page!=='advanced')return oldNavV06(page);
  if(!can('reports')){toast('لا توجد صلاحية عرض',true);return}
  state.page='advanced';
  document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  $('page-title').textContent='المالية والذكاء والمراجعة';
  $('page-sub').textContent='عمليات تحتاج مراجعة واعتماد صريح';
  $('content').innerHTML=advancedV06();
};
function advancedV06(){
 const authorities=(state.partners||[]).filter(x=>x.kind==='authority');
 const pharmacies=(state.partners||[]).filter(x=>x.kind==='pharmacy');
 return `<div class="grid2">
 <div class="panel"><h2>القوائم المالية وميزان المراجعة</h2><p class="help">ملخص حسابي من القيود، للاطلاع والمراجعة وليس قوائم معتمدة من محاسب.</p>
 <div class="formgrid">${f('من تاريخ','fin-from','date','')}${f('إلى تاريخ','fin-to','date','')}</div>
 <button class="btn" onclick="showFinancialV06()">عرض القيود والربح</button>
 ${can('finance')?`<h3>إقفال شهر سابق</h3>${f('الشهر YYYY-MM','close-month','month','')}${f('سبب الإقفال','close-reason','text','بعد المراجعة المحاسبية')}<button class="btn outline" onclick="closeMonthV06()">إقفال الفترة</button>`:''}
 </div>
 <div class="panel"><h2>تأمينات ومطالبات الجهات</h2><p class="help">يمكن إرسال المطالبة ثم اعتماد المبلغ المقبول من الجهة، مع إثبات المرفوض منفصلاً.</p>
 ${sel('المطالبة','v6-claim',(state.claims||[]).map(c=>[c.id,`#${c.id} ${c.authority} — ${c.period} (${c.status}) ${fmt(c.total)}`]))}
 <div class="actions">${can('claims')?`<button class="btn" onclick="submitClaimV06()">إرسال المطالبة</button>`:''}</div>
 ${f('المبلغ المقبول لدى الجهة','v6-approved','number','')}${f('سبب القرار','v6-decision-reason','text','')}
 ${can('claims')?`<button class="btn outline" onclick="adjudicateClaimV06()">تسجيل قرار الجهة</button>`:''}
 </div>
 <div class="panel"><h2>التسعير الجماعي بالمراجعة</h2><p class="help">معاينة الأصناف المتغيرة فقط؛ لا يتغير سعر واحد قبل اعتمادك.</p>
 ${sel('مصدر الاحتساب','v6-mode',[['current','السعر الحالي + نسبة'],['supplier','آخر تكلفة عرض مورد + نسبة']],'current')}
 <div class="formgrid">${f('نسبة الزيادة %','v6-markup','number','30')}${sel('تقريب السعر','v6-round',[[1,'بدون تقريب'],[10,'10'],[50,'50'],[100,'100'],[500,'500'],[1000,'1000']],100)}
 ${sel('اتجاه التقريب','v6-direction',[['nearest','للأقرب'],['up','للأعلى'],['down','للأسفل']],'nearest')}</div>
 <div style="max-height:190px;overflow:auto;border:1px solid #d5e6e1;border-radius:10px;padding:8px">${(state.products||[]).filter(p=>p.active).flatMap(p=>p.packages.map(k=>`<label class="line"><span>${esc(p.name)} · ${esc(k.unit_name)} · ${fmt(k.sale_price)}</span><input class="v06-pack" type="checkbox" value="${k.id}"></label>`)).join('')}</div>
 <button class="btn section" onclick="previewPricesV06()">معاينة الأسعار</button><div id="v06-price-results"></div>
 </div>
 <div class="panel"><h2>اقتراح الطلبيات دون حجز</h2><p class="help">يحتسب مبيعات الفترة ورصيد المخزون والوارد المتوقع، ولا يصدر شراء تلقائياً.</p>
 <div class="formgrid">${f('مدة تحليل البيع (يوم)','v6-history','number','30')}${f('مهلة التوريد (يوم)','v6-lead','number','7')}${f('مخزون تغطية (يوم)','v6-cover','number','30')}</div>
 ${can('purchase')?`<button class="btn" onclick="reorderV06()">احسب مقترحات الشراء</button>`:''}<div id="v06-order-results"></div>
 </div>
 ${can('finance')?`<div class="panel"><h2>تسوية حساب صيدلية خارجية</h2>${sel('الصيدلية','v6-pharmacy',pharmacies.map(x=>[x.id,x.name]))}${f('مبلغ التسوية','v6-pharm-amt','number','0')}${sel('طريقة السداد','v6-pharm-method',[['cash','كاش'],['bank','تحويل بنكي']],'cash')}${f('مرجع التحويل (إن وجد)','v6-pharm-ref')}
 <button class="btn" onclick="settlePharmacyV06()">حفظ التسوية مع المقاصة</button></div>`:''}
 ${can('claims')?`<div class="panel"><h2>إشعار دائن لتصحيح التأمين</h2><p class="help">اختر رقم تصحيح تغطية سالب لفاتورة دخلت مطالبة سابقاً؛ لا يتكرر القيد المحاسبي.</p>${f('رقم تصحيح التغطية','v6-correction','number','')}${f('سبب الإشعار','v6-credit-reason','text','تسوية بعد رفع المطالبة')}<button class="btn" onclick="creditNoteV06()">إصدار إشعار مرتبط</button></div>`:''}
 </div>`;
}
let reviewedPriceV06=null;
function selectedPriceV06(){return [...document.querySelectorAll('.v06-pack:checked')].map(x=>Number(x.value))}
function pricePayloadV06(){return {mode:v('v6-mode'),markup_pct:v('v6-markup'),rounding:n('v6-round'),direction:v('v6-direction'),package_ids:selectedPriceV06()}}
async function previewPricesV06(){try{
 const p=pricePayloadV06(), preview=await api('pricing-preview',p);
 reviewedPriceV06={payload:p,preview};
 const changed=preview.rows.filter(x=>x.changed);
 $('v06-price-results').innerHTML=`<p class="help">${preview.changed} سعر متغير · ${preview.review_required} شاذ أو يحتاج تدقيق</p>
 ${table(['الدواء / الوحدة','السعر الحالي','المقترح','قرارك'],changed.map((r,i)=>`<tr><td>${esc(r.product)} · ${esc(r.unit)} ${r.flagged?'⚠️ سعر شاذ':''}</td><td>${fmt(r.old_price)}</td><td><input style="width:115px" type="number" id="v6-price-${r.package_id}" value="${r.new_price}" min="0"></td><td><label><input type="checkbox" class="v6-approve" value="${r.package_id}" checked> اعتماد</label>${r.flagged?`<label> <input type="checkbox" id="v6-alert-${r.package_id}"> فهمت التنبيه</label>`:''}</td></tr>`))}
 ${can('prices')?`<button class="btn" onclick="approvePricesV06()">اعتماد الأسعار المحددة فقط</button>`:''}`;
 }catch(e){toast(e.message,true)}}
async function approvePricesV06(){try{
 if(!reviewedPriceV06)throw Error('عاين الأسعار أولاً');
 const {payload,preview}=reviewedPriceV06;
 const selected=preview.rows.filter(x=>x.changed && document.querySelector(`.v6-approve[value="${x.package_id}"]`)?.checked);
 if(!selected.length)throw Error('لم تحدد تغييراً لاعتماده');
 // API checks the full preview set, even when only a subset changed. For unchecked rows set original price.
 const reviewed_rows=preview.rows.map(x=>({package_id:x.package_id,old_price:x.old_price,
   new_price:selected.find(y=>y.package_id===x.package_id)?Number($('v6-price-'+x.package_id).value):x.old_price,
   supplier_quote_id:x.supplier_quote_id,
   anomaly_ack:!x.flagged||Boolean($('v6-alert-'+x.package_id)?.checked)}));
 if(!confirm(`هل تؤكد اعتماد ${selected.length} تغييراً في أسعار البيع؟`))return;
 const result=await api('pricing-approve',{...payload,reviewed_rows,confirm:true,note:'اعتماد يدوي من شاشة التسعير'});
 reviewedPriceV06=null;await refresh();nav('advanced');toast('تم تحديث '+result.updated+' سعر مع حفظ التاريخ');
 }catch(e){toast(e.message,true)}}
async function reorderV06(){try{const x=await api('reorder-suggestions',{history_days:n('v6-history'),lead_days:n('v6-lead'),cover_days:n('v6-cover')});
 $('v06-order-results').innerHTML=`<div class="help">${x.needing_order} صنف بحاجة مراجعة طلب؛ لا حجز ولا أمر شراء تلقائي.</div>${table(['الصنف','المتاح','قيد التوريد','المقترح','المورد'],x.items.filter(p=>p.needed_base>0).map(p=>`<tr><td>${esc(p.name)}</td><td>${p.available_base}</td><td>${p.incoming_base}</td><td>${p.recommended_packages} عبوات (×${p.needed_base} وحدة أساسية تقريباً)</td><td>${esc(p.supplier?.supplier_name||'لم يحدد')}</td></tr>`))}`;
 }catch(e){toast(e.message,true)}}
async function showFinancialV06(){try{const r=await api('finance-statements',{start:v('fin-from'),end:v('fin-to')});modal('ميزان المراجعة والتقرير المالي',`<div class="help">${esc(r.warning)}</div><h3>الإيراد الصافي: ${fmt(r.income_summary.gross_revenue)} · الربح الأولي: ${fmt(r.income_summary.net_profit_before_other_accounts)}</h3><p>توازن القيود: ${r.period_balanced?'نعم':'لا — هناك خلل'}</p>${table(['الحساب','مدين','دائن'],r.accounts.map(x=>`<tr><td>${esc(x.account)}</td><td>${fmt(x.debit)}</td><td>${fmt(x.credit)}</td></tr>`))}`)}catch(e){toast(e.message,true)}}
async function closeMonthV06(){try{if(!confirm('إقفال شهر محاسبي إجراء حساس. هل تمت مراجعته؟'))return;const r=await api('close-period',{period:v('close-month'),reason:v('close-reason')});toast('تم إقفال '+r.period)}catch(e){toast(e.message,true)}}
async function submitClaimV06(){try{let id=n('v6-claim');await api('insurance-submit',{claim_id:id});await refresh();nav('advanced');toast('تم وضع المطالبة في حالة مرسلة')}catch(e){toast(e.message,true)}}
async function adjudicateClaimV06(){try{let id=n('v6-claim');if(!confirm('تأكيد قرار الجهة؟ مبلغ الرفض سينعكس في سجل المحاسبة.'))return;const r=await api('insurance-decision',{claim_id:id,approved_amount:n('v6-approved'),reason:v('v6-decision-reason')});await refresh();nav('advanced');toast('تم تسجيل القرار: '+r.status)}catch(e){toast(e.message,true)}}
async function creditNoteV06(){try{const r=await api('insurance-credit',{adjustment_id:n('v6-correction'),reason:v('v6-credit-reason')});toast('تم إنشاء إشعار دائن رقم '+r.id)}catch(e){toast(e.message,true)}}
async function settlePharmacyV06(){try{if(!confirm('هل تحققت من التسوية المالية؟'))return;const r=await api('pharmacy-settle',{partner_id:n('v6-pharmacy'),amount:n('v6-pharm-amt'),method:v('v6-pharm-method'),bank_ref:v('v6-pharm-ref')});toast('تمت التسوية · المتبقي '+fmt(r.remaining))}catch(e){toast(e.message,true)}}
