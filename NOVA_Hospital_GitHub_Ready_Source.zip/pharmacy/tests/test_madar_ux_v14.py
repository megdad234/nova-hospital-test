"""Regression checks for everyday purchasing and searchable drug directory."""
import tempfile, unittest
from datetime import date,timedelta
from pathlib import Path
import app

class MadarEverydayWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.original_db,self.original_data=app.DB,app.DATA
        app.DATA=Path(self.temp.name);app.DB=app.DATA/'test.sqlite3';app.init_db()
        self.c=app.db_connect()
        app.bootstrap(self.c, {'username':'owner','full_name':'Owner','password':'LongPassword1234'})
        self.uid=app.one(self.c,'SELECT id FROM users')['id']
        self.pid=app.create_product(self.c,{'sku':'TEST-SUP','name':'Check 500mg','packages':[{'unit_name':'حبة','factor':1,'barcode':'UX100','sale_price':900,'is_default':1}]},self.uid)['id']
        self.pkg=app.one(self.c,'SELECT id FROM packages WHERE product_id=?',(self.pid,))['id']
        self.supplier=app.create_party(self.c,{'name':'Trusted supplier'},'supplier',self.uid)['id']
        self.expiry=(date.today()+timedelta(days=400)).isoformat()
    def tearDown(self):
        self.c.close();app.DB,app.DATA=self.original_db,self.original_data;self.temp.cleanup()
    def buy(self,qty,received=None,ref='INV-UX'):
        line={'package_id':self.pkg,'qty':qty,'unit_cost':500,'expiry':self.expiry}
        if received is not None:line['received']=received
        return app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':ref,'items':[line]},self.uid)
    def test_full_receipt_is_posted_once_without_second_approval(self):
        self.buy(66)
        p=next(x for x in app.catalog(self.c) if x['id']==self.pid)
        self.assertEqual(p['available'],66)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM stock_moves WHERE kind='purchase'").fetchone()[0],1)
        self.assertEqual(self.c.execute('SELECT received FROM purchase_lines').fetchone()[0],66)
        with self.assertRaises(Exception):self.buy(66)
        self.assertEqual(next(x for x in app.catalog(self.c) if x['id']==self.pid)['available'],66)
    def test_partial_receipt_only_posts_arrived_quantity(self):
        self.buy(66,1)
        self.assertEqual(next(x for x in app.catalog(self.c) if x['id']==self.pid)['available'],1)
        line=self.c.execute('SELECT id FROM purchase_lines').fetchone()[0]
        app.purchase_receipt(self.c,{'purchase_line_id':line,'qty':65,'expiry':self.expiry},self.uid)
        self.assertEqual(next(x for x in app.catalog(self.c) if x['id']==self.pid)['available'],66)
    def test_ui_assets_and_visible_controls(self):
        root=Path(__file__).resolve().parents[1]
        html=(root/'static/index.html').read_text(encoding='utf-8')
        js=(root/'static/ux_v14.js').read_text(encoding='utf-8')
        self.assertIn('/static/ux_v14.js',html)
        for t in ['استلام جزئي','حفظ الفاتورة وإضافة الكمية للمخزون','madar-catalog-search','makeLongSelectSearch','filterCards']:
            self.assertIn(t,js)

if __name__=='__main__':unittest.main()
