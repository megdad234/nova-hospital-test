import os,sys,tempfile,unittest,uuid
from datetime import date,timedelta
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
class MoreTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();app.DATA=Path(self.tmp.name);app.DB=app.DATA/'extra.sqlite3';app.init_db();self.c=app.db_connect();app.bootstrap(self.c,{'username':'o','full_name':'owner','password':'super_long_password'});self.uid=1
  self.ids=[]
  for j in range(2):
   p=app.create_product(self.c,{'sku':f'PK{j}','name':f'Drug {j}','packages':[{'unit_name':'شريط','factor':10,'sale_price':10000,'barcode':f'123{j}','is_default':1}]},self.uid)
   self.ids.append(app.one(self.c,'SELECT id FROM packages WHERE product_id=?',(p['id'],))['id'])
  self.sup=app.create_party(self.c,{'name':'Supplier'},'supplier',self.uid)['id'];self.pharm=app.create_party(self.c,{'name':'External Pharmacy'},'pharmacy',self.uid)['id']
 def tearDown(self):self.c.close();self.tmp.cleanup()
 def buy(self,qty=3,received=2):return app.purchase(self.c,{'supplier_id':self.sup,'invoice_ref':'A101','items':[{'package_id':self.ids[0],'qty':qty,'received':received,'unit_cost':8000,'batch':'A1','expiry':(date.today()+timedelta(days=600)).isoformat()}]},self.uid)
 def test_receipt_remainder_ledger(self):
  p=self.buy();l=app.one(self.c,'SELECT id FROM purchase_lines LIMIT 1');ex=(date.today()+timedelta(days=600)).isoformat()
  rec=app.purchase_receipt(self.c,{'purchase_line_id':l['id'],'qty':1,'batch':'A1','expiry':ex},self.uid)
  self.assertEqual(rec['received'],1);self.assertEqual(app.catalog(self.c)[0]['available'],30)
  with self.assertRaisesRegex(ValueError,'يتجاوز'):app.purchase_receipt(self.c,{'purchase_line_id':l['id'],'qty':1,'batch':'A1','expiry':ex},self.uid)
  self.assertTrue(app.report(self.c)['journals_balanced'])
 def test_purchase_return(self):
  p=self.buy(qty=2,received=2);l=app.one(self.c,'SELECT id FROM purchase_lines LIMIT 1')
  r=app.purchase_return(self.c,{'purchase_line_id':l['id'],'qty':1,'reason':'company return'},self.uid)
  self.assertEqual(app.catalog(self.c)[0]['available'],10)
  with self.assertRaisesRegex(ValueError,'يتجاوز'):app.purchase_return(self.c,{'purchase_line_id':l['id'],'qty':2,'reason':'duplicate'},self.uid)
  self.assertTrue(app.report(self.c)['journals_balanced'])
 def test_exchange_atomic(self):
  self.buy(qty=3,received=3);ex=(date.today()+timedelta(days=600)).isoformat()
  r=app.pharmacy_exchange(self.c,{'partner_id':self.pharm,'out_package_id':self.ids[0],'out_qty':1,'out_value':10000,'in_package_id':self.ids[1],'in_qty':2,'in_value':20000,'in_batch':'B1','in_expiry':ex},self.uid)
  cat=app.catalog(self.c)
  self.assertEqual({p['sku']:p['available'] for p in cat},{'PK0':20,'PK1':20})
  self.assertEqual(r['difference'],-10000)
  self.assertTrue(app.report(self.c)['journals_balanced'])
  with self.assertRaisesRegex(ValueError,'المخزون'):app.pharmacy_exchange(self.c,{'partner_id':self.pharm,'out_package_id':self.ids[0],'out_qty':10,'out_value':10,'in_package_id':self.ids[1],'in_qty':10,'in_value':10,'in_batch':'B2','in_expiry':ex},self.uid)
  self.assertEqual({p['sku']:p['available'] for p in app.catalog(self.c)},{'PK0':20,'PK1':20})
if __name__=='__main__':unittest.main()
