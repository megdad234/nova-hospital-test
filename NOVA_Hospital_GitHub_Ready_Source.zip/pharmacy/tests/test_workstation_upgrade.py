"""Non-destructive workstation upgrades: catalogs, control permissions, finance and shifts."""
import json,sqlite3,tempfile,unittest,uuid
from pathlib import Path
import app,catalog_import

class WorkstationUpgradeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.saved=(app.DB,app.DATA)
        app.DATA=Path(self.temp.name)
        app.DB=app.DATA/'pharmacy.sqlite3'
        app.init_db();self.c=app.db_connect()
        app.bootstrap(self.c,{'username':'owner','full_name':'مدير الصيدلية','password':'VeryLongUniquePass2026'})
        self.uid=app.one(self.c,'SELECT id FROM users LIMIT 1')['id']
    def tearDown(self):
        self.c.close();app.DB,app.DATA=self.saved;self.temp.cleanup()
    def rows(self):
        return [['name','barcode','sku','unit_name','factor','supplier_price','sale_price'],
                ['Panadol 500','CUSTOM-B-101','PAN-500','علبة',1,1000,''],
                ['Brufen 400','CUSTOM-B-102','BRU-400','علبة',1,2000,3000]]
    def test_pricelist_import_creates_catalog_without_phantom_stock(self):
        rows=self.rows();preview=catalog_import.preview(self.c,rows)
        self.assertEqual(preview['new'],2);self.assertEqual(preview['invalid'],0)
        r=catalog_import.commit(self.c,rows,'Supplier price list',self.uid,uuid.uuid4().hex)
        self.assertEqual(r['new'],2)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM products')['n'],2)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM lots')['n'],0)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM stock_moves')['n'],0)
        self.assertEqual(app.one(self.c,'SELECT COALESCE(SUM(qty_base),0) n FROM lots')['n'],0)
        self.assertEqual(app.one(self.c,'SELECT sale_price FROM packages WHERE barcode=?',('CUSTOM-B-101',))['sale_price'],0)
        self.assertEqual(app.one(self.c,'SELECT price FROM supplier_price_references WHERE source=? AND product_id=(SELECT id FROM products WHERE sku=?)',('Supplier price list','PAN-500'))['price'],1000)
        with self.assertRaisesRegex(ValueError,'سابقاً'):
            catalog_import.commit(self.c,rows,'Supplier price list',self.uid,uuid.uuid4().hex)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM products')['n'],2)
    def test_existing_live_price_not_overwritten(self):
        rows=self.rows();catalog_import.commit(self.c,rows,'Price A',self.uid,uuid.uuid4().hex)
        pkg=app.one(self.c,'SELECT id FROM packages WHERE barcode=?',('CUSTOM-B-102',))['id']
        app.edit_package(self.c,{'package_id':pkg,'sale_price':8900},self.uid)
        rows[2][5]=2500;rows[2][6]=1
        catalog_import.commit(self.c,rows,'Price B',self.uid,uuid.uuid4().hex)
        self.assertEqual(app.one(self.c,'SELECT sale_price FROM packages WHERE id=?',(pkg,))['sale_price'],8900)
    def test_bad_duplicate_list_rolls_back_entire_file(self):
        rows=self.rows();rows.append(rows[1].copy())
        with self.assertRaisesRegex(ValueError,'يحتاج تصحيح'):
            catalog_import.commit(self.c,rows,'supplier A',self.uid,uuid.uuid4().hex)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM products')['n'],0)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM catalog_imports')['n'],0)
    def test_owner_permission_migrated_and_accountants_cannot_change_stock_automatically(self):
        self.assertIn('stock_adjust',app.PERMISSIONS)
        owner=json.loads(app.one(self.c,'SELECT permissions FROM users WHERE id=?',(self.uid,))['permissions'])
        self.assertIn('stock_adjust',owner)
        self.assertIn('shift_manage',owner)
        self.assertNotIn('stock_adjust',app.DEFAULT_PERMS['pharmacist'])
        self.assertNotIn('shift_manage',app.DEFAULT_PERMS['cashier'])
    def test_close_individual_and_all_shifts_records_real_differences(self):
        owner=app.shift_open(self.c,{'opening_cash':1000},self.uid)
        # Other clerk with finance only can close own but not owner's shift.
        self.c.execute("INSERT INTO users(username,full_name,pass_hash,salt,permissions) SELECT 'cashier','cashier',pass_hash,salt,? FROM users WHERE id=?",(json.dumps(['finance']),self.uid))
        cashier=app.one(self.c,"SELECT id FROM users WHERE username='cashier'")['id']
        other=app.shift_open(self.c,{'opening_cash':2000},cashier)
        with self.assertRaises(PermissionError):
            app.shift_close(self.c,{'shift_id':owner['id'],'actual_cash':1000},cashier,False)
        self.assertEqual(len(app.finance_overview(self.c)['open_shifts']),2)
        with self.assertRaisesRegex(ValueError,'تغيرت الورديات'):
            app.shift_close_all(self.c,{'counts':[{'shift_id':owner['id'],'actual_cash':999}]},self.uid)
        self.assertEqual(len(app.finance_overview(self.c)['open_shifts']),2)
        r=app.shift_close_all(self.c,{'counts':[{'shift_id':owner['id'],'actual_cash':1100},
                                                 {'shift_id':other['id'],'actual_cash':1800}]},self.uid)
        self.assertEqual(r['closed'],2)
        self.assertEqual(sorted(x['variance'] for x in r['results']),[-200,100])
        self.assertFalse(app.finance_overview(self.c)['open_shifts'])
    def test_upgrade_keeps_existing_product_and_assigns_owner_permissions(self):
        app.create_product(self.c,{'sku':'KEEP-10','name':'Existing stock item',
            'packages':[{'unit_name':'strip','factor':1,'sale_price':2000,'is_default':1}]},self.uid)
        existing=app.one(self.c,'SELECT id,name FROM products WHERE sku=?',('KEEP-10',))
        perms=json.dumps(['catalog','users','stock','finance'])
        self.c.execute('UPDATE users SET permissions=? WHERE id=?',(perms,self.uid))
        self.c.execute('DROP TABLE supplier_price_references')
        self.c.execute('DROP TABLE catalog_imports')
        self.c.execute('PRAGMA user_version=8')
        self.c.close()
        app.init_db()
        self.c=app.db_connect()
        self.assertEqual(app.one(self.c,'SELECT id,name FROM products WHERE sku=?',('KEEP-10',)),existing)
        updated=json.loads(app.one(self.c,'SELECT permissions FROM users WHERE id=?',(self.uid,))['permissions'])
        self.assertIn('stock_adjust',updated)
        self.assertIn('shift_manage',updated)
        self.assertEqual(self.c.execute('PRAGMA user_version').fetchone()[0],9)
        self.assertTrue(list((app.DATA/'preupgrade-backups').glob('*.sqlite3')))

    def test_finance_labels_and_zero_ledger(self):
        r=app.finance_overview(self.c)
        self.assertEqual(r['summary']['cash_ledger'],0)
        self.assertIn('دفترية',r['bank_note'])
        self.assertIn('insurance_receivable',r['summary'])

if __name__=='__main__': unittest.main()
