"""Tests the real bundled ten-supplier catalog without touching existing pharmacy data."""
import tempfile,unittest
from pathlib import Path
from contextlib import closing
import app,preloaded_catalog

class PrefilledCatalogTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  self.old=(app.DATA,app.DB)
  app.DATA=Path(self.tmp.name);app.DB=app.DATA/'pharmacy.sqlite3'
  app.init_db()
 def tearDown(self):
  app.DATA,app.DB=self.old
  self.tmp.cleanup()
 def test_first_open_loads_master_not_inventory(self):
  app.init_db(preload_catalog=True)
  with closing(app.db_connect()) as c:
   self.assertEqual(c.execute('SELECT COUNT(*) FROM products').fetchone()[0],1867)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM packages').fetchone()[0],1867)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM lots').fetchone()[0],0)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM stock_moves').fetchone()[0],0)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM journals').fetchone()[0],0)
   self.assertEqual(c.execute('SELECT COALESCE(SUM(sale_price),0) FROM packages').fetchone()[0],0)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM supplier_price_references').fetchone()[0],1215)
   self.assertGreater(len(app.catalog(c)),1800)
 def test_repeat_startup_does_not_duplicate(self):
  app.init_db(preload_catalog=True)
  app.init_db(preload_catalog=True)
  with closing(app.db_connect()) as c:
   self.assertEqual(c.execute('SELECT COUNT(*) FROM products').fetchone()[0],1867)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM supplier_price_references').fetchone()[0],1215)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM prefilled_catalog_versions').fetchone()[0],1)
 def test_existing_catalog_price_and_stock_stay_untouched(self):
  with closing(app.db_connect()) as c:
   app.bootstrap(c,{'username':'owner','full_name':'المالك','password':'StrongUniquePassword2026'})
   r=app.create_product(c,{'sku':'OLD-001','name':'Alatrol Syrup',
          'packages':[{'unit_name':'زجاجة','factor':1,'sale_price':7500,'is_default':1}]},1)
   old_id=r['id'];pk=c.execute('SELECT id FROM packages WHERE product_id=?',(old_id,)).fetchone()[0]
   c.execute('INSERT INTO lots(product_id,batch,expiry,qty_base) VALUES(?,?,?,?)',(old_id,'LOT-KEPT','2030-01-01',5))
  app.init_db(preload_catalog=True)
  with closing(app.db_connect()) as c:
   self.assertEqual(c.execute('SELECT COUNT(*) FROM products').fetchone()[0],1867)
   self.assertEqual(c.execute('SELECT sale_price FROM packages WHERE id=?',(pk,)).fetchone()[0],7500)
   self.assertEqual(c.execute('SELECT qty_base FROM lots WHERE product_id=?',(old_id,)).fetchone()[0],5)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM products WHERE name=?',('Alatrol Syrup',)).fetchone()[0],1)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM lots').fetchone()[0],1)
   self.assertEqual(c.execute('SELECT SUM(sale_price) FROM packages WHERE product_id!=?',(old_id,)).fetchone()[0],0)

if __name__=='__main__':unittest.main()
