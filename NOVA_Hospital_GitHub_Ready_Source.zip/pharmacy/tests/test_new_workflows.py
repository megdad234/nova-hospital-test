import tempfile,unittest,sys,uuid
from pathlib import Path
from datetime import date,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
class ExtendedTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();app.DATA=Path(self.tmp.name);app.DB=app.DATA/'test.db';app.init_db();self.c=app.db_connect()
  app.bootstrap(self.c,{'username':'owner','full_name':'Owner','password':'LongPassword1234'})
  self.uid=app.one(self.c,'SELECT id FROM users')['id']
  self.pid=app.create_product(self.c,{'sku':'A','name':'Test Medicine','packages':[{'unit_name':'piece','factor':1,'barcode':'8881','sale_price':1000,'is_default':1},{'unit_name':'strip','factor':10,'barcode':'88810','sale_price':10000}]},self.uid)['id']
  self.pk=app.one(self.c,'SELECT id FROM packages WHERE product_id=? AND factor=1',(self.pid,))['id']
  self.supplier=app.create_party(self.c,{'name':'Supplier'},'supplier',self.uid)['id']
  self.partner=app.create_party(self.c,{'name':'Customer'},'customer',self.uid)['id']
  self.authority=app.create_party(self.c,{'name':'Judiciary'},'authority',self.uid)['id']
 def tearDown(self):self.c.close();self.tmp.cleanup()
 def purchase(self):
  return app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':'INV-1','items':[{'package_id':self.pk,'qty':200,'unit_cost':500,'received':200,'batch':'L1','expiry':(date.today()+timedelta(days=300)).isoformat()}]},self.uid)
 def sell(self,qty=10,cash=True,authority=False):
  kwargs={'items':[{'package_id':self.pk,'qty':qty}],'idempotency':uuid.uuid4().hex,'partner_id':self.partner}
  if authority:kwargs.update(authority_id=self.authority,coverage=90)
  if cash:kwargs['payments']=[{'method':'cash','amount':1000 if authority else qty*1000}]
  return app.sell(self.c,kwargs,self.uid)
 def test_supplier_overpayment_rejected(self):
  self.purchase()
  with self.assertRaisesRegex(ValueError,'أكبر من رصيد'):app.supplier_payment(self.c,{'supplier_id':self.supplier,'amount':100001,'method':'cash'},self.uid)
  self.assertEqual(app.supplier_balances(self.c)[0]['balance'],100000)
 def test_repeated_partial_return_tracks_lots(self):
  self.purchase();s=self.sell(10);sl=app.one(self.c,'SELECT id FROM sale_lines WHERE sale_id=?',(s['id'],))
  for _ in range(2):app.sale_return(self.c,{'sale_id':s['id'],'reason':'Return','items':[{'sale_line_id':sl['id'],'qty':3}],'refund_method':'cash'},self.uid)
  q=self.c.execute("SELECT SUM(qty_base) FROM lots WHERE status='quarantine'").fetchone()[0]
  self.assertEqual(q,6)
  alloc=self.c.execute('SELECT SUM(qty_base),SUM(cost) FROM return_allocations').fetchone()
  self.assertEqual(alloc[0],6);self.assertEqual(alloc[1],3000)
  self.assertTrue(app.report(self.c)['journals_balanced'])
 def test_inventory_adjustment_value_journal(self):
  self.purchase();lot=app.one(self.c,'SELECT batch,expiry FROM lots WHERE product_id=?',(self.pid,))
  app.stock_adjust(self.c,{'product_id':self.pid,'batch':lot['batch'],'expiry':lot['expiry'],'delta':-3,'reason':'Damaged'},self.uid)
  self.assertEqual(app.one(self.c,"SELECT SUM(debit) AS v FROM journals WHERE account='INVENTORY_LOSS'")['v'],1500)
  self.assertTrue(app.report(self.c)['journals_balanced'])
 def test_recurring_no_stock_reservation(self):
  self.purchase();start=app.catalog(self.c)[0]['available']
  r=app.recurring_create(self.c,{'partner_id':self.partner,'package_id':self.pk,'qty':10,'interval_days':30,'next_due':date.today().isoformat()},self.uid)
  self.assertEqual(app.catalog(self.c)[0]['available'],start)
  self.assertEqual(app.recurring_list(self.c)[0]['shortage_base'],0)
  with self.assertRaisesRegex(ValueError,'الفاتورة'):app.recurring_dispensed(self.c,{'plan_id':r['id'],'sale_id':999},self.uid)
  s=self.sell(10);app.recurring_dispensed(self.c,{'plan_id':r['id'],'sale_id':s['id']},self.uid)
  self.assertEqual(app.catalog(self.c)[0]['available'],start-10)
 def test_cash_shift_with_expense_and_sale(self):
  self.purchase();s=app.shift_open(self.c,{'opening_cash':2000},self.uid)
  self.sell(10);app.expense_create(self.c,{'category':'rent','description':'Utilities','amount':1000,'method':'cash'},self.uid)
  result=app.shift_close(self.c,{'actual_cash':11000},self.uid)
  self.assertEqual(result['variance'],0)
 def test_customer_credit_collection(self):
  self.purchase();sale=self.sell(10,cash=False)
  r=app.customer_payment(self.c,{'sale_id':sale['id'],'amount':3000,'method':'cash'},self.uid)
  self.assertEqual(r['remaining'],7000)
  with self.assertRaisesRegex(ValueError,'أكبر'):app.customer_payment(self.c,{'sale_id':sale['id'],'amount':8000,'method':'cash'},self.uid)
 def test_quote_anomaly_no_price_change(self):
  x=app.quote_preview(self.c,{'barcode':'88810','supplier_id':self.supplier,'supplier_price':5000})
  self.assertTrue(x['matched']);self.assertEqual(x['supplier_factor'],10)
  app.quote_save(self.c,{'barcode':'88810','supplier_id':self.supplier,'supplier_price':5000},self.uid)
  y=app.quote_preview(self.c,{'barcode':'88810','supplier_id':self.supplier,'supplier_price':12000})
  self.assertTrue(y['anomaly'])
  with self.assertRaisesRegex(ValueError,'مراجعة'):app.quote_save(self.c,{'barcode':'88810','supplier_id':self.supplier,'supplier_price':12000},self.uid)
  self.assertEqual(app.one(self.c,'SELECT sale_price FROM packages WHERE id=?',(self.pk,))['sale_price'],1000)
 def test_correction_prior_claim_carried_forward(self):
  self.purchase();s=self.sell(10,authority=True)
  period=date.today().strftime('%Y-%m')
  cl=app.claim_create(self.c,{'authority_id':self.authority,'period':period},self.uid)
  self.assertEqual(cl['total'],9000)
  a=app.coverage_correct(self.c,{'sale_id':s['id'],'coverage':80,'reason':'Covered eighty'},self.uid)
  self.assertEqual(a['covered_adjustment'],-1000)
  # next month, there are no new sales but a negative credit note; reject rather than silently corrupt claims.
  nxt=(date.today().replace(day=1)+timedelta(days=32)).replace(day=1).strftime('%Y-%m')
  with self.assertRaisesRegex(ValueError,'إشعار دائن'):app.claim_create(self.c,{'authority_id':self.authority,'period':nxt},self.uid)
  self.assertEqual(app.one(self.c,'SELECT total FROM claims WHERE id=?',(cl['id'],))['total'],9000)
  self.assertTrue(app.report(self.c)['journals_balanced'])
if __name__=='__main__':unittest.main()

class FinancialIntegrityTests(ExtendedTests):
 def test_supplier_return_reduces_payable(self):
  self.purchase()
  line=app.one(self.c,'SELECT id FROM purchase_lines LIMIT 1')
  r=app.purchase_return(self.c,{'purchase_line_id':line['id'],'qty':10,'reason':'Damaged'},self.uid)
  self.assertEqual(app.supplier_balances(self.c)[0]['balance'],100000-r['amount'])
  with self.assertRaisesRegex(ValueError,'أكبر من رصيد'):app.supplier_payment(self.c,{'supplier_id':self.supplier,'amount':100000,'method':'cash'},self.uid)
 def test_bank_verification_posts_journal_once(self):
  self.purchase()
  s=self.sell(10,cash=False)
  app.customer_payment(self.c,{'sale_id':s['id'],'amount':10000,'method':'bank','bank_ref':'BANK-X'},self.uid)
  payment=app.one(self.c,"SELECT id FROM payments WHERE method='bank' AND party_kind='customer'")
  app.bank_verify(self.c,{'payment_id':payment['id'],'note':'Matched bank statement'},self.uid)
  self.assertEqual(app.one(self.c,"SELECT SUM(debit) as x FROM journals WHERE account='BANK'")['x'],10000)
  with self.assertRaises(Exception):app.bank_verify(self.c,{'payment_id':payment['id'],'note':'Second time'},self.uid)
  self.assertTrue(app.report(self.c)['journals_balanced'])
 def test_bank_expense_reconciliation_outgoing(self):
  app.expense_create(self.c,{'category':'utilities','description':'Electricity','amount':3500,'method':'bank','bank_ref':'TR-2'},self.uid)
  pay=app.one(self.c,"SELECT id FROM payments WHERE party_kind='expense'")
  app.bank_verify(self.c,{'payment_id':pay['id'],'note':'Confirmed on statement'},self.uid)
  self.assertEqual(app.one(self.c,"SELECT SUM(credit) as x FROM journals WHERE account='BANK'")['x'],3500)
  self.assertTrue(app.report(self.c)['journals_balanced'])
 def test_same_sale_for_multiple_monthly_medicines(self):
  self.purchase()
  p=app.recurring_create(self.c,{'partner_id':self.partner,'package_id':self.pk,'qty':3,'interval_days':30,'next_due':date.today().isoformat()},self.uid)
  p2=app.recurring_create(self.c,{'partner_id':self.partner,'package_id':self.pk,'qty':4,'interval_days':30,'next_due':date.today().isoformat()},self.uid)
  s=self.sell(10)
  app.recurring_dispensed(self.c,{'plan_id':p['id'],'sale_id':s['id']},self.uid)
  app.recurring_dispensed(self.c,{'plan_id':p2['id'],'sale_id':s['id']},self.uid)
  self.assertEqual(app.catalog(self.c)[0]['available'],190)

class BackupAndReturnTests(ExtendedTests):
 def test_periodic_backup_is_consistent(self):
  self.purchase()
  x=app.automatic_backup_once(force=True)
  import sqlite3
  self.assertTrue(Path(x['file']).exists())
  db=sqlite3.connect(x['file'])
  self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
  db.close()
 def test_cash_refund_cannot_exceed_collected(self):
  self.purchase();s=self.sell(10,cash=False)
  line=app.one(self.c,'SELECT id FROM sale_lines WHERE sale_id=?',(s['id'],))
  with self.assertRaisesRegex(ValueError,'يتجاوز المبالغ المحصلة'):
   app.sale_return(self.c,{'sale_id':s['id'],'items':[{'sale_line_id':line['id'],'qty':1}],'reason':'Return','refund_method':'cash'},self.uid)
  self.assertFalse(app.one(self.c,'SELECT id FROM sale_returns LIMIT 1'))
