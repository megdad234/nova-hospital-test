import sys, unittest, uuid, tempfile
from pathlib import Path
from datetime import date,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app,erp_extensions_v06 as ext

class V06Fixture:
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();app.DATA=Path(self.t.name);app.DB=app.DATA/'db.sqlite3';app.init_db();self.c=app.db_connect()
  app.bootstrap(self.c,{'username':'admin','full_name':'Admin','password':'StrongAndPrivate123!'})
  self.uid=app.one(self.c,'SELECT id FROM users')['id']
  self.pid=app.create_product(self.c,{'sku':'001','name':'Medicine A','reorder_point':5,'packages':[{'unit_name':'strip','factor':10,'barcode':'B001','sale_price':3000,'is_default':1},{'unit_name':'box','factor':30,'barcode':'B003','sale_price':9000}]},self.uid)['id']
  self.strip=app.one(self.c,"SELECT id FROM packages WHERE barcode='B001'")['id']
  self.box=app.one(self.c,"SELECT id FROM packages WHERE barcode='B003'")['id']
  self.supplier=app.create_party(self.c,{'name':'Supplier One'},'supplier',self.uid)['id']
  self.authority=app.create_party(self.c,{'name':'Judiciary'},'authority',self.uid)['id']
  self.customer=app.create_party(self.c,{'name':'Test Customer'},'customer',self.uid)['id']
  self.otherpharmacy=app.create_party(self.c,{'name':'External'},'pharmacy',self.uid)['id']
  self.datefuture=(date.today()+timedelta(days=500)).isoformat()
 def tearDown(self):self.c.close();self.t.cleanup()
 def purchase(self):
  return app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':'INV1','items':[{'package_id':self.box,'qty':10,'received':10,'batch':'X001','expiry':self.datefuture,'unit_cost':6000}]},self.uid)
 def sale(self,coverage=0):
  return app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.strip,'qty':3}], 'partner_id':self.customer,
   'authority_id':self.authority if coverage else None,'coverage':coverage,'payments':[] if coverage==100 else [{'method':'cash','amount':9000*(100-coverage)//100}]},self.uid)
class V06Tests(V06Fixture,unittest.TestCase):
 def test_financial_profit_trial_balance(self):
  self.purchase();self.sale()
  r=ext.finance_statements(self.c,{})
  self.assertTrue(r['period_balanced']);self.assertEqual(r['income_summary']['revenue'],9000)
  self.assertGreater(r['income_summary']['net_profit_before_other_accounts'],0)
 def test_close_past_month_without_changing_data(self):
  d=(date.today().replace(day=1)-timedelta(days=1)).strftime('%Y-%m')
  r=ext.close_period(self.c,{'period':d,'reason':'تمت المراجعة'},self.uid)
  self.assertTrue(r['closed'])
  with self.assertRaisesRegex(ValueError,'مقفلة'):ext.close_period(self.c,{'period':d,'reason':'again'},self.uid)
 def test_insurance_submit_approve_partial_and_cap_payment(self):
  self.purchase();self.sale(100)
  cid=app.claim_create(self.c,{'authority_id':self.authority,'period':date.today().strftime('%Y-%m')},self.uid)['id']
  ext.insurance_submit(self.c,{'claim_id':cid},self.uid)
  r=ext.insurance_adjudicate(self.c,{'claim_id':cid,'approved_amount':7000,'reason':'رفض 2000'},self.uid)
  self.assertEqual(r['rejected'],2000)
  with self.assertRaisesRegex(ValueError,'المبلغ المعتمد'):app.claim_payment(self.c,{'claim_id':cid,'amount':7001,'method':'cash'},self.uid)
  app.claim_payment(self.c,{'claim_id':cid,'amount':7000,'method':'cash'},self.uid)
  self.assertEqual(app.one(self.c,'SELECT paid,status FROM claims WHERE id=?',(cid,))['status'],'paid')
  self.assertTrue(ext.finance_statements(self.c,{})['period_balanced'])
 def test_insurance_negative_credit_note_no_double_gl(self):
  self.purchase();self.sale(100)
  cid=app.claim_create(self.c,{'authority_id':self.authority,'period':date.today().strftime('%Y-%m')},self.uid)['id']
  corr=app.coverage_correct(self.c,{'sale_id':1,'coverage':90,'reason':'Coverage was wrong'},self.uid)
  old=len(app.query(self.c,'SELECT * FROM journals'))
  credit=ext.insurance_credit(self.c,{'adjustment_id':corr['id'],'reason':'Credit note'},self.uid)
  self.assertEqual(credit['amount'],900);self.assertEqual(len(app.query(self.c,'SELECT * FROM journals')),old)
  with self.assertRaises(Exception):ext.insurance_credit(self.c,{'adjustment_id':corr['id'],'reason':'Again'},self.uid)
 def test_price_preview_rounding_and_approval(self):
  payload={'mode':'current','markup_pct':'10','rounding':100,'direction':'nearest','package_ids':[self.strip,self.box]}
  pv=ext.price_batch_preview(self.c,payload)
  self.assertEqual(pv['changed'],2)
  r=[{'package_id':p['package_id'],'old_price':p['old_price'],'new_price':p['new_price'],'anomaly_ack':True} for p in pv['rows']]
  with self.assertRaisesRegex(ValueError,'الموافقة'):ext.price_batch_approve(self.c,{**payload,'reviewed_rows':r},self.uid)
  done=ext.price_batch_approve(self.c,{**payload,'reviewed_rows':r,'confirm':True},self.uid)
  self.assertEqual(done['updated'],2)
  self.assertEqual(app.one(self.c,'SELECT sale_price FROM packages WHERE id=?',(self.strip,))['sale_price'],3300)
  with self.assertRaisesRegex(ValueError,'تغير منذ المعاينة'):ext.price_batch_approve(self.c,{**payload,'reviewed_rows':r,'confirm':True},self.uid)
 def test_reject_sharp_price_change_without_ack(self):
  payload={'mode':'current','markup_pct':300,'rounding':100,'direction':'nearest','package_ids':[self.strip]}
  pv=ext.price_batch_preview(self.c,payload)
  self.assertEqual(pv['review_required'],1)
  rows=[{'package_id':self.strip,'old_price':3000,'new_price':12000}]
  with self.assertRaisesRegex(ValueError,'شاذ'):ext.price_batch_approve(self.c,{**payload,'reviewed_rows':rows,'confirm':True},self.uid)
  self.assertEqual(app.one(self.c,'SELECT sale_price FROM packages WHERE id=?',(self.strip,))['sale_price'],3000)
 def test_supplier_quote_converts_pack_to_strip(self):
  app.quote_save(self.c,{'supplier_id':self.supplier,'package_id':self.strip,'supplier_pack_factor':30,'confirmed_review':True,'supplier_price':9000},self.uid)
  r=ext.price_batch_preview(self.c,{'mode':'supplier','markup_pct':30,'rounding':100,'direction':'nearest','package_ids':[self.strip]})
  self.assertEqual(r['rows'][0]['new_price'],3900)
 def test_reorder_never_reserves_stock(self):
  self.purchase();self.sale()
  r=ext.reorder_suggestions(self.c,{'history_days':30,'lead_days':7,'cover_days':30})
  self.assertEqual(len(r['items']),1)
  self.assertTrue(r['no_stock_reserved'])
  self.assertEqual(app.catalog(self.c)[0]['available'],270)
 def test_pharmacy_exchange_netting_and_settlement(self):
  self.purchase()
  r=app.pharmacy_exchange(self.c,{'partner_id':self.otherpharmacy,'out_package_id':self.strip,'out_qty':3,
      'in_package_id':self.strip,'in_qty':1,'in_batch':'Z2','in_expiry':self.datefuture,'out_value':10000,'in_value':3000},self.uid)
  self.assertEqual(ext.pharmacy_balance(self.c,self.otherpharmacy),7000)
  res=ext.pharmacy_settle(self.c,{'partner_id':self.otherpharmacy,'amount':4000,'method':'cash'},self.uid)
  self.assertEqual(res['remaining'],3000)
  ext.pharmacy_settle(self.c,{'partner_id':self.otherpharmacy,'amount':3000,'method':'cash'},self.uid)
  self.assertEqual(ext.pharmacy_balance(self.c,self.otherpharmacy),0)
  self.assertEqual(app.one(self.c,"SELECT COALESCE(SUM(debit-credit),0) n FROM journals WHERE account='AR_PHARMACY'")['n'],0)
  self.assertEqual(app.one(self.c,"SELECT COALESCE(SUM(credit-debit),0) n FROM journals WHERE account='AP_PHARMACY'")['n'],0)
 def test_no_excel_import_or_price_suggestion_mutates_inventory(self):
  first=app.catalog(self.c)[0]['available']
  ext.reorder_suggestions(self.c,{})
  ext.price_batch_preview(self.c,{'mode':'current','markup_pct':30,'rounding':100,'package_ids':[self.strip]})
  self.assertEqual(app.catalog(self.c)[0]['available'],first)

if __name__=='__main__':unittest.main()

class V06ExceptionalOperations(V06Fixture,unittest.TestCase):
 def test_return_late_receipt_specific_batch(self):
  r=app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':'LATE','items':[{'package_id':self.box,'qty':5,'received':1,'unit_cost':6000,'batch':'EARLY','expiry':self.datefuture}]},self.uid)
  line=app.one(self.c,'SELECT id FROM purchase_lines WHERE purchase_id=?',(r['id'],))['id']
  app.purchase_receipt(self.c,{'purchase_line_id':line,'qty':2,'batch':'LATER','expiry':self.datefuture},self.uid)
  r=app.purchase_return(self.c,{'purchase_line_id':line,'qty':1,'batch':'LATER','reason':'Damaged'},self.uid)
  self.assertEqual(r['amount'],6000)
  self.assertEqual(app.one(self.c,"SELECT qty_base FROM lots WHERE batch='LATER'")['qty_base'],30)
  self.assertTrue(app.integrity_review(self.c)['passed'])
 def test_claimed_sale_return_credit_and_payment_cap(self):
  self.purchase();sale=self.sale(100)
  cid=app.claim_create(self.c,{'authority_id':self.authority,'period':date.today().strftime('%Y-%m')},self.uid)['id']
  line=app.one(self.c,'SELECT id FROM sale_lines WHERE sale_id=?',(sale['id'],))['id']
  r=app.sale_return(self.c,{'sale_id':sale['id'],'items':[{'sale_line_id':line,'qty':1}],'reason':'Returned'},self.uid)
  note=app.one(self.c,'SELECT * FROM insurance_return_credit_notes WHERE sale_return_id=?',(r['id'],))
  self.assertEqual(note['amount'],3000)
  with self.assertRaisesRegex(ValueError,'المبلغ المعتمد'):app.claim_payment(self.c,{'claim_id':cid,'amount':9000,'method':'cash'},self.uid)
  app.claim_payment(self.c,{'claim_id':cid,'amount':6000,'method':'cash'},self.uid)
  self.assertTrue(ext.finance_statements(self.c,{})['period_balanced'])
 def test_supplier_credit_uses_invoice_value_not_avg_stock_cost(self):
  self.purchase()
  # same lot, different supplier invoice price -> avg valuation changes
  app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':'INV2','items':[{'package_id':self.box,'qty':2,'unit_cost':9000,'received':2,'batch':'X001','expiry':self.datefuture}]},self.uid)
  line=app.one(self.c,"SELECT pl.id FROM purchase_lines pl JOIN purchases pu ON pu.id=pl.purchase_id WHERE pu.invoice_ref='INV2'")['id']
  r=app.purchase_return(self.c,{'purchase_line_id':line,'qty':1,'reason':'Supplier recall'},self.uid)
  self.assertEqual(r['amount'],9000)
  self.assertNotEqual(r['inventory_value'],9000)
  self.assertTrue(ext.finance_statements(self.c,{})['period_balanced'])
 def test_customer_receivable_after_coverage_change_no_double_subtraction(self):
  self.purchase()
  sale=app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.strip,'qty':3}],
      'partner_id':self.customer,'authority_id':self.authority,'coverage':50,'payments':[]},self.uid)
  app.coverage_correct(self.c,{'sale_id':sale['id'],'coverage':60,'reason':'New benefit verified'},self.uid)
  r=app.customer_payment(self.c,{'sale_id':sale['id'],'amount':3600,'method':'cash'},self.uid)
  self.assertEqual(r['remaining'],0)
  with self.assertRaises(ValueError):app.customer_payment(self.c,{'sale_id':sale['id'],'amount':1,'method':'cash'},self.uid)
 def test_duplicate_return_lines_rollback(self):
  self.purchase();sale=self.sale()
  line=app.one(self.c,'SELECT id FROM sale_lines WHERE sale_id=?',(sale['id'],))['id']
  with self.assertRaisesRegex(ValueError,'تكرر'):
   app.sale_return(self.c,{'sale_id':sale['id'],'reason':'wrong','items':[{'sale_line_id':line,'qty':1},{'sale_line_id':line,'qty':1}]},self.uid)
  self.assertIsNone(app.one(self.c,'SELECT id FROM sale_returns LIMIT 1'))

class V06SafetyRules(V06Fixture,unittest.TestCase):
 def test_manual_extreme_price_requires_ack_even_if_preview_normal(self):
  payload={'mode':'current','markup_pct':10,'rounding':100,'package_ids':[self.strip]}
  preview=ext.price_batch_preview(self.c,payload)
  with self.assertRaisesRegex(ValueError,'شاذ'):
   ext.price_batch_approve(self.c,{**payload,'confirm':True,'reviewed_rows':[
    {'package_id':self.strip,'old_price':3000,'new_price':1000000}]},self.uid)
  self.assertEqual(app.one(self.c,'SELECT sale_price FROM packages WHERE id=?',(self.strip,))['sale_price'],3000)
 def test_supplier_quote_changed_after_preview_rejected(self):
  app.quote_save(self.c,{'supplier_id':self.supplier,'package_id':self.strip,'supplier_pack_factor':30,'supplier_price':9000,'confirmed_review':True},self.uid)
  payload={'mode':'supplier','markup_pct':30,'rounding':100,'package_ids':[self.strip]}
  preview=ext.price_batch_preview(self.c,payload)
  first=preview['rows'][0]
  app.quote_save(self.c,{'supplier_id':self.supplier,'package_id':self.strip,'supplier_pack_factor':30,'supplier_price':9500,'confirmed_review':True},self.uid)
  with self.assertRaisesRegex(ValueError,'عرض المورد تغير'):
   ext.price_batch_approve(self.c,{**payload,'confirm':True,'reviewed_rows':[
    {'package_id':self.strip,'old_price':first['old_price'],'new_price':first['new_price'],'supplier_quote_id':first['supplier_quote_id'],'anomaly_ack':True}]},self.uid)
 def test_reorder_excludes_stock_expiring_before_target(self):
  expiry=(date.today()+timedelta(days=3)).isoformat()
  app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':'SHORT','items':[
   {'package_id':self.box,'qty':3,'received':3,'batch':'SHORT','expiry':expiry,'unit_cost':6000}]},self.uid)
  result=ext.reorder_suggestions(self.c,{'history_days':30,'lead_days':7,'cover_days':30})['items'][0]
  self.assertEqual(result['available_base'],90)
  self.assertEqual(result['usable_until_horizon_base'],0)
  self.assertGreater(result['needed_base'],0)

class V06FinancialReporting(V06Fixture,unittest.TestCase):
 def test_expense_and_stock_loss_in_profit_statement(self):
  self.purchase()
  before=ext.finance_statements(self.c,{})['income_summary']['net_profit_before_other_accounts']
  app.expense_create(self.c,{'category':'electricity','description':'Monthly power','amount':500,'method':'cash'},self.uid)
  after=ext.finance_statements(self.c,{})['income_summary']['net_profit_before_other_accounts']
  self.assertEqual(before-after,500)
  app.stock_adjust(self.c,{'product_id':self.pid,'batch':'X001','expiry':self.datefuture,'delta':-1,'reason':'Damaged'},self.uid)
  self.assertLess(ext.finance_statements(self.c,{})['income_summary']['net_profit_before_other_accounts'],after)
  self.assertTrue(ext.finance_statements(self.c,{})['period_balanced'])
