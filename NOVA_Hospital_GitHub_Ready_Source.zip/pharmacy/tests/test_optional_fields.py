"""Receipt safety: optional fields must not collapse manufacturer-untracked lots."""
import sys,tempfile,unittest,uuid
from datetime import date,timedelta
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app,opening_inventory

EXP=(date.today()+timedelta(days=420)).isoformat()

class OptionalFieldsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.old=(app.DB,app.DATA)
        app.DATA=Path(self.tmp.name);app.DB=app.DATA/'pharmacy.sqlite3'
        app.init_db();self.c=app.db_connect()
        app.bootstrap(self.c,{'username':'chief','full_name':'Pharmacy Owner','password':'LongPasswordForTests2026'})
        self.uid=app.one(self.c,'SELECT id FROM users LIMIT 1')['id']
        self.pid=app.create_product(self.c,{'sku':'MED-1','name':'Test Medicines 100mg',
            'packages':[{'unit_name':'strip','factor':10,'barcode':'TEST-001','sale_price':5000,'is_default':1}]},self.uid)['id']
        self.pkid=app.one(self.c,'SELECT id FROM packages WHERE product_id=?',(self.pid,))['id']
        self.supplier=app.create_party(self.c,{'name':'A supplier'},'supplier',self.uid)['id']
    def tearDown(self):
        self.c.close();app.DB,app.DATA=self.old;self.tmp.cleanup()
    def buy(self,**overrides):
        row={'package_id':self.pkid,'qty':2,'received':2,'unit_cost':2000,'expiry':EXP}
        row.update(overrides)
        return app.purchase(self.c,{'supplier_id':self.supplier,'items':[row]},self.uid)
    def test_batch_and_supplier_invoice_number_are_optional(self):
        first=self.buy()
        second=self.buy()
        purchases=app.query(self.c,'SELECT invoice_ref FROM purchases ORDER BY id')
        self.assertNotEqual(purchases[0]['invoice_ref'],purchases[1]['invoice_ref'])
        self.assertTrue(all(x['invoice_ref'].startswith('LOCAL-') for x in purchases))
        original=app.query(self.c,'SELECT batch FROM purchase_lines ORDER BY id')
        self.assertEqual([x['batch'] for x in original],['',''])
        lots=app.query(self.c,"SELECT id,batch,qty_base FROM lots WHERE status='sellable' ORDER BY id")
        self.assertEqual(len(lots),2)
        self.assertTrue(all(x['batch'].startswith('UNRECORDED-PUR-') for x in lots))
        self.assertNotEqual(lots[0]['batch'],lots[1]['batch'])
        self.assertEqual(app.catalog(self.c)[0]['available'],40)
        self.assertTrue(app.integrity_review(self.c)['passed'])
        self.assertEqual(first['outstanding'],4000)
        self.assertEqual(second['outstanding'],4000)
    def test_manual_batch_still_merges_same_real_batch(self):
        self.buy(batch='REAL-MANUFACTURER-BATCH')
        self.buy(batch='REAL-MANUFACTURER-BATCH')
        lots=app.query(self.c,"SELECT batch,qty_base FROM lots WHERE status='sellable'")
        self.assertEqual(len(lots),1)
        self.assertEqual(lots[0]['qty_base'],40)
    def test_expiry_is_required_for_received_stock_and_atomic(self):
        with self.assertRaisesRegex(ValueError,'الصلاحية'):
            self.buy(expiry='')
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM purchases')['n'],0)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM lots')['n'],0)
    def test_unreceived_items_can_have_no_batch_or_expiry(self):
        result=self.buy(received=0,expiry='')
        self.assertEqual(result['total'],4000)
        self.assertEqual(app.one(self.c,'SELECT COUNT(*) n FROM lots')['n'],0)
    def test_late_receipt_batch_optional_without_merging(self):
        self.buy(received=0,expiry='')
        line=app.one(self.c,'SELECT id FROM purchase_lines')['id']
        r=app.purchase_receipt(self.c,{'purchase_line_id':line,'qty':1,'expiry':EXP},self.uid)
        lot=app.one(self.c,'SELECT batch,qty_base FROM lots')
        self.assertEqual(lot['qty_base'],10)
        self.assertTrue(lot['batch'].startswith('UNRECORDED-REC-'))
        self.assertEqual(app.one(self.c,'SELECT received FROM purchase_lines')['received'],1)
    def test_opening_import_without_batch_column_or_batch_value(self):
        header=['sku','name','barcode','unit_name','factor','base_uom','quantity','expiry','unit_cost','sale_price']
        row=['MED-2','Other Product','TEST-002','strip','10','tablet','3',EXP,'1300','2500']
        result=opening_inventory.import_stock(self.c,[header,row],self.uid,'REQ'+uuid.uuid4().hex)
        self.assertEqual(result['total_value'],3900)
        lot=app.one(self.c,'SELECT batch,qty_base FROM lots WHERE product_id!=(?)',(self.pid,))
        self.assertTrue(lot['batch'].startswith('UNRECORDED-OPEN-'))
        self.assertEqual(lot['qty_base'],30)
        self.assertTrue(app.integrity_review(self.c)['passed'])
    def test_exchange_incoming_batch_can_be_blank_with_trace_id(self):
        self.buy(batch='REAL-BATCH')
        partner=app.create_party(self.c,{'name':'Other pharmacy'},'pharmacy',self.uid)['id']
        result=app.pharmacy_exchange(self.c,{'partner_id':partner,
             'out_package_id':self.pkid,'out_qty':1,'out_value':5000,
             'in_package_id':self.pkid,'in_qty':1,'in_value':4000,
             'in_expiry':EXP},self.uid)
        self.assertTrue(result['id']>0)
        lot=app.one(self.c,"SELECT batch FROM lots WHERE batch LIKE 'UNRECORDED-EXC-%'")
        self.assertTrue(lot['batch'].startswith('UNRECORDED-EXC-'))
        self.assertEqual(app.catalog(self.c)[0]['available'],20)
        self.assertTrue(app.report(self.c)['journals_balanced'])

    def test_unknown_batches_are_still_sale_allocated_and_costed(self):
        self.buy()
        sold=app.sell(self.c,{'items':[{'package_id':self.pkid,'qty':1}],
                 'idempotency':uuid.uuid4().hex,'payments':[{'method':'cash','amount':5000}]},self.uid)
        self.assertEqual(sold['total'],5000)
        self.assertEqual(app.catalog(self.c)[0]['available'],10)
        self.assertTrue(app.report(self.c)['journals_balanced'])

if __name__=='__main__':unittest.main()
