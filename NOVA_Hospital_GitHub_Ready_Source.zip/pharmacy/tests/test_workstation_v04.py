import os,sys,json,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from desktop import validate_server_url,read_config
import device_services

class WorkstationConfigurationTest(unittest.TestCase):
    def test_loopback_and_tls(self):
        self.assertEqual('',validate_server_url(''))
        self.assertEqual('http://127.0.0.1:8080', validate_server_url('http://127.0.0.1:8080/'))
        self.assertEqual('https://pharmacy.hospital.local:8443',validate_server_url('https://pharmacy.hospital.local:8443'))
    def test_bad_server_addresses(self):
        for u in ['http://192.168.1.99:8080','http://example.com:80', 'ftp://example.com:12', 'https://user:secret@server:8443','https://server:8443/private','https://server']:
            with self.subTest(u=u),self.assertRaises(ValueError):validate_server_url(u)
    def test_printer_settings(self):
        with tempfile.TemporaryDirectory() as d:
            old=os.environ.get('LOCALAPPDATA')
            try:
                os.environ['LOCALAPPDATA']=d
                self.assertEqual('thermal80',device_services.load_settings()['paper'])
                device_services.save_settings('thermal58','')
                self.assertEqual('thermal58',device_services.load_settings()['paper'])
                with self.assertRaises(ValueError):device_services.save_settings('bad','')
                self.assertTrue((Path(d)/'HospitalPharmacyERP'/'workstation.json').exists())
            finally:
                if old is None:os.environ.pop('LOCALAPPDATA',None)
                else:os.environ['LOCALAPPDATA']=old

if __name__=='__main__': unittest.main()
