"""Invariant tests: opening stock is atomic, non-duplicating and backup can roundtrip."""
import tempfile,unittest,sqlite3
from pathlib import Path
from datetime import date,timedelta
from contextlib import closing
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app,opening_inventory,recovery

HEADERS=['sku','name','barcode','unit_name','factor','base_uom','quantity','batch','expiry','unit_cost','sale_price','generic_name','manufacturer']
EXP=(date.today()+timedelta(days=540)).isoformat()
def stock_row(sku='A1',unit='شريط',factor='10',qty='3',barcode='9988001',batch='X1',cost='1200',sale='2000'):
    return [sku,'Para 500',barcode,unit,factor,'حبة',qty,batch,EXP,cost,sale,'Paracetamol','Producer']

class OpeningTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.old=(app.DATA,app.DB)
        app.DATA=Path(self.t.name);app.DB=app.DATA/'pharmacy.sqlite3';app.init_db()
        self.c=app.db_connect()
        app.bootstrap(self.c,{'username':'owner','full_name':'Owner','password':'MyLongPassword1234!'})
        self.uid=app.one(self.c,'SELECT id FROM users LIMIT 1')['id']
    def tearDown(self):
        self.c.close();app.DATA,app.DB=self.old;self.t.cleanup()
    def _import(self,rows,token='OPENINGTOKEN1234567890'):
        return opening_inventory.import_stock(self.c,[HEADERS,*rows],self.uid,token)
    def test_create_product_lot_and_ledger(self):
        r=self._import([stock_row()]);self.assertEqual(r['total_value'],3600)
        p=app.catalog(self.c)[0];self.assertEqual(p['available'],30)
        self.assertEqual(p['packages'][0]['barcode'],'9988001')
        self.assertTrue(app.integrity_review(self.c)['passed'])
        self.assertEqual(app.one(self.c,"SELECT SUM(debit) AS n FROM journals WHERE account='INVENTORY'")['n'],3600)
        self.assertEqual(app.one(self.c,"SELECT SUM(credit) AS n FROM journals WHERE account='OPENING_EQUITY'")['n'],3600)
    def test_multiple_packages_multiple_batches(self):
        rows=[stock_row(),stock_row(unit='علبة',factor='30',qty='2',barcode='9988002',batch='X2',cost='3000',sale='5000')]
        self._import(rows)
        self.assertEqual(app.catalog(self.c)[0]['available'],90)
        self.assertEqual(len(app.catalog(self.c)[0]['packages']),2)
        self.assertTrue(app.integrity_review(self.c)['passed'])
    def test_repeated_import_never_doubles_stock(self):
        self._import([stock_row()])
        with self.assertRaisesRegex(ValueError,'قبل كدا'):self._import([stock_row()],'SECONDIMPORTTOKEN1234')
        self.assertEqual(app.catalog(self.c)[0]['available'],30)
    def test_invalid_row_aborts_whole_import(self):
        preview=opening_inventory.validate(self.c,[HEADERS,stock_row(),stock_row(sku='B1',barcode='9988003',qty='0')])
        self.assertEqual(preview['invalid'],1)
        with self.assertRaises(ValueError):self._import([stock_row(),stock_row(sku='B1',barcode='9988003',qty='0')])
        self.assertEqual(len(app.catalog(self.c)),0)
        self.assertEqual(len(app.query(self.c,'SELECT * FROM journals')),0)
    def test_opening_rejected_after_product_sold(self):
        self._import([stock_row()])
        package=app.one(self.c,'SELECT id FROM packages')['id']
        app.sell(self.c,{'idempotency':'DEMO111111111','items':[{'package_id':package,'qty':1}],'payments':[{'method':'cash','amount':2000}]},self.uid)
        with self.assertRaisesRegex(ValueError,'تحتاج تصحيح'):
            self._import([stock_row(qty='1',batch='X3')],'THIRDIMPORTTOKEN1234')
        self.assertEqual(app.catalog(self.c)[0]['available'],20)
    def test_same_barcode_two_products_cannot_commit(self):
        preview=opening_inventory.validate(self.c,[HEADERS,stock_row(),stock_row(sku='A2')])
        self.assertTrue(preview['invalid'])
        with self.assertRaises(ValueError):self._import([stock_row(),stock_row(sku='A2')])
        self.assertEqual(len(app.catalog(self.c)),0)
    def test_external_backup_verified_and_restorable(self):
        self._import([stock_row()]);backup=app.DATA/'usb'/'snapshot.sqlite3'
        recovery.copy_verified(app.DB,backup)
        self.assertTrue(recovery.validate_backup(backup)['sha256'])
        p=app.one(self.c,'SELECT id FROM products LIMIT 1')['id']
        app.stock_adjust(self.c,{'product_id':p,'batch':'X1','expiry':EXP,'delta':-3,'reason':'Damage'},self.uid)
        self.assertEqual(app.catalog(self.c)[0]['available'],27)
        # Close the transaction and all handles before restoring, as required on Windows.
        self.c.close()
        result=recovery.restore_backup(backup,app.DB)
        self.assertTrue(result['verified'])
        self.assertTrue(Path(result['previous_backup']).exists())
        self.c=app.db_connect()
        self.assertEqual(app.catalog(self.c)[0]['available'],30)
        self.assertTrue(app.integrity_review(self.c)['passed'])
    def test_rx_sale_requires_pharmacist_confirmation_and_audit(self):
        self._import([stock_row()])
        prod=app.one(self.c,'SELECT id FROM products')['id']
        self.c.execute('UPDATE products SET rx_required=1 WHERE id=?',(prod,))
        pk=app.one(self.c,'SELECT id FROM packages')['id']
        data={'idempotency':'RxPrescriptSale12345678','items':[{'package_id':pk,'qty':1}],
              'payments':[{'method':'cash','amount':2000}]}
        with self.assertRaisesRegex(ValueError,'تأكيد الصيدلي'):
            app.sell(self.c,data,self.uid)
        self.assertEqual(app.catalog(self.c)[0]['available'],30)
        result=app.sell(self.c,{**data,'prescription':{'prescriber':'Dr X','reference':'RX-100','confirmed':True}},self.uid)
        row=app.one(self.c,'SELECT * FROM sale_prescriptions WHERE sale_id=?',(result['id'],))
        self.assertEqual(row['prescription_ref'],'RX-100')
        self.assertEqual(app.catalog(self.c)[0]['available'],20)
        # A cashier's sale permission alone must not authorize prescription verification.
        user=app.one(self.c,'SELECT id FROM users')['id']
        self.c.execute('UPDATE users SET permissions=? WHERE id=?',(' ["sale"] ',user))
        with self.assertRaises(PermissionError):
            app.sell(self.c,{**data,'idempotency':'DifferentSale123456789',
               'prescription':{'prescriber':'Dr X','reference':'RX-101','confirmed':True}},self.uid)

    def test_checksum_tampering_rejected(self):
        self._import([stock_row()]);bk=app.DATA/'usb'/'snapshot.sqlite3';recovery.copy_verified(app.DB,bk)
        with bk.open('ab') as f:f.write(b'garbage')
        with self.assertRaisesRegex(ValueError,'بصمة'):recovery.validate_backup(bk)

if __name__=='__main__':unittest.main()
