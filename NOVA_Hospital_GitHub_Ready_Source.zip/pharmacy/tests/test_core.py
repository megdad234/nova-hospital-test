import os,sys,tempfile,unittest,uuid,sqlite3,threading
from datetime import date,timedelta
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
class IntegrationTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();app.DATA=Path(self.tmp.name);app.DB=app.DATA/'test.sqlite3';app.init_db();self.c=app.db_connect()
  app.bootstrap(self.c,{'username':'boss','full_name':'مدير تجريبي','password':'LongTestPassword123'})
  self.uid=app.one(self.c,'SELECT id FROM users')['id']
  self.pid=app.create_product(self.c,{'sku':'SKU123','name':'Test Pharma 500 mg','base_uom':'حبة','packages':[{'unit_name':'حبة','factor':1,'barcode':'77701','sale_price':2000,'is_default':1},{'unit_name':'شريط','factor':10,'barcode':'77710','sale_price':19000},{'unit_name':'علبة','factor':30,'barcode':'77730','sale_price':55000}]},self.uid)['id']
  self.packages=app.query(self.c,'SELECT * FROM packages WHERE product_id=? ORDER BY factor',(self.pid,))
  self.supplier=app.create_party(self.c,{'name':'Meds Corp'},'supplier',self.uid)['id']
  self.authority=app.create_party(self.c,{'name':'Judiciary'},'authority',self.uid)['id']
  self.customer=app.create_party(self.c,{'name':'Test customer'},'customer',self.uid)['id']
 def tearDown(self):self.c.close();self.tmp.cleanup()
 def purchase(self,ref='A-01',received=2,qty=2):
  return app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':ref,'items':[{'package_id':self.packages[2]['id'],'qty':qty,'received':received,'unit_cost':40000,'bonus':0,'batch':'LOT-1','expiry':(date.today()+timedelta(days=400)).isoformat()}]},self.uid)
 def test_purchase_barcode_sale_in_pieces(self):
  self.purchase();p=app.catalog(self.c)[0];self.assertEqual(p['available'],60)
  barcodes={k['barcode']:k['factor'] for k in p['packages']};self.assertEqual(barcodes,{'77701':1,'77710':10,'77730':30})
  result=app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.packages[1]['id'],'qty':2}],'payments':[{'method':'cash','amount':38000}]},self.uid)
  self.assertEqual(app.catalog(self.c)[0]['available'],40)
  self.assertEqual(result['total'],38000)
  self.assertEqual(sum(x['debit'] for x in app.report(self.c)['accounts']),sum(x['credit'] for x in app.report(self.c)['accounts']))
 def test_atomic_insufficient_inventory(self):
  self.purchase();before=len(app.query(self.c,'SELECT * FROM sales'))
  with self.assertRaisesRegex(ValueError,'الرصيد'):app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.packages[2]['id'],'qty':3}],'payments':[{'method':'cash','amount':165000}]},self.uid)
  self.assertEqual(app.catalog(self.c)[0]['available'],60)
  self.assertEqual(before,len(app.query(self.c,'SELECT * FROM sales')))
 def test_idempotent_sale(self):
  self.purchase();token=uuid.uuid4().hex
  p={'idempotency':token,'items':[{'package_id':self.packages[2]['id'],'qty':1}],'payments':[{'method':'cash','amount':55000}]}
  app.sell(self.c,p,self.uid);r=app.sell(self.c,p,self.uid)
  self.assertTrue(r['duplicate']);self.assertEqual(app.catalog(self.c)[0]['available'],30)
 def test_rejected_duplicate_purchase(self):
  self.purchase()
  with self.assertRaises(sqlite3.IntegrityError):self.purchase()
  self.assertEqual(app.catalog(self.c)[0]['available'],60)
 def test_claims_and_no_double_claim(self):
  self.purchase();sale=app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.packages[2]['id'],'qty':1}],'authority_id':self.authority,'partner_id':self.customer,'coverage':90,'payments':[{'method':'bank','amount':5500,'ref':'XYZ123'}]},self.uid)
  self.assertEqual(sale['covered'],49500)
  cl=app.claim_create(self.c,{'authority_id':self.authority,'period':date.today().isoformat()[:7]},self.uid)
  self.assertEqual(cl['total'],49500)
  with self.assertRaisesRegex(ValueError,'موجودة'):app.claim_create(self.c,{'authority_id':self.authority,'period':date.today().isoformat()[:7]},self.uid)
  app.claim_payment(self.c,{'claim_id':cl['id'],'amount':20000,'method':'bank','bank_ref':'TX100'},self.uid)
  self.assertEqual(app.one(self.c,'SELECT paid FROM claims WHERE id=?',(cl['id'],))['paid'],20000)
 def test_returns_quarantine(self):
  self.purchase();sale=app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.packages[1]['id'],'qty':2}],'payments':[{'method':'cash','amount':38000}]},self.uid)
  line=app.one(self.c,'SELECT id FROM sale_lines WHERE sale_id=?',(sale['id'],))
  result=app.sale_return(self.c,{'sale_id':sale['id'],'items':[{'sale_line_id':line['id'],'qty':1}],'reason':'تالف'},self.uid)
  self.assertEqual(result['amount'],19000)
  self.assertEqual(app.catalog(self.c)[0]['available'],40) # returns NOT sellable
  self.assertEqual(app.one(self.c,'SELECT SUM(qty_base) as n FROM lots WHERE status=?',('quarantine',))['n'],10)
  with self.assertRaisesRegex(ValueError,'يتجاوز'):app.sale_return(self.c,{'sale_id':sale['id'],'items':[{'sale_line_id':line['id'],'qty':2}],'reason':'محاولة تكرار'},self.uid)
 def test_partial_receipt_never_overstates_stock(self):
  p=self.purchase('AB',received=1,qty=3)
  self.assertEqual(app.catalog(self.c)[0]['available'],30)
  self.assertEqual(p['total'],120000)
 def test_save_price_does_not_change_past_receipt(self):
  self.purchase();sale=app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.packages[2]['id'],'qty':1}],'payments':[{'method':'cash','amount':55000}]},self.uid)
  app.price_update(self.c,{'items':[{'package_id':self.packages[2]['id'],'price':80000}]},self.uid)
  self.assertEqual(app.one(self.c,'SELECT total FROM sales WHERE id=?',(sale['id'],))['total'],55000)
  self.assertEqual(app.catalog(self.c)[0]['available'],30)
 def test_online_backup_integrity(self):
  self.purchase();res=app.backup(self.c,self.uid);bk=sqlite3.connect(res['file']);self.assertEqual(bk.execute('PRAGMA integrity_check').fetchone()[0],'ok');bk.close()
 def test_concurrent_stock_no_negative(self):
  self.purchase();results=[]
  def run():
   c=app.db_connect()
   try:
    results.append(app.sell(c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.packages[2]['id'],'qty':2}],'payments':[{'method':'cash','amount':110000}]},self.uid))
   except Exception as e:results.append(e)
   finally:c.close()
  t1=threading.Thread(target=run);t2=threading.Thread(target=run);t1.start();t2.start();t1.join();t2.join()
  self.assertEqual(sum(isinstance(x,dict) for x in results),1)
  self.assertEqual(app.catalog(self.c)[0]['available'],0)
 def test_import_xlsx_stdlib(self):
  import openpyxl,io
  f=openpyxl.Workbook();ws=f.active;ws.append(['Barcode','Qty','Price']);ws.append(['77730',2,40000]);buf=io.BytesIO();f.save(buf)
  r=app.read_invoice_file(buf.getvalue(),'a.xlsx');self.assertEqual(r[1],['77730','2','40000'])
if __name__=='__main__':unittest.main(verbosity=2)
