import sys,tempfile,unittest,uuid
from pathlib import Path
from datetime import date,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app

class V05WorkflowTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();app.DATA=Path(self.t.name);app.DB=app.DATA/'test.sqlite3';app.init_db();self.c=app.db_connect()
  app.bootstrap(self.c,{'username':'owner','full_name':'Owner','password':'StrongUserPassword1234'})
  self.uid=app.one(self.c,'SELECT id FROM users')['id']
  self.product=app.create_product(self.c,{'sku':'DR001','name':'Medicine X 500mg','packages':[{'unit_name':'حبة','factor':1,'barcode':'712111','sale_price':200,'is_default':0},{'unit_name':'شريط','factor':10,'barcode':'712222','sale_price':2000,'is_default':1},{'unit_name':'علبة','factor':30,'barcode':'712333','sale_price':6000,'is_default':0}]},self.uid)['id']
  self.pkg=app.one(self.c,"SELECT id FROM packages WHERE barcode='712222'")['id']
  self.supplier=app.create_party(self.c,{'name':'Supplier'},'supplier',self.uid)['id']
  self.insurer=app.create_party(self.c,{'name':'Insurance Company'},'authority',self.uid)['id']
  self.member=app.create_party(self.c,{'name':'Judge Member'},'customer',self.uid)['id']
 def tearDown(self):self.c.close();self.t.cleanup()
 def create_contract(self,**kwargs):
  r={'authority_id':self.insurer,'code':'INS2026','coverage_default':100,'starts':date.today().isoformat()}
  r.update(kwargs)
  return app.insurance_contract_create(self.c,r,self.uid)['id']
 def add_stock(self):
  app.purchase(self.c,{'supplier_id':self.supplier,'invoice_ref':'B-100','items':[{'package_id':self.pkg,'qty':10,'unit_cost':1000,'received':10,'batch':'BT001','expiry':(date.today()+timedelta(days=300)).isoformat()}]},self.uid)
 def test_contract_member_and_coverage_unrestricted(self):
  cid=self.create_contract()
  mid=app.insurance_member_create(self.c,{'contract_id':cid,'partner_id':self.member,'relation':'الأصل','coverage_override':90},self.uid)['id']
  self.assertEqual(app.insurance_list(self.c)[0]['members'][0]['coverage_override'],90)
  self.add_stock()
  s=app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.pkg,'qty':2}], 'partner_id':self.member,'authority_id':self.insurer,'insurance_contract_id':cid,'coverage':75,'payments':[{'method':'cash','amount':1000}]},self.uid)
  self.assertEqual(s['covered'],3000)
  self.assertEqual(app.one(self.c,'SELECT member_id,coverage_applied FROM sale_insurance WHERE sale_id=?',(s['id'],))['member_id'],mid)
  self.assertTrue(app.integrity_review(self.c)['passed'])
 def test_unregistered_beneficiary_rejected_when_contract_selected(self):
  cid=self.create_contract()
  self.add_stock()
  with self.assertRaisesRegex(ValueError,'غير مرتبط'):
   app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.pkg,'qty':1}], 'partner_id':self.member,'authority_id':self.insurer,'insurance_contract_id':cid,'coverage':100,'payments':[]},self.uid)
 def test_expired_contract_rejected(self):
  yesterday=(date.today()-timedelta(days=2)).isoformat()
  cid=self.create_contract(starts=yesterday,ends=yesterday)
  self.add_stock()
  with self.assertRaisesRegex(ValueError,'غير نشط'):
   app.sell(self.c,{'idempotency':uuid.uuid4().hex,'items':[{'package_id':self.pkg,'qty':1}], 'authority_id':self.insurer,'insurance_contract_id':cid,'coverage':100,'payments':[]},self.uid)
 def test_import_matches_barcode_only_and_has_no_side_effects(self):
  rows=[['barcode','qty','price','description','batch','expiry'],['712222','3','1000','Medicine X 500mg','LOTZ','2027-12-01'],['UNKNOWN','2','200','Another Drug','','']]
  result=app.prepare_invoice_preview(self.c,{'rows':rows,'columns':{'barcode':0,'qty':1,'unit_cost':2,'description':3,'batch':4,'expiry':5}})
  self.assertEqual(result['matched'],1);self.assertEqual(result['needs_review'],1)
  self.assertEqual(result['rows'][0]['package_id'],self.pkg)
  self.assertEqual(result['updates_applied'],0)
  self.assertEqual(app.catalog(self.c)[0]['available'],0)
  self.assertFalse(app.one(self.c,'SELECT * FROM purchases LIMIT 1'))
 def test_import_price_and_qty_validation(self):
  rows=[['712222','bad','xx','Medicine X 500mg','LOT','2027-12-01']]
  result=app.prepare_invoice_preview(self.c,{'rows':rows,'columns':{'barcode':0,'qty':1,'unit_cost':2,'description':3,'batch':4,'expiry':5}})
  self.assertEqual(result['needs_review'],1)
  self.assertIn('كمية غير صحيحة',result['rows'][0]['warnings'])
 def test_integrity_detects_unbalanced_doc_and_stock_mismatch(self):
  self.add_stock();self.assertTrue(app.integrity_review(self.c)['passed'])
  self.c.execute("INSERT INTO journals(doc,account,debit,credit,created_at) VALUES('BROKEN','X',100,0,?)",(app.now(),))
  r=app.integrity_review(self.c);self.assertFalse(r['passed']);self.assertGreater(r['checks'][0]['errors'],0)
  self.c.execute('UPDATE lots SET qty_base=qty_base-1')
  r=app.integrity_review(self.c);self.assertFalse(r['checks'][2]['passed'])
 def test_no_duplicate_contract_code_same_insurer(self):
  self.create_contract()
  with self.assertRaises(Exception):self.create_contract()
 def test_invalid_pct_and_date_rejected(self):
  with self.assertRaisesRegex(ValueError,'0 إلى 100'):self.create_contract(coverage_default=101)
  with self.assertRaisesRegex(ValueError,'قبل بدايته'):self.create_contract(starts='2026-10-16',ends='2026-10-01')

if __name__=='__main__': unittest.main()
