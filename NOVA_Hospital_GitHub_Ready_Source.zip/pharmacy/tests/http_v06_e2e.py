"""Transport smoke test using real HTTP, separate test database; run manually on dev host."""
import sys,subprocess,os,tempfile,time,urllib.request,urllib.error,json,http.cookiejar
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as d:
 env=os.environ.copy();env['PHARMACY_DB']=str(Path(d)/'v06_http.sqlite3')
 proc=subprocess.Popen([sys.executable,str(root/'app.py'),'--host','127.0.0.1','--port','18893','--no-browser'],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
  def get(path):return op.open('http://127.0.0.1:18893/api/v1/'+path,timeout=4).read().decode()
  def post(path,data):
   request=urllib.request.Request('http://127.0.0.1:18893/api/v1/'+path,data=json.dumps(data).encode('utf-8'),headers={'Content-Type':'application/json'},method='POST')
   return json.loads(op.open(request,timeout=6).read().decode())
  for i in range(60):
   try:get('status');break
   except Exception:time.sleep(.12)
  else:raise Exception('local server unavailable')
  post('bootstrap',{'username':'owner','full_name':'Owner','password':'StrongPassword012345'})
  post('login',{'username':'owner','password':'StrongPassword012345'})
  pr=post('products',{'sku':'X1','name':'Drug test','packages':[{'unit_name':'strip','factor':10,'barcode':'122200001','is_default':1,'sale_price':3000}]})
  data=json.loads(get('products'));pk=data[0]['packages'][0]['id']
  pre=post('pricing-preview',{'mode':'current','markup_pct':10,'package_ids':[pk],'rounding':100})
  assert pre['rows'][0]['new_price']==3300
  approved=post('pricing-approve',{'mode':'current','markup_pct':10,'package_ids':[pk],'rounding':100,
               'confirm':True,'reviewed_rows':[{'package_id':pk,'old_price':3000,'new_price':3300}]})
  assert approved['updated']==1
  finance=post('finance-statements',{})
  assert finance['period_balanced']
  recommendation=post('reorder-suggestions',{'history_days':30,'lead_days':7,'cover_days':30})
  assert recommendation['no_stock_reserved']
  js=urllib.request.urlopen('http://127.0.0.1:18893/static/v06_extensions.js',timeout=4).read().decode()
  assert 'advance' in js
  print('HTTP e2e V06 PASS: login, catalog, pricing preview/approval, finance, reorder, JS asset')
 finally:
  proc.terminate()
  try:proc.wait(timeout=4)
  except subprocess.TimeoutExpired:proc.kill()
