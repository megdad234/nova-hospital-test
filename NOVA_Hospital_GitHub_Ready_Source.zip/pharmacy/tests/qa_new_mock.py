from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'static/index.html').read_text()
css=(root/'static/style.css').read_text();js=(root/'static/app.js').read_text()
mock=r'''
window.fetch=async function(url,opts){
 const path=String(url).split('/').pop();
 const p={id:1,sku:'PH-01',name:'Medicine Example 500mg',generic_name:'Example',strength:'500mg',base_uom:'حبة',active:1,available:50,reorder_point:10,lots:[{id:1,batch:'LOT-1',expiry:'2028-12-31',status:'sellable',qty_base:50}],packages:[{id:1,product_id:1,unit_name:'شريط',factor:10,barcode:'123010',sale_price:18000,is_default:1},{id:2,product_id:1,unit_name:'علبة',factor:30,barcode:'123030',sale_price:50000,is_default:0}]};
 const lookup={status:{ready:true},me:{user:{username:'test',full_name:'مالك الصيدلية',permissions:['catalog','purchase','sale','refund','stock','partners','finance','claims','prices','users','reports','backup']}},products:[p],suppliers:[{id:1,name:'شركة توزيع الأدوية',balance:170000,phone:''}],partners:[{id:1,name:'السلطة القضائية',kind:'authority',active:1}],sales:[],purchases:[],claims:[],reports:{sales:1250000,purchases:700000,sale_returns:0,products:1,accounts:[],journals_balanced:true},'stock-moves':[], 'purchase-lines':[],exchanges:[]};
 return {ok:true,status:200,json:async()=>lookup[path]??[]}
};
'''
html=html.replace('<link rel="stylesheet" href="/static/style.css">','<style>'+css+'</style>').replace('<script src="/static/app.js"></script>','<script>'+mock+'\n'+js+'</script>')
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':950},device_scale_factor=1)
 errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(1500)
 print('errors',errs)
 assert page.locator('#shell').is_visible(),page.locator('body').inner_text()[:300]
 page.screenshot(path=str(root/'واجهة_الرئيسية_المحسنة.png'),full_page=True)
 page.locator('nav button[data-page="purchase"]').click();page.wait_for_timeout(100)
 page.screenshot(path=str(root/'واجهة_المشتريات_المحسنة.png'),full_page=True)
 page.locator('nav button[data-page="pos"]').click();page.wait_for_timeout(100)
 page.screenshot(path=str(root/'واجهة_البيع_المحسنة.png'),full_page=True)
 page.locator('nav button[data-page="catalog"]').click();page.wait_for_timeout(100)
 page.screenshot(path=str(root/'واجهة_الأدوية_المحسنة.png'),full_page=True)
 for key in ['refills','cashdesk','quotes','corrections']:
  page.locator(f'nav button[data-page="{key}"]').click();page.wait_for_timeout(120)
  assert page.locator('#content .panel').count()>0,key
  page.screenshot(path=str(root/f'واجهة_{key}.png'),full_page=True)
 print('UI MOCK render all screens; JavaScript exceptions:', errs)
 assert not errs,errs
 b.close()
