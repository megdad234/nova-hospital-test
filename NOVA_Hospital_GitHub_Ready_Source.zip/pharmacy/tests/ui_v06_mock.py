from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'static/index.html').read_text(encoding='utf-8')
css=(root/'static/style.css').read_text(encoding='utf-8')
js=(root/'static/app.js').read_text(encoding='utf-8')
ext=(root/'static/v06_extensions.js').read_text(encoding='utf-8')
mock=r'''
window.fetch=async (url,opts)=>{
 let path=String(url).split('/').pop();
 const product={id:1,name:'دواء تجريبي 500mg',sku:'TST001',active:1,available:60,reorder_point:10,base_uom:'حبة',lots:[],packages:[{id:1,unit_name:'شريط',factor:10,barcode:'BAR123',sale_price:3000,is_default:1}]};
 let items={status:{ready:true},me:{user:{id:1,username:'owner',full_name:'Owner',permissions:['catalog','purchase','sale','refund','stock','partners','finance','claims','prices','users','reports','backup']}},products:[product],suppliers:[{id:1,name:'مورد',balance:0}],partners:[{id:1,name:'شركة تأمين',kind:'authority'},{id:2,name:'صيدلية أخرى',kind:'pharmacy'}],sales:[],purchases:[],claims:[{id:1,authority:'شركة تأمين',period:'2026-10',status:'draft',total:9000}],reports:{sales:0,purchases:0,products:1,accounts:[]},'stock-moves':[],'purchase-lines':[],exchanges:[],refills:[],shifts:[],expenses:[],quotes:[],'coverage-adjustments':[],'bank-checks':[],payments:[],insurance:[],'reorder-suggestions':{items:[{name:'دواء تجريبي',available_base:4,incoming_base:0,needed_base:6,recommended_packages:1,supplier:null}],needing_order:1},'pricing-preview':{rows:[{package_id:1,product:'دواء تجريبي',unit:'شريط',old_price:3000,new_price:3300,changed:true,flagged:false}],changed:1,review_required:0}}
 return {ok:true,status:200,json:async()=>items[path]??{}};
};
'''
html=html.replace('<link rel="stylesheet" href="/static/style.css">','<style>'+css+'</style>').replace('<script src="/static/app.js"></script>','<script>'+mock+'\n'+js+'</script>').replace('<script src="/static/v06_extensions.js"></script>','<script>'+ext+'</script>')
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1440,'height':960})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(400)
 assert page.locator('#shell').is_visible()
 page.locator('nav button[data-page="advanced"]').click();page.wait_for_timeout(150)
 assert page.locator('#v6-mode').count()==1
 page.locator('.v06-pack').first.check()
 page.get_by_role('button',name='معاينة الأسعار').click();page.wait_for_timeout(200)
 assert page.locator('#v6-price-1').input_value()=='3300'
 page.get_by_role('button',name='احسب مقترحات الشراء').click();page.wait_for_timeout(150)
 assert 'دواء تجريبي' in page.locator('#v06-order-results').inner_text()
 page.screenshot(path=str(root/'واجهة_المراجعة_والتسعير_V06.png'),full_page=True)
 print('advanced UI passed, JS exceptions:',errors)
 assert errors==[],errors
 b.close()
