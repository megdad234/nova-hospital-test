import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'static/index.html').read_text(encoding='utf-8')
css=(root/'static/style.css').read_text(encoding='utf-8')
js=(root/'static/app.js').read_text(encoding='utf-8')
mock='''
window.fetch=async function(url, opts){
 let path=String(url).split('/').pop();
 const p={id:1,sku:'SKU001',name:'Medicine Example 500mg',generic_name:'Example',strength:'500mg',base_uom:'حبة',active:1,available:50,reorder_point:10,lots:[],packages:[{id:1,product_id:1,unit_name:'شريط',factor:10,barcode:'123010',sale_price:18000,is_default:1},{id:2,product_id:1,unit_name:'علبة',factor:30,barcode:'123030',sale_price:50000,is_default:0}]};
 const lookup={status:{ready:true},me:{user:{id:1,username:'test',full_name:'مدير الصيدلية',permissions:['catalog','purchase','sale','refund','stock','partners','finance','claims','prices','users','reports','backup']}},products:[p],suppliers:[{id:1,name:'مورد تجريبي',balance:1000}],partners:[{id:1,name:'السلطة القضائية',kind:'authority',active:1},{id:2,name:'مستفيد',kind:'customer',active:1}],insurance:[{id:1,authority_id:1,authority_name:'السلطة القضائية',code:'Judiciary 2026',coverage_default:90,starts:'2026-01-01',ends:'',active:1,members:[{id:1,partner_id:2,beneficiary_name:'مستفيد',relation:'الأصل',coverage_override:90}]}],sales:[],purchases:[],claims:[],reports:{sales:0,purchases:0,products:1,accounts:[],journals_balanced:true},'stock-moves':[], 'purchase-lines':[],exchanges:[],refills:[],shifts:[],expenses:[],quotes:[],'coverage-adjustments':[],'bank-checks':[],payments:[]};
 if(path==='invoice-preview')return {ok:true,json:async()=>({rows:[{source_row:1,source_barcode:'123010',description:'Medicine Example 500mg',package_id:1,qty:2,unit_cost:10000,batch:'LOT01',expiry:'2028-01-01',warnings:[],status:'matched'}],matched:1,needs_review:0})};
 return {ok:true,status:200,json:async()=>lookup[path]??[]};
};
'''
html=html.replace('<link rel="stylesheet" href="/static/style.css">','<style>'+css+'</style>').replace('<script src="/static/app.js"></script>','<script>'+mock+'\n'+js+'</script>')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':900})
 errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(700)
 assert page.locator('#shell').is_visible()
 page.locator('nav button[data-page="insurance"]').click();page.wait_for_timeout(120)
 assert 'التأمينات والجهات المتعاقدة' in page.locator('#content').inner_text()
 page.screenshot(path=str(root/'واجهة_التأمينات_v05.png'),full_page=True)
 page.locator('nav button[data-page="purchase"]').click();page.wait_for_timeout(100)
 page.screenshot(path=str(root/'واجهة_المشتريات_v05.png'),full_page=True)
 page.locator('nav button[data-page="pos"]').click();page.wait_for_timeout(100)
 page.locator('#pos-authority').select_option('1');page.wait_for_timeout(80)
 assert page.locator('#pos-insurance').count()==1
 page.screenshot(path=str(root/'واجهة_البيع_v05.png'),full_page=True)
 page.locator('nav button[data-page="system"]').click();page.wait_for_timeout(100)
 assert 'تشغيل فحص الاتساق' in page.locator('#content').inner_text()
 print('UI rendered pages, JS errors:',errors)
 assert not errors,errors
 browser.close()
