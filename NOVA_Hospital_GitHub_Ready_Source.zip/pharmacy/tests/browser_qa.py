from playwright.sync_api import sync_playwright
import json,time
U='http://127.0.0.1:8876'
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':900},accept_downloads=True)
 errs=[];page.on('pageerror',lambda err:errs.append(str(err)))
 page.goto(U,wait_until='domcontentloaded');page.wait_for_timeout(600)
 print('auth',page.locator('#auth-body').inner_text()[:100]);assert page.get_by_text('إنشاء حساب المالك').count()==1
 page.locator('#setup-user').fill('owner');page.locator('#setup-full').fill('مدير الصيدلية');page.locator('#setup-password').fill('TestPassword#9876');page.get_by_text('إنشاء حساب المالك').last.click();page.wait_for_timeout(400)
 page.locator('#login-user').fill('owner');page.locator('#login-password').fill('TestPassword#9876');page.locator('button:has-text("دخول للنظام")').click();page.wait_for_timeout(650)
 assert page.locator('#shell').is_visible()
 page.screenshot(path='/mnt/data/pharmacy_local_app/واجهة_الرئيسية.png',full_page=True)
 # product
 page.locator('nav button[data-page="catalog"]').click();page.get_by_text('صنف جديد مع وحدات التعبئة').first.click();page.locator('#new-sku').fill('ABC-500');page.locator('#new-name').fill('دواء تجريبي 500 ملجم');page.locator('#new-generic').fill('Example generics');page.locator('#new-b1').fill('991001');page.locator('#new-p1').fill('2000');page.locator('#new-b2').fill('991010');page.locator('#new-p2').fill('19000');page.locator('#new-b3').fill('991030');page.locator('#new-p3').fill('55000');page.get_by_text('حفظ الصنف ووحدات التعبئة').click();page.wait_for_timeout(450)
 print('new product',page.locator('#content').inner_text()[:150]);assert '991030' in page.locator('#content').inner_text()
 # supplier
 page.locator('nav button[data-page="suppliers"]').click();page.get_by_text('إضافة مورد').click();page.locator('#supplier-name').fill('شركة أدوية تجريبية');page.get_by_text('حفظ المورد',exact=True).click();page.wait_for_timeout(250)
 # purchase by barcode with header preservation
 page.locator('nav button[data-page="purchase"]').click();page.locator('#buy-ref').fill('IN-001');page.locator('#buy-scan').fill('991030');page.locator('#buy-scan').press('Enter');page.wait_for_timeout(250)
 assert page.locator('#buy-ref').input_value()=='IN-001','purchase reference lost after adding barcode line!'
 # inline row inputs
 page.locator('input[onchange*="unit_cost"]').fill('40000');page.locator('input[onchange*="unit_cost"]').press('Tab');page.locator('input[onchange*="batch"]').fill('B-22');page.locator('input[onchange*="batch"]').press('Tab');page.locator('input[onchange*="expiry"]').fill('2028-12-31');page.locator('input[onchange*="expiry"]').press('Tab');page.screenshot(path='/mnt/data/pharmacy_local_app/واجهة_المشتريات.png',full_page=True)
 page.get_by_text('حفظ فاتورة المورد والاستلام').click();page.wait_for_timeout(450)
 print('purchase message',page.locator('#notify').inner_text());assert 'فاتورة مشتريات' in page.locator('#notify').inner_text()
 # POS barcode box, sale
 page.locator('nav button[data-page="pos"]').click();page.locator('#pos-scan').fill('991010');page.locator('#pos-scan').press('Enter');page.wait_for_timeout(280)
 assert 'دواء تجريبي' in page.locator('#content').inner_text()
 page.screenshot(path='/mnt/data/pharmacy_local_app/واجهة_البيع.png',full_page=True)
 page.get_by_text('تأكيد البيع وإصدار الفاتورة').click();page.wait_for_timeout(380)
 print('sale modal',page.locator('#modal-title').inner_text());assert 'تم إصدار فاتورة' in page.locator('#modal-title').inner_text()
 page.locator('#close-modal').click();page.locator('nav button[data-page="stock"]').click();print('stock',page.locator('#content').inner_text()[:300])
 assert '20 حبة' in page.locator('#content').inner_text() or '20' in page.locator('#content').inner_text()
 print('errors',errs)
 if errs:raise Exception(errs)
 b.close()
