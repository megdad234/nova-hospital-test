"""HTTP smoke tests on a real local Python server, isolated temp DB."""
import subprocess,sys,time,tempfile,os,requests,socket
from pathlib import Path
from datetime import date,timedelta
base=Path(__file__).resolve().parents[1]
port=8977
with tempfile.TemporaryDirectory() as d:
 env=os.environ.copy();env['PHARMACY_DB']=str(Path(d)/'run.sqlite3')
 proc=subprocess.Popen([sys.executable,str(base/'app.py'),'--no-browser','--port',str(port)],cwd=base,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 try:
  url=f'http://127.0.0.1:{port}/api/v1/';s=requests.Session()
  for _ in range(50):
   try:
    status=s.get(url+'status',timeout=1);break
   except requests.RequestException:time.sleep(.1)
  assert status.ok,status.text
  def post(key,data):
   r=s.post(url+key,json=data,timeout=4)
   if not r.ok:raise AssertionError(f'{key}: {r.status_code}: {r.text}')
   return r.json()
  assert not s.get(url+'products').ok
  post('bootstrap',{'username':'owner','full_name':'المسؤول','password':'StrongLocalPassword123'})
  post('login',{'username':'owner','password':'StrongLocalPassword123'})
  p=post('products',{'sku':'AB-10','name':'Drug for test','base_uom':'حبة','packages':[{'unit_name':'حبة','factor':1,'barcode':'0001','sale_price':1000,'is_default':1},{'unit_name':'علبة','factor':30,'barcode':'0030','sale_price':27000}]})
  su=post('supplier',{'name':'Supplier A'})['id']
  pkg=[x for x in s.get(url+'products').json()[0]['packages'] if x['unit_name']=='علبة'][0]['id']
  pr=post('purchase',{'supplier_id':su,'invoice_ref':'INV-1','items':[{'package_id':pkg,'qty':2,'received':2,'unit_cost':20000,'batch':'AA','expiry':(date.today()+timedelta(days=400)).isoformat()}]})
  assert pr['total']==40000
  sale=post('sale',{'idempotency':'test_http_unique','items':[{'package_id':pkg,'qty':1}],'payments':[{'method':'cash','amount':27000}]})
  assert sale['total']==27000
  assert s.get(url+'products').json()[0]['available']==30
  assert s.get(url+'reports').json()['journals_balanced']
  b=post('backup',{})
  assert Path(b['file']).is_file()
  post('logout',{})
  assert s.get(url+'me').json()['user'] is None
  print('HTTP E2E PASSED: setup, user login, barcode item, purchase, sale, ledger, backup, logout')
 finally:
  proc.terminate()
  try:proc.wait(timeout=3)
  except subprocess.TimeoutExpired:proc.kill()
