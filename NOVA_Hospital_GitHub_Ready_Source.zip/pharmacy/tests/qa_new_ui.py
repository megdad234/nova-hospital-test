import os,sys,tempfile,subprocess,time,requests,socket
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as t:
 env=os.environ.copy();env['PHARMACY_DB']=str(Path(t)/'case.sqlite3')
 port=8876
 proc=subprocess.Popen([sys.executable,str(P/'app.py'),'--port',str(port),'--no-browser'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  for _ in range(50):
   try:
    if requests.get(f'http://127.0.0.1:{port}/api/v1/status',timeout=1).ok:break
   except:time.sleep(.1)
  with sync_playwright() as p:
   b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':900})
   errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
   page.goto(f'http://127.0.0.1:{port}/');page.wait_for_timeout(300)
   page.locator('#setup-user').fill('admin');page.locator('#setup-full').fill('Pharmacy Owner');page.locator('#setup-password').fill('StrongSecretPassword123');page.get_by_text('إنشاء حساب المالك').click();page.wait_for_timeout(250)
   page.locator('#login-user').fill('admin');page.locator('#login-password').fill('StrongSecretPassword123');page.get_by_text('دخول للنظام').click();page.wait_for_timeout(700)
   assert page.locator('#shell').is_visible()
   labels={ 'refills':'الأدوية الشهرية', 'cashdesk':'الورديات والمصروفات','quotes':'مراجعة عروض الموردين','corrections':'تصحيح تغطية الجهات'}
   for key,txt in labels.items():
    page.locator(f'nav button[data-page="{key}"]').click();page.wait_for_timeout(200)
    assert txt in page.locator('#page-title').inner_text(),(key,page.locator('#page-title').inner_text())
    assert page.locator('#content .panel').count()>0,key
    if key=='cashdesk':
     page.locator('#shift-opening').fill('1000');page.get_by_text('فتح وردية جديدة').click();page.wait_for_timeout(270)
     assert page.get_by_text('إقفال الوردية وحساب الفرق').count()==1
   assert not errors,errors
   page.locator('nav button[data-page="cashdesk"]').click()
   page.screenshot(path=str(P/'screenshot_cashdesk.png'),full_page=True)
   print('CHROME UI SMOKE PASSED: 4 new pages, open shift, no JS errors')
   b.close()
 finally:
  proc.terminate();proc.wait(timeout=5)
