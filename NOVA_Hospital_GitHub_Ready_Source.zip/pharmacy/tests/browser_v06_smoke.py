import os,sys,subprocess,tempfile,time,urllib.request,json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
 env=os.environ.copy();env['PHARMACY_DB']=str(Path(tmp)/'qa.sqlite3')
 server=subprocess.Popen([sys.executable,str(root/'app.py'),'--host','127.0.0.1','--port','18891','--no-browser'],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 try:
  for i in range(70):
   try:
    r=urllib.request.urlopen('http://127.0.0.1:18891/api/v1/status',timeout=1)
    print('server_status',r.read().decode()[:150]);break
   except Exception:time.sleep(.2)
  else:raise RuntimeError('Server did not start '+str(server.poll()))
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
   page=browser.new_page(viewport={'width':1440,'height':900})
   errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
   page.goto('http://127.0.0.1:18891/',wait_until='networkidle')
   page.fill('#setup-user','admin');page.fill('#setup-full','Manager');page.fill('#setup-password','VeryStrongPassword123!')
   page.locator('button',has_text='إنشاء حساب المالك').click()
   page.wait_for_selector('#login-user')
   page.fill('#login-user','admin');page.fill('#login-password','VeryStrongPassword123!')
   page.locator('button',has_text='دخول').first.click()
   page.wait_for_selector('#shell:visible')
   page.locator('[data-page="advanced"]').click()
   page.wait_for_selector('#v6-mode')
   print('advanced_screen',page.locator('#page-title').inner_text())
   # no products: reorder returns without crashing; form HTML renders
   page.get_by_text('احسب مقترحات الشراء').click()
   page.wait_for_timeout(500)
   print('reorder_content',page.locator('#v06-order-results').inner_text()[:130])
   page.screenshot(path=str(root/'معاينة_المرحلة_V06.png'),full_page=True)
   print('browser_errors',errors)
   assert not errors
   browser.close()
 finally:
  server.terminate()
  try:server.wait(timeout=8)
  except subprocess.TimeoutExpired:server.kill()
