"""Non-destructive upgrade and downgrade-block tests."""
from contextlib import closing
import sqlite3
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
from schema_guard import prepare_upgrade,run_schema,finish_upgrade,SCHEMA_VERSION

class UpgradeSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.old_db,self.old_data=app.DB,app.DATA
        app.DATA=Path(self.tmp.name)
        app.DB=app.DATA/'pharmacy.sqlite3'
    def tearDown(self):
        app.DB,app.DATA=self.old_db,self.old_data
        self.tmp.cleanup()

    def test_fresh_initialization_and_repeat_does_not_reset_data(self):
        app.init_db()
        with closing(app.db_connect()) as c:
            self.assertEqual(c.execute('PRAGMA user_version').fetchone()[0],SCHEMA_VERSION)
            c.execute("INSERT INTO settings(key,value) VALUES('proof','DO_NOT_LOSE')")
        app.init_db()
        with closing(app.db_connect()) as c:
            self.assertEqual(c.execute("SELECT value FROM settings WHERE key='proof'").fetchone()[0],'DO_NOT_LOSE')

    def test_upgrade_from_unversioned_legacy_schema_creates_verified_backup(self):
        app.init_db()
        with closing(app.db_connect()) as c:
            c.execute("INSERT INTO settings(key,value) VALUES('proof','KEEP_ME')")
            c.execute('PRAGMA user_version=0')
        app.init_db()
        with closing(app.db_connect()) as c:
            self.assertEqual(c.execute('PRAGMA user_version').fetchone()[0],SCHEMA_VERSION)
            self.assertEqual(c.execute("SELECT value FROM settings WHERE key='proof'").fetchone()[0],'KEEP_ME')
        files=list((app.DATA/'preupgrade-backups').glob('*.sqlite3'))
        self.assertEqual(len(files),1)
        with closing(sqlite3.connect(files[0])) as c:
            self.assertEqual(c.execute("SELECT value FROM settings WHERE key='proof'").fetchone()[0],'KEEP_ME')
            self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0],'ok')

    def test_newer_database_blocks_downgrade_without_changing_data(self):
        app.init_db()
        with closing(app.db_connect()) as c:
            c.execute('PRAGMA user_version=99')
            c.execute("INSERT INTO settings(key,value) VALUES('proof','PRESERVED')")
        with self.assertRaisesRegex(RuntimeError,'downgrade blocked'):
            app.init_db()
        with closing(app.db_connect()) as c:
            self.assertEqual(c.execute('PRAGMA user_version').fetchone()[0],99)
            self.assertEqual(c.execute("SELECT value FROM settings WHERE key='proof'").fetchone()[0],'PRESERVED')

    def test_failed_schema_change_rolls_back_transaction(self):
        app.init_db()
        with closing(app.db_connect()) as c:
            c.execute('BEGIN IMMEDIATE')
            try:
                with self.assertRaises(sqlite3.OperationalError):
                    run_schema(c,'CREATE TABLE important_test(id INTEGER);\nBAD SQL COMMAND;')
            finally:
                c.execute('ROLLBACK')
            self.assertIsNone(c.execute("SELECT name FROM sqlite_master WHERE name='important_test'").fetchone())

    def test_unknown_db_not_treated_as_pharmacy(self):
        with closing(app.db_connect()) as c:
            c.execute('CREATE TABLE alien_table(x INTEGER)')
        with self.assertRaisesRegex(RuntimeError,'not a recognized pharmacy'):
            app.init_db()
        with closing(app.db_connect()) as c:
            self.assertIsNotNone(c.execute("SELECT name FROM sqlite_master WHERE name='alien_table'").fetchone())

if __name__=='__main__':unittest.main()
