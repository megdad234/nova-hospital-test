"""Guard day-filtered finance views, accountant receipt access and readable thermal receipt template."""
import tempfile,sqlite3,unittest
from pathlib import Path
import app
class MadarFinanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.orig=(app.DB,app.DATA)
        app.DATA=Path(self.tmp.name);app.DB=app.DATA/'pharmacy.sqlite3'
        app.init_db();self.c=app.db_connect()
        app.bootstrap(self.c,{'username':'owner','full_name':'Hospital owner','password':'VeryStrongValidPassword2026'})
        self.owner=app.one(self.c,'SELECT id FROM users LIMIT 1')['id']
    def tearDown(self):
        self.c.close();app.DB,app.DATA=self.orig;self.tmp.cleanup()
    def test_daily_filter_separates_sale_cash_bank_insurance_credit(self):
        self.c.execute("INSERT INTO sales(ref,idempotency,created_at,user_id,coverage,total,covered,due,cash_paid,bank_paid,bank_ref) VALUES(?,?,?,?,?,?,?,?,?,?,?)",('SAL-1','UUID-1','2026-10-17T12:00:00',self.owner,30,10000,3000,7000,2000,4000,'BK-22'))
        self.c.execute("INSERT INTO sales(ref,idempotency,created_at,user_id,coverage,total,covered,due,cash_paid,bank_paid,bank_ref) VALUES(?,?,?,?,?,?,?,?,?,?,?)",('SAL-2','UUID-2','2026-10-16T12:00:00',self.owner,0,500,0,500,500,0,''))
        self.c.execute("INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)",('customer',0,'SAL-1','bank',4000,'BK-22','2026-10-17T12:00:00',self.owner))
        self.c.execute("INSERT INTO payments(party_kind,party_id,doc,method,amount,created_at,user_id) VALUES(?,?,?,?,?,?,?)",('customer',0,'SAL-1','cash',2000,'2026-10-17T12:00:00',self.owner))
        self.c.execute("INSERT INTO expenses(category,description,amount,method,created_at,user_id) VALUES(?,?,?,?,?,?)",('Utilities','electricity',100,'cash','2026-10-17T13:00:00',self.owner))
        self.c.commit()
        info=app.daily_cashdesk(self.c,'2026-10-17')
        self.assertEqual(info['sales']['invoice_count'],1)
        self.assertEqual(info['sales']['gross'],10000)
        self.assertEqual(info['sales']['covered'],3000)
        self.assertEqual(info['sales']['pos_cash'],2000)
        self.assertEqual(info['sales']['pos_bank'],4000)
        self.assertEqual(info['sales']['credit'],1000)
        self.assertEqual(info['expenses'][0]['amount'],100)
        self.assertEqual(len(info['bank_incoming']),1)
        self.assertEqual(info['bank_incoming'][0]['verified'],0)
        receipts=app.finance_sale_receipts(self.c,'2026-10-17')
        self.assertEqual(len(receipts),1);self.assertEqual(receipts[0]['ref'],'SAL-1')
    def test_invalid_calendar_date_rejected(self):
        for value in ('2026-02-30','any','2026-01-1'):
            with self.assertRaises(ValueError):app.daily_cashdesk(self.c,value)
    def test_static_assets_and_explicit_finance_permission(self):
        p=Path(__file__).resolve().parents[1]
        backend=(p/'app.py').read_text()
        self.assertIn("'/api/v1/daily-cashdesk':'finance'",backend)
        self.assertIn("'/api/v1/finance-receipts':'finance'",backend)
        html=(p/'static/index.html').read_text()
        self.assertIn('/static/daily_finance.js',html)
        js=(p/'static/app.js').read_text()
        self.assertIn('receipt-sum',js)
        self.assertIn('مدار | MADAR',js)
        self.assertIn("'daily-finance':'finance'",js)
if __name__=='__main__':unittest.main()
