"""Rebrand checks must protect the installed pharmacy and its original data."""
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class HospitalBrandTests(unittest.TestCase):
    def test_existing_windows_data_path_does_not_change(self):
        desktop=(ROOT/'desktop.py').read_text(encoding='utf-8')
        assert "'HospitalPharmacyERP'" in desktop
        assert "'pharmacy.sqlite3'" in desktop
        assert "Local\\\\HospitalPharmacyERP-Desktop" in desktop
    def test_installer_in_place_upgrade_identity(self):
        installer=(ROOT/'windows-installer.iss').read_text(encoding='utf-8')
        self.assertIn('AppId={{9D2B425C-3AE9-4FCF-B654-A85942C52A11}',installer)
        self.assertIn('DefaultDirName={autopf}\\HospitalPharmacyERP',installer)
        self.assertIn('#define MyAppExeName "HospitalPharmacyERP.exe"',installer)
        self.assertIn('OutputBaseFilename=MADAR-Pharmacy-Setup',installer)
    def test_brand_consistency_and_module_scope(self):
        index=(ROOT/'static/index.html').read_text(encoding='utf-8')
        self.assertIn('مدار | MADAR',index)
        self.assertIn('وحدة الصيدلية',index)
        for name in ('index.html','app.js','workstation_upgrade.js'):
            s=(ROOT/'static'/name).read_text(encoding='utf-8')
            self.assertNotIn('PharmaPlus',s)
        js=(ROOT/'static/app.js').read_text(encoding='utf-8')
        self.assertIn('MADAR',js)
        self.assertIn('sale-cart-list',js)
    def test_new_logo_and_icon(self):
        png=(ROOT/'static/logo.png').read_bytes()
        ico=(ROOT/'assets/app.ico').read_bytes()
        self.assertTrue(png.startswith(b'\x89PNG\r\n\x1a\n'))
        self.assertTrue(ico.startswith(b'\x00\x00\x01\x00'))
        self.assertGreater(len(png),1000)
        self.assertGreater(len(ico),1000)
if __name__=='__main__':unittest.main()
