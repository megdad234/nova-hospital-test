MADAR 1.3 — prefilled product master (10 supplier PDFs, 2026)

- 1,867 conservatively normalized product names are seeded automatically on desktop startup.
- Initial lots/stock remain EMPTY, no batches, no expiry dates and sale prices remain zero.
- Supplier prices retained only as dated references, never as retail prices or inventory.
- New purchase screen includes name search, and add-new without leaving purchase draft.
- POS displays only stocked and priced items; large zero-stock master does not flood sales.
- Catalog DB query optimized for many products and zero-stock warning logic adjusted.
- Existing product names are linked without editing their sale price or stock; seed idempotent.
- DO NOT assume supplier pack size/barcode/expiry are current pharmacy facts.
- Clinical identity, packaging and possible near-duplicates should be confirmed during real purchasing.
