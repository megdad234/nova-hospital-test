"""Additional offline ERP workflows. Monetary amounts are integer SDG; reviews require explicit consent.

These features provide tested primitives, not regulatory certification or full accounting closure.
"""
from __future__ import annotations
import calendar, math, uuid, json
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP, ROUND_CEILING, ROUND_FLOOR


def init_extensions(c):
    from schema_guard import run_schema
    run_schema(c, '''
    CREATE TABLE IF NOT EXISTS claims_adjudication(
        id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL UNIQUE REFERENCES claims(id),
        approved_amount INTEGER NOT NULL CHECK(approved_amount>=0),
        rejected_amount INTEGER NOT NULL CHECK(rejected_amount>=0),
        reason TEXT NOT NULL, decided_at TEXT NOT NULL, user_id INTEGER REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS insurance_credit_notes(
        id INTEGER PRIMARY KEY, authority_id INTEGER NOT NULL REFERENCES partners(id),
        claim_id INTEGER NOT NULL REFERENCES claims(id),
        coverage_adjustment_id INTEGER NOT NULL UNIQUE REFERENCES coverage_adjustments(id),
        amount INTEGER NOT NULL CHECK(amount>0), reason TEXT NOT NULL, issued_at TEXT NOT NULL,
        user_id INTEGER REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS pricing_batches(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL,
        user_id INTEGER REFERENCES users(id), mode TEXT NOT NULL, markup_pct TEXT NOT NULL,
        rounding INTEGER NOT NULL, direction TEXT NOT NULL, note TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS pricing_lines(id INTEGER PRIMARY KEY, batch_id INTEGER NOT NULL REFERENCES pricing_batches(id),
        package_id INTEGER NOT NULL REFERENCES packages(id),before_price INTEGER NOT NULL,
        new_price INTEGER NOT NULL, flagged INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS pharmacy_settlements(id INTEGER PRIMARY KEY,
        partner_id INTEGER NOT NULL REFERENCES partners(id), direction TEXT NOT NULL,
        method TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0),bank_ref TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL, user_id INTEGER REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS purchase_receipt_allocations(
      id INTEGER PRIMARY KEY,purchase_line_id INTEGER NOT NULL REFERENCES purchase_lines(id),
      lot_id INTEGER NOT NULL REFERENCES lots(id), received_base INTEGER NOT NULL CHECK(received_base>0),
      returned_base INTEGER NOT NULL DEFAULT 0 CHECK(returned_base>=0 AND returned_base<=received_base),
      created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS ix_purchase_receipt_line ON purchase_receipt_allocations(purchase_line_id);
    CREATE TABLE IF NOT EXISTS insurance_return_credit_notes(
      id INTEGER PRIMARY KEY,claim_id INTEGER NOT NULL REFERENCES claims(id),
      sale_return_id INTEGER NOT NULL UNIQUE REFERENCES sale_returns(id),
      amount INTEGER NOT NULL CHECK(amount>=0),issued_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS pharmacy_nettings(id INTEGER PRIMARY KEY,partner_id INTEGER NOT NULL REFERENCES partners(id),
        amount INTEGER NOT NULL CHECK(amount>0),created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS closed_periods(period TEXT PRIMARY KEY, closed_at TEXT NOT NULL,
        closed_by INTEGER REFERENCES users(id), reason TEXT NOT NULL);
    ''')


def _base():
    import app
    return app


def finance_statements(c,p):
    a=_base(); start=a.textv(p,'start',10) or '0001-01-01'; end=a.textv(p,'end',10) or '9999-12-31'
    if start!='0001-01-01': date.fromisoformat(start)
    if end!='9999-12-31': date.fromisoformat(end)
    if start>end: raise ValueError('بداية الفترة بعد نهايتها')
    period_rows=a.query(c,"""SELECT account, COALESCE(SUM(debit),0) debit, COALESCE(SUM(credit),0) credit
        FROM journals WHERE substr(created_at,1,10)>=? AND substr(created_at,1,10)<=?
        GROUP BY account ORDER BY account""",(start,end))
    groups={'revenue':{'SALES'},'contra_revenue':{'SALES_RETURNS'},'other_income':{'INVENTORY_SURPLUS'},'expense':{'COGS','EXPENSES','EXPENSE','INVENTORY_LOSS','CLAIM_DENIAL_EXPENSE','PURCHASE_RETURN_VARIANCE'}}
    sums={k:0 for k in groups}
    for row in period_rows:
        acct=row['account'];d=row['debit'];cr=row['credit']
        if acct in groups['revenue']: sums['revenue']+=cr-d
        elif acct in groups['contra_revenue']: sums['contra_revenue']+=d-cr
        elif acct in groups['other_income']: sums['other_income']+=cr-d
        elif acct in groups['expense'] or acct.startswith('EXPENSE_'):sums['expense']+=d-cr
    sums['gross_revenue']=sums['revenue']-sums['contra_revenue']
    sums['net_profit_before_other_accounts']=sums['gross_revenue']+sums['other_income']-sums['expense']
    diff=sum(x['debit']-x['credit'] for x in period_rows)
    totals={x['account']:x['debit']-x['credit'] for x in period_rows}
    return {'period':{'start':start,'end':end},'accounts':period_rows,'period_balanced':diff==0,
            'balance_difference':diff,'income_summary':sums,'net_account_positions':totals,
            'warning':'قائمة إدارة أولية مبنية على الحسابات المسجلة، ليست قوائم مالية معتمدة؛ راجع افتتاحيات الحسابات وسياسات التكلفة والتسويات.'}


def close_period(c,p,uid):
    a=_base();period=a.textv(p,'period',7,True);reason=a.textv(p,'reason',300,True)
    try:date.fromisoformat(period+'-01')
    except:raise ValueError('الشهر غير صالح')
    if period>=a.today()[:7]:raise ValueError('لا يمكن إقفال الشهر الحالي أو المستقبل')
    a.begin(c)
    try:
        if a.one(c,'SELECT period FROM closed_periods WHERE period=?',(period,)):raise ValueError('الفترة مقفلة مسبقاً')
        issues=a.integrity_review(c)
        if not issues['passed']:raise ValueError('فحص اتساق الحسابات أو المخزون فشل؛ لا يمكن الإقفال')
        pending=a.one(c,"SELECT COUNT(*) n FROM purchases WHERE substr(invoice_date,1,7)=? AND total<0",(period,))['n']
        if pending:raise ValueError('مستندات مالية غير سليمة')
        c.execute('INSERT INTO closed_periods(period,closed_at,closed_by,reason) VALUES(?,?,?,?)',(period,a.now(),uid,reason))
        a.audit(c,uid,'period_closed',{'period':period,'reason':reason})
        a.finish(c)
    except:a.rollback(c);raise
    return {'period':period,'closed':True}


def insurance_submit(c,p,uid):
    a=_base();cid=a.posint(p.get('claim_id'),'المطالبة')
    a.begin(c)
    try:
        cl=a.one(c,'SELECT * FROM claims WHERE id=?',(cid,))
        if not cl or cl['status']!='draft':raise ValueError('تُرسل المطالبة من حالة مسودة فقط')
        if cl['total']<=0:raise ValueError('المطالبة فارغة؛ لا يمكن إرسالها')
        c.execute("UPDATE claims SET status='submitted' WHERE id=?",(cid,))
        a.audit(c,uid,'insurance_claim_submitted',{'claim_id':cid,'amount':cl['total']})
        a.finish(c)
    except:a.rollback(c);raise
    return {'claim_id':cid,'status':'submitted','total':cl['total']}


def insurance_adjudicate(c,p,uid):
    a=_base();cid=a.posint(p.get('claim_id'),'المطالبة')
    approved=a.amt(p.get('approved_amount'),'المبلغ المقبول');reason=a.textv(p,'reason',300,True)
    a.begin(c)
    try:
        cl=a.one(c,'SELECT * FROM claims WHERE id=?',(cid,))
        if not cl or cl['status']!='submitted':raise ValueError('لا يمكن اعتماد إلا مطالبة مرسلة ولم تُسوى')
        if approved>cl['total'] or cl['paid']:raise ValueError('المبلغ المقبول غير صالح أو المطالبة تم تحصيل جزء منها')
        denied=cl['total']-approved
        c.execute('INSERT INTO claims_adjudication(claim_id,approved_amount,rejected_amount,reason,decided_at,user_id) VALUES(?,?,?,?,?,?)',
                  (cid,approved,denied,reason,a.now(),uid))
        if denied:
            # Disallowed claim is written off here: policy choice; not an automatic receivable on the patient.
            a.journal(c,f'CLAIM-{cid}-DENIAL',[('CLAIM_DENIAL_EXPENSE',denied,0),('AR_AUTH',0,denied)])
        status='rejected' if approved==0 else 'approved' if approved==cl['total'] else 'partially_approved'
        c.execute('UPDATE claims SET status=? WHERE id=?',(status,cid))
        a.audit(c,uid,'claim_adjudicated',{'claim_id':cid,'approved':approved,'rejected':denied,'reason':reason})
        a.finish(c)
    except:a.rollback(c);raise
    return {'id':cid,'status':status,'approved':approved,'rejected':denied}


def insurance_credit(c,p,uid):
    """Document negative corrections after an already-issued claim; never rewrite paid claim."""
    a=_base();aid=a.posint(p.get('adjustment_id'),'تصحيح التغطية');reason=a.textv(p,'reason',200,True)
    a.begin(c)
    try:
        adj=a.one(c,'''SELECT ca.*,cs.claim_id,cl.authority_id FROM coverage_adjustments ca
           JOIN claim_sales cs ON cs.sale_id=ca.sale_id JOIN claims cl ON cl.id=cs.claim_id
           WHERE ca.id=?''',(aid,))
        if not adj or adj['delta_covered']>=0:raise ValueError('يلزم تصحيح تغطية سالب مرتبط بمطالبة سابقة')
        if a.one(c,'SELECT id FROM claim_adjustments WHERE coverage_adjustment_id=?',(aid,)):
            raise ValueError('تمت إضافة التصحيح بالفعل لمطالبة أخرى')
        amount=-adj['delta_covered']
        res=c.execute('INSERT INTO insurance_credit_notes(authority_id,claim_id,coverage_adjustment_id,amount,reason,issued_at,user_id) VALUES(?,?,?,?,?,?,?)',
            (adj['authority_id'],adj['claim_id'],aid,amount,reason,a.now(),uid))
        # coverage_correct has already posted AR_AUTH credit, so DO NOT post a second GL entry.
        a.audit(c,uid,'insurance_credit_note',{'id':res.lastrowid,'claim_id':adj['claim_id'],'amount':amount})
        a.finish(c)
    except:a.rollback(c);raise
    return {'id':res.lastrowid,'claim_id':adj['claim_id'],'amount':amount,'journal_posted':False}


def _price_calc(c,p):
    a=_base();mode=a.textv(p,'mode',20) or 'current'; direction=a.textv(p,'direction',12) or 'nearest'
    if mode not in ('current','supplier'):raise ValueError('مصدر السعر غير معروف')
    if direction not in ('nearest','up','down'):raise ValueError('اتجاه التقريب غير صالح')
    percent=Decimal(str(p.get('markup_pct',30)))
    if not percent.is_finite() or percent < -90 or percent > 1000:raise ValueError('نسبة التعديل غير صحيحة')
    step=a.posint(p.get('rounding',100),'مقدار التقريب')
    if step not in (1,10,50,100,500,1000):raise ValueError('قيمة التقريب غير معتمدة')
    supplier=p.get('supplier_id')
    if supplier not in (None,''):supplier=a.posint(supplier,'المورد')
    else:supplier=None
    rounding={'nearest':ROUND_HALF_UP,'up':ROUND_CEILING,'down':ROUND_FLOOR}[direction]
    selected=p.get('package_ids',[])
    if not isinstance(selected,list) or not selected or len(selected)>1000:raise ValueError('حدد من 1 إلى 1000 عبوة')
    results=[]
    for item in selected:
        pack=a.one(c,'SELECT pk.*,pr.name,pr.active FROM packages pk JOIN products pr ON pr.id=pk.product_id WHERE pk.id=?',
                   (a.posint(item,'العبوة'),))
        if not pack or not pack['active']:raise ValueError('عبوة غير موجودة أو غير نشطة')
        source=pack['sale_price'];supplier_quote=None
        if mode=='supplier':
            supplier_quote=a.one(c,'''SELECT * FROM price_quotes WHERE package_id=? AND (? IS NULL OR supplier_id=?)
               ORDER BY created_at DESC,id DESC LIMIT 1''',(pack['id'],supplier,supplier))
            if not supplier_quote:raise ValueError('لا يوجد عرض سعر موثق للعبوة: '+pack['name'])
            source=Decimal(supplier_quote['unit_base_milli'])*pack['factor']/1000
            if source<=0:raise ValueError('تكلفة المورد يجب أن تكون موجبة')
        suggested=int(((Decimal(source)*(1+percent/100))/step).quantize(Decimal('1'),rounding=rounding)*step)
        if suggested<0:raise ValueError('لا يقبل سعر بيع سالب')
        old=pack['sale_price'];changed=suggested!=old
        change_pct=(Decimal(suggested-old)*100/Decimal(old)) if old else Decimal(100 if suggested else 0)
        flagged=bool(old and (suggested > old*2 or (suggested < old//2))) or (mode=='supplier' and suggested<source)
        results.append({'package_id':pack['id'],'product':pack['name'],'unit':pack['unit_name'],'old_price':old,
            'new_price':suggested,'difference':suggested-old,'percent_change':str(change_pct.quantize(Decimal('0.01'))),
            'changed':changed,'flagged':flagged,'source_price':str(source),
            'supplier_quote_id':supplier_quote['id'] if supplier_quote else None})
    return {'rows':results,'changed':sum(x['changed'] for x in results),'review_required':sum(x['flagged'] for x in results),
            'mode':mode,'markup_pct':str(percent),'rounding':step,'direction':direction}


def price_batch_preview(c,p):return _price_calc(c,p)


def price_batch_approve(c,p,uid):
    a=_base()
    if p.get('confirm') is not True:raise ValueError('الموافقة الصريحة على الأسعار مطلوبة')
    review=p.get('reviewed_rows')
    if not isinstance(review,list) or not review:raise ValueError('يجب إرسال صفوف الأسعار بعد مراجعتها')
    a.begin(c)
    try:
        calculation=_price_calc(c,p)
        indexed={r['package_id']:r for r in calculation['rows']}
        if len(review)!=len(indexed):raise ValueError('قائمة المراجعة لا تطابق العبوات المختارة')
        checked=[]
        for item in review:
            if not isinstance(item,dict):raise ValueError('سطر المراجعة غير صالح')
            pid=a.posint(item.get('package_id'),'العبوة');calc=indexed.get(pid)
            if not calc or any(i['package_id']==pid for i in checked):raise ValueError('تكرار أو اختلاف في صف المراجعة')
            expected=a.amt(item.get('old_price'),'السعر السابق')
            if expected!=calc['old_price']:raise ValueError('سعر البيع تغير منذ المعاينة: أعد المراجعة')
            new=a.amt(item.get('new_price'),'السعر الجديد')
            if calculation['mode']=='supplier' and item.get('supplier_quote_id')!=calc['supplier_quote_id']:
                raise ValueError('عرض المورد تغير منذ المعاينة؛ أعد التحقق')
            manually_flagged=bool(expected and (new>expected*2 or new<expected//2)) or (calculation['mode']=='supplier' and new<Decimal(calc['source_price']))
            if (calc['flagged'] or manually_flagged) and not item.get('anomaly_ack'):
                raise ValueError('سعر شاذ يحتاج تأكيداً واضحاً')
            checked.append(dict(calc,new_price=new,flagged=calc['flagged'] or manually_flagged,manual_override=new!=calc['new_price']))
        batch=c.execute('''INSERT INTO pricing_batches(created_at,user_id,mode,markup_pct,rounding,direction,note)
           VALUES(?,?,?,?,?,?,?)''',(a.now(),uid,calculation['mode'],calculation['markup_pct'],calculation['rounding'],calculation['direction'],a.textv(p,'note',250))).lastrowid
        changed=[]
        for row in checked:
            if row['new_price']==row['old_price']:continue
            c.execute('UPDATE packages SET sale_price=? WHERE id=?',(row['new_price'],row['package_id']))
            c.execute('INSERT INTO pricing_lines(batch_id,package_id,before_price,new_price,flagged) VALUES(?,?,?,?,?)',
                (batch,row['package_id'],row['old_price'],row['new_price'],int(row['flagged'])))
            changed.append({'package_id':row['package_id'],'old_price':row['old_price'],'new_price':row['new_price']})
        a.audit(c,uid,'price_batch_approved',{'batch':batch,'items':changed,'reviewed':len(checked)})
        a.finish(c)
    except:a.rollback(c);raise
    return {'batch_id':batch,'updated':len(changed),'prices':changed}


def reorder_suggestions(c,p):
    a=_base();days=a.posint(p.get('history_days',30),'أيام التحليل'); lead=a.posint(p.get('lead_days',7),'مدة التوريد')
    cover=a.posint(p.get('cover_days',30),'مدة التغطية')
    if days>730 or lead>365 or cover>365:raise ValueError('عدد الأيام كبير')
    since=(date.today()-timedelta(days=days)).isoformat()
    products=a.query(c,'SELECT * FROM products WHERE active=1 ORDER BY name')
    out=[]
    for prod in products:
        movement=a.one(c,"""SELECT COALESCE(SUM(-qty_base),0) n FROM stock_moves WHERE product_id=?
            AND kind IN ('sale','exchange_out') AND substr(created_at,1,10)>=?""",(prod['id'],since))['n']
        daily=Decimal(movement)/days
        target=int((daily*(lead+cover)).to_integral_value(rounding=ROUND_CEILING))+prod['reorder_point']
        onhand=a.one(c,"""SELECT COALESCE(SUM(qty_base),0) n FROM lots WHERE product_id=?
            AND status='sellable' AND (expiry='' OR expiry>=date('now'))""",(prod['id'],))['n']
        horizon=(date.today()+timedelta(days=lead+cover)).isoformat()
        usable=a.one(c,"""SELECT COALESCE(SUM(qty_base),0) n FROM lots WHERE product_id=?
            AND status='sellable' AND (expiry='' OR expiry>=?)""",(prod['id'],horizon))['n']
        incoming=a.one(c,"""SELECT COALESCE(SUM((pl.qty-pl.received)*pk.factor),0) n FROM purchase_lines pl
           JOIN packages pk ON pk.id=pl.package_id WHERE pk.product_id=? AND pl.qty>pl.received""",(prod['id'],))['n']
        needed=max(0,target-usable-incoming)
        quote=a.one(c,"""SELECT q.supplier_id,sp.name supplier_name,q.unit_base_milli,q.created_at
             FROM price_quotes q JOIN packages pk ON pk.id=q.package_id JOIN suppliers sp ON sp.id=q.supplier_id
             WHERE pk.product_id=? AND q.id=(SELECT MAX(q2.id) FROM price_quotes q2
                  WHERE q2.package_id=q.package_id AND q2.supplier_id=q.supplier_id)
             ORDER BY q.unit_base_milli ASC,q.id DESC LIMIT 1""",(prod['id'],))
        packs=a.query(c,'SELECT id,unit_name,factor FROM packages WHERE product_id=? ORDER BY factor DESC',(prod['id'],))
        preferred=packs[0] if packs else None
        suggested_units=int(math.ceil(needed/preferred['factor'])) if preferred else 0
        out.append({'product_id':prod['id'],'name':prod['name'],'usage_base':movement,'daily_avg_base':str(daily.quantize(Decimal('0.01'))),
            'available_base':onhand,'usable_until_horizon_base':usable,'expiring_before_horizon_base':onhand-usable,'incoming_base':incoming,'target_base':target,'needed_base':needed,
            'recommended_package_id':preferred['id'] if preferred else None,
            'recommended_packages':suggested_units,'supplier':quote,'unreserved':True})
    return {'items':out,'needing_order':sum(x['needed_base']>0 for x in out),'no_stock_reserved':True,
            'note':'اقتراح يستند إلى حركات البيع المسجلة فقط ولا يحجز الأدوية أو يصدر أمر شراء تلقائياً.'}


def pharmacy_balance(c,partner):
    a=_base()
    row=a.one(c,"""SELECT COALESCE(SUM(out_value-in_value),0) diff FROM pharmacy_exchanges WHERE partner_id=?""",(partner,))
    settlements=a.one(c,"""SELECT COALESCE(SUM(CASE WHEN direction='receive' THEN amount ELSE -amount END),0) n
               FROM pharmacy_settlements WHERE partner_id=?""",(partner,))
    return row['diff']-settlements['n']


def pharmacy_settle(c,p,uid):
    a=_base();partner=a.posint(p.get('partner_id'),'الصيدلية');amount=a.posint(p.get('amount'),'المبلغ');method=a.textv(p,'method',12)
    if method not in ('cash','bank'):raise ValueError('طريقة دفع غير صحيحة')
    ref=a.textv(p,'bank_ref',80)
    if method=='bank' and not ref:raise ValueError('رقم التحويل مطلوب')
    a.begin(c)
    try:
        if not a.one(c,"SELECT id FROM partners WHERE id=? AND kind='pharmacy'",(partner,)):
            raise ValueError('ليست صيدلية خارجية مسجلة')
        # Net the opposing receivable/payable from recorded barter before settlement.
        outgoing=a.one(c,'SELECT COALESCE(SUM(out_value),0) n FROM pharmacy_exchanges WHERE partner_id=?',(partner,))['n']
        incoming=a.one(c,'SELECT COALESCE(SUM(in_value),0) n FROM pharmacy_exchanges WHERE partner_id=?',(partner,))['n']
        netted=a.one(c,'SELECT COALESCE(SUM(amount),0) n FROM pharmacy_nettings WHERE partner_id=?',(partner,))['n']
        received=a.one(c,"SELECT COALESCE(SUM(amount),0) n FROM pharmacy_settlements WHERE partner_id=? AND direction='receive'",(partner,))['n']
        paid=a.one(c,"SELECT COALESCE(SUM(amount),0) n FROM pharmacy_settlements WHERE partner_id=? AND direction='pay'",(partner,))['n']
        net_amt=min(outgoing-received-netted,incoming-paid-netted)
        if net_amt>0:
            netid=c.execute('INSERT INTO pharmacy_nettings(partner_id,amount,created_at,user_id) VALUES(?,?,?,?)',(partner,net_amt,a.now(),uid)).lastrowid
            a.journal(c,f'PHNET-{netid}',[('AP_PHARMACY',net_amt,0),('AR_PHARMACY',0,net_amt)])
        outstanding=pharmacy_balance(c,partner)
        if outstanding==0:raise ValueError('لا توجد مستحقات صافية')
        if amount>abs(outstanding):raise ValueError('السداد يتجاوز الفرق المتبقي')
        direction='receive' if outstanding>0 else 'pay'
        id=c.execute('''INSERT INTO pharmacy_settlements(partner_id,direction,method,amount,bank_ref,created_at,user_id)
            VALUES(?,?,?,?,?,?,?)''',(partner,direction,method,amount,ref,a.now(),uid)).lastrowid
        # Exchanged goods posted against AR_PHARMACY and AP_PHARMACY separately.
        # Netting balances first is necessary to avoid leaving both accounts inflated.
        if direction=='receive':
            a.journal(c,f'PHSET-{id}',[('CASH' if method=='cash' else 'BANK_PENDING',amount,0),('AR_PHARMACY',0,amount)])
        else:
            a.journal(c,f'PHSET-{id}',[('AP_PHARMACY',amount,0),('CASH' if method=='cash' else 'BANK_PENDING',0,amount)])
        a.audit(c,uid,'pharmacy_settlement',{'partner_id':partner,'direction':direction,'amount':amount})
        a.finish(c)
    except:a.rollback(c);raise
    return {'id':id,'direction':direction,'remaining':pharmacy_balance(c,partner)}
