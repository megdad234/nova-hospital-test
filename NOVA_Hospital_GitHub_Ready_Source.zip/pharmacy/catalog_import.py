"""Safe catalog/price-list import, without changing stock or treating supplier price as sale price."""
from __future__ import annotations
import hashlib, json, re
from datetime import datetime

SCHEMA = '''
CREATE TABLE IF NOT EXISTS catalog_imports(
 id INTEGER PRIMARY KEY, file_hash TEXT NOT NULL UNIQUE,source TEXT NOT NULL,
 count INTEGER NOT NULL,created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS supplier_price_references(
 id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),
 source TEXT NOT NULL,price INTEGER NOT NULL CHECK(price>=0),created_at TEXT NOT NULL,
 import_id INTEGER REFERENCES catalog_imports(id));
'''
HEADERS={
 'sku':{'sku','code','item_code','كود','الكود','كود الصنف','رمز الصنف'},
 'name':{'name','product','item','item_name','اسم الصنف','اسم الدواء','الصنف','الدواء','اسم المنتج'},
 'barcode':{'barcode','باركود','الباركود'},
 'supplier_price':{'supplier_price','cost','purchase_price','price','السعر','سعر المورد','سعر الشراء','سعر','سعر الجملة'},
 'sale_price':{'sale_price','retail_price','سعر البيع','بيع'},
 'unit_name':{'unit_name','unit','وحدة','الوحدة','التعبئة'},
 'factor':{'factor','pack_size','size','المعامل','معامل التحويل','حجم العبوة'},
 'generic_name':{'generic_name','scientific_name','الاسم العلمي'},
 'manufacturer':{'manufacturer','company','الشركة','الشركة المصنعة'},
}
def normalize(s):
    return re.sub(r'\s+',' ',str(s or '').strip().lower().replace('_',' '))

def _num(x,label):
    s=str(x if x is not None else '').strip().replace(',','').replace('٬','')
    if not s:return None
    if not re.fullmatch(r'\d+(?:\.0+)?',s):raise ValueError(label+' يجب أن يكون عدداً صحيحاً غير سالب')
    n=int(float(s))
    if n>10**12:raise ValueError(label+' أكبر من المسموح')
    return n

def parse(rows):
    if not isinstance(rows,list) or len(rows)>5001 or not rows:raise ValueError('ملف غير صالح أو أكبر من 5000 صنف')
    if not isinstance(rows[0],list):raise ValueError('تنسيق الأعمدة غير صحيح')
    headers=[normalize(x) for x in rows[0]]
    cols={k:next((i for i,x in enumerate(headers) if x in {normalize(a) for a in aliases}),None) for k,aliases in HEADERS.items()}
    if cols['name'] is None:raise ValueError('لا يوجد عمود اسم الصنف: name أو اسم الصنف')
    def cell(line,key):
        idx=cols[key]
        return str(line[idx]).strip() if idx is not None and idx<len(line) and line[idx] is not None else ''
    checked=[]
    for rownum,line in enumerate(rows[1:],2):
        if not isinstance(line,list):raise ValueError('السطر '+str(rownum)+' غير صالح')
        if not any(str(v).strip() for v in line):continue
        item={'row':rownum,'name':cell(line,'name'),'sku':cell(line,'sku'),'barcode':cell(line,'barcode'),
          'unit_name':cell(line,'unit_name') or 'علبة','generic_name':cell(line,'generic_name'),
          'manufacturer':cell(line,'manufacturer'),'errors':[]}
        if not item['name'] or len(item['name'])>140:item['errors'].append('اسم الصنف مطلوب')
        for field,limit in [('sku',60),('barcode',80),('unit_name',40),('manufacturer',160),('generic_name',160)]:
            if len(item[field])>limit:item['errors'].append('الحقل طويل: '+field)
        try:
            item['factor']=_num(cell(line,'factor'),'معامل التحويل') or 1
            if not 1<=item['factor']<=100000:item['errors'].append('معامل التحويل غير مناسب')
            item['supplier_price']=_num(cell(line,'supplier_price'),'سعر المورد')
            item['sale_price']=_num(cell(line,'sale_price'),'سعر البيع')
        except ValueError as e:item['errors'].append(str(e));item['factor']=1;item['supplier_price']=None;item['sale_price']=None
        checked.append(item)
    if not checked:raise ValueError('الملف لا يحتوي أصنافاً')
    return checked

def preview(c,rows):
    items=parse(rows);seen=set()
    for item in items:
        key=('sku',item['sku'].casefold()) if item['sku'] else ('barcode',item['barcode']) if item['barcode'] else ('name',normalize(item['name']))
        if key in seen:item['errors'].append('الصنف مكرر في الملف')
        seen.add(key)
        linked=[]
        if item['sku']:linked += c.execute('SELECT id,name FROM products WHERE sku=?',(item['sku'],)).fetchall()
        if item['barcode']:linked += c.execute('SELECT p.id,p.name FROM products p JOIN packages k ON k.product_id=p.id WHERE k.barcode=?',(item['barcode'],)).fetchall()
        known={r['id']:r['name'] for r in linked}
        if len(known)>1:item['errors'].append('الكود والباركود يخصان دواءين مختلفين')
        elif len(known)==1:
            item['existing_id']=next(iter(known))
            item['status']='موجود، لن يتكرر'
            pkg=c.execute('SELECT barcode FROM packages WHERE product_id=? AND unit_name=?',(item['existing_id'],item['unit_name'])).fetchone()
            if item['barcode'] and pkg and pkg['barcode'] not in (None,item['barcode']):item['errors'].append('باركود مختلف لنفس العبوة')
        else:
            item['existing_id']=None;item['status']='صنف جديد'
            # Matching by name is intentionally review-only; ambiguous names should not be merged silently.
            match=c.execute('SELECT id FROM products WHERE lower(name)=lower(?)',(item['name'],)).fetchone()
            if match:item['errors'].append('اسم مطابق لصنف موجود، راجع الكود قبل الاستيراد')
    return {'rows':items,'new':sum(not x['existing_id'] for x in items),'existing':sum(bool(x['existing_id']) for x in items),
            'invalid':sum(bool(x['errors']) for x in items),'total':len(items)}

def commit(c,rows,source,uid,request_id):
    from app import audit,begin,finish,rollback,now
    source=str(source or '').strip()[:160]
    if not source:raise ValueError('اسم المصدر مطلوب')
    if not isinstance(request_id,str) or len(request_id)<16:raise ValueError('مرجع الطلب غير صالح')
    # Stable content hash; independent of the request ID so reimports cannot silently multiply supplier references.
    digest=hashlib.sha256(json.dumps({'source':source,'rows':rows},ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    begin(c)
    try:
        reviewed=preview(c,rows)
        if reviewed['invalid']:
            raise ValueError('يوجد '+str(reviewed['invalid'])+' سطر يحتاج تصحيح؛ لا شيء تم حفظه')
        if c.execute('SELECT 1 FROM catalog_imports WHERE file_hash=?',(digest,)).fetchone():
            raise ValueError('هذا الملف تم استيراده سابقاً؛ لن نكرره')
        imp=c.execute('INSERT INTO catalog_imports(file_hash,source,count,created_at,user_id) VALUES(?,?,?,?,?)',
                      (digest,source,reviewed['total'],now(),uid)).lastrowid
        for item in reviewed['rows']:
            pid=item['existing_id']
            if not pid:
                sku=item['sku'] or 'CAT-'+hashlib.sha256((source+'|'+str(item['row'])+'|'+item['name']).encode()).hexdigest()[:12].upper()
                pid=c.execute('''INSERT INTO products(sku,name,generic_name,manufacturer,base_uom,created_at)
                          VALUES(?,?,?,?,?,?)''',(sku,item['name'],item['generic_name'],item['manufacturer'],item['unit_name'] if item['factor']==1 else 'حبة',now())).lastrowid
                c.execute('INSERT INTO packages(product_id,unit_name,factor,barcode,sale_price,is_default) VALUES(?,?,?,?,?,1)',
                          (pid,item['unit_name'],item['factor'],item['barcode'] or None,item['sale_price'] or 0))
            else:
                # Do not overwrite live sale prices or package ratios from uploaded supplier price lists.
                pass
            if item['supplier_price'] is not None:
                c.execute('INSERT INTO supplier_price_references(product_id,source,price,created_at,import_id) VALUES(?,?,?,?,?)',
                          (pid,source,item['supplier_price'],now(),imp))
        audit(c,uid,'catalog_import',{'id':imp,'new':reviewed['new'],'existing':reviewed['existing'],'source':source})
        finish(c)
    except Exception:
        rollback(c);raise
    return {'import_id':imp,'new':reviewed['new'],'existing':reviewed['existing'],'total':reviewed['total']}
