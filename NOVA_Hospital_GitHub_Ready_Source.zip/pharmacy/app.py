#!/usr/bin/env python3
"""Pharmacy LAN ERP - offline functional pilot. Only Python standard library.
Intended for review and testing, NOT validated for clinical/financial production.
"""
from __future__ import annotations
import argparse, base64, csv, hashlib, hmac, http.cookies, http.server, io, json, os, re, secrets, sqlite3, sys, threading, time, traceback, uuid, webbrowser, zipfile
from datetime import date, datetime, timedelta
from contextlib import closing
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import xml.etree.ElementTree as ET

if __name__ == '__main__':
    sys.modules.setdefault('app',sys.modules['__main__'])
import erp_extensions_v06 as extensions
import opening_inventory
import catalog_import
import preloaded_catalog
import recovery
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
DB=Path(os.getenv('PHARMACY_DB', str(DATA/'pharmacy.sqlite3')))
LOCK=threading.RLock()
PERMISSIONS={'catalog','purchase','sale','refund','stock','partners','finance','claims','prices','users','reports','backup','rx_verify','stock_adjust','shift_manage'}
DEFAULT_PERMS={'owner':set(PERMISSIONS),'manager':set(PERMISSIONS)-{'users','rx_verify'},'pharmacist':{'catalog','sale','refund','stock','reports','claims','partners','purchase','rx_verify'},'cashier':{'sale','reports'}}
CREATE_SQL="""
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, full_name TEXT NOT NULL, pass_hash TEXT NOT NULL, salt TEXT NOT NULL, permissions TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, sku TEXT NOT NULL UNIQUE, name TEXT NOT NULL, generic_name TEXT NOT NULL DEFAULT '', strength TEXT NOT NULL DEFAULT '', form TEXT NOT NULL DEFAULT '', manufacturer TEXT NOT NULL DEFAULT '', base_uom TEXT NOT NULL DEFAULT 'حبة', rx_required INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, reorder_point INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS packages(id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), unit_name TEXT NOT NULL, factor INTEGER NOT NULL CHECK(factor > 0), barcode TEXT UNIQUE, sale_price INTEGER NOT NULL DEFAULT 0 CHECK(sale_price>=0), is_default INTEGER NOT NULL DEFAULT 0, UNIQUE(product_id,unit_name,factor));
CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, phone TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS partners(id INTEGER PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('customer','authority','pharmacy')), phone TEXT NOT NULL DEFAULT '', parent_id INTEGER REFERENCES partners(id), active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS lots(id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), batch TEXT NOT NULL, expiry TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'sellable' CHECK(status IN ('sellable','quarantine')), qty_base INTEGER NOT NULL DEFAULT 0 CHECK(qty_base>=0), unit_cost_milli INTEGER NOT NULL DEFAULT 0, UNIQUE(product_id,batch,expiry,status));
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY, supplier_id INTEGER NOT NULL REFERENCES suppliers(id), invoice_ref TEXT NOT NULL, invoice_date TEXT NOT NULL, created_at TEXT NOT NULL, user_id INTEGER REFERENCES users(id), total INTEGER NOT NULL, paid INTEGER NOT NULL DEFAULT 0, payment_method TEXT NOT NULL DEFAULT 'credit', bank_ref TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', UNIQUE(supplier_id,invoice_ref));
CREATE TABLE IF NOT EXISTS purchase_lines(id INTEGER PRIMARY KEY,purchase_id INTEGER NOT NULL REFERENCES purchases(id), package_id INTEGER NOT NULL REFERENCES packages(id), qty INTEGER NOT NULL CHECK(qty>0), received INTEGER NOT NULL DEFAULT 0, bonus INTEGER NOT NULL DEFAULT 0, cost INTEGER NOT NULL CHECK(cost>=0), batch TEXT NOT NULL DEFAULT '', expiry TEXT NOT NULL DEFAULT '', amount INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY, ref TEXT NOT NULL UNIQUE, idempotency TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL, user_id INTEGER REFERENCES users(id), partner_id INTEGER REFERENCES partners(id), authority_id INTEGER REFERENCES partners(id), coverage INTEGER NOT NULL DEFAULT 0 CHECK(coverage BETWEEN 0 AND 100), total INTEGER NOT NULL, covered INTEGER NOT NULL, due INTEGER NOT NULL, cash_paid INTEGER NOT NULL DEFAULT 0, bank_paid INTEGER NOT NULL DEFAULT 0, bank_ref TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'completed');
CREATE TABLE IF NOT EXISTS sale_lines(id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id), package_id INTEGER NOT NULL REFERENCES packages(id), qty INTEGER NOT NULL, unit_price INTEGER NOT NULL, total INTEGER NOT NULL, cost INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sale_allocations(id INTEGER PRIMARY KEY, sale_line_id INTEGER NOT NULL REFERENCES sale_lines(id),lot_id INTEGER NOT NULL REFERENCES lots(id),qty_base INTEGER NOT NULL,cost INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS purchase_returns(id INTEGER PRIMARY KEY,purchase_line_id INTEGER NOT NULL REFERENCES purchase_lines(id),qty INTEGER NOT NULL,amount INTEGER NOT NULL,created_at TEXT NOT NULL,reason TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS pharmacy_exchanges(id INTEGER PRIMARY KEY,partner_id INTEGER NOT NULL REFERENCES partners(id),out_package_id INTEGER NOT NULL REFERENCES packages(id),out_qty INTEGER NOT NULL,in_package_id INTEGER NOT NULL REFERENCES packages(id),in_qty INTEGER NOT NULL, in_batch TEXT NOT NULL,in_expiry TEXT NOT NULL,out_value INTEGER NOT NULL,in_value INTEGER NOT NULL,created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS sale_returns(id INTEGER PRIMARY KEY,sale_id INTEGER NOT NULL REFERENCES sales(id),created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id),reason TEXT NOT NULL,refund_method TEXT NOT NULL DEFAULT 'credit',amount INTEGER NOT NULL,covered INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS return_lines(id INTEGER PRIMARY KEY,return_id INTEGER NOT NULL REFERENCES sale_returns(id),sale_line_id INTEGER NOT NULL REFERENCES sale_lines(id),qty INTEGER NOT NULL,amount INTEGER NOT NULL,covered INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS stock_moves(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),lot_id INTEGER NOT NULL REFERENCES lots(id),qty_base INTEGER NOT NULL,kind TEXT NOT NULL,document TEXT NOT NULL, created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS journals(id INTEGER PRIMARY KEY,doc TEXT NOT NULL,account TEXT NOT NULL,debit INTEGER NOT NULL DEFAULT 0,credit INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL, CHECK(debit>=0 AND credit>=0),CHECK((debit>0 AND credit=0) OR (credit>0 AND debit=0)));
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,party_kind TEXT NOT NULL,party_id INTEGER NOT NULL,doc TEXT NOT NULL,method TEXT NOT NULL,amount INTEGER NOT NULL,bank_ref TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS claims(id INTEGER PRIMARY KEY, authority_id INTEGER NOT NULL REFERENCES partners(id),period TEXT NOT NULL,created_at TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft',total INTEGER NOT NULL DEFAULT 0,paid INTEGER NOT NULL DEFAULT 0,UNIQUE(authority_id,period));
CREATE TABLE IF NOT EXISTS claim_sales(claim_id INTEGER NOT NULL REFERENCES claims(id),sale_id INTEGER NOT NULL REFERENCES sales(id),covered_amount INTEGER NOT NULL,PRIMARY KEY(claim_id,sale_id),UNIQUE(sale_id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id),action TEXT NOT NULL, details TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_packages_barcode ON packages(barcode);
CREATE INDEX IF NOT EXISTS ix_lots_available ON lots(product_id,status,expiry,qty_base);
CREATE INDEX IF NOT EXISTS ix_stock_product ON stock_moves(product_id);
"""

def now(): return datetime.now().isoformat(timespec='microseconds')
def today(): return date.today().isoformat()
def amt(x, field='المبلغ'):
    if isinstance(x,bool): raise ValueError('قيمة غير صحيحة: '+field)
    try: d=Decimal(str(x).strip())
    except (InvalidOperation,ValueError,AttributeError): raise ValueError('قيمة غير صحيحة: '+field)
    if not d.is_finite() or d != d.to_integral_value(): raise ValueError(field+' يجب أن يكون عدداً صحيحاً بالجنيه')
    n=int(d)
    if n < 0 or n>999999999999:raise ValueError('قيمة خارج النطاق: '+field)
    return n

def posint(x,name='الكمية'):
    n=amt(x,name)
    if n<=0: raise ValueError(name+' يجب أن تكون موجبة')
    return n

def textv(d,k,limit=200,required=False):
    s=str(d.get(k,'') or '').strip()
    if len(s)>limit or (required and not s):raise ValueError('حقل غير صالح: '+k)
    return s

def db_connect():
    DATA.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(DB,timeout=20,isolation_level=None,check_same_thread=False)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=20000')
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('PRAGMA synchronous=FULL')
    return con

ADD_SQL="""
CREATE TABLE IF NOT EXISTS return_allocations(id INTEGER PRIMARY KEY,return_id INTEGER NOT NULL REFERENCES sale_returns(id),sale_allocation_id INTEGER NOT NULL REFERENCES sale_allocations(id),qty_base INTEGER NOT NULL CHECK(qty_base>0),cost INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS recurring_plans(id INTEGER PRIMARY KEY,partner_id INTEGER NOT NULL REFERENCES partners(id),package_id INTEGER NOT NULL REFERENCES packages(id),qty INTEGER NOT NULL CHECK(qty>0),interval_days INTEGER NOT NULL CHECK(interval_days BETWEEN 1 AND 365),next_due TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,last_sale_id INTEGER REFERENCES sales(id),created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS cash_shifts(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),opened_at TEXT NOT NULL,opening_cash INTEGER NOT NULL CHECK(opening_cash>=0),closed_at TEXT,closing_cash INTEGER,expected_cash INTEGER,variance INTEGER,notes TEXT NOT NULL DEFAULT '');
CREATE UNIQUE INDEX IF NOT EXISTS ix_shift_one_open ON cash_shifts(user_id) WHERE closed_at IS NULL;
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY,category TEXT NOT NULL,description TEXT NOT NULL,amount INTEGER NOT NULL CHECK(amount>0),method TEXT NOT NULL CHECK(method IN ('cash','bank')),bank_ref TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS price_quotes(id INTEGER PRIMARY KEY,supplier_id INTEGER NOT NULL REFERENCES suppliers(id),package_id INTEGER NOT NULL REFERENCES packages(id),supplier_pack_factor INTEGER NOT NULL CHECK(supplier_pack_factor>0),supplier_price INTEGER NOT NULL CHECK(supplier_price>=0),unit_base_milli INTEGER NOT NULL,source_file TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS coverage_adjustments(id INTEGER PRIMARY KEY,sale_id INTEGER NOT NULL REFERENCES sales(id),old_coverage INTEGER NOT NULL,new_coverage INTEGER NOT NULL,delta_covered INTEGER NOT NULL,reason TEXT NOT NULL,created_at TEXT NOT NULL,user_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS bank_checks(id INTEGER PRIMARY KEY,payment_id INTEGER NOT NULL UNIQUE REFERENCES payments(id),verified_at TEXT NOT NULL,verified_by INTEGER REFERENCES users(id),note TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS claim_adjustments(id INTEGER PRIMARY KEY,claim_id INTEGER NOT NULL REFERENCES claims(id),coverage_adjustment_id INTEGER NOT NULL UNIQUE REFERENCES coverage_adjustments(id),amount INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS insurance_contracts(
 id INTEGER PRIMARY KEY, authority_id INTEGER NOT NULL REFERENCES partners(id), code TEXT NOT NULL,
 coverage_default INTEGER NOT NULL CHECK(coverage_default BETWEEN 0 AND 100),
 starts TEXT NOT NULL, ends TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
 notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
 UNIQUE(authority_id,code));
CREATE TABLE IF NOT EXISTS insurance_members(
 id INTEGER PRIMARY KEY, contract_id INTEGER NOT NULL REFERENCES insurance_contracts(id),
 partner_id INTEGER NOT NULL REFERENCES partners(id), relation TEXT NOT NULL,
 coverage_override INTEGER CHECK(coverage_override BETWEEN 0 AND 100),
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
 UNIQUE(contract_id,partner_id));
CREATE TABLE IF NOT EXISTS sale_insurance(
 sale_id INTEGER PRIMARY KEY REFERENCES sales(id),contract_id INTEGER NOT NULL REFERENCES insurance_contracts(id),
 member_id INTEGER REFERENCES insurance_members(id),coverage_applied INTEGER NOT NULL CHECK(coverage_applied BETWEEN 0 AND 100));
CREATE INDEX IF NOT EXISTS ix_insurance_member_partner ON insurance_members(partner_id,contract_id);
"""
def init_db(preload_catalog=False):
    from schema_guard import prepare_upgrade,run_schema,finish_upgrade
    from erp_extensions_v06 import init_extensions
    with closing(db_connect()) as c:
        plan=prepare_upgrade(c,DB)
        if not plan['upgrade']:
            if preload_catalog:preloaded_catalog.apply(c)
            return
        c.execute('BEGIN IMMEDIATE')
        try:
            run_schema(c,CREATE_SQL,ADD_SQL)
            init_extensions(c)
            run_schema(c,opening_inventory.SCHEMA)
            run_schema(c,catalog_import.SCHEMA)
            run_schema(c,"""CREATE TABLE IF NOT EXISTS sale_prescriptions(
                sale_id INTEGER PRIMARY KEY REFERENCES sales(id),prescriber TEXT NOT NULL,
                prescription_ref TEXT NOT NULL,verified_by INTEGER NOT NULL REFERENCES users(id),
                verified_at TEXT NOT NULL);""")
            # Existing first owner retains access to pharmacist prescription verification,
            # while ordinary users do not acquire the privilege silently.
            owner=one(c,'SELECT id,permissions FROM users WHERE id=1')
            if owner:
                owned=set(json.loads(owner['permissions']))
                if {'rx_verify','stock_adjust','shift_manage'} - owned:
                    c.execute('UPDATE users SET permissions=? WHERE id=1',(json.dumps(sorted(owned|{'rx_verify','stock_adjust','shift_manage'})),))
            finish_upgrade(c)
            c.execute('COMMIT')
        except Exception:
            c.execute('ROLLBACK')
            raise
        if preload_catalog:preloaded_catalog.apply(c)

def query(c,sql,params=()):return [dict(x) for x in c.execute(sql,params).fetchall()]
def one(c,sql,params=()):
    a=c.execute(sql,params).fetchone();return dict(a) if a else None

def begin(c):c.execute('BEGIN IMMEDIATE')
def finish(c):c.execute('COMMIT')
def rollback(c):c.execute('ROLLBACK')
def audit(c,uid,action,details):c.execute('INSERT INTO audit(created_at,user_id,action,details) VALUES(?,?,?,?)',(now(),uid,action,json.dumps(details,ensure_ascii=False)))
def journal(c,doc,lines):
    dd=sum(x[1] for x in lines);cc=sum(x[2] for x in lines)
    if dd!=cc:raise RuntimeError('قيد محاسبي غير متوازن '+doc+' '+str(dd)+' '+str(cc))
    if one(c,'SELECT period FROM closed_periods WHERE period=?',(today()[:7],)):
        raise ValueError('الفترة الحالية مقفلة؛ لا يمكن ترحيل قيد مالي فيها')
    for account,debit,credit in lines:
        if debit or credit:c.execute('INSERT INTO journals(doc,account,debit,credit,created_at) VALUES(?,?,?,?,?)',(doc,account,debit,credit,now()))

def password_hash(password,salt):return hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),310000).hex()
def bootstrap(c,p):
    if one(c,'SELECT id FROM users LIMIT 1'):raise ValueError('تم إعداد حساب المالك مسبقاً')
    username=textv(p,'username',60,True); fullname=textv(p,'full_name',100,True); password=str(p.get('password',''))
    if len(password)<12:raise ValueError('كلمة المرور يجب ألا تقل عن 12 حرفاً')
    salt=secrets.token_hex(16)
    begin(c)
    try:
        c.execute('INSERT INTO users(username,full_name,pass_hash,salt,permissions) VALUES(?,?,?,?,?)',(username,fullname,password_hash(password,salt),salt,json.dumps(sorted(PERMISSIONS))))
        finish(c)
    except:rollback(c);raise
    return {'ok':True}

def authenticated(c,headers):
    raw=headers.get('Cookie','')
    cookie=http.cookies.SimpleCookie()
    try:cookie.load(raw)
    except:pass
    if 'pharmacy_session' not in cookie:return None
    token=cookie['pharmacy_session'].value
    digest=hashlib.sha256(token.encode()).hexdigest()
    return one(c,'SELECT u.id,u.username,u.full_name,u.permissions,u.active FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>? AND u.active=1',(digest,int(time.time())))

def allowed(u,permission):
    if not u:return False
    return permission in json.loads(u['permissions'])

def logged_user(c,p):
    u=one(c,'SELECT * FROM users WHERE username=? AND active=1',(textv(p,'username',60),))
    password=str(p.get('password',''))
    fake_salt='00'*16
    calc=password_hash(password,u['salt'] if u else fake_salt)
    if not u or not hmac.compare_digest(calc,u['pass_hash']):raise PermissionError('اسم المستخدم أو كلمة المرور غير صحيحة')
    token=secrets.token_urlsafe(32)
    c.execute('INSERT INTO sessions(token_hash,user_id,expires) VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u['id'],int(time.time())+60*60*12))
    return {'token':token,'user':{'id':u['id'],'username':u['username'],'full_name':u['full_name'],'permissions':json.loads(u['permissions'])}}

def catalog(c):
    prods=query(c,'SELECT * FROM products ORDER BY name')
    packs=query(c,'SELECT * FROM packages ORDER BY is_default DESC,id')
    lots=query(c,'SELECT id,product_id,batch,expiry,status,qty_base,unit_cost_milli FROM lots ORDER BY expiry')
    by_packs={};by_lots={}
    for pk in packs:by_packs.setdefault(pk['product_id'],[]).append(pk)
    for lot in lots:by_lots.setdefault(lot['product_id'],[]).append(lot)
    for p in prods:
        p['packages']=by_packs.get(p['id'],[])
        p['lots']=by_lots.get(p['id'],[])
        p['available']=sum(l['qty_base'] for l in p['lots'] if l['status']=='sellable' and (not l['expiry'] or l['expiry']>=today()))
    return prods

def create_product(c,p,uid):
    sku=textv(p,'sku',60,True);name=textv(p,'name',140,True)
    packages=p.get('packages',[])
    if not isinstance(packages,list) or not packages:raise ValueError('أدخل وحدة تعبئة واحدة على الأقل مع باركودها أو رمزها الداخلي')
    checked=[]
    for pk in packages:
        factor=posint(pk.get('factor'),'معامل التحويل')
        unit=textv(pk,'unit_name',40,True)
        barcode=textv(pk,'barcode',80)
        price=amt(pk.get('sale_price',0),'سعر البيع')
        checked.append((unit,factor,barcode or None,price,int(bool(pk.get('is_default',0)))))
    if sum(x[4] for x in checked)!=1:raise ValueError('يجب اختيار وحدة بيع افتراضية واحدة')
    begin(c)
    try:
        row=c.execute('INSERT INTO products(sku,name,generic_name,strength,form,manufacturer,base_uom,rx_required,reorder_point,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(sku,name,textv(p,'generic_name'),textv(p,'strength'),textv(p,'form'),textv(p,'manufacturer'),textv(p,'base_uom',30) or 'حبة',int(bool(p.get('rx_required',0))),amt(p.get('reorder_point',0)),now()))
        pid=row.lastrowid
        for unit,factor,barcode,price,default in checked:c.execute('INSERT INTO packages(product_id,unit_name,factor,barcode,sale_price,is_default) VALUES(?,?,?,?,?,?)',(pid,unit,factor,barcode,price,default))
        audit(c,uid,'create_product',{'id':pid,'sku':sku})
        finish(c)
    except:rollback(c);raise
    return {'id':pid}

def update_product(c,p,uid):
    pid=posint(p.get('product_id'),'الصنف')
    begin(c)
    try:
        existing=one(c,'SELECT * FROM products WHERE id=?',(pid,))
        if not existing:raise ValueError('الصنف غير موجود')
        editable={'name':140,'generic_name':160,'strength':80,'form':80,'manufacturer':160}
        vals={k:textv(p,k,limit,required=k=='name') if k in p else existing[k] for k,limit in editable.items()}
        active=int(bool(p.get('active',existing['active'])))
        rx=int(bool(p.get('rx_required',existing['rx_required'])))
        reorder=amt(p.get('reorder_point',existing['reorder_point']),'حد إعادة الطلب')
        c.execute('UPDATE products SET name=?,generic_name=?,strength=?,form=?,manufacturer=?,active=?,rx_required=?,reorder_point=? WHERE id=?',(vals['name'],vals['generic_name'],vals['strength'],vals['form'],vals['manufacturer'],active,rx,reorder,pid))
        audit(c,uid,'edit_product',{'id':pid,'old':{k:existing[k] for k in ['name','active','rx_required','reorder_point']},'new':{'name':vals['name'],'active':active,'rx_required':rx,'reorder_point':reorder}})
        finish(c)
    except:rollback(c);raise
    return {'id':pid,'updated':True}

def edit_package(c,p,uid):
    id=posint(p.get('package_id'),'معرف العبوة');row=one(c,'SELECT * FROM packages WHERE id=?',(id,))
    if not row:raise ValueError('العبوة غير موجودة')
    barcode=textv(p,'barcode',80)
    price=amt(p.get('sale_price',row['sale_price']),'سعر البيع')
    begin(c)
    try:
        # Packaging factor cannot change after stock history; requires separate migration workflow
        c.execute('UPDATE packages SET barcode=?,sale_price=? WHERE id=?',(barcode or None,price,id))
        audit(c,uid,'update_package',{'id':id,'barcode_before':row['barcode'],'barcode_after':barcode,'old_price':row['sale_price'],'new_price':price})
        finish(c)
    except:rollback(c);raise
    return {'id':id}

def create_party(c,p,kind,uid):
    name=textv(p,'name',160,True)
    begin(c)
    try:
        cur=c.execute(('INSERT INTO suppliers(name,phone,notes) VALUES(?,?,?)' if kind=='supplier' else 'INSERT INTO partners(name,kind,phone,parent_id) VALUES(?,?,?,?)'),((name,textv(p,'phone',35),textv(p,'notes',300)) if kind=='supplier' else (name,kind,textv(p,'phone',35),p.get('parent_id'))))
        audit(c,uid,'create_'+kind,{'id':cur.lastrowid,'name':name})
        finish(c)
    except:rollback(c);raise
    return {'id':cur.lastrowid}

def available_lots(c,pid):
    return query(c,'SELECT * FROM lots WHERE product_id=? AND status=? AND qty_base>0 AND (expiry=? OR expiry>=?) ORDER BY CASE WHEN expiry=? THEN 1 ELSE 0 END,expiry,id',(pid,'sellable','',today(),''))

def allocate(c,pid,qty,slid,uid,doc):
    needed=qty;total_cost=0
    for lot in available_lots(c,pid):
        take=min(needed,lot['qty_base'])
        if take<=0:continue
        c.execute('UPDATE lots SET qty_base=qty_base-? WHERE id=? AND qty_base>=?',(take,lot['id'],take))
        if c.execute('SELECT changes()').fetchone()[0]!=1:raise ValueError('تعذر حسم الرصيد، حاول مرة أخرى')
        cost=(take*lot['unit_cost_milli']+500)//1000
        c.execute('INSERT INTO sale_allocations(sale_line_id,lot_id,qty_base,cost) VALUES(?,?,?,?)',(slid,lot['id'],take,cost))
        c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(pid,lot['id'],-take,'sale',doc,now(),uid))
        total_cost+=cost;needed-=take
        if needed==0:break
    if needed:raise ValueError('الرصيد المتاح غير كافٍ: '+one(c,'SELECT name FROM products WHERE id=?',(pid,))['name'])
    return total_cost

def purchase(c,p,uid):
    supplier=posint(p.get('supplier_id'),'المورد')
    if not one(c,'SELECT id FROM suppliers WHERE id=?',(supplier,)):raise ValueError('المورد غير موجود')
    ref=textv(p,'invoice_ref',100) or ('LOCAL-'+datetime.now().strftime('%Y%m%d')+'-'+uuid.uuid4().hex[:12].upper()); dt=textv(p,'invoice_date',20) or today(); date.fromisoformat(dt)
    if one(c,'SELECT period FROM closed_periods WHERE period=?',(dt[:7],)):
        raise ValueError('لا يمكن إنشاء فاتورة بتاريخ فترة مقفلة')
    rows=p.get('items')
    if not isinstance(rows,list) or not rows:raise ValueError('أضف صنفاً واحداً على الأقل')
    checked=[]
    for x in rows:
        pk=one(c,'SELECT packages.*,products.name FROM packages JOIN products ON products.id=packages.product_id WHERE packages.id=?',(posint(x.get('package_id'),'العبوة'),))
        if not pk:raise ValueError('صنف الفاتورة غير موجود')
        qty=posint(x.get('qty'),'كمية الفاتورة');received=amt(x.get('received',qty),'المستلم');bonus=amt(x.get('bonus',0),'البونص')
        if received>qty:raise ValueError('المستلم لا يمكن أن يتجاوز كمية الفاتورة')
        cost=amt(x.get('unit_cost'),'سعر الشراء');batch=textv(x,'batch',70); expiry=textv(x,'expiry',10)
        if received+bonus and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',expiry):raise ValueError('الصلاحية يجب أن تكون YYYY-MM-DD')
        if expiry:
            try:expiry_date=date.fromisoformat(expiry)
            except ValueError:raise ValueError('تاريخ الصلاحية غير صحيح')
            if received+bonus and expiry_date<=date.today():raise ValueError('الصلاحية اليوم أو منتهية؛ لا يمكن إضافة كمية متاحة للبيع')
        discount=amt(x.get('discount',0),'خصم السطر');line=qty*cost-discount
        if line<0:raise ValueError('خصم أكبر من قيمة السطر')
        checked.append((pk,qty,received,bonus,cost,batch,expiry,line))
    total=sum(x[-1] for x in checked);paid=amt(p.get('paid',0),'المدفوع');method=textv(p,'payment_method',24) or 'credit'
    if paid>total or method not in ('cash','bank','credit'):raise ValueError('سداد غير صالح')
    if method=='credit' and paid:raise ValueError('اختر كاش أو تحويل للسداد الجزئي')
    bankref=textv(p,'bank_ref',90)
    if paid and method=='bank' and not bankref:raise ValueError('أدخل مرجع التحويل')
    begin(c)
    try:
        new=c.execute('INSERT INTO purchases(supplier_id,invoice_ref,invoice_date,created_at,user_id,total,paid,payment_method,bank_ref,note) VALUES(?,?,?,?,?,?,?,?,?,?)',(supplier,ref,dt,now(),uid,total,paid,method,bankref,textv(p,'note',500))).lastrowid
        asset=0
        for pk,qty,received,bonus,cost,batch,expiry,line in checked:
            lineid=c.execute('INSERT INTO purchase_lines(purchase_id,package_id,qty,received,bonus,cost,batch,expiry,amount) VALUES(?,?,?,?,?,?,?,?,?)',(new,pk['id'],qty,received,bonus,cost,batch,expiry,line)).lastrowid
            rec=(received+bonus)*pk['factor']
            if rec:
                # pilot simplified cost recognition: received item value allocated by billed qty ratio.
                value=(line*received//qty) if received else 0
                basecost=value*1000//rec if rec else 0
                # Unknown manufacturer batch must not merge separate physical receipts.
                # Original batch remains empty in purchase_lines; internal reference is NOT a manufacturer batch.
                inventory_batch=batch or f'UNRECORDED-PUR-{new}-{lineid}'
                old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(pk['product_id'],inventory_batch,expiry,'sellable'))
                if old:
                    cumulative=old['qty_base']*old['unit_cost_milli']+rec*basecost
                    newcost=cumulative//(old['qty_base']+rec)
                    c.execute('UPDATE lots SET qty_base=qty_base+?,unit_cost_milli=? WHERE id=?',(rec,newcost,old['id']))
                    lotid=old['id']
                else:lotid=c.execute('INSERT INTO lots(product_id,batch,expiry,status,qty_base,unit_cost_milli) VALUES(?,?,?,?,?,?)',(pk['product_id'],inventory_batch,expiry,'sellable',rec,basecost)).lastrowid
                c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(pk['product_id'],lotid,rec,'purchase',f'PUR-{new}',now(),uid))
                c.execute('INSERT INTO purchase_receipt_allocations(purchase_line_id,lot_id,received_base,created_at) VALUES(?,?,?,?)',(lineid,lotid,rec,now()))
                asset+=value
        # items invoiced but not yet received get clearing account until receiving workflow is completed.
        doc=f'PUR-{new}'
        journal(c,doc,[('INVENTORY',asset,0),('GOODS_IN_TRANSIT',total-asset,0),('AP',0,total)])
        if paid:
            journal(c,doc+'-PAY',[('AP',paid,0),('CASH' if method=='cash' else 'BANK_PENDING',0,paid)])
            c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('supplier',supplier,doc,method,paid,bankref,now(),uid))
        audit(c,uid,'purchase',{'id':new,'supplier':supplier,'invoice':ref,'total':total})
        finish(c)
    except:rollback(c);raise
    return {'id':new,'total':total,'paid':paid,'outstanding':total-paid}

def sell(c,p,uid):
    rows=p.get('items')
    if not isinstance(rows,list) or not rows:raise ValueError('أضف أصنافاً إلى فاتورة البيع')
    idemp=textv(p,'idempotency',90,True)
    partner_id=p.get('partner_id') or None;authority_id=p.get('authority_id') or None
    coverage=amt(p.get('coverage',0),'نسبة التغطية')
    if coverage>100:raise ValueError('نسبة التغطية يجب أن تكون بين 0 و100')
    if coverage and not authority_id:raise ValueError('اختر الجهة التي تتحمل الفاتورة')
    if authority_id:
        party=one(c,'SELECT * FROM partners WHERE id=? AND kind=?',(authority_id,'authority'))
        if not party:raise ValueError('الجهة غير موجودة')
    if partner_id and not one(c,'SELECT id FROM partners WHERE id=?',(partner_id,)):raise ValueError('المستفيد غير موجود')
    contract_id=p.get('insurance_contract_id') or None
    contract=None;membership=None
    if contract_id:
        contract=one(c,'SELECT * FROM insurance_contracts WHERE id=?',(posint(contract_id,'عقد التأمين'),))
        if not contract or not contract['active'] or contract['starts']>today() or (contract['ends'] and contract['ends']<today()):
            raise ValueError('عقد التأمين غير نشط أو خارج فترة الصلاحية')
        if int(authority_id or 0)!=contract['authority_id']:raise ValueError('جهة التغطية لا تطابق عقد التأمين')
        if partner_id:
            membership=one(c,'SELECT * FROM insurance_members WHERE contract_id=? AND partner_id=? AND active=1',(contract['id'],partner_id))
            if not membership:raise ValueError('المستفيد غير مرتبط بعقد التأمين')
    checked=[]
    rx_needed=False
    for x in rows:
        pkg=one(c,'SELECT pk.*,pr.name,pr.active,pr.rx_required FROM packages pk JOIN products pr ON pr.id=pk.product_id WHERE pk.id=?',(posint(x.get('package_id'),'العبوة'),))
        if not pkg or not pkg['active']:raise ValueError('الصنف غير موجود أو موقوف')
        if pkg['rx_required']:rx_needed=True
        qty=posint(x.get('qty'),'كمية البيع')
        checked.append((pkg,qty,qty*pkg['sale_price']))
    prescription=None
    if rx_needed:
        person=one(c,'SELECT permissions FROM users WHERE id=? AND active=1',(uid,))
        if not person or 'rx_verify' not in json.loads(person['permissions']):
            raise PermissionError('بيع الأدوية المقيدة بالوصفة يتطلب دخول صيدلي مخوّل بمراجعتها')
        record=p.get('prescription') or {}
        if not isinstance(record,dict) or record.get('confirmed') is not True:
            raise ValueError('تأكيد الصيدلي لمراجعة الوصفة مطلوب')
        prescription={'prescriber':textv(record,'prescriber',150,True),'reference':textv(record,'reference',150,True)}
    total=sum(x[2] for x in checked)
    covered=(total*coverage+50)//100
    due=total-covered
    payments=p.get('payments',[])
    if not isinstance(payments,list):raise ValueError('طرق الدفع غير صحيحة')
    cash=bank=0;bankref=''
    for pay in payments:
        method=pay.get('method');a=amt(pay.get('amount',0),'المبلغ المدفوع')
        if method=='cash':cash+=a
        elif method=='bank':
            bank+=a;bankref=textv(pay,'ref',90)
            if a and not bankref:raise ValueError('رقم التحويل مطلوب')
        else:raise ValueError('طريقة الدفع غير مدعومة')
    if cash+bank>due:raise ValueError('المدفوع أكبر من المطلوب، سجل الباقي خارج الفاتورة')
    if cash+bank<due and not partner_id:raise ValueError('السداد ناقص، لا يمكن إنشاء آجل بدون حساب عميل')
    begin(c)
    try:
        existed=one(c,'SELECT id,ref,total FROM sales WHERE idempotency=?',(idemp,))
        if existed:finish(c);return dict(existed,duplicate=True)
        ref='SAL-'+datetime.now().strftime('%Y%m%d')+'-'+uuid.uuid4().hex[:7].upper()
        saleid=c.execute('INSERT INTO sales(ref,idempotency,created_at,user_id,partner_id,authority_id,coverage,total,covered,due,cash_paid,bank_paid,bank_ref) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(ref,idemp,now(),uid,partner_id,authority_id,coverage,total,covered,due,cash,bank,bankref)).lastrowid
        if prescription:
            c.execute('INSERT INTO sale_prescriptions(sale_id,prescriber,prescription_ref,verified_by,verified_at) VALUES(?,?,?,?,?)',
                (saleid,prescription['prescriber'],prescription['reference'],uid,now()))
        if contract:
            c.execute('INSERT INTO sale_insurance(sale_id,contract_id,member_id,coverage_applied) VALUES(?,?,?,?)',
                      (saleid,contract['id'],membership['id'] if membership else None,coverage))
        cost_total=0
        for pkg,qty,line_amount in checked:
            sl=c.execute('INSERT INTO sale_lines(sale_id,package_id,qty,unit_price,total,cost) VALUES(?,?,?,?,?,?)',(saleid,pkg['id'],qty,pkg['sale_price'],line_amount,0)).lastrowid
            cost=allocate(c,pkg['product_id'],qty*pkg['factor'],sl,uid,ref)
            c.execute('UPDATE sale_lines SET cost=? WHERE id=?',(cost,sl));cost_total+=cost
        remaining=due-cash-bank
        journal(c,ref,[('CASH',cash,0),('BANK_PENDING',bank,0),('AR_AUTH',covered,0),('AR_CUSTOMER',remaining,0),('SALES',0,total),('COGS',cost_total,0),('INVENTORY',0,cost_total)])
        if cash:c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,created_at,user_id) VALUES(?,?,?,?,?,?,?)',('customer',partner_id or 0,ref,'cash',cash,now(),uid))
        if bank:c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('customer',partner_id or 0,ref,'bank',bank,bankref,now(),uid))
        audit(c,uid,'sale',{'ref':ref,'total':total,'covered':covered,'cost':cost_total})
        finish(c)
    except:rollback(c);raise
    return {'id':saleid,'ref':ref,'total':total,'covered':covered,'cash_due':due,'cash_paid':cash,'bank_paid':bank,'balance':remaining}

def sales(c):
    r=query(c,'SELECT s.*,u.full_name AS employee,p.name AS customer,a.name AS authority FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN partners p ON p.id=s.partner_id LEFT JOIN partners a ON a.id=s.authority_id ORDER BY s.id DESC LIMIT 250')
    for s in r:
        s['lines']=query(c,'SELECT sl.*,p.name,pk.unit_name,pk.factor,pk.barcode,COALESCE((SELECT SUM(qty) FROM return_lines rl WHERE rl.sale_line_id=sl.id),0) AS returned FROM sale_lines sl JOIN packages pk ON pk.id=sl.package_id JOIN products p ON p.id=pk.product_id WHERE sl.sale_id=?',(s['id'],))
    return r

def sale_return(c,p,uid):
    saleid=posint(p.get('sale_id'),'الفاتورة');reason=textv(p,'reason',250,True);refund_method=textv(p,'refund_method',24) or 'credit'
    if refund_method not in ('cash','bank','credit'):raise ValueError('طريقة الاسترداد غير صحيحة')
    r=p.get('items',[])
    if not r:raise ValueError('حدد الأصناف الراجعة')
    s=one(c,'SELECT * FROM sales WHERE id=?',(saleid,))
    if not s:raise ValueError('فاتورة البيع غير موجودة')
    # On the legacy one-click return, choose cash for a fully cash-paid invoice.
    # Explicit credit still requires outstanding customer debt.
    if not p.get('refund_method') and s['cash_paid']>=s['due'] and s['due']>0:
        refund_method='cash'
    linked_claim=one(c,'SELECT cs.claim_id FROM claim_sales cs WHERE cs.sale_id=?',(saleid,))
    begin(c)
    try:
        checked=[];value=0;covered=0;seen_lines=set()
        for x in r:
            lineid=posint(x.get('sale_line_id'),'سطر الفاتورة');qty=posint(x.get('qty'),'المرتجع')
            if lineid in seen_lines:raise ValueError('تكرر سطر المرتجع داخل نفس الطلب')
            seen_lines.add(lineid)
            row=one(c,'SELECT sl.*,pk.factor,pk.product_id FROM sale_lines sl JOIN packages pk ON pk.id=sl.package_id WHERE sl.id=? AND sl.sale_id=?',(lineid,saleid))
            if not row:raise ValueError('سطر غير موجود بالفاتورة')
            earlier=c.execute('SELECT COALESCE(SUM(qty),0) FROM return_lines WHERE sale_line_id=?',(lineid,)).fetchone()[0]
            if qty+earlier>row['qty']:raise ValueError('المرتجع يتجاوز كمية البيع الأصلية')
            amount=qty*row['unit_price'];cv=(amount*s['coverage']+50)//100
            checked.append((row,qty,amount,cv));value+=amount;covered+=cv
        rid=c.execute('INSERT INTO sale_returns(sale_id,created_at,user_id,reason,refund_method,amount,covered) VALUES(?,?,?,?,?,?,?)',(saleid,now(),uid,reason,refund_method,value,covered)).lastrowid
        for row,qty,amount,cv in checked:
            c.execute('INSERT INTO return_lines(return_id,sale_line_id,qty,amount,covered) VALUES(?,?,?,?,?)',(rid,row['id'],qty,amount,cv))
            # returned medicines quarantined: not resellable until pharmacist assessment
            allocs=query(c,'SELECT a.*,l.batch,l.expiry,l.unit_cost_milli FROM sale_allocations a JOIN lots l ON l.id=a.lot_id WHERE a.sale_line_id=? ORDER BY a.id',(row['id'],))
            need=qty*row['factor'];returned_cost=0
            for a in allocs:
                prior=one(c,'SELECT COALESCE(SUM(qty_base),0) AS q,COALESCE(SUM(cost),0) AS cost FROM return_allocations WHERE sale_allocation_id=?',(a['id'],))
                take=min(need,a['qty_base']-prior['q'])
                if take<=0:continue
                if prior['q']+take==a['qty_base']:cost=a['cost']-prior['cost']
                else:cost=(a['cost']*(prior['q']+take))//a['qty_base']-prior['cost']
                if cost<0:raise RuntimeError('تكلفة مرتجع سالبة')
                lot=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(row['product_id'],a['batch'],a['expiry'],'quarantine'))
                if lot:
                    oldtotal=lot['qty_base']*lot['unit_cost_milli']
                    combined=(oldtotal+cost*1000)//(lot['qty_base']+take)
                    lid=lot['id'];c.execute('UPDATE lots SET qty_base=qty_base+?,unit_cost_milli=? WHERE id=?',(take,combined,lid))
                else:
                    lid=c.execute('INSERT INTO lots(product_id,batch,expiry,status,qty_base,unit_cost_milli) VALUES(?,?,?,?,?,?)',(row['product_id'],a['batch'],a['expiry'],'quarantine',take,cost*1000//take)).lastrowid
                c.execute('INSERT INTO return_allocations(return_id,sale_allocation_id,qty_base,cost) VALUES(?,?,?,?)',(rid,a['id'],take,cost))
                c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(row['product_id'],lid,take,'return_quarantine',f'SRET-{rid}',now(),uid))
                returned_cost+=cost;need-=take
                if not need:break
            if need:raise RuntimeError('لم يمكن ربط كمية المرتجع بالتشغيلات الأصلية')
            if returned_cost:
                journal(c,f'SRET-{rid}-COST-{row["id"]}',[('INVENTORY_QUARANTINE',returned_cost,0),('COGS',0,returned_cost)])
        if linked_claim and covered:
            c.execute('INSERT INTO insurance_return_credit_notes(claim_id,sale_return_id,amount,issued_at,user_id) VALUES(?,?,?,?,?)',
                      (linked_claim['claim_id'],rid,covered,now(),uid))
        noncovered=value-covered
        if refund_method=='credit' and noncovered:
            original_paid=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE party_kind='customer' AND doc=?",(s['ref'],)).fetchone()[0]
            credit_returns=c.execute("SELECT COALESCE(SUM(amount-covered),0) FROM sale_returns WHERE sale_id=? AND refund_method='credit' AND id<>?",(saleid,rid)).fetchone()[0]
            open_receivable=s['due']-original_paid-credit_returns
            if noncovered>open_receivable:
                raise ValueError('لا يوجد دين عميل كافٍ لهذا المرتجع الآجل. استخدم استرداد كاش أو تحويل، أو سير عمل رصيد العميل المعتمد')
        if refund_method in ('cash','bank') and noncovered:
            all_paid=c.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE party_kind=? AND doc=?',('customer',s['ref'])).fetchone()[0]
            prior_refunds=c.execute("SELECT COALESCE(SUM(amount-covered),0) FROM sale_returns WHERE sale_id=? AND refund_method IN ('cash','bank') AND id<>?",(saleid,rid)).fetchone()[0]
            if prior_refunds+noncovered>all_paid:raise ValueError('الاسترداد النقدي يتجاوز المبالغ المحصلة؛ استخدم تسوية آجل بدلاً منه')
        if refund_method=='bank' and noncovered and not textv(p,'bank_ref',90):raise ValueError('مرجع تحويل المردود مطلوب')
        if refund_method=='bank' and noncovered:
            c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('refund',s['partner_id'] or 0,f'SRET-{rid}','bank',noncovered,textv(p,'bank_ref',90),now(),uid))
        # no automatic cash refund for authority-backed amounts; reduce receivable instead.
        journal(c,f'SRET-{rid}', [('SALES_RETURNS',value,0),('AR_AUTH',0,covered),('AR_CUSTOMER' if refund_method=='credit' else 'CASH' if refund_method=='cash' else 'BANK_PENDING',0,noncovered)])
        audit(c,uid,'sale_return',{'id':rid,'sale':saleid,'amount':value,'quarantine':True})
        finish(c)
    except:rollback(c);raise
    return {'id':rid,'amount':value,'covered_adjustment':covered,'quarantined':True}

def purchase_receipt(c,p,uid):
    lineid=posint(p.get('purchase_line_id'),'سطر المشتريات')
    qty=posint(p.get('qty'),'كمية المستلم')
    batch=textv(p,'batch',70);expiry=textv(p,'expiry',10,True)
    try:expiry_date=date.fromisoformat(expiry)
    except ValueError:raise ValueError('تاريخ الصلاحية غير صحيح')
    if expiry_date<=date.today():raise ValueError('التشغيلة منتهية الصلاحية أو تنتهي اليوم')
    begin(c)
    try:
        line=one(c,'SELECT pl.*,pk.product_id,pk.factor,pu.invoice_ref FROM purchase_lines pl JOIN packages pk ON pk.id=pl.package_id JOIN purchases pu ON pu.id=pl.purchase_id WHERE pl.id=?',(lineid,))
        if not line:raise ValueError('السطر غير موجود')
        if line['received']+qty>line['qty']:raise ValueError('المستلم يتجاوز الكمية المتبقية')
        before=(line['amount']*line['received'])//line['qty']
        after=(line['amount']*(line['received']+qty))//line['qty']
        value=after-before
        base=qty*line['factor'];unit_cost=value*1000//base if base else 0
        inventory_batch=batch or ('UNRECORDED-REC-'+uuid.uuid4().hex[:16].upper())
        old=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(line['product_id'],inventory_batch,expiry,'sellable'))
        if old:
            newcost=(old['qty_base']*old['unit_cost_milli']+base*unit_cost)//(old['qty_base']+base)
            c.execute('UPDATE lots SET qty_base=qty_base+?,unit_cost_milli=? WHERE id=?',(base,newcost,old['id']));lotid=old['id']
        else:lotid=c.execute('INSERT INTO lots(product_id,batch,expiry,status,qty_base,unit_cost_milli) VALUES(?,?,?,?,?,?)',(line['product_id'],inventory_batch,expiry,'sellable',base,unit_cost)).lastrowid
        c.execute('UPDATE purchase_lines SET received=received+? WHERE id=?',(qty,lineid))
        c.execute('INSERT INTO purchase_receipt_allocations(purchase_line_id,lot_id,received_base,created_at) VALUES(?,?,?,?)',(lineid,lotid,base,now()))
        doc='REC-'+uuid.uuid4().hex[:10]
        c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(line['product_id'],lotid,base,'late_purchase_receipt',doc,now(),uid))
        journal(c,doc,[('INVENTORY',value,0),('GOODS_IN_TRANSIT',0,value)])
        audit(c,uid,'purchase_receipt',{'line':lineid,'qty':qty,'batch':batch})
        finish(c)
    except:rollback(c);raise
    return {'document':doc,'received':qty,'value':value}

def purchase_return(c,p,uid):
    '''Return a documented received batch; invoice credit and inventory cost remain separate.'''
    lineid=posint(p.get('purchase_line_id'),'سطر المشتريات');qty=posint(p.get('qty'),'المرتجع')
    reason=textv(p,'reason',160,True);requested_batch=textv(p,'batch',70)
    begin(c)
    try:
        line=one(c,'SELECT pl.*,pk.product_id,pk.factor FROM purchase_lines pl JOIN packages pk ON pk.id=pl.package_id WHERE pl.id=?',(lineid,))
        if not line:raise ValueError('بند شراء غير موجود')
        oldreturn=c.execute('SELECT COALESCE(SUM(qty),0) FROM purchase_returns WHERE purchase_line_id=?',(lineid,)).fetchone()[0]
        if qty>line['received']-oldreturn:raise ValueError('المرتجع يتجاوز الاستلام الصافي')
        base=qty*line['factor']
        allocations=query(c,'''SELECT pra.*,l.batch,l.expiry,l.product_id,l.qty_base,l.unit_cost_milli
            FROM purchase_receipt_allocations pra JOIN lots l ON l.id=pra.lot_id
            WHERE pra.purchase_line_id=? AND pra.returned_base<pra.received_base
            AND (?='' OR l.batch=?) ORDER BY pra.id''',(lineid,requested_batch,requested_batch))
        if not allocations:
            raise ValueError('لا يوجد سجل استلام موثق لهذه التشغيلة؛ يلزم ترحيل/تسوية البيانات القديمة قبل المردود')
        required=base;selected=[];carrying_value=0
        for x in allocations:
            take=min(required,x['received_base']-x['returned_base'],x['qty_base'])
            if take<=0:continue
            val=(take*x['unit_cost_milli']+500)//1000
            selected.append((x,take,val));carrying_value+=val;required-=take
            if not required:break
        if required:raise ValueError('كمية تشغيلة الشراء القابلة للإرجاع أقل من المطلوب')
        before=(line['amount']*oldreturn)//line['qty']
        after=(line['amount']*(oldreturn+qty))//line['qty']
        credit=after-before
        docid=c.execute('INSERT INTO purchase_returns(purchase_line_id,qty,amount,created_at,reason,user_id) VALUES(?,?,?,?,?,?)',
                        (lineid,qty,credit,now(),reason,uid)).lastrowid
        for r,take,value in selected:
            c.execute('UPDATE purchase_receipt_allocations SET returned_base=returned_base+? WHERE id=?',(take,r['id']))
            c.execute('UPDATE lots SET qty_base=qty_base-? WHERE id=? AND qty_base>=?',(take,r['lot_id'],take))
            if c.execute('SELECT changes()').fetchone()[0]!=1:raise ValueError('تغير رصيد التشغيلة أثناء المردود')
            c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',
                      (line['product_id'],r['lot_id'],-take,'purchase_return',f'PRET-{docid}',now(),uid))
        lines=[('AP',credit,0),('INVENTORY',0,carrying_value)]
        if credit>carrying_value:lines.append(('PURCHASE_RETURN_VARIANCE',0,credit-carrying_value))
        elif credit<carrying_value:lines.append(('PURCHASE_RETURN_VARIANCE',carrying_value-credit,0))
        journal(c,f'PRET-{docid}',lines)
        audit(c,uid,'purchase_return',{'id':docid,'purchase_line_id':lineid,'qty':qty,
                                       'supplier_credit':credit,'inventory_cost':carrying_value,'batch':requested_batch})
        finish(c)
    except:rollback(c);raise
    return {'id':docid,'amount':credit,'inventory_value':carrying_value,'qty':qty}

def pharmacy_exchange(c,p,uid):
    partner=posint(p.get('partner_id'),'الصيدلية');external=one(c,"SELECT id FROM partners WHERE id=? AND kind='pharmacy'",(partner,))
    if not external:raise ValueError('اختر صيدلية خارجية')
    outid=posint(p.get('out_package_id'),'الصنف الخارج');inid=posint(p.get('in_package_id'),'الصنف الداخل')
    qty_out=posint(p.get('out_qty'),'الصادر');qty_in=posint(p.get('in_qty'),'الوارد')
    incoming=one(c,'SELECT pk.*,pr.name FROM packages pk JOIN products pr ON pr.id=pk.product_id WHERE pk.id=?',(inid,))
    outgoing=one(c,'SELECT pk.*,pr.name FROM packages pk JOIN products pr ON pr.id=pk.product_id WHERE pk.id=?',(outid,))
    if not incoming or not outgoing:raise ValueError('صنف غير معروف')
    batch=textv(p,'in_batch',70);expiry=textv(p,'in_expiry',10,True)
    try:expiry_date=date.fromisoformat(expiry)
    except ValueError:raise ValueError('تاريخ الصلاحية غير صحيح')
    if expiry_date<=date.today():raise ValueError('تشغيلة داخلة منتهية الصلاحية أو تنتهي اليوم')
    outvalue=amt(p.get('out_value'),'قيمة الدواء الصادر');invalue=amt(p.get('in_value'),'قيمة الدواء الوارد')
    begin(c)
    try:
        exchid=c.execute('INSERT INTO pharmacy_exchanges(partner_id,out_package_id,out_qty,in_package_id,in_qty,in_batch,in_expiry,out_value,in_value,created_at,user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(partner,outid,qty_out,inid,qty_in,batch,expiry,outvalue,invalue,now(),uid)).lastrowid
        doc=f'EXC-{exchid}'
        inventory_batch=batch or f'UNRECORDED-EXC-{exchid}'
        # Sale allocations require existing sale_line: use direct FEFO without sale record for barter.
        needed=qty_out*outgoing['factor'];cost_out=0
        for lot in available_lots(c,outgoing['product_id']):
            take=min(needed,lot['qty_base'])
            if not take:continue
            c.execute('UPDATE lots SET qty_base=qty_base-? WHERE id=?',(take,lot['id']))
            c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(outgoing['product_id'],lot['id'],-take,'exchange_out',doc,now(),uid))
            cost_out+=(take*lot['unit_cost_milli']+500)//1000;needed-=take
            if not needed:break
        if needed:raise ValueError('المخزون غير كافٍ لإتمام المبادلة')
        base=qty_in*incoming['factor'];unit_cost=invalue*1000//base
        lot=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(incoming['product_id'],inventory_batch,expiry,'sellable'))
        if lot:
            cost=(lot['qty_base']*lot['unit_cost_milli']+base*unit_cost)//(lot['qty_base']+base)
            c.execute('UPDATE lots SET qty_base=qty_base+?,unit_cost_milli=? WHERE id=?',(base,cost,lot['id']));lotid=lot['id']
        else:lotid=c.execute('INSERT INTO lots(product_id,batch,expiry,status,qty_base,unit_cost_milli) VALUES(?,?,?,?,?,?)',(incoming['product_id'],inventory_batch,expiry,'sellable',base,unit_cost)).lastrowid
        c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(incoming['product_id'],lotid,base,'exchange_in',doc,now(),uid))
        journal(c,doc,[('AR_PHARMACY',outvalue,0),('SALES',0,outvalue),('COGS',cost_out,0),('INVENTORY',0,cost_out),('INVENTORY',invalue,0),('AP_PHARMACY',0,invalue)])
        audit(c,uid,'pharmacy_exchange',{'id':exchid,'partner':partner,'difference_out_minus_in':outvalue-invalue})
        finish(c)
    except:rollback(c);raise
    return {'id':exchid,'out_value':outvalue,'in_value':invalue,'difference':outvalue-invalue}

def supplier_payment(c,p,uid):
    supplier=posint(p.get('supplier_id'),'المورد');value=posint(p.get('amount'),'المبلغ');method=textv(p,'method',20)
    if method not in ('cash','bank'):raise ValueError('وسيلة سداد غير معروفة')
    bankref=textv(p,'bank_ref',90)
    if method=='bank' and not bankref:raise ValueError('أدخل مرجع التحويل')
    if not one(c,'SELECT id FROM suppliers WHERE id=?',(supplier,)):raise ValueError('المورد غير موجود')
    begin(c)
    try:
        balance=(c.execute('SELECT COALESCE(SUM(total),0) FROM purchases WHERE supplier_id=?',(supplier,)).fetchone()[0]-c.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE party_kind=? AND party_id=?',('supplier',supplier)).fetchone()[0]-c.execute('SELECT COALESCE(SUM(r.amount),0) FROM purchase_returns r JOIN purchase_lines l ON l.id=r.purchase_line_id JOIN purchases p ON p.id=l.purchase_id WHERE p.supplier_id=?',(supplier,)).fetchone()[0])
        if value>balance:raise ValueError('المبلغ أكبر من رصيد مديونية المورد. لا يمكن تسجيل سداد زائد بدون إجراء دفعة مقدمة مستقل')
        doc='SPAY-'+uuid.uuid4().hex[:10].upper()
        c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('supplier',supplier,doc,method,value,bankref,now(),uid))
        journal(c,doc,[('AP',value,0),('CASH' if method=='cash' else 'BANK_PENDING',0,value)])
        audit(c,uid,'supplier_payment',{'supplier':supplier,'amount':value})
        finish(c)
    except:rollback(c);raise
    return {'doc':doc,'amount':value}

def price_update(c,p,uid):
    items=p.get('items',[])
    if not items:raise ValueError('لا توجد أسعار لاعتمادها')
    begin(c)
    try:
        changed=[]
        for x in items:
            id=posint(x.get('package_id'),'العبوة');price=amt(x.get('price'),'سعر البيع')
            old=one(c,'SELECT * FROM packages WHERE id=?',(id,))
            if not old:raise ValueError('عبوة غير موجودة')
            if old['sale_price']!=price:
                c.execute('UPDATE packages SET sale_price=? WHERE id=?',(price,id))
                changed.append({'package_id':id,'before':old['sale_price'],'after':price})
        audit(c,uid,'price_update',{'changed':changed})
        finish(c)
    except:rollback(c);raise
    return {'updated':len(changed),'items':changed}

def claim_create(c,p,uid):
    authority=posint(p.get('authority_id'),'الجهة');period=textv(p,'period',7,True)
    if not re.fullmatch(r'\d{4}-\d{2}',period):raise ValueError('الشهر مطلوب YYYY-MM')
    if not one(c,'SELECT id FROM partners WHERE id=? AND kind=?',(authority,'authority')):raise ValueError('الجهة غير موجودة')
    begin(c)
    try:
        cl=one(c,'SELECT * FROM claims WHERE authority_id=? AND period=?',(authority,period))
        if cl:raise ValueError('المطالبة لهذا الشهر موجودة بالفعل')
        doc=c.execute('INSERT INTO claims(authority_id,period,created_at,total) VALUES(?,?,?,0)',(authority,period,now())).lastrowid
        invoices=query(c,"SELECT s.id,s.covered,COALESCE((SELECT SUM(sr.covered) FROM sale_returns sr WHERE sr.sale_id=s.id),0) returned FROM sales s WHERE s.authority_id=? AND substr(s.created_at,1,7)=? AND s.covered>0 AND NOT EXISTS(SELECT 1 FROM claim_sales cs WHERE cs.sale_id=s.id)",(authority,period))
        total=0
        for s in invoices:
            remaining=max(0,s['covered']-s['returned'])
            c.execute('INSERT INTO claim_sales(claim_id,sale_id,covered_amount) VALUES(?,?,?)',(doc,s['id'],remaining));total+=remaining
        # Corrections of already claimed invoices are carried into a *new* claim,
        # without mutating the original claim or duplicating the original sale.
        adjustments=query(c,'''SELECT ca.id,ca.delta_covered FROM coverage_adjustments ca
            JOIN claim_sales cs ON cs.sale_id=ca.sale_id
            JOIN claims previous ON previous.id=cs.claim_id
            WHERE previous.authority_id=? AND previous.period<? AND ca.created_at<=? AND NOT EXISTS
            (SELECT 1 FROM claim_adjustments q WHERE q.coverage_adjustment_id=ca.id)
             AND NOT EXISTS(SELECT 1 FROM insurance_credit_notes n WHERE n.coverage_adjustment_id=ca.id)''',
            (authority,period,period+'-31T23:59:59'))
        if total+sum(a['delta_covered'] for a in adjustments)<0:
            raise ValueError('تسويات التخفيض أكبر من المطالبة الجديدة: يتطلب إشعار دائن مستقل قبل اعتماد الكشف')
        for a in adjustments:
            c.execute('INSERT INTO claim_adjustments(claim_id,coverage_adjustment_id,amount) VALUES(?,?,?)',(doc,a['id'],a['delta_covered']))
            total+=a['delta_covered']
        c.execute('UPDATE claims SET total=? WHERE id=?',(total,doc))
        audit(c,uid,'create_claim',{'id':doc,'period':period,'total':total,'correction_count':len(adjustments)})
        finish(c)
    except:rollback(c);raise
    return {'id':doc,'total':total,'invoice_count':len(invoices),'prior_claim_corrections':len(adjustments)}

def claim_payment(c,p,uid):
    cid=posint(p.get('claim_id'),'المطالبة');amount=posint(p.get('amount'),'السداد');method=textv(p,'method',12)
    if method not in ('cash','bank'):raise ValueError('طريقة السداد غير صحيحة')
    if method=='bank' and not textv(p,'bank_ref',90):raise ValueError('رقم التحويل مطلوب لتسجيل تحصيل المطالبة')
    begin(c)
    try:
        claim=one(c,'SELECT * FROM claims WHERE id=?',(cid,))
        if not claim:raise ValueError('المطالبة غير موجودة')
        decision=one(c,'SELECT approved_amount FROM claims_adjudication WHERE claim_id=?',(cid,))
        payable=decision['approved_amount'] if decision else claim['total']
        credit_return=one(c,'SELECT COALESCE(SUM(amount),0) n FROM insurance_return_credit_notes WHERE claim_id=?',(cid,))['n']
        credit_coverage=one(c,'SELECT COALESCE(SUM(amount),0) n FROM insurance_credit_notes WHERE claim_id=?',(cid,))['n']
        payable=max(0,payable-credit_return-credit_coverage)
        if amount>payable-claim['paid']:raise ValueError('سداد يزيد عن المبلغ المعتمد المتبقي')
        c.execute('UPDATE claims SET paid=paid+?,status=CASE WHEN paid+?=? THEN ? ELSE ? END WHERE id=?',(amount,amount,payable,'paid','partial',cid))
        doc=f'CLAIM-{cid}-PAY-{uuid.uuid4().hex[:5]}'
        journal(c,doc,[('CASH' if method=='cash' else 'BANK_PENDING',amount,0),('AR_AUTH',0,amount)])
        c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('authority',claim['authority_id'],doc,method,amount,textv(p,'bank_ref',90),now(),uid))
        audit(c,uid,'claim_payment',{'id':cid,'amount':amount})
        finish(c)
    except:rollback(c);raise
    return {'id':cid,'amount':amount}

def stock_adjust(c,p,uid):
    product=posint(p.get('product_id'),'الصنف');batch=textv(p,'batch',70,True);expiry=textv(p,'expiry',10,True);reason=textv(p,'reason',150,True);diff=int(str(p.get('delta',0)))
    if diff==0 or abs(diff)>10_000_000:raise ValueError('أدخل فرق جرد صالح')
    begin(c)
    try:
        lot=one(c,'SELECT * FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status=?',(product,batch,expiry,'sellable'))
        if not lot and diff<0:raise ValueError('لا يمكن الخصم من تشغيلة غير موجودة')
        if not lot:
            if not one(c,'SELECT id FROM products WHERE id=?',(product,)):raise ValueError('الصنف غير موجود')
            initial_cost=posint(p.get('unit_cost'),'تكلفة الوحدة الأساسية للجرد الافتتاحي')
            lid=c.execute('INSERT INTO lots(product_id,batch,expiry,status,qty_base,unit_cost_milli) VALUES(?,?,?,?,?,?)',(product,batch,expiry,'sellable',0,initial_cost*1000)).lastrowid
            unit_milli=initial_cost*1000
        else:
            lid=lot['id'];unit_milli=lot['unit_cost_milli']
        c.execute('UPDATE lots SET qty_base=qty_base+? WHERE id=? AND qty_base+?>=0',(diff,lid,diff))
        if c.execute('SELECT changes()').fetchone()[0]!=1:raise ValueError('فرق جرد يؤدي لمخزون سالب')
        doc='ADJ-'+uuid.uuid4().hex[:9]
        c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(product,lid,diff,'adjustment:'+reason,doc,now(),uid))
        adjustment_value=(abs(diff)*unit_milli+500)//1000
        if adjustment_value:
            if diff>0:journal(c,doc,[('INVENTORY',adjustment_value,0),('INVENTORY_SURPLUS',0,adjustment_value)])
            else:journal(c,doc,[('INVENTORY_LOSS',adjustment_value,0),('INVENTORY',0,adjustment_value)])
        audit(c,uid,'stock_adjust',{'product':product,'batch':batch,'difference':diff,'reason':reason,'value':adjustment_value})
        finish(c)
    except:rollback(c);raise
    return {'document':doc}

def read_invoice_file(filebytes,name):
    if len(filebytes)>4*1024*1024:raise ValueError('حجم الملف أكبر من 4MB')
    if name.lower().endswith('.csv'):
        try:s=filebytes.decode('utf-8-sig')
        except UnicodeDecodeError:s=filebytes.decode('cp1256')
        return list(csv.reader(io.StringIO(s)))[:5001]
    if not name.lower().endswith('.xlsx'):raise ValueError('يدعم الاستيراد CSV وXLSX فقط حالياً')
    # Minimal XLSX reader, no formulas, does not execute macros, local standard library only.
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(io.BytesIO(filebytes)) as z:
        if len(z.namelist())>250 or sum(i.file_size for i in z.infolist())>15*1024*1024:raise ValueError('حجم الملف بعد الفتح كبير')
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in root.findall('m:si',ns):shared.append(''.join(t.text or '' for t in si.iter('{'+ns['m']+'}t')))
        files=sorted(x for x in z.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',x))
        if not files:raise ValueError('لا توجد ورقة بيانات في الملف')
        sheet=ET.fromstring(z.read(files[0]));rows=[]
        for row in sheet.findall('.//m:sheetData/m:row',ns)[:5001]:
            cells={}
            for cell in row.findall('m:c',ns):
                reference=cell.get('r','A1');letters=re.match('[A-Z]+',reference)
                if not letters:continue
                index=0
                for char in letters.group():index=index*26+ord(char)-64
                value=cell.find('m:v',ns)
                textcell=cell.find('m:is',ns)
                content=(value.text or '') if value is not None else ''.join(t.text or '' for t in textcell.iter('{'+ns['m']+'}t')) if textcell is not None else ''
                if cell.get('t')=='s' and content:content=shared[int(content)]
                cells[index-1]=content
            if cells:rows.append([cells.get(i,'') for i in range(min(max(cells)+1,40))])
        return rows

def supplier_balances(c):
    return query(c,"""SELECT su.*,
        COALESCE((SELECT SUM(total) FROM purchases pu WHERE pu.supplier_id=su.id),0)
        - COALESCE((SELECT SUM(amount) FROM payments p WHERE p.party_kind='supplier' AND p.party_id=su.id),0)
        - COALESCE((SELECT SUM(pr.amount) FROM purchase_returns pr JOIN purchase_lines pl ON pl.id=pr.purchase_line_id JOIN purchases pu ON pu.id=pl.purchase_id WHERE pu.supplier_id=su.id),0)
        AS balance FROM suppliers su ORDER BY name""")

def report(c):
    vals={k:c.execute(q).fetchone()[0] or 0 for k,q in {'sales':'SELECT SUM(total) FROM sales','purchases':'SELECT SUM(total) FROM purchases','sale_returns':'SELECT SUM(amount) FROM sale_returns','pending_bank':"SELECT SUM(amount) FROM payments WHERE method='bank'",'products':'SELECT COUNT(*) FROM products','low_stock':'SELECT COUNT(*) FROM products p WHERE (p.reorder_point > 0 OR EXISTS(SELECT 1 FROM lots l WHERE l.product_id=p.id)) AND (SELECT COALESCE(SUM(qty_base),0) FROM lots l WHERE l.product_id=p.id AND l.status=\'sellable\' AND (expiry=\'\' OR expiry>=date(\'now\'))) <= p.reorder_point'}.items()}
    vals['accounts']=query(c,'SELECT account,SUM(debit) AS debit,SUM(credit) AS credit FROM journals GROUP BY account ORDER BY account')
    vals['recent_moves']=query(c,'SELECT sm.*,p.name FROM stock_moves sm JOIN products p ON p.id=sm.product_id ORDER BY sm.id DESC LIMIT 80')
    vals['journals_balanced']=c.execute('SELECT COALESCE(SUM(debit),0)=COALESCE(SUM(credit),0) FROM journals').fetchone()[0]==1
    return vals

def finance_overview(c):
    """Read-only ledger picture; NOT an actual Bankak bank balance."""
    balances={r['account']:r['amount'] for r in query(c,'SELECT account,COALESCE(SUM(debit-credit),0) amount FROM journals GROUP BY account')}
    claims=query(c,"SELECT cl.id,cl.period,cl.total,cl.paid,cl.status,p.name AS authority FROM claims cl JOIN partners p ON p.id=cl.authority_id ORDER BY cl.id DESC LIMIT 100")
    open_shifts=query(c,"SELECT s.id,s.opened_at,s.opening_cash,s.user_id,u.full_name FROM cash_shifts s LEFT JOIN users u ON u.id=s.user_id WHERE s.closed_at IS NULL ORDER BY s.opened_at DESC")
    summary={
        'cash_ledger':balances.get('CASH',0),
        'bank_pending_ledger':balances.get('BANK_PENDING',0),
        'bank_verified_ledger':balances.get('BANK',0),
        'insurance_receivable':balances.get('AR_AUTH',0),
        'customer_receivable':balances.get('AR_CUSTOMER',0),
        'supplier_payable':-balances.get('AP',0),
        'claims_total_unpaid':sum(max(0,x['total']-x['paid']) for x in claims),
        'unverified_transfers':c.execute("SELECT COALESCE(SUM(p.amount),0) FROM payments p LEFT JOIN bank_checks b ON b.payment_id=p.id WHERE p.method='bank' AND b.id IS NULL").fetchone()[0],
    }
    return {'summary':summary,'claims':claims,'open_shifts':[dict(row,expected_cash=shift_expected(c,row,now())) for row in open_shifts],
            'recent_shifts':query(c,"SELECT s.*,u.full_name FROM cash_shifts s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 80"),
            'expenses':query(c,'SELECT * FROM expenses ORDER BY id DESC LIMIT 80'),
            'generated_at':now(),
            'bank_note':'أرصدة التحويلات دفترية، ولا تمثل الرصيد الحقيقي في بنكك إلا بعد مطابقتها بكشف البنك.'}

def daily_cashdesk(c, day):
    """Daily activity totals. Payments, sales, ledger balances and Bankak deposits stay distinct."""
    try:
        if date.fromisoformat(day).isoformat() != day: raise ValueError()
    except (ValueError, TypeError): raise ValueError('التاريخ يجب أن يكون YYYY-MM-DD')
    sale=one(c,"""SELECT COUNT(*) invoice_count,COALESCE(SUM(total),0) gross,
                 COALESCE(SUM(covered),0) covered,COALESCE(SUM(cash_paid),0) pos_cash,
                 COALESCE(SUM(bank_paid),0) pos_bank,
                 COALESCE(SUM(due-cash_paid-bank_paid),0) credit
                 FROM sales WHERE substr(created_at,1,10)=?""",(day,))
    refunds=query(c,"""SELECT refund_method,COALESCE(SUM(amount),0) gross,
                    COALESCE(SUM(covered),0) covered,COUNT(*) count
                    FROM sale_returns WHERE substr(created_at,1,10)=? GROUP BY refund_method""",(day,))
    payments=query(c,"""SELECT party_kind,method,COALESCE(SUM(amount),0) amount,COUNT(*) count
                    FROM payments WHERE substr(created_at,1,10)=?
                    GROUP BY party_kind,method ORDER BY party_kind,method""",(day,))
    expenses=query(c,"""SELECT method,COALESCE(SUM(amount),0) amount,COUNT(*) count
                    FROM expenses WHERE substr(created_at,1,10)=? GROUP BY method""",(day,))
    transfers=query(c,"""SELECT p.id,p.doc,p.amount,p.bank_ref,p.created_at,p.party_kind,
                 (b.id IS NOT NULL) verified FROM payments p
                 LEFT JOIN bank_checks b ON b.payment_id=p.id
                 WHERE p.method='bank' AND substr(p.created_at,1,10)=?
                 AND p.party_kind IN ('customer','authority') ORDER BY p.id DESC LIMIT 250""",(day,))
    return {'day':day,'sales':dict(sale),'refunds':refunds,'payments':payments,
      'expenses':expenses,'bank_incoming':transfers,
      'note':'الأرقام من قيود البرنامج، وليست الرصيد الحقيقي في بنكك. مبيعات اليوم والتحصيلات والمرتجعات والمصروفات فئات مستقلة منعاً للجمع المكرر.'}


def finance_sale_receipts(c,day):
    """The accountant may reprint invoices without receiving rights to edit sales."""
    try:
        if date.fromisoformat(day).isoformat()!=day:raise ValueError()
    except (ValueError,TypeError):raise ValueError('التاريخ يجب أن يكون YYYY-MM-DD')
    rows=query(c,"""SELECT s.*,u.full_name employee,p.name customer,a.name authority
               FROM sales s LEFT JOIN users u ON u.id=s.user_id
               LEFT JOIN partners p ON p.id=s.partner_id
               LEFT JOIN partners a ON a.id=s.authority_id
               WHERE substr(s.created_at,1,10)=? ORDER BY s.id DESC LIMIT 500""",(day,))
    for s in rows:
        s['lines']=query(c,"""SELECT sl.*,pr.name,pk.unit_name FROM sale_lines sl
                     JOIN packages pk ON pk.id=sl.package_id
                     JOIN products pr ON pr.id=pk.product_id
                     WHERE sl.sale_id=? ORDER BY sl.id""",(s['id'],))
    return rows


def automatic_backup_once(force=False):
    """Verified, online SQLite snapshots on local drive and optional external drive.

    External destination is user-selected, not presumed. Failure never loses the local backup.
    """
    local=DATA/'backups'
    local.mkdir(parents=True,exist_ok=True)
    results={}
    for label,location,frequency in [('local',local,6*3600)]:
        existing=sorted(location.glob('auto-*.sqlite3'))
        if existing and not force and time.time()-existing[-1].stat().st_mtime<frequency:
            results[label]={'skipped':True,'file':str(existing[-1])}
        else:
            out=location/('auto-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.sqlite3')
            results[label]=recovery.copy_verified(DB,out)
            for old in sorted(location.glob('auto-*.sqlite3'))[:-28]:
                try:
                    old.unlink()
                    old.with_name(old.name+'.sha256').unlink(missing_ok=True)
                except OSError:pass
    ext_cfg=DATA/'external_backup.json'
    if ext_cfg.exists():
        try:
            external=Path(json.loads(ext_cfg.read_text(encoding='utf-8'))['folder'])
            if not external.is_dir():raise OSError('External backup drive is not connected')
            existing=sorted(external.glob('Pharmacy-auto-*.sqlite3'))
            if existing and not force and time.time()-existing[-1].stat().st_mtime<24*3600:
                results['external']={'skipped':True,'file':str(existing[-1])}
            else:
                out=external/('Pharmacy-auto-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.sqlite3')
                results['external']=recovery.copy_verified(DB,out)
                for old in sorted(external.glob('Pharmacy-auto-*.sqlite3'))[:-30]:
                    old.unlink(missing_ok=True)
                    old.with_name(old.name+'.sha256').unlink(missing_ok=True)
        except Exception as e:
            results['external']={'error':str(e)}
            print('WARNING external backup failed: '+str(e),file=sys.stderr)
    return {**results['local'],'external':results.get('external',{'configured':False})}

def start_automatic_backups():
    def task():
        while True:
            try:automatic_backup_once()
            except Exception as e:print('WARNING automatic backup failed:',e,file=sys.stderr)
            time.sleep(60*60)
    threading.Thread(target=task,name='pharmacy-backup',daemon=True).start()

def backup(c,uid):
    location=DATA/'backups';location.mkdir(parents=True,exist_ok=True)
    filename=location/('pharmacy-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3)+'.sqlite3')
    result=recovery.copy_verified(DB,filename)
    audit(c,uid,'backup',{'file':filename.name,'sha256':result['sha256']})
    return {**result,'warning':'انسخ هذا الملف إلى USB أو قرص خارجي؛ نفس الجهاز وحده لا يحمي من تعطل القرص'}

# Add-on operational workflows. Every mutation uses one SQLite transaction.
def recurring_list(c):
    plans=query(c,"""SELECT r.*,p.name AS customer, pr.name AS product,pk.unit_name,pk.factor,
      (SELECT COALESCE(SUM(l.qty_base),0) FROM lots l WHERE l.product_id=pk.product_id AND l.status='sellable' AND (l.expiry='' OR l.expiry>=date('now'))) AS available_base
      FROM recurring_plans r JOIN partners p ON p.id=r.partner_id JOIN packages pk ON pk.id=r.package_id JOIN products pr ON pr.id=pk.product_id
      ORDER BY r.active DESC,r.next_due,r.id""")
    for x in plans:
        x['required_base']=x['qty']*x['factor']
        x['shortage_base']=max(0,x['required_base']-x['available_base'])
    return plans

def recurring_create(c,p,uid):
    partner=posint(p.get('partner_id'),'العميل');package=posint(p.get('package_id'),'العبوة')
    qty=posint(p.get('qty'),'الكمية');days=posint(p.get('interval_days',30),'الدورية')
    if days>365:raise ValueError('الدورية القصوى 365 يوماً')
    due=textv(p,'next_due',10,True);date.fromisoformat(due)
    if not one(c,"SELECT id FROM partners WHERE id=? AND kind IN ('customer','pharmacy') AND active=1",(partner,)):raise ValueError('حساب العميل غير موجود')
    if not one(c,'SELECT id FROM packages WHERE id=?',(package,)):raise ValueError('العبوة غير موجودة')
    begin(c)
    try:
        id=c.execute('INSERT INTO recurring_plans(partner_id,package_id,qty,interval_days,next_due,notes,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',(partner,package,qty,days,due,textv(p,'notes',300),now(),uid)).lastrowid
        audit(c,uid,'create_refill',{'id':id,'partner':partner,'package':package})
        finish(c)
    except:rollback(c);raise
    return {'id':id,'stock_reserved':False}

def recurring_dispensed(c,p,uid):
    planid=posint(p.get('plan_id'),'خطة الدواء');saleid=posint(p.get('sale_id'),'فاتورة البيع')
    begin(c)
    try:
        plan=one(c,'SELECT * FROM recurring_plans WHERE id=? AND active=1',(planid,))
        if not plan:raise ValueError('الخطة غير نشطة')
        if plan['last_sale_id']==saleid:raise ValueError('تم ربط الفاتورة بهذه الخطة مسبقاً')
        sale=one(c,'SELECT * FROM sales WHERE id=? AND partner_id=?',(saleid,plan['partner_id']))
        if not sale:raise ValueError('الفاتورة غير مرتبطة بنفس المستفيد')
        line=one(c,'SELECT COALESCE(SUM(qty),0) AS qty FROM sale_lines WHERE sale_id=? AND package_id=?',(saleid,plan['package_id']))
        if line['qty']<plan['qty']:raise ValueError('الفاتورة لا تحتوي على الكمية المتكررة المحددة')
        nextdate=(date.today()+timedelta(days=plan['interval_days'])).isoformat()
        c.execute('UPDATE recurring_plans SET next_due=?,last_sale_id=? WHERE id=?',(nextdate,saleid,planid))
        audit(c,uid,'refill_dispensed',{'id':planid,'sale_id':saleid,'next_due':nextdate})
        finish(c)
    except:rollback(c);raise
    return {'id':planid,'next_due':nextdate,'reserved':False}

def recurring_deactivate(c,p,uid):
    id=posint(p.get('plan_id'),'الخطة');begin(c)
    try:
        c.execute('UPDATE recurring_plans SET active=0 WHERE id=?',(id,))
        if not c.execute('SELECT changes()').fetchone()[0]:raise ValueError('الخطة غير موجودة')
        audit(c,uid,'stop_refill',{'id':id});finish(c)
    except:rollback(c);raise
    return {'id':id,'active':False}

def expense_create(c,p,uid):
    category=textv(p,'category',60,True);description=textv(p,'description',300,True)
    amount=posint(p.get('amount'),'المصروف');method=textv(p,'method',12,True)
    if method not in ('cash','bank'):raise ValueError('اختار كاش أو تحويل بنكي')
    bank_ref=textv(p,'bank_ref',90)
    if method=='bank' and not bank_ref:raise ValueError('رقم عملية التحويل مطلوب')
    begin(c)
    try:
        id=c.execute('INSERT INTO expenses(category,description,amount,method,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(category,description,amount,method,bank_ref,now(),uid)).lastrowid
        journal(c,'EXP-'+str(id),[('EXPENSES',amount,0),('CASH' if method=='cash' else 'BANK_PENDING',0,amount)])
        if method=='bank':
            c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('expense',0,'EXP-'+str(id),method,amount,bank_ref,now(),uid))
        audit(c,uid,'expense',{'id':id,'amount':amount,'category':category})
        finish(c)
    except:rollback(c);raise
    return {'id':id,'amount':amount}

def shift_open(c,p,uid):
    opening=amt(p.get('opening_cash',0),'رصيد افتتاح الكاش');begin(c)
    try:
        if one(c,'SELECT id FROM cash_shifts WHERE user_id=? AND closed_at IS NULL',(uid,)):raise ValueError('عندك وردية مفتوحة بالفعل')
        id=c.execute('INSERT INTO cash_shifts(user_id,opened_at,opening_cash) VALUES(?,?,?)',(uid,now(),opening)).lastrowid
        audit(c,uid,'shift_open',{'id':id,'opening_cash':opening});finish(c)
    except:rollback(c);raise
    return {'id':id}

def shift_expected(c,row,closed_at):
    uid=row['user_id'];start=row['opened_at'];end=closed_at
    # Single responsible cashier: count cash movements created by this user inside the shift.
    received=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=? AND method='cash' AND party_kind='customer' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    authority_cash=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=? AND method='cash' AND party_kind='authority' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    supplier_cash=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=? AND method='cash' AND party_kind='supplier' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    refunds=c.execute("SELECT COALESCE(SUM(amount-covered),0) FROM sale_returns WHERE user_id=? AND refund_method='cash' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    expenses=c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND method='cash' AND created_at>=? AND created_at<=?",(uid,start,end)).fetchone()[0]
    return row['opening_cash']+received+authority_cash-supplier_cash-refunds-expenses

def shift_close(c,p,uid,manage=False):
    actual=amt(p.get('actual_cash'),'المبلغ المعدود');notes=textv(p,'notes',300)
    selected=p.get('shift_id')
    if selected not in (None,''):
        selected=posint(selected,'الوردية')
    begin(c)
    try:
        if selected:
            row=one(c,'SELECT * FROM cash_shifts WHERE id=? AND closed_at IS NULL',(selected,))
            if not row:raise ValueError('الوردية غير موجودة أو مقفلة')
            if row['user_id']!=uid and not manage:raise PermissionError('ليس لك صلاحية إقفال وردية موظف آخر')
        else:
            row=one(c,'SELECT * FROM cash_shifts WHERE user_id=? AND closed_at IS NULL',(uid,))
        if not row:raise ValueError('لا توجد وردية مفتوحة')
        end=now();expected=shift_expected(c,row,end);diff=actual-expected
        c.execute('UPDATE cash_shifts SET closed_at=?,closing_cash=?,expected_cash=?,variance=?,notes=? WHERE id=? AND closed_at IS NULL',
                  (end,actual,expected,diff,notes,row['id']))
        audit(c,uid,'shift_close',{'id':row['id'],'owner':row['user_id'],'expected':expected,'counted':actual,'variance':diff})
        finish(c)
    except:rollback(c);raise
    return {'id':row['id'],'expected_cash':expected,'counted':actual,'variance':diff}

def shift_close_all(c,p,uid):
    """Supervisor can close every open shift only with individual physical cash counts."""
    counts=p.get('counts')
    if not isinstance(counts,list) or not counts:raise ValueError('أدخل جرد الكاش الفعلي لكل وردية')
    notes=textv(p,'notes',300)
    begin(c)
    try:
        rows=query(c,'SELECT * FROM cash_shifts WHERE closed_at IS NULL ORDER BY id')
        if len(counts)!=len(rows) or {str(x.get('shift_id')) for x in counts}!={str(x['id']) for x in rows}:
            raise ValueError('تغيرت الورديات المفتوحة؛ حدّث القائمة أولاً')
        by_id={int(x['shift_id']):amt(x.get('actual_cash'),'الكاش المعدود') for x in counts}
        end=now();result=[]
        for row in rows:
            actual=by_id[row['id']];expected=shift_expected(c,row,end);variance=actual-expected
            c.execute('UPDATE cash_shifts SET closed_at=?,closing_cash=?,expected_cash=?,variance=?,notes=? WHERE id=? AND closed_at IS NULL',
                      (end,actual,expected,variance,notes,row['id']))
            result.append({'shift_id':row['id'],'expected_cash':expected,'counted':actual,'variance':variance})
        audit(c,uid,'shift_close_all',{'results':result})
        finish(c)
    except:rollback(c);raise
    return {'closed':len(result),'results':result}

def customer_payment(c,p,uid):
    sid=posint(p.get('sale_id'),'فاتورة العميل');value=posint(p.get('amount'),'السداد');method=textv(p,'method',12)
    if method not in ('cash','bank'):raise ValueError('اختر كاش أو تحويل بنكي')
    ref=textv(p,'bank_ref',90)
    if method=='bank' and not ref:raise ValueError('مرجع التحويل مطلوب')
    begin(c)
    try:
        sale=one(c,'SELECT * FROM sales WHERE id=?',(sid,))
        if not sale or not sale['partner_id']:raise ValueError('الفاتورة غير مرتبطة بحساب عميل')
        previously=c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE doc=? AND party_kind='customer'",(sale['ref'],)).fetchone()[0]
        reduced=c.execute("SELECT COALESCE(SUM(amount-covered),0) FROM sale_returns WHERE sale_id=? AND refund_method='credit'",(sid,)).fetchone()[0]
        changes=c.execute('SELECT COALESCE(SUM(delta_covered),0) FROM coverage_adjustments WHERE sale_id=?',(sid,)).fetchone()[0]
        # sale.due already includes every coverage correction; subtracting changes again double-counts.
        remaining=sale['due']-previously-reduced
        if value>remaining:raise ValueError('السداد أكبر من الرصيد المستحق على العميل')
        journal(c,'CPAY-'+uuid.uuid4().hex[:12],[('CASH' if method=='cash' else 'BANK_PENDING',value,0),('AR_CUSTOMER',0,value)])
        c.execute('INSERT INTO payments(party_kind,party_id,doc,method,amount,bank_ref,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',('customer',sale['partner_id'],sale['ref'],method,value,ref,now(),uid))
        audit(c,uid,'customer_payment',{'sale':sid,'amount':value})
        finish(c)
    except:rollback(c);raise
    return {'sale_id':sid,'paid':value,'remaining':remaining-value}

def quote_preview(c,p):
    barcode=textv(p,'barcode',80);packageid=p.get('package_id')
    if packageid:pk=one(c,'SELECT * FROM packages WHERE id=?',(posint(packageid,'العبوة'),))
    else:pk=one(c,'SELECT * FROM packages WHERE barcode=?',(barcode,)) if barcode else None
    if not pk:return {'matched':False,'question':'الصنف أو الباركود غير معروف. حدد الصنف والعبوة يدوياً، ولا يتم اعتماد سعر تلقائياً.'}
    factor=posint(p.get('supplier_pack_factor',pk['factor']),'حجم عبوة المورد');cost=amt(p.get('supplier_price'),'السعر')
    supplierid=p.get('supplier_id')
    prev=one(c,'SELECT * FROM price_quotes WHERE supplier_id=? AND package_id=? ORDER BY id DESC LIMIT 1',(supplierid,pk['id'])) if supplierid else None
    normalized=cost*1000//factor
    old=prev['unit_base_milli'] if prev else None
    anomalous=bool(old is not None and old>0 and abs(normalized-old)*100>40*old)
    ambiguity=factor!=pk['factor']
    return {'matched':True,'package_id':pk['id'],'unit_name':pk['unit_name'],'package_factor':pk['factor'],'supplier_factor':factor,'supplier_price':cost,'price_per_base_milli':normalized,'previous_per_base_milli':old,'different':(old is None or normalized!=old),'anomaly':anomalous,'unit_mismatch':ambiguity,'requires_review':anomalous or ambiguity}

def quote_save(c,p,uid):
    supplier=posint(p.get('supplier_id'),'المورد')
    if not one(c,'SELECT id FROM suppliers WHERE id=?',(supplier,)):raise ValueError('المورد غير موجود')
    preview=quote_preview(c,p)
    if not preview['matched']:raise ValueError('يجب مطابقة الصنف والعبوة أولاً')
    if preview['requires_review'] and not p.get('confirmed_review'):raise ValueError('العبوة أو السعر يحتاج تأكيد المراجعة قبل الحفظ')
    begin(c)
    try:
        row=c.execute('INSERT INTO price_quotes(supplier_id,package_id,supplier_pack_factor,supplier_price,unit_base_milli,source_file,created_at,user_id) VALUES(?,?,?,?,?,?,?,?)',(supplier,preview['package_id'],preview['supplier_factor'],preview['supplier_price'],preview['price_per_base_milli'],textv(p,'source_file',150),now(),uid))
        audit(c,uid,'supplier_quote',{'id':row.lastrowid,'anomaly':preview['anomaly'],'unit_mismatch':preview['unit_mismatch']})
        finish(c)
    except:rollback(c);raise
    return {'id':row.lastrowid,'preview':preview,'inventory_modified':False,'selling_prices_modified':False}

def coverage_correct(c,p,uid):
    sid=posint(p.get('sale_id'),'الفاتورة');new=amt(p.get('coverage'),'نسبة تغطية الجهة');reason=textv(p,'reason',300,True)
    if new>100:raise ValueError('النسبة من 0 إلى 100 فقط')
    begin(c)
    try:
        sale=one(c,'SELECT * FROM sales WHERE id=?',(sid,))
        if not sale or not sale['authority_id']:raise ValueError('لا توجد جهة مرتبطة بالفاتورة')
        oldcov=sale['covered'];newcov=(sale['total']*new+50)//100
        refunded=c.execute("SELECT COALESCE(SUM(covered),0) FROM sale_returns WHERE sale_id=?",(sid,)).fetchone()[0]
        if refunded:raise ValueError('الفاتورة فيها مرتجع، تحتاج معالجة تسوية مفصلة قبل تغيير التغطية')
        paid=sale['cash_paid']+sale['bank_paid']+c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE doc=? AND party_kind='customer'",(sale['ref'],)).fetchone()[0]-sale['cash_paid']-sale['bank_paid']
        if paid>sale['total']-newcov:raise ValueError('التغطية الجديدة تستوجب رد مبلغ للعميل؛ نفّذ تسوية استرداد معتمدة أولاً')
        delta=newcov-oldcov
        if not delta:finish(c);return {'id':sid,'changed':False}
        old= sale['coverage']
        c.execute('UPDATE sales SET coverage=?,covered=?,due=? WHERE id=?',(new,newcov,sale['total']-newcov,sid))
        a=c.execute('INSERT INTO coverage_adjustments(sale_id,old_coverage,new_coverage,delta_covered,reason,created_at,user_id) VALUES(?,?,?,?,?,?,?)',(sid,old,new,delta,reason,now(),uid)).lastrowid
        if delta>0:journal(c,'COV-'+str(a),[('AR_AUTH',delta,0),('AR_CUSTOMER',0,delta)])
        else:journal(c,'COV-'+str(a),[('AR_CUSTOMER',-delta,0),('AR_AUTH',0,-delta)])
        audit(c,uid,'coverage_correction',{'sale_id':sid,'before':old,'after':new,'delta':delta})
        finish(c)
    except:rollback(c);raise
    return {'id':a,'sale_id':sid,'covered_adjustment':delta,'claim_already_created':bool(one(c,'SELECT 1 AS yes FROM claim_sales WHERE sale_id=?',(sid,))),'requires_claim_settlement':bool(one(c,'SELECT 1 AS yes FROM claim_sales WHERE sale_id=?',(sid,)))}

def bank_verify(c,p,uid):
    payment=posint(p.get('payment_id'),'الدفعة');note=textv(p,'note',300,True)
    begin(c)
    try:
        row=one(c,"SELECT * FROM payments WHERE id=? AND method='bank'",(payment,))
        if not row or not row['bank_ref']:raise ValueError('عملية تحويل غير موجودة أو بلا مرجع')
        id=c.execute('INSERT INTO bank_checks(payment_id,verified_at,verified_by,note) VALUES(?,?,?,?)',(payment,now(),uid,note)).lastrowid
        if row['party_kind'] in ('supplier','expense','refund'):
            journal(c,'BANK-CHECK-'+str(id),[('BANK_PENDING',row['amount'],0),('BANK',0,row['amount'])])
        else:
            journal(c,'BANK-CHECK-'+str(id),[('BANK',row['amount'],0),('BANK_PENDING',0,row['amount'])])
        audit(c,uid,'bank_verified_manually',{'payment_id':payment,'note':note})
        finish(c)
    except:rollback(c);raise
    return {'id':id,'status':'verified_manually_not_via_bank'}

def insurance_contract_create(c,p,uid):
    authority=posint(p.get('authority_id'),'الجهة')
    row=one(c,"SELECT id FROM partners WHERE id=? AND kind='authority' AND active=1",(authority,))
    if not row:raise ValueError('الجهة غير مسجلة ضمن جهات التأمين')
    code=textv(p,'code',64,True);starts=textv(p,'starts',10,True);ends=textv(p,'ends',10)
    date.fromisoformat(starts)
    if ends:
        date.fromisoformat(ends)
        if ends<starts:raise ValueError('تاريخ انتهاء العقد قبل بدايته')
    pct=amt(p.get('coverage_default',100),'التغطية الافتراضية')
    if pct>100:raise ValueError('نسبة التغطية من 0 إلى 100')
    begin(c)
    try:
        new=c.execute('INSERT INTO insurance_contracts(authority_id,code,coverage_default,starts,ends,active,notes,created_at) VALUES(?,?,?,?,?,?,?,?)',
          (authority,code,pct,starts,ends,1,textv(p,'notes',500),now())).lastrowid
        audit(c,uid,'create_insurance_contract',{'id':new,'authority_id':authority,'code':code,'coverage_default':pct})
        finish(c)
    except:rollback(c);raise
    return {'id':new}

def insurance_member_create(c,p,uid):
    contract=posint(p.get('contract_id'),'العقد');partner=posint(p.get('partner_id'),'المستفيد')
    if not one(c,'SELECT id FROM insurance_contracts WHERE id=?',(contract,)):raise ValueError('عقد التأمين غير موجود')
    if not one(c,'SELECT id FROM partners WHERE id=?',(partner,)):raise ValueError('المستفيد غير موجود')
    relation=textv(p,'relation',50,True)
    override=p.get('coverage_override')
    if override in (None,''):override=None
    else:
        override=amt(override,'التغطية الافتراضية للمستفيد')
        if override>100:raise ValueError('التغطية 0 إلى 100')
    begin(c)
    try:
        new=c.execute('INSERT INTO insurance_members(contract_id,partner_id,relation,coverage_override,created_at) VALUES(?,?,?,?,?)',
         (contract,partner,relation,override,now())).lastrowid
        audit(c,uid,'create_insurance_member',{'id':new,'contract_id':contract,'partner_id':partner,'relation':relation})
        finish(c)
    except:rollback(c);raise
    return {'id':new}

def insurance_list(c):
    entries=query(c,"""SELECT ic.*,p.name AS authority_name FROM insurance_contracts ic
        JOIN partners p ON p.id=ic.authority_id ORDER BY ic.id DESC""")
    for entry in entries:
        entry['members']=query(c,"""SELECT im.*,p.name AS beneficiary_name FROM insurance_members im
         JOIN partners p ON p.id=im.partner_id WHERE im.contract_id=? ORDER BY im.id""",(entry['id'],))
    return entries

def prepare_invoice_preview(c,p):
    """Never updates inventory. Preview imported rows, exact barcode/SKU and cautious matching only."""
    rows=p.get('rows')
    if not isinstance(rows,list) or len(rows)>1000:raise ValueError('صفوف الفاتورة غير صالحة')
    cols=p.get('columns') or {'barcode':0,'qty':1,'unit_cost':2,'description':3}
    if not isinstance(cols,dict):raise ValueError('تحديد الأعمدة غير صالح')
    for key,index in cols.items():
        if key not in ('barcode','qty','unit_cost','description','batch','expiry','bonus','discount'):raise ValueError('عمود غير مدعوم')
        if not isinstance(index,int) or index<0 or index>39:raise ValueError('رقم عمود غير صالح')
    results=[]
    for idx,row in enumerate(rows[:1000],1):
        if not isinstance(row,list):continue
        def col(k):
            n=cols.get(k)
            return str(row[n] if n is not None and n<len(row) else '').strip()
        barcode=col('barcode');description=col('description')
        if not any(str(x).strip() for x in row):continue
        if idx==1 and any(x.lower() in {'barcode','الباركود','qty','quantity','الكمية','price','السعر'} for x in row if isinstance(x,str)):
            continue
        matches=query(c,'SELECT pk.id AS package_id,pk.unit_name,pk.factor,pk.barcode,pr.name FROM packages pk JOIN products pr ON pr.id=pk.product_id WHERE pk.barcode=?',(barcode,)) if barcode else []
        if not matches and description:
            matches=query(c,'SELECT pk.id AS package_id,pk.unit_name,pk.factor,pk.barcode,pr.name FROM packages pk JOIN products pr ON pr.id=pk.product_id WHERE lower(pr.name)=lower(?) AND pr.active=1',(description,))
        issue=[]
        if len(matches)!=1:issue.append('مطابقة غير مؤكدة: اختر العبوة يدوياً' if matches else 'صنف غير معروف / راجع الباركود أو الاسم')
        try:qty=posint(col('qty'),'الكمية')
        except ValueError:qty=None;issue.append('كمية غير صحيحة')
        try:price=amt(col('unit_cost'),'التكلفة')
        except ValueError:price=None;issue.append('سعر غير صحيح')
        try:bonus=amt(col('bonus') or 0,'البونص')
        except ValueError:bonus=None;issue.append('بونص غير صحيح')
        try:discount=amt(col('discount') or 0,'الخصم')
        except ValueError:discount=None;issue.append('خصم غير صحيح')
        expiry=col('expiry');batch=col('batch')
        if expiry:
            try:date.fromisoformat(expiry)
            except ValueError:issue.append('تاريخ صلاحية غير صحيح')
        if qty is not None and price is not None and discount is not None and discount>qty*price:issue.append('خصم يتجاوز قيمة السطر')
        results.append({'source_row':idx,'source_barcode':barcode,'description':description,'package_id':matches[0]['package_id'] if len(matches)==1 else None,'matched_name':matches[0]['name'] if len(matches)==1 else '',
          'qty':qty,'unit_cost':price,'bonus':bonus,'discount':discount,'batch':batch,'expiry':expiry,'warnings':issue,'status':'needs_review' if issue else 'matched'})
    return {'rows':results,'matched':sum(x['status']=='matched' for x in results),'needs_review':sum(x['status']!='matched' for x in results),'updates_applied':0}

def integrity_review(c):
    """Operational diagnostics, not a warranty/certification of financial or clinical correctness."""
    checks=[]
    def check(label,failures,details=None):checks.append({'check':label,'passed':failures==0,'errors':failures,'details':details or ''})
    r=one(c,"SELECT COUNT(*) AS n FROM (SELECT doc FROM journals GROUP BY doc HAVING SUM(debit)<>SUM(credit))")
    check('توازن كل مستند في دفتر اليومية',r['n'])
    r=one(c,"SELECT COUNT(*) AS n FROM lots WHERE qty_base<0")
    check('عدم وجود رصيد تشغيلة سالب',r['n'])
    r=one(c,"SELECT COUNT(*) AS n FROM (SELECT lot_id,SUM(qty_base) AS movement FROM stock_moves GROUP BY lot_id) x JOIN lots l ON l.id=x.lot_id WHERE x.movement<>l.qty_base")
    check('رصيد التشغيلات يطابق سجل حركات المخزون',r['n'])
    r=one(c,"SELECT COUNT(*) AS n FROM claims WHERE paid>total OR paid<0 OR total<0")
    check('المطالبات لا تتجاوز تحصيلاتها',r['n'])
    r=one(c,"SELECT COUNT(*) AS n FROM sales WHERE covered>total OR coverage<0 OR coverage>100 OR cash_paid+bank_paid>due")
    check('تغطيات الفواتير وحدود التحصيل',r['n'])
    check('فحص سلامة SQLite',int(c.execute('PRAGMA quick_check').fetchone()[0]!='ok'))
    return {'passed':all(x['passed'] for x in checks),'checks':checks,'checked_at':now(),'scope':'فحص اتساق آلي جزئي؛ لا يعني جاهزية التشغيل'}

class Handler(http.server.BaseHTTPRequestHandler):
    server_version='MADAR/1.2'
    def log_message(self,*args):pass
    def reply(self,data,status=200,extra_headers=None):
        b=json.dumps(data,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        if extra_headers:
            for a,v in extra_headers:self.send_header(a,v)
        self.end_headers();self.wfile.write(b)
    def get_path(self):return urlparse(self.path).path
    def handle_error(self,e):
        if isinstance(e,PermissionError):status=403
        elif isinstance(e,(ValueError,sqlite3.IntegrityError)):status=400
        else:status=500;traceback.print_exc()
        self.reply({'error':str(e) if status!=500 else 'خطأ داخلي؛ راجع سجل السيرفر'},status)
    def do_GET(self):
        path=self.get_path()
        if path=='/' or path=='/index.html':
            content=(ROOT/'static'/'index.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(content)));self.send_header('Cache-Control','no-cache');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(content);return
        if path in ('/static/style.css','/static/app.js','/static/v06_extensions.js','/static/opening_inventory.js','/static/workstation_upgrade.js','/static/daily_finance.js','/static/ux_v14.js','/static/logo.png'):
            f=ROOT/path.lstrip('/');content=f.read_bytes();self.send_response(200);self.send_header('Content-Type','text/css' if f.suffix=='.css' else 'image/png' if f.suffix=='.png' else 'application/javascript');self.send_header('Content-Length',str(len(content)));self.send_header('Cache-Control','no-cache');self.end_headers();self.wfile.write(content);return
        if not path.startswith('/api/v1/'):self.send_error(404);return
        try:
            with closing(db_connect()) as c:
                u=authenticated(c,self.headers)
                if path=='/api/v1/status':return self.reply({'ready':bool(one(c,'SELECT id FROM users LIMIT 1')),'pilot':True})
                if path=='/api/v1/me':return self.reply({'user':{'id':u['id'],'username':u['username'],'full_name':u['full_name'],'permissions':json.loads(u['permissions'])} if u else None})
                if not u:raise PermissionError('يجب تسجيل الدخول')
                permission={'/api/v1/products':'catalog','/api/v1/suppliers':'purchase','/api/v1/partners':'sale','/api/v1/sales':'sale','/api/v1/purchases':'purchase','/api/v1/stock-moves':'stock','/api/v1/claims':'claims','/api/v1/purchase-lines':'purchase','/api/v1/exchanges':'partners','/api/v1/reports':'reports','/api/v1/users':'users','/api/v1/audit':'users','/api/v1/refills':'sale','/api/v1/shifts':'finance','/api/v1/expenses':'finance','/api/v1/quotes':'prices','/api/v1/coverage-adjustments':'claims','/api/v1/bank-checks':'finance','/api/v1/payments':'finance','/api/v1/insurance':'claims','/api/v1/integrity':'backup','/api/v1/insurance-decisions':'claims','/api/v1/insurance-credit-notes':'claims','/api/v1/pricing-history':'prices','/api/v1/closed-periods':'finance','/api/v1/pharmacy-settlements':'finance','/api/v1/insurance-return-credits':'claims','/api/v1/opening-imports':'stock','/api/v1/catalog-imports':'catalog','/api/v1/finance-overview':'finance','/api/v1/daily-cashdesk':'finance','/api/v1/finance-receipts':'finance'}.get(path,'reports')
                if not allowed(u,permission):raise PermissionError('لا تملك صلاحية العرض')
                results={
                    '/api/v1/products':lambda:catalog(c),
                    '/api/v1/suppliers':lambda:supplier_balances(c),
                    '/api/v1/partners':lambda:query(c,'SELECT * FROM partners ORDER BY name'),
                    '/api/v1/sales':lambda:sales(c),
                    '/api/v1/purchases':lambda:query(c,'SELECT p.*,s.name AS supplier FROM purchases p JOIN suppliers s ON s.id=p.supplier_id ORDER BY p.id DESC LIMIT 250'),
                    '/api/v1/stock-moves':lambda:query(c,'SELECT sm.*,p.name FROM stock_moves sm JOIN products p ON p.id=sm.product_id ORDER BY sm.id DESC LIMIT 200'),
                    '/api/v1/claims':lambda:query(c,'SELECT cl.*,p.name AS authority FROM claims cl JOIN partners p ON p.id=cl.authority_id ORDER BY cl.id DESC'),
                    '/api/v1/purchase-lines':lambda:query(c,'SELECT pl.*,pk.unit_name,pr.name AS product_name FROM purchase_lines pl JOIN packages pk ON pk.id=pl.package_id JOIN products pr ON pr.id=pk.product_id ORDER BY pl.id DESC LIMIT 1000'),
                    '/api/v1/exchanges':lambda:query(c,'SELECT ex.*,p.name AS pharmacy FROM pharmacy_exchanges ex JOIN partners p ON p.id=ex.partner_id ORDER BY ex.id DESC LIMIT 100'),
                    '/api/v1/reports':lambda:report(c),
                    '/api/v1/opening-imports':lambda:query(c,'SELECT * FROM opening_imports ORDER BY id DESC LIMIT 100'),
                    '/api/v1/catalog-imports':lambda:query(c,'SELECT * FROM catalog_imports ORDER BY id DESC LIMIT 50'),
                    '/api/v1/finance-overview':lambda:finance_overview(c),
                    '/api/v1/daily-cashdesk':lambda:daily_cashdesk(c,(parse_qs(urlparse(self.path).query).get('day') or [today()])[0]),
                    '/api/v1/finance-receipts':lambda:finance_sale_receipts(c,(parse_qs(urlparse(self.path).query).get('day') or [today()])[0]),
                    '/api/v1/users':lambda:query(c,'SELECT id,username,full_name,permissions,active FROM users'),
                    '/api/v1/audit':lambda:query(c,'SELECT a.*,u.username FROM audit a JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100'),
                    '/api/v1/refills':lambda:recurring_list(c),
                    '/api/v1/shifts':lambda:query(c,'SELECT * FROM cash_shifts ORDER BY id DESC LIMIT 150'),
                    '/api/v1/expenses':lambda:query(c,'SELECT * FROM expenses ORDER BY id DESC LIMIT 200'),
                    '/api/v1/quotes':lambda:query(c,'SELECT q.*,pr.name,pk.unit_name FROM price_quotes q JOIN packages pk ON pk.id=q.package_id JOIN products pr ON pr.id=pk.product_id ORDER BY q.id DESC LIMIT 200'),
                    '/api/v1/coverage-adjustments':lambda:query(c,'SELECT * FROM coverage_adjustments ORDER BY id DESC LIMIT 150'),
                    '/api/v1/bank-checks':lambda:query(c,'SELECT * FROM bank_checks ORDER BY id DESC LIMIT 150'),
                    '/api/v1/payments':lambda:query(c,'SELECT * FROM payments ORDER BY id DESC LIMIT 200'),'/api/v1/insurance':lambda:insurance_list(c),'/api/v1/integrity':lambda:integrity_review(c),
                    '/api/v1/insurance-decisions':lambda:query(c,'SELECT * FROM claims_adjudication ORDER BY id DESC'),
                    '/api/v1/insurance-credit-notes':lambda:query(c,'SELECT * FROM insurance_credit_notes ORDER BY id DESC'),
                    '/api/v1/pricing-history':lambda:query(c,'SELECT * FROM pricing_batches ORDER BY id DESC LIMIT 250'),
                    '/api/v1/closed-periods':lambda:query(c,'SELECT * FROM closed_periods ORDER BY period DESC'),
                    '/api/v1/pharmacy-settlements':lambda:query(c,'SELECT * FROM pharmacy_settlements ORDER BY id DESC'),'/api/v1/insurance-return-credits':lambda:query(c,'SELECT * FROM insurance_return_credit_notes ORDER BY id DESC')}
                if path not in results:self.send_error(404);return
                return self.reply(results[path]())
        except Exception as e:self.handle_error(e)
    def do_POST(self):
        path=self.get_path()
        if not path.startswith('/api/v1/'):self.send_error(404);return
        try:
            length=int(self.headers.get('Content-Length',0))
            if length<0 or length>8*1024*1024:raise ValueError('حجم الطلب كبير')
            data=json.loads(self.rfile.read(length)) if length else {}
            if not isinstance(data,dict):raise ValueError('بيانات الطلب غير صالحة')
            origin=self.headers.get('Origin','')
            if origin and urlparse(origin).netloc!=self.headers.get('Host',''):raise PermissionError('Origin غير مسموح')
            with closing(db_connect()) as c:
                if path=='/api/v1/bootstrap':return self.reply(bootstrap(c,data))
                if path=='/api/v1/login':
                    res=logged_user(c,data)
                    return self.reply({'user':res['user']},extra_headers=[('Set-Cookie','pharmacy_session='+res['token']+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200')])
                u=authenticated(c,self.headers)
                if not u:raise PermissionError('يجب تسجيل الدخول')
                # Disallow form posts from other origins when Origin is supplied
                origin=self.headers.get('Origin','')
                if origin and urlparse(origin).netloc!=self.headers.get('Host',''):raise PermissionError('Origin غير مسموح')
                routes={
                    '/api/v1/products':('catalog',lambda:create_product(c,data,u['id'])),
                    '/api/v1/product-update':('catalog',lambda:update_product(c,data,u['id'])),
                    '/api/v1/package':('catalog',lambda:edit_package(c,data,u['id'])),
                    '/api/v1/supplier':('purchase',lambda:create_party(c,data,'supplier',u['id'])),
                    '/api/v1/partner':('partners',lambda:create_party(c,data,textv(data,'kind',25,True),u['id'])),
                    '/api/v1/purchase':('purchase',lambda:purchase(c,data,u['id'])),
                    '/api/v1/purchase-receipt':('purchase',lambda:purchase_receipt(c,data,u['id'])),
                    '/api/v1/purchase-return':('purchase',lambda:purchase_return(c,data,u['id'])),
                    '/api/v1/exchange':('partners',lambda:pharmacy_exchange(c,data,u['id'])),
                    '/api/v1/sale':('sale',lambda:sell(c,data,u['id'])),
                    '/api/v1/return':('refund',lambda:sale_return(c,data,u['id'])),
                    '/api/v1/supplier-payment':('finance',lambda:supplier_payment(c,data,u['id'])),
                    '/api/v1/prices':('prices',lambda:price_update(c,data,u['id'])),
                    '/api/v1/claim':('claims',lambda:claim_create(c,data,u['id'])),
                    '/api/v1/claim-payment':('claims',lambda:claim_payment(c,data,u['id'])),
                    '/api/v1/stock-adjust':('stock_adjust',lambda:stock_adjust(c,data,u['id'])),
                    '/api/v1/catalog-preview':('catalog',lambda:catalog_import.preview(c,data.get('rows'))),
                    '/api/v1/catalog-commit':('catalog',lambda:catalog_import.commit(c,data.get('rows'),data.get('source'),u['id'],data.get('request_id'))),
                    '/api/v1/catalog-parse':('catalog',lambda:{'rows':read_invoice_file(base64.b64decode(data['data'],validate=True),textv(data,'name',200,True))}),
                    '/api/v1/opening-preview':('stock',lambda:opening_inventory.validate(c,data.get('rows'))),
                    '/api/v1/opening-commit':('stock',lambda:opening_inventory.import_stock(c,data.get('rows'),u['id'],data.get('request_id'))),
                    '/api/v1/backup':('backup',lambda:backup(c,u['id'])),
                    '/api/v1/parse-file':('purchase',lambda:{'rows':read_invoice_file(base64.b64decode(data['data']),textv(data,'name',200,True))}),
                    '/api/v1/opening-parse-file':('stock',lambda:{'rows':read_invoice_file(base64.b64decode(data['data'],validate=True),textv(data,'name',200,True))}),
                    '/api/v1/refill':('sale',lambda:recurring_create(c,data,u['id'])),
                    '/api/v1/refill-dispensed':('sale',lambda:recurring_dispensed(c,data,u['id'])),
                    '/api/v1/refill-deactivate':('sale',lambda:recurring_deactivate(c,data,u['id'])),
                    '/api/v1/expense':('finance',lambda:expense_create(c,data,u['id'])),
                    '/api/v1/shift-open':('finance',lambda:shift_open(c,data,u['id'])),
                    '/api/v1/shift-close':('finance',lambda:shift_close(c,data,u['id'],allowed(u,'shift_manage'))),
                    '/api/v1/shift-close-all':('shift_manage',lambda:shift_close_all(c,data,u['id'])),
                    '/api/v1/customer-payment':('finance',lambda:customer_payment(c,data,u['id'])),
                    '/api/v1/quote':('prices',lambda:quote_save(c,data,u['id'])),
                    '/api/v1/quote-preview':('prices',lambda:quote_preview(c,data)),
                    '/api/v1/coverage-correction':('claims',lambda:coverage_correct(c,data,u['id'])),
                    '/api/v1/bank-verify':('finance',lambda:bank_verify(c,data,u['id'])),
                    '/api/v1/insurance-contract':('claims',lambda:insurance_contract_create(c,data,u['id'])),
                    '/api/v1/insurance-member':('claims',lambda:insurance_member_create(c,data,u['id'])),
                    '/api/v1/invoice-preview':('purchase',lambda:prepare_invoice_preview(c,data)),
                    '/api/v1/finance-statements':('finance',lambda:extensions.finance_statements(c,data)),
                    '/api/v1/close-period':('finance',lambda:extensions.close_period(c,data,u['id'])),
                    '/api/v1/insurance-submit':('claims',lambda:extensions.insurance_submit(c,data,u['id'])),
                    '/api/v1/insurance-decision':('claims',lambda:extensions.insurance_adjudicate(c,data,u['id'])),
                    '/api/v1/insurance-credit':('claims',lambda:extensions.insurance_credit(c,data,u['id'])),
                    '/api/v1/pricing-preview':('prices',lambda:extensions.price_batch_preview(c,data)),
                    '/api/v1/pricing-approve':('prices',lambda:extensions.price_batch_approve(c,data,u['id'])),
                    '/api/v1/reorder-suggestions':('purchase',lambda:extensions.reorder_suggestions(c,data)),
                    '/api/v1/pharmacy-settle':('finance',lambda:extensions.pharmacy_settle(c,data,u['id'])),
                }
                if path=='/api/v1/logout':
                    raw=self.headers.get('Cookie','')
                    cookie=http.cookies.SimpleCookie()
                    try:cookie.load(raw)
                    except:pass
                    if 'pharmacy_session' in cookie:
                        hashed=hashlib.sha256(cookie['pharmacy_session'].value.encode()).hexdigest()
                        c.execute('DELETE FROM sessions WHERE token_hash=?',(hashed,))
                    return self.reply({'ok':True},extra_headers=[('Set-Cookie','pharmacy_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')])
                if path=='/api/v1/user':
                    if not allowed(u,'users'):raise PermissionError('صلاحية إدارة المستخدمين مطلوبة')
                    username=textv(data,'username',60,True);full=textv(data,'full_name',100,True);password=str(data.get('password',''))
                    if len(password)<12:raise ValueError('كلمة المرور قصيرة')
                    perms=data.get('permissions',[])
                    if not isinstance(perms,list) or set(perms)-PERMISSIONS:raise ValueError('صلاحيات غير صالحة')
                    if not set(perms).issubset(set(json.loads(u['permissions']))):raise PermissionError('لا يمكن منح صلاحيات لا يملكها المسؤول الحالي')
                    salt=secrets.token_hex(16)
                    with c:
                        cur=c.execute('INSERT INTO users(username,full_name,pass_hash,salt,permissions) VALUES(?,?,?,?,?)',(username,full,password_hash(password,salt),salt,json.dumps(perms)))
                        audit(c,u['id'],'create_user',{'id':cur.lastrowid})
                    return self.reply({'id':cur.lastrowid})
                if path=='/api/v1/user-permissions':
                    if not allowed(u,'users'):raise PermissionError('صلاحية إدارة المستخدمين مطلوبة')
                    target=posint(data.get('user_id'),'المستخدم');perms=data.get('permissions',[])
                    if not isinstance(perms,list) or set(perms)-PERMISSIONS:raise ValueError('صلاحيات غير صالحة')
                    if not set(perms).issubset(set(json.loads(u['permissions']))):
                        raise PermissionError('لا يمكن منح صلاحيات لا يملكها المسؤول الحالي')
                    existing=one(c,'SELECT id,permissions FROM users WHERE id=?',(target,))
                    if not existing:raise ValueError('المستخدم المطلوب غير موجود')
                    if target==u['id'] and 'users' not in perms:raise ValueError('لا يمكن حذف صلاحية إدارة المستخدمين من حسابك مباشرة')
                    if existing['id']==1 and 'users' not in perms:raise ValueError('لا يمكن حرمان حساب المالك الأساسي من إدارة المستخدمين')
                    with c:
                        c.execute('UPDATE users SET permissions=? WHERE id=?',(json.dumps(perms),target))
                        audit(c,u['id'],'edit_user_permissions',{'target':target,'permissions':perms})
                    return self.reply({'ok':True})
                if path not in routes:self.send_error(404);return
                permission,func=routes[path]
                if not allowed(u,permission):raise PermissionError('الصلاحية غير متاحة: '+permission)
                return self.reply(func())
        except Exception as e:self.handle_error(e)

class ThreadServer(http.server.ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True

def main():
    global DB,DATA
    parser=argparse.ArgumentParser()
    parser.add_argument('--host',default='127.0.0.1',help='127.0.0.1 for one PC, 0.0.0.0 for LAN test on trusted network only')
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--backup',action='store_true')
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    init_db(preload_catalog=True)
    if not args.backup:start_automatic_backups()
    if args.backup:
        with closing(db_connect()) as c:
            location=DATA/'backups';location.mkdir(parents=True,exist_ok=True)
            out=location/('manual-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.sqlite3')
            dst=sqlite3.connect(out);c.backup(dst);dst.close();print(out)
        return
    url=f'http://127.0.0.1:{args.port}'
    print('Pharmacy ERP functional PILOT - not certified for production')
    print('DB:',DB)
    print('Local URL:',url)
    if args.host=='0.0.0.0':print('WARNING: LAN HTTP is not encrypted. Use only isolated trusted test network.')
    srv=ThreadServer((args.host,args.port),Handler)
    if not args.no_browser:threading.Timer(1.2,lambda:webbrowser.open(url)).start()
    try:srv.serve_forever()
    except KeyboardInterrupt:pass
    finally:srv.server_close()

if __name__=='__main__':main()
