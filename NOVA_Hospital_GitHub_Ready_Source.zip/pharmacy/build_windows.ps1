$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'MADAR Pharmacy: isolated offline Windows installer'
python -m pip install --disable-pip-version-check --upgrade pip
python -m pip install --disable-pip-version-check pyinstaller pywebview pywin32
python -m pip install --disable-pip-version-check openpyxl
python -m unittest discover -s tests -p 'test_*.py' -v
python -m PyInstaller --runtime-hook ci/smoke_desktop.py --hidden-import=device_services --hidden-import=recovery --hidden-import=opening_inventory --hidden-import=catalog_import --hidden-import=preloaded_catalog --noconfirm --clean --windowed --onedir --icon 'assets/app.ico' --name HospitalPharmacyERP --add-data 'static;static' --collect-all webview --hidden-import=win32print desktop.py
if ($LASTEXITCODE -ne 0) { throw "Desktop packaging failed" }
python -m PyInstaller --runtime-hook ci/smoke_restore.py --hidden-import=app --hidden-import=opening_inventory --hidden-import=catalog_import --hidden-import=preloaded_catalog --noconfirm --clean --onefile --windowed --icon 'assets/app.ico' --name RestorePharmacyBackup recovery.py
if ($LASTEXITCODE -ne 0) { throw "Restore tool packaging failed" }
if (-not (Test-Path '.\dist\HospitalPharmacyERP\HospitalPharmacyERP.exe')) { throw 'PyInstaller output missing' }
# Offline WebView2 runtime: user is not required to download it on each pharmacy computer.
New-Item -ItemType Directory -Force -Path redist | Out-Null
$runtime = Join-Path $PSScriptRoot 'redist\MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/?linkid=2124701' -OutFile $runtime -MaximumRedirection 10
if ((Get-Item $runtime).Length -lt 10000000) { throw 'WebView2 offline installer download is invalid.' }
$iscc = @('C:\Program Files (x86)\Inno Setup 6\ISCC.exe','C:\Program Files\Inno Setup 6\ISCC.exe') | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { $command = Get-Command ISCC.exe -ErrorAction SilentlyContinue; if ($command) { $iscc = $command.Source } }
if (-not $iscc) { throw 'Inno Setup 6 missing on runner.' }
& $iscc 'windows-installer.iss'
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup failed' }
if (-not (Test-Path 'Output\MADAR-Pharmacy-Setup.exe')) { throw 'Setup.exe missing after compiler' }
Get-FileHash -Algorithm SHA256 'Output\MADAR-Pharmacy-Setup.exe' | Format-List
