"""Auditable, atomic initial stock import for a *single workstation* pharmacy.

No inferred product/lot matches, no fictitious expiry, and no silent partial commits.
"""
from __future__ import annotations
import hashlib
import json
import re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation

FIELDS = ('sku','name','barcode','unit_name','factor','base_uom','quantity','batch','expiry','unit_cost','sale_price','generic_name','manufacturer')
ALIAS = {
    'sku':('sku','code','item_code','كود','كود الصنف','رمز الصنف'),
    'name':('name','product','medicine','product_name','اسم الدواء','الصنف','اسم الصنف'),
    'barcode':('barcode','باركود','الباركود'),
    'unit_name':('unit','unit_name','package','وحدة','وحدة التعبئة','العبوة'),
    'factor':('factor','conversion','pack_factor','معامل التحويل','عدد الحبات'),
    'base_uom':('base_uom','base_unit','الوحدة الأساسية'),
    'quantity':('quantity','qty','qty_packages','الكمية','العدد'),
    'batch':('batch','lot','التشغيلة','رقم التشغيلة'),
    'expiry':('expiry','exp','expiration','الصلاحية','تاريخ الصلاحية'),
    'unit_cost':('unit_cost','cost','purchase_price','سعر الشراء','تكلفة العبوة'),
    'sale_price':('sale_price','price','selling_price','سعر البيع'),
    'generic_name':('generic_name','generic','الاسم العلمي'),
    'manufacturer':('manufacturer','company','الشركة','المصنع'),
}

SCHEMA = '''
CREATE TABLE IF NOT EXISTS opening_imports(
 id INTEGER PRIMARY KEY, fingerprint TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL,
 user_id INTEGER NOT NULL REFERENCES users(id), row_count INTEGER NOT NULL,
 total_value INTEGER NOT NULL CHECK(total_value>=0));
CREATE TABLE IF NOT EXISTS opening_import_lines(
 id INTEGER PRIMARY KEY, import_id INTEGER NOT NULL REFERENCES opening_imports(id),
 source_row INTEGER NOT NULL, package_id INTEGER NOT NULL REFERENCES packages(id),
 lot_id INTEGER NOT NULL REFERENCES lots(id), qty_base INTEGER NOT NULL,
 amount INTEGER NOT NULL CHECK(amount>=0));
'''

def _normalized_header(value):
    return re.sub(r'[\s\-]+','_',str(value or '').strip().lower())

ALIASES = {_normalized_header(a): k for k,opts in ALIAS.items() for a in opts}

def _int(value,field,positive=False):
    if isinstance(value,bool):raise ValueError(field+' غير صحيح')
    raw=str(value if value is not None else '').strip().replace('٬','').replace('،','').replace(',','')
    try:num=Decimal(raw)
    except (InvalidOperation,ValueError):raise ValueError(field+' غير صحيح')
    if not num.is_finite() or num!=num.to_integral_value():raise ValueError(field+' لازم عدد صحيح')
    n=int(num)
    if n<(1 if positive else 0) or n>999999999:
        raise ValueError(field+' خارج المدى')
    return n

def normalize_rows(table):
    if not isinstance(table,list) or len(table)<2:raise ValueError('الملف فارغ أو ما فيه رؤوس أعمدة')
    if len(table)>5001:raise ValueError('الحد 5000 صنف/تشغيلة في المرة؛ قسم الملف')
    headers=[ALIASES.get(_normalized_header(v)) for v in table[0]]
    if len(headers)!=len(set(x for x in headers if x)) + headers.count(None):
        raise ValueError('في أعمدة مكررة بالملف')
    required=('name','unit_name','factor','quantity','expiry','unit_cost','sale_price')
    missing=[x for x in required if x not in headers]
    if missing:raise ValueError('أعمدة ناقصة: '+', '.join(missing))
    result=[]
    for index,line in enumerate(table[1:],start=2):
        if not any(str(v or '').strip() for v in line):continue
        d={key:(str(line[i] if i<len(line) and line[i] is not None else '').strip()) for i,key in enumerate(headers) if key}
        d['source_row']=index
        result.append(d)
    if not result:raise ValueError('ما في سطور أصناف')
    return result

def validate(c,table):
    """Preview never writes. All problems are returned per row; commit is all-or-nothing."""
    from app import one,today
    rows=normalize_rows(table)
    result=[]; seen_barcodes={};seen_pack={};seen_names={};seen_base_units={}
    for raw in rows:
        errors=[]
        def fail(message):errors.append(message)
        row={k:str(raw.get(k,'') or '').strip() for k in FIELDS}
        row['source_row']=raw['source_row']
        for field in ('name','unit_name'):
            if not row[field]:fail(field+' مطلوب')
        if len(row['name'])>140 or len(row['sku'])>60 or len(row['batch'])>70 or len(row['barcode'])>80:
            fail('نص طويل جداً')
        if not row['sku'] and row['barcode']:row['sku']='BAR-'+row['barcode']
        if not row['sku']:fail('sku أو barcode مطلوب لتحديد الدواء بلا تخمين')
        try:
            for field in ('quantity','factor','unit_cost','sale_price'):
                row[field]=_int(row[field],field,positive=field in ('quantity','factor'))
        except ValueError as ex:fail(str(ex))
        try:
            raw_expiry=row['expiry'].strip()
            if re.fullmatch(r'\d{5}(?:\.0+)?',raw_expiry):
                raw_expiry=(datetime(1899,12,30)+timedelta(days=int(Decimal(raw_expiry)))).date().isoformat()
            elif re.fullmatch(r'\d{1,2}/\d{1,2}/\d{4}',raw_expiry):
                raw_expiry=datetime.strptime(raw_expiry,'%d/%m/%Y').date().isoformat()
            expiry=date.fromisoformat(raw_expiry)
            row['expiry']=expiry.isoformat()
            if expiry<=date.today():fail('لا تقبل صلاحية اليوم أو الصلاحية المنتهية')
        except ValueError:fail('تاريخ الصلاحية مطلوب بصيغة YYYY-MM-DD')
        if not row['base_uom']:row['base_uom']='حبة'
        identity=(row['sku'],row['unit_name'])
        if row['sku'] in seen_names and seen_names[row['sku']]!=row['name']:
            fail('نفس SKU مستخدم لأسماء أدوية مختلفة')
        seen_names[row['sku']]=row['name']
        if row['sku'] in seen_base_units and seen_base_units[row['sku']]!=row['base_uom']:
            fail('نفس SKU مستخدم بوحدتين أساسيتين مختلفتين')
        seen_base_units[row['sku']]=row['base_uom']
        if all(isinstance(row[k],int) for k in ('quantity','factor','unit_cost','sale_price')):
            row['qty_base']=row['quantity']*row['factor']
            row['amount']=row['quantity']*row['unit_cost']
            if row['amount']>999999999999:fail('القيمة كبيرة جداً')
        if identity in seen_pack and seen_pack[identity]!=(row['factor'],row['barcode'],row['sale_price']):
            fail('نفس العبوة لها معامل/باركود/سعر مختلف في الملف')
        seen_pack[identity]=(row['factor'],row['barcode'],row['sale_price'])
        if row['barcode']:
            owner=seen_barcodes.setdefault(row['barcode'],identity)
            if owner!=identity:fail('الباركود مكرر لصنف أو عبوة مختلفة')
            current=one(c,'SELECT p.sku,pk.unit_name FROM packages pk JOIN products p ON p.id=pk.product_id WHERE pk.barcode=?',(row['barcode'],))
            if current and (current['sku'],current['unit_name'])!=identity:fail('الباركود موجود لصنف مختلف')
        old=one(c,'SELECT id,name,base_uom FROM products WHERE sku=?',(row['sku'],))
        if old:
            if old['name']!=row['name']:fail('اسم SKU مختلف عن بطاقة الصنف المسجلة')
            if old['base_uom']!=row['base_uom']:fail('الوحدة الأساسية مختلفة')
            pk=one(c,'SELECT factor,barcode,sale_price FROM packages WHERE product_id=? AND unit_name=?',(old['id'],row['unit_name']))
            if pk and (pk['factor']!=row['factor'] or (pk['barcode'] or '')!=row['barcode']):fail('بيانات عبوة موجودة مختلفة؛ عدلها في دليل الأدوية أولاً')
            if pk and pk['sale_price']!=row['sale_price']:fail('سعر العبوة المسجل مختلف؛ عدل السعر أولاً ولا نعتمد تغييراً صامتاً')
            used=one(c,"SELECT COUNT(*) n FROM stock_moves WHERE product_id=? AND kind NOT LIKE 'opening%'",(old['id'],))
            if used['n']:fail('الصنف مستخدم في عمليات سابقة؛ أدخله عبر المشتريات أو تسوية موثقة')
        result.append({'row':row,'errors':errors})
    return {'rows':result,'valid':sum(not r['errors'] for r in result),'invalid':sum(bool(r['errors']) for r in result),
            'total_value':sum(r['row'].get('amount',0) for r in result if not r['errors'])}

def import_stock(c,table,uid,request_id):
    import app
    if not isinstance(request_id,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{16,90}',request_id):
        raise ValueError('معرف عملية الاستيراد غير صالح')
    # Check and lock before validating to prevent concurrent imports of the same stock.
    app.begin(c)
    try:
        preview=validate(c,table)
        if preview['invalid']:
            raise ValueError('لا يمكن اعتماد جرد فيه '+str(preview['invalid'])+' سطور تحتاج تصحيح')
        canonical=json.dumps([r['row'] for r in preview['rows']],sort_keys=True,ensure_ascii=False,separators=(',',':'))
        digest=hashlib.sha256(canonical.encode()).hexdigest()
        existing=app.one(c,'SELECT id,row_count,total_value FROM opening_imports WHERE fingerprint=?',(digest,))
        if existing:raise ValueError('الملف دا تم اعتماده قبل كدا؛ لن نكرر إضافة المخزون')
        # No further mutation may occur if duplicate import requested with other token.
        import_id=c.execute('INSERT INTO opening_imports(fingerprint,created_at,user_id,row_count,total_value) VALUES(?,?,?,?,?)',
            (digest,app.now(),uid,len(preview['rows']),preview['total_value'])).lastrowid
        for item in preview['rows']:
            row=item['row']
            prod=app.one(c,'SELECT id FROM products WHERE sku=?',(row['sku'],))
            if prod:pid=prod['id']
            else:
                pid=c.execute('INSERT INTO products(sku,name,generic_name,manufacturer,base_uom,created_at) VALUES(?,?,?,?,?,?)',
                    (row['sku'],row['name'],row['generic_name'],row['manufacturer'],row['base_uom'],app.now())).lastrowid
            pack=app.one(c,'SELECT id FROM packages WHERE product_id=? AND unit_name=?',(pid,row['unit_name']))
            if pack:pkid=pack['id']
            else:
                is_default=1 if not app.one(c,'SELECT id FROM packages WHERE product_id=? LIMIT 1',(pid,)) else 0
                pkid=c.execute('INSERT INTO packages(product_id,unit_name,factor,barcode,sale_price,is_default) VALUES(?,?,?,?,?,?)',
                    (pid,row['unit_name'],row['factor'],row['barcode'] or None,row['sale_price'],is_default)).lastrowid
            inventory_batch=row['batch'] or f'UNRECORDED-OPEN-{import_id}-ROW-{row["source_row"]}'
            lot=app.one(c,"SELECT id,qty_base,unit_cost_milli FROM lots WHERE product_id=? AND batch=? AND expiry=? AND status='sellable'",
                (pid,inventory_batch,row['expiry']))
            per_base_milli=(row['unit_cost']*1000)//row['factor']
            if lot:
                lid=lot['id']
                old_qty=lot['qty_base'];new_qty=row['qty_base']
                avg=(old_qty*lot['unit_cost_milli']+new_qty*per_base_milli)//(old_qty+new_qty)
                c.execute('UPDATE lots SET qty_base=qty_base+?,unit_cost_milli=? WHERE id=?',(new_qty,avg,lid))
            else:
                lid=c.execute('INSERT INTO lots(product_id,batch,expiry,status,qty_base,unit_cost_milli) VALUES(?,?,?,?,?,?)',
                    (pid,inventory_batch,row['expiry'],'sellable',row['qty_base'],per_base_milli)).lastrowid
            c.execute('INSERT INTO stock_moves(product_id,lot_id,qty_base,kind,document,created_at,user_id) VALUES(?,?,?,?,?,?,?)',
                (pid,lid,row['qty_base'],'opening',f'OPEN-{import_id}',app.now(),uid))
            c.execute('INSERT INTO opening_import_lines(import_id,source_row,package_id,lot_id,qty_base,amount) VALUES(?,?,?,?,?,?)',
                (import_id,row['source_row'],pkid,lid,row['qty_base'],row['amount']))
        app.journal(c,'OPEN-'+str(import_id),[('INVENTORY',preview['total_value'],0),('OPENING_EQUITY',0,preview['total_value'])])
        app.audit(c,uid,'opening_stock_import',{'import_id':import_id,'rows':len(preview['rows']),'value':preview['total_value']})
        app.finish(c)
        return {'id':import_id,'rows':len(preview['rows']),'total_value':preview['total_value']}
    except:
        app.rollback(c)
        raise
