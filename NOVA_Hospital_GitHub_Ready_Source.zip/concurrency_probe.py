"""Isolated, synthetic-only concurrency test of supplied pharmacy HTTP endpoints."""
import concurrent.futures, datetime, json, sys, tempfile, threading, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'pharmacy'
sys.path.insert(0,str(ROOT))
import app

def fetch(base,path,body=None,cookie=None):
    payload=None if body is None else json.dumps(body).encode('utf8')
    hdr={'Content-Type':'application/json'}
    if cookie:hdr['Cookie']=cookie
    req=urllib.request.Request(base+path,payload,headers=hdr)
    try:
        with urllib.request.urlopen(req,timeout=40) as r:return r.status,json.loads(r.read()),r.headers.get('Set-Cookie','')
    except urllib.error.HTTPError as e:
        return e.code,json.loads(e.read()),''

def main():
    with tempfile.TemporaryDirectory(prefix='nova-synth-') as root:
        app.DATA=Path(root);app.DB=app.DATA/'test.sqlite3';app.ROOT=ROOT
        app.init_db(preload_catalog=False)
        server=app.ThreadServer(('127.0.0.1',0),app.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_address[1]}'
        try:
            fetch(base,'/api/v1/bootstrap',{'username':'owner','full_name':'Synthetic QA','password':'not-real-password-12345678'})
            code,data,cookie=fetch(base,'/api/v1/login',{'username':'owner','password':'not-real-password-12345678'})
            cookie=cookie.split(';',1)[0]
            cases=range(30)
            def do_write(i):
                return fetch(base,'/api/v1/products',{'sku':f'QA-{i:04d}','name':f'Synthetic Product {i}', 'packages':[{'unit_name':'unit','factor':1,'barcode':f'QA-BC-{i:04d}','sale_price':100,'is_default':True}]},cookie)
            with concurrent.futures.ThreadPoolExecutor(max_workers=15) as pool:
                writes=list(pool.map(do_write,cases))
            assert all(s==200 for s,_,_ in writes),writes
            with app.db_connect() as c:
                n=c.execute('select count(*) from products').fetchone()[0]
                audit=c.execute("select count(*) from audit where action='create_product'").fetchone()[0]
                integrity=c.execute('pragma integrity_check').fetchone()[0]
            assert (n,audit,integrity)==(30,30,'ok'),(n,audit,integrity)
            def do_read(_):return fetch(base,'/api/v1/status')
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:
                reads=list(pool.map(do_read,range(100)))
            assert all(s==200 for s,_,_ in reads)
            # Genuine concurrent stock contention: 40 attempts to sell 25 units.
            supplier=fetch(base,'/api/v1/supplier',{'name':'QA supplier'},cookie)[1]['id']
            pkid=app.db_connect()
            try:
                pkg=pkid.execute("select id from packages where barcode='QA-BC-0000'").fetchone()[0]
            finally:
                pkid.close()
            exp=(datetime.date.today()+datetime.timedelta(days=365)).isoformat()
            ps,pr,_=fetch(base,'/api/v1/purchase',{'supplier_id':supplier,'invoice_ref':'SYNTH-PUR-001','items':[{'package_id':pkg,'qty':25,'unit_cost':10,'batch':'QA-SYNTH-LOT','expiry':exp}]},cookie)
            assert ps==200,(ps,pr)
            # Different authenticated employee accounts, not just threads sharing one owner cookie.
            staff_cookies=[]
            for i in range(20):
                username=f'qa_staff_{i}'
                added=fetch(base,'/api/v1/user',{'username':username,'full_name':f'QA Staff {i}','password':'temporary-qa-pass-12345678','permissions':['sale','reports']},cookie)
                assert added[0]==200,added
                logged=fetch(base,'/api/v1/login',{'username':username,'password':'temporary-qa-pass-12345678'})
                assert logged[0]==200,logged
                staff_cookies.append(logged[2].split(';',1)[0])
            def do_sale(i):
                return fetch(base,'/api/v1/sale',{'idempotency':f'QA-SALE-{i}','items':[{'package_id':pkg,'qty':1}],'payments':[{'method':'cash','amount':100}]},staff_cookies[i%20])
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:
                results=list(pool.map(do_sale,range(40)))
            sold=sum(code==200 for code,_,_ in results)
            blocked=sum(code==400 for code,_,_ in results)
            with app.db_connect() as c:
                stock=c.execute("select sum(qty_base) from lots where product_id=(select id from products where sku='QA-0000')").fetchone()[0]
                stored_sales=c.execute('select count(*) from sales').fetchone()[0]
                integrity=c.execute('pragma integrity_check').fetchone()[0]
            assert (sold,blocked,stock,stored_sales,integrity)==(25,15,0,25,'ok'),(sold,blocked,stock,stored_sales,integrity)
            print(json.dumps({'simultaneous_workers':15,'distinct_authenticated_staff_accounts':len(staff_cookies),'unique_writes':n,'audit_rows':audit,'simultaneous_read_workers':20,'read_requests':len(reads),'sqlite_integrity':integrity,'sales_succeeded':sold,'oversell_prevented':blocked,'remaining_stock':stock,'result':'PASS','limitation':'isolated in-process single-computer test only; does not establish clinical production readiness'},ensure_ascii=False))
        finally:
            server.shutdown();server.server_close();thread.join(4)
if __name__=='__main__':main()
