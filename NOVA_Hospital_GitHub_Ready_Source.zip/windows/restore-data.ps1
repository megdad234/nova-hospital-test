# Safe administrative recovery of NOVA's ONE central database.
# Starts a GUI (no terminal input required), stops the Windows service, and
# relies on NOVA's existing verified SQLite backup/restore mechanism.
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$service='NOVA_Hospital_Server'
$exe=Join-Path $PSScriptRoot 'NOVA-Hospital-Server\NOVA-Hospital-Server.exe'
$root=Join-Path $env:ProgramData 'NOVA_Hospital'
$logDir=Join-Path $root 'logs'
New-Item -Path $logDir -ItemType Directory -Force | Out-Null
$log=Join-Path $logDir 'restore-data.log'
function Log([string]$message) { ('{0} {1}' -f (Get-Date).ToString('s'),$message) | Out-File $log -Append -Encoding UTF8 }
Add-Type -AssemblyName System.Windows.Forms
$wasRunning=$false
$restored=$false
try {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  $principal=New-Object Security.Principal.WindowsPrincipal($identity)
  if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # Elevation is explicitly requested by Windows; no silent privileged restore.
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @(
      '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'))
    exit 0
  }
  $dialog=New-Object System.Windows.Forms.OpenFileDialog
  $dialog.Title='اختر نسخة NOVA الاحتياطية لاستعادتها'
  $dialog.Filter='SQLite backup (*.sqlite3)|*.sqlite3'
  $dialog.CheckFileExists=$true
  $backupHome=Join-Path $root 'data\backups'
  if (Test-Path $backupHome) { $dialog.InitialDirectory=$backupHome }
  if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
  $response=[System.Windows.Forms.MessageBox]::Show(
    'سيتم إيقاف المستشفى مؤقتاً عن كل الأجهزة واستعادة قاعدة البيانات المختارة. أي بيانات أُدخلت بعد تاريخ النسخة ستُفقد. هل أنت متأكد؟',
    'تأكيد استعادة NOVA',[System.Windows.Forms.MessageBoxButtons]::YesNo,
    [System.Windows.Forms.MessageBoxIcon]::Warning)
  if ($response -ne [System.Windows.Forms.DialogResult]::Yes) { exit 0 }
  if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'NOVA server executable is missing' }
  # Reject pharmacy-only or incomplete backup BEFORE disrupting any employees.
  $env:NOVA_DATA_HOME=$root
  & $exe --verify-backup $dialog.FileName 2>&1 | Out-File -FilePath $log -Append -Encoding UTF8
  if ($LASTEXITCODE -ne 0) { throw 'ملف النسخة غير مكتمل أو يخص الصيدلية فقط؛ لن يتم إيقاف النظام أو استبدال بياناته' }
    $state=Get-Service $service -ErrorAction Stop
  if ($state.Status -ne 'Stopped') {
    $wasRunning=$true
    Stop-Service $service -Force -ErrorAction Stop
    $state.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(120))
  }
  if ((Get-Service $service).Status -ne 'Stopped') { throw 'Service did not stop' }
  $env:NOVA_DATA_HOME=$root
  & $exe --restore-backup $dialog.FileName 2>&1 | Out-File -FilePath $log -Append -Encoding UTF8
  if ($LASTEXITCODE -ne 0) { throw 'NOVA rejected the backup or failed to restore its data' }
  $restored=$true
  Start-Service $service -ErrorAction Stop
  $healthy=$false
  for ($i=0;$i -lt 40;$i++) {
    try {
      $r=Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8765/api/v1/status' -TimeoutSec 2
      if ($r.StatusCode -eq 200) { $healthy=$true; break }
    } catch { Start-Sleep -Seconds 1 }
  }
  if (-not $healthy) { throw 'Data restored, but NOVA did not start successfully; contact technical support' }
  Log ('RESTORE_SUCCESS: '+[IO.Path]::GetFileName($dialog.FileName))
  [System.Windows.Forms.MessageBox]::Show('تمت استعادة قاعدة البيانات والتحقق من تشغيل السيرفر.','NOVA Hospital') | Out-Null
} catch {
  Log ('RESTORE_FAILURE: '+$_.Exception.Message)
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message+' — راجع restore-data.log في مجلد سجلات NOVA.',
    'تعذر استعادة البيانات',[System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
  # A rejected backup never replaces the current database: resume operations.
  # After an attempted successful replacement, do not claim recovery if startup failed.
  if (-not $restored -and $wasRunning) {
    try { Start-Service $service -ErrorAction Stop } catch { Log ('SERVICE_RESTART_FAILED: '+$_.Exception.Message) }
  }
  exit 1
}
