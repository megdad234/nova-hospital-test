$ErrorActionPreference='Continue'
$service='NOVA_Hospital_Server'
& netsh advfirewall firewall delete rule name='NOVA Hospital LAN (Private Subnet)' | Out-Null
$nssm=Join-Path $PSScriptRoot 'nssm.exe'
if(Test-Path $nssm){
 & $nssm stop $service | Out-Null
 & $nssm remove $service confirm | Out-Null
}
# Never delete %PROGRAMDATA%\NOVA_Hospital automatically.
exit 0
