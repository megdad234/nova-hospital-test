# NOVA Windows acceptance checks — synthetic data and disposable GitHub runner only.
# Runs AFTER a successful build. NEVER use on a hospital production machine.
$ErrorActionPreference = 'Stop'

# === Install the actual single Setup.exe on fresh Windows ===
$ErrorActionPreference='Stop'
$setup=(Resolve-Path windows/output/NOVA-Hospital-Setup-DEV.exe).Path
$p=Start-Process -FilePath $setup -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART' -Wait -PassThru
if($p.ExitCode -ne 0){throw "NOVA Setup failed with $($p.ExitCode)"}
$svc=Get-Service -Name 'NOVA_Hospital_Server' -ErrorAction Stop
if($svc.Status -ne 'Running'){throw 'NOVA service is not running'}
$url='http://127.0.0.1:8765/api/v1/status'
$r=Invoke-WebRequest -UseBasicParsing -Uri $url -TimeoutSec 12
if($r.StatusCode -ne 200 -or -not ($r.Content | ConvertFrom-Json).nova_server){throw 'Installed application health failed'}
$body= @{username='qa_owner';full_name='Synthetic QA';password='synthetic-only-long-2342'} | ConvertTo-Json
$created=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/bootstrap' -Method Post -ContentType 'application/json' -Body $body
if(-not $created.ok){throw 'First administrator setup failed'}
$loginBody= @{username='qa_owner';password='synthetic-only-long-2342'} | ConvertTo-Json
$session=New-Object Microsoft.PowerShell.Commands.WebRequestSession
$login=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/login' -Method Post -ContentType 'application/json' -Body $loginBody -WebSession $session
if($login.user.username -ne 'qa_owner'){throw 'First login failed'}
Restart-Service -Name 'NOVA_Hospital_Server'
Start-Sleep -Seconds 8
$r=Invoke-WebRequest -UseBasicParsing -Uri $url -TimeoutSec 12
if($r.StatusCode -ne 200){throw 'Service restart recovery failed'}
$me=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/me' -WebSession $session
if($me.user.username -ne 'qa_owner'){throw 'Session did not survive restart'}
$portal=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/' -TimeoutSec 10
if($portal.Content -notmatch 'NOVA HOSPITAL'){throw 'Hospital portal missing'}
$staffBody=@{username='qa_lab';full_name='Synthetic Lab';password='synthetic-lab-pass-1234';role='lab'} | ConvertTo-Json
$staff=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/hospital/staff' -Method Post -ContentType 'application/json' -WebSession $session -Body $staffBody
if($staff.role -ne 'lab'){throw 'Hospital staff provisioning failed'}
$staffList=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/hospital/staff' -WebSession $session
if(-not ($staffList | Where-Object username -eq 'qa_lab')){throw 'Staff not in central user store'}
$labSession=New-Object Microsoft.PowerShell.Commands.WebRequestSession
$labLogin=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/login' -Method Post -ContentType 'application/json' -WebSession $labSession -Body (@{username='qa_lab';password='synthetic-lab-pass-1234'}|ConvertTo-Json)
try {
  Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/products' -WebSession $labSession -ErrorAction Stop
  throw 'Lab was allowed to view pharmacy data'
} catch [Microsoft.PowerShell.Commands.HttpResponseException] {
  if([int]$_.Exception.Response.StatusCode -ne 403){throw 'Unexpected pharmacy deny status'}
}
$fw=Get-NetFirewallRule -DisplayName 'NOVA Hospital LAN (Private Subnet)' -ErrorAction Stop
if(-not $fw){throw 'LAN-only firewall rule missing'}
$urlFile=Join-Path $env:ProgramData 'NOVA_Hospital\NOVA_LAN_ADDRESS.txt'
if(!(Test-Path $urlFile)){throw 'LAN access instructions missing'}
Write-Host 'NOVA_FRESH_WINDOWS_INSTALL_AND_RESTART_PASS'

# === Reinstall over live synthetic data and verify pre-update backup ===
$ErrorActionPreference='Stop'
$setup=(Resolve-Path windows/output/NOVA-Hospital-Setup-DEV.exe).Path
$p=Start-Process -FilePath $setup -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART' -Wait -PassThru
if($p.ExitCode -ne 0){throw "In-place setup upgrade failed: $($p.ExitCode)"}
$svc=Get-Service NOVA_Hospital_Server
if($svc.Status -ne 'Running'){throw 'Service did not restart after upgrade'}
$backupRoot=Join-Path $env:ProgramData 'NOVA_Hospital\upgrade_backups'
$snapshots=@(Get-ChildItem -LiteralPath $backupRoot -Directory | Sort-Object LastWriteTime -Descending)
if($snapshots.Count -lt 1){throw 'Upgrade did not create an offline backup'}
$latest=$snapshots[0].FullName
$manifest=Get-Content -LiteralPath (Join-Path $latest 'manifest.json') -Raw | ConvertFrom-Json
if(-not $manifest.database_present -or -not $manifest.program_present){throw 'Upgrade backup is incomplete'}
$db=Join-Path $latest 'data\pharmacy.sqlite3'
if(!(Test-Path $db)){throw 'Upgrade backup missing central database'}
$hash=(Get-FileHash -LiteralPath $db -Algorithm SHA256).Hash
$expected=@($manifest.files | Where-Object name -eq 'pharmacy.sqlite3')
if($expected.Count -ne 1 -or $hash -ne $expected[0].sha256){throw 'Upgrade backup SHA256 verification failed'}
if(!(Test-Path (Join-Path $latest 'previous_program\NOVA-Hospital-Server.exe'))){throw 'Previous version not preserved'}
$session=New-Object Microsoft.PowerShell.Commands.WebRequestSession
$login=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/login' -Method Post -ContentType 'application/json' -WebSession $session -Body (@{username='qa_owner';password='synthetic-only-long-2342'} | ConvertTo-Json)
if($login.user.username -ne 'qa_owner'){throw 'Administrator lost after re-install'}
$me=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/me' -WebSession $session
if($me.user.username -ne 'qa_owner'){throw 'Central data not preserved on upgrade'}
Write-Host 'NOVA_WINDOWS_INPLACE_UPGRADE_AND_DATABASE_BACKUP_PASS'

# === Verify rollback after an intentionally broken upgrade (synthetic data only) ===
./windows/test-upgrade-rollback.ps1
if ($LASTEXITCODE -ne 0) { throw 'Windows rollback acceptance script failed' }
