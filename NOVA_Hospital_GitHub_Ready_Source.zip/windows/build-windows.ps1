# For a disposable Windows CI runner or developer build machine ONLY.
# End users do not install Python, NSSM, Inno Setup or any database separately.
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$root=Split-Path -Parent $here
Set-Location $root
Push-Location pharmacy
python -m unittest discover -s tests -p 'test_*.py' -q
$testsExit=$LASTEXITCODE
Pop-Location
if($testsExit -ne 0){throw 'Pharmacy regression tests failed'}
# Discover the canonical test package once. The shared fixture no longer
# inherits unittest.TestCase; inherited duplicates previously inflated the suite.
python -m unittest discover -s tests -t . -p 'test_*.py' -q
if($LASTEXITCODE -ne 0){throw 'Hospital integration tests failed'}
python concurrency_probe.py
if($LASTEXITCODE -ne 0){throw 'Concurrent synthetic smoke failed'}
python nova_server.py --self-check
if($LASTEXITCODE -ne 0){throw 'Self-check failed'}
python -m pip install --disable-pip-version-check 'pyinstaller>=6.14,<7'
if($LASTEXITCODE -ne 0){throw 'PyInstaller build tool unavailable'}
# Onedir runs much faster at startup than unpacking a onefile executable on every service restart.
python -m PyInstaller --noconfirm --clean --onedir --name NOVA-Hospital-Server --paths pharmacy --add-data 'pharmacy/static;static' --add-data 'hospital/static;hospital/static' --hidden-import=hospital.gateway --hidden-import=hospital.core --hidden-import=hospital.lab --hidden-import=hospital.lab_catalog --hidden-import=hospital.finance --hidden-import=hospital.admin --hidden-import=hospital.backup --hidden-import=erp_extensions_v06 --hidden-import=opening_inventory --hidden-import=catalog_import --hidden-import=preloaded_catalog --hidden-import=recovery --hidden-import=schema_guard nova_server.py --distpath windows/dist --workpath windows/build --specpath windows
if($LASTEXITCODE -ne 0){throw 'PyInstaller failed'}
& "$here\dist\NOVA-Hospital-Server\NOVA-Hospital-Server.exe" --self-check
if($LASTEXITCODE -ne 0){throw 'Frozen application self-check failed'}
$compiler=@("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "${env:ProgramFiles}\Inno Setup 6\ISCC.exe") | Where-Object {Test-Path $_} | Select-Object -First 1
if(-not $compiler){throw 'Inno Setup required on BUILD runner'}
# Obtain exact upstream NSSM artifact during the CI build, not on the end-user machine.
$vendor=Join-Path $here 'third_party'
New-Item -ItemType Directory -Path $vendor -Force | Out-Null
$nssm=Join-Path $vendor 'nssm.exe'
if(!(Test-Path $nssm)) {
 $url='https://raw.githubusercontent.com/kainpl/bamdude/00e42a8a73972ac88be561ee3edb2cf71d83b8b5/installers/windows/vendor/nssm.exe'
 Invoke-WebRequest -Uri $url -OutFile $nssm -MaximumRedirection 5
}
$bytes=[IO.File]::ReadAllBytes($nssm)
$header=[Text.Encoding]::ASCII.GetBytes("blob $($bytes.Length)" + [char]0)
$all=New-Object byte[] ($header.Length+$bytes.Length)
[Array]::Copy($header,0,$all,0,$header.Length)
[Array]::Copy($bytes,0,$all,$header.Length,$bytes.Length)
$sha=[Security.Cryptography.SHA1]::Create().ComputeHash($all)
$actual=([BitConverter]::ToString($sha)).Replace('-','').ToLowerInvariant()
if($actual -ne '6ccfe3cfb85f0f7126648dceb7ac93d58b025a0f') {throw 'Bundled NSSM hash mismatch'}
Push-Location $here
& $compiler 'nova-hospital.iss'
if($LASTEXITCODE -ne 0){throw 'Inno Setup failed'}
Pop-Location
if(!(Test-Path "$here\output\NOVA-Hospital-Setup-DEV.exe")){throw 'Installer missing'}
Write-Host "BUILT: $here\output\NOVA-Hospital-Setup-DEV.exe"
