# Emergency offline rollback of a FAILED NOVA Windows update.
# Only the last VERIFIED preflight snapshot can be restored. This is not a
# general-purpose database restore tool; it is called by Inno on installer failure.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Join-Path $env:ProgramData 'NOVA_Hospital'
$backupRoot = Join-Path $root 'upgrade_backups'
$pending = Join-Path $backupRoot 'pending-update.json'
$serviceName = 'NOVA_Hospital_Server'
$installDir = $PSScriptRoot
$appDir = Join-Path $installDir 'NOVA-Hospital-Server'
$logDir = Join-Path $root 'logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$log = Join-Path $logDir 'update-rollback.log'
function Log([string]$msg) {
  ('{0} {1}' -f (Get-Date).ToString('s'), $msg) | Out-File -FilePath $log -Append -Encoding UTF8
}
function Check-Hash([string]$file,[string]$digest) {
  if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw ('Missing snapshot file: ' + $file) }
  if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $digest) {
    throw ('Snapshot checksum mismatch: ' + $file)
  }
}
try {
  if (-not (Test-Path -LiteralPath $pending -PathType Leaf)) {
    throw 'No pending verified upgrade snapshot; cannot automatically roll back a first installation'
  }
  $state = Get-Content -LiteralPath $pending -Raw | ConvertFrom-Json
  $snapshot = [IO.Path]::GetFullPath([string]$state.snapshot)
  $allowed = [IO.Path]::GetFullPath($backupRoot).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
  if (-not $snapshot.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)) {
    throw 'Upgrade snapshot is outside the controlled recovery folder'
  }
  $manifestFile = Join-Path $snapshot 'manifest.json'
  if (-not (Test-Path -LiteralPath $manifestFile -PathType Leaf)) { throw 'Upgrade manifest is missing' }
  $manifest = Get-Content -LiteralPath $manifestFile -Raw | ConvertFrom-Json
  if (-not $manifest.program_present) { throw 'No previous program is available for safe automatic rollback' }
  $oldDir = Join-Path $snapshot 'previous_program'
  $oldExe = Join-Path $oldDir 'NOVA-Hospital-Server.exe'
  Check-Hash $oldExe ([string]$manifest.previous_exe_sha256)
  # Require the full-tree manifest added in 5.7. This is validated before
  # stopping the running service or replacing any live file.
  if (-not $manifest.PSObject.Properties['program_files']) {
    throw 'Snapshot has no full program inventory; use assisted recovery'
  }
  $programFiles = @($manifest.program_files)
  if ($programFiles.Count -eq 0) { throw 'Snapshot contains no application files' }
  foreach ($entry in $programFiles) {
    $relative = [string]$entry.relative
    if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)' -or
        [string]::IsNullOrWhiteSpace($relative)) { throw 'Invalid relative file path in recovery manifest' }
    $savedFile = Join-Path $oldDir $relative
    $absoluteFile = [IO.Path]::GetFullPath($savedFile)
    $oldPrefix = [IO.Path]::GetFullPath($oldDir).TrimEnd('\','/') + [IO.Path]::DirectorySeparatorChar
    if (-not $absoluteFile.StartsWith($oldPrefix,[StringComparison]::OrdinalIgnoreCase)) {
      throw 'Program file escapes verified snapshot directory'
    }
    Check-Hash $savedFile ([string]$entry.sha256)
    if ((Get-Item -LiteralPath $savedFile).Length -ne [long]$entry.bytes) {
      throw 'Program file snapshot has incorrect length'
    }
  }
  if (@(Get-ChildItem -LiteralPath $oldDir -Recurse -File -Force).Count -ne $programFiles.Count) {
    throw 'Recovery snapshot program tree differs from verified manifest'
  }
  if ($manifest.database_present) { foreach ($entry in @($manifest.files)) {
    $name = [string]$entry.name
    if ($name -notin @('pharmacy.sqlite3','pharmacy.sqlite3-wal','external_backup.json')) {
      throw 'Unexpected snapshot database file in manifest'
    }
    Check-Hash (Join-Path (Join-Path $snapshot 'data') $name) ([string]$entry.sha256)
  } }
  if ($manifest.database_present -and @($manifest.files | Where-Object { $_.name -eq 'pharmacy.sqlite3' }).Count -ne 1) {
    throw 'Upgrade snapshot does not contain the main database'
  }
  # Validate snapshot files FIRST, without changing the service or live data.
  Log ('Verified rollback snapshot: ' + $snapshot)
  $svc = Get-Service -Name $serviceName -ErrorAction Stop
  if ($svc.Status -ne 'Stopped') {
    Stop-Service -Name $serviceName -Force -ErrorAction Stop
    $svc.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(120))
  }
  if ((Get-Service -Name $serviceName).Status -ne 'Stopped') { throw 'Service could not be stopped for rollback' }
  # Copy files while service is down. Preserve the failed upgrade for diagnosis.
  $failedDir = Join-Path $snapshot 'failed_program'
  if (Test-Path -LiteralPath $appDir -PathType Container) {
    if (-not (Test-Path -LiteralPath $failedDir)) {
      Move-Item -LiteralPath $appDir -Destination $failedDir -ErrorAction Stop
    } else {
      Remove-Item -LiteralPath $appDir -Recurse -Force -ErrorAction Stop
    }
  }
  Copy-Item -LiteralPath $oldDir -Destination $appDir -Recurse -Force -ErrorAction Stop
  # Validate the RESTORED tree as well as the original snapshot, not just EXE.
  foreach ($entry in $programFiles) {
    Check-Hash (Join-Path $appDir ([string]$entry.relative)) ([string]$entry.sha256)
  }
  if (@(Get-ChildItem -LiteralPath $appDir -Recurse -File -Force).Count -ne $programFiles.Count) {
    throw 'Restored program tree has missing or extra files'
  }
  if ($manifest.database_present) {
    $dataDir = Join-Path $root 'data'
    New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
    foreach ($name in @('pharmacy.sqlite3','pharmacy.sqlite3-wal','pharmacy.sqlite3-shm')) {
      $dest = Join-Path $dataDir $name
      if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force -ErrorAction Stop }
    }
    foreach ($entry in @($manifest.files)) {
      if ($entry.name -in @('pharmacy.sqlite3','pharmacy.sqlite3-wal','external_backup.json')) {
        $restoredFile = Join-Path $dataDir ([string]$entry.name)
        Copy-Item -LiteralPath (Join-Path (Join-Path $snapshot 'data') $entry.name) -Destination $restoredFile -ErrorAction Stop
        Check-Hash $restoredFile ([string]$entry.sha256)
      }
    }
  }
  if ($manifest.was_running) {
    Start-Service -Name $serviceName -ErrorAction Stop
    $healthy = $false
    for ($i=0;$i -lt 40;$i++) {
      try {
        $res=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/status' -TimeoutSec 2
        if ($res.nova_server) { $healthy=$true; break }
      } catch { Start-Sleep -Seconds 1 }
    }
    if (-not $healthy) { throw 'Old NOVA version was restored but did not pass service health check' }
  }
  Remove-Item -LiteralPath $pending -Force -ErrorAction Stop
  Log 'ROLLBACK_OK: Previous application and database snapshot restored.'
  exit 0
} catch {
  Log ('ROLLBACK_FAILED: ' + $_.Exception.Message)
  # Retain the pending marker and snapshots for assisted recovery. Never claim success.
  Write-Error $_.Exception.Message
  exit 39
}
