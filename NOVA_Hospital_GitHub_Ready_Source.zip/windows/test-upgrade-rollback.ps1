# Run ONLY on a disposable Windows CI runner, never on an actual hospital server.
# Simulates an interrupted/failed update using an intentionally broken EXE,
# then invokes the EXACT installed offline rollback handler. No patient data.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$install = Join-Path $env:ProgramFiles 'NOVA_Hospital'
$dataRoot = Join-Path $env:ProgramData 'NOVA_Hospital'
$binary = Join-Path $install 'NOVA-Hospital-Server\NOVA-Hospital-Server.exe'
$pending = Join-Path $dataRoot 'upgrade_backups\pending-update.json'
$service = 'NOVA_Hospital_Server'
if (-not (Test-Path -LiteralPath $binary -PathType Leaf)) { throw 'Installed NOVA executable missing' }
if ((Get-Service -Name $service -ErrorAction Stop).Status -ne 'Running') { throw 'NOVA must be running before rollback acceptance' }
if (Test-Path -LiteralPath $pending) { throw 'Unexpected pending upgrade before rollback acceptance' }
$db = Join-Path $dataRoot 'data\pharmacy.sqlite3'
if (-not (Test-Path -LiteralPath $db -PathType Leaf)) { throw 'No synthetic database to preserve' }
$beforeExe = (Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash
$beforeDb = (Get-FileHash -LiteralPath $db -Algorithm SHA256).Hash
Write-Host 'Creating a VERIFIED snapshot before fault injection...'
& (Join-Path $PSScriptRoot 'preflight-upgrade.ps1') -InstallDir $install -DataRoot $dataRoot
if ($LASTEXITCODE -ne 0) { throw 'Upgrade preflight failed' }
if (-not (Test-Path -LiteralPath $pending -PathType Leaf)) { throw 'Preflight did not create pending upgrade snapshot' }
if ((Get-Service -Name $service).Status -ne 'Stopped') { throw 'Preflight did not stop service' }
# The service has stopped. Replace its EXE with invalid bytes; recover should
# restore every original program file and data from the verified snapshot.
[IO.File]::WriteAllText($binary, 'INTENTIONAL_TEST_CORRUPTION_NOT_AN_EXE')
Write-Host 'Invoking offline rollback of deliberately broken test executable...'
& (Join-Path $install 'recover-failed-upgrade.ps1')
if ($LASTEXITCODE -ne 0) { throw 'NOVA rollback failed; inspect update-rollback.log in CI artifact' }
if (Test-Path -LiteralPath $pending) { throw 'Rollback did not clear pending upgrade marker' }
if ((Get-Service -Name $service).Status -ne 'Running') { throw 'Service failed to restart after rollback' }
if ((Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash -ne $beforeExe) {
  throw 'Previous binary was not restored byte-for-byte'
}
# SQLite can checkpoint on a new process startup; compare logical records and
# quick_check instead of expecting byte-identical databases after restart.
$check = Invoke-RestMethod 'http://127.0.0.1:8765/api/v1/status' -TimeoutSec 10
if (-not $check.nova_server -or -not $check.ready) { throw 'Restored server or users missing' }
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$body = @{username='qa_owner';password='synthetic-only-long-2342'} | ConvertTo-Json
$login = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/v1/login' -Method Post -ContentType 'application/json' -Body $body -WebSession $session
if ($login.user.username -ne 'qa_owner') { throw 'Synthetic administrator lost in rollback' }
Write-Host 'NOVA_WINDOWS_OFFLINE_ROLLBACK_FAULT_INJECTION_PASS'
