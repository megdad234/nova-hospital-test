; This is a NOVA-specific adaptation of the Inno Setup + bundled Python + NSSM
; Windows service packaging approach from the AGPL-3.0 BamDude project.
; See THIRD_PARTY.md for credits and the license obligations.
#define Product "NOVA Hospital — Offline LAN"
#define ProductVer "0.5.7-dev"
[Setup]
AppId={{14E6D94B-CAB7-4ED5-B388-5279C7B63B58}
AppName={#Product}
AppVersion={#ProductVer}
DefaultDirName={autopf}\NOVA_Hospital
DefaultGroupName=NOVA Hospital
OutputDir=output
OutputBaseFilename=NOVA-Hospital-Setup-DEV
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableProgramGroupPage=yes
; Inno processes [InstallDelete] after PrepareToInstall and before [Files].
; Preflight MUST finish its snapshot first: never intermix stale PyInstaller
; DLLs with the new onedir build. Rollback recovers the saved old tree.
[InstallDelete]
Type: filesandordirs; Name: "{app}\NOVA-Hospital-Server"
[Files]
Source: "dist\NOVA-Hospital-Server\*"; DestDir: "{app}\NOVA-Hospital-Server"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "third_party\nssm.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "install-service.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "recover-failed-upgrade.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "preflight-upgrade.ps1"; Flags: dontcopy
Source: "uninstall-service.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "restore-data.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\docs\THIRD_PARTY.md"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{autoprograms}\NOVA Hospital"; Filename: "http://127.0.0.1:8765"; IconFilename: "{sys}\shell32.dll"
Name: "{autoprograms}\NOVA Hospital — استعادة البيانات"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -STA -ExecutionPolicy Bypass -File ""{app}\restore-data.ps1"""; IconFilename: "{sys}\shell32.dll"; Comment: "Administrative data recovery — stop all users first"
Name: "{autodesktop}\NOVA Hospital"; Filename: "http://127.0.0.1:8765"; IconFilename: "{sys}\shell32.dll"
Name: "{autoprograms}\NOVA Hospital — روابط أجهزة الموظفين"; Filename: "{commonappdata}\NOVA_Hospital\NOVA_LAN_ADDRESS.txt"; Comment: "LAN links generated on the server after installation"
[UninstallRun]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\uninstall-service.ps1"""; Flags: runhidden waituntilterminated; RunOnceId: "NOVAUnregisterService"
[Run]
Filename: "http://127.0.0.1:8765"; Description: "Open NOVA Hospital test server"; Flags: shellexec postinstall nowait skipifsilent
[Code]
// This gate executes BEFORE [Files], including on upgrades. The previous
// version is kept intact if service stop or backup verification fails.
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  ResultCode: Integer;
  Args: String;
begin
  Result := '';
  ExtractTemporaryFile('preflight-upgrade.ps1');
  Args := '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' +
    ExpandConstant('{tmp}\preflight-upgrade.ps1') + '" -InstallDir "' +
    ExpandConstant('{app}') + '" -DataRoot "' +
    ExpandConstant('{commonappdata}\NOVA_Hospital') + '"';
  if (not Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
      Args, '', SW_HIDE, ewWaitUntilTerminated, ResultCode)) or (ResultCode <> 0) then begin
    Result := 'تعذر إيقاف خدمة NOVA أو حفظ نسخة احتياطية سليمة. لم يتم استبدال ملفات البرنامج. راجع update-preflight.log داخل ProgramData\NOVA_Hospital\logs';
  end;
end;
procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
  Cmd: String;
  RecoveryArgs: String;
  RecoveryExit: Integer;
begin
  if CurStep = ssPostInstall then begin
    Cmd := '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + ExpandConstant('{app}\install-service.ps1') + '"';
    if (not Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'), Cmd, '', SW_HIDE, ewWaitUntilTerminated, ResultCode)) or (ResultCode <> 0) then begin
      RecoveryArgs := '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' +
        ExpandConstant('{app}\recover-failed-upgrade.ps1') + '"';
      if Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
          RecoveryArgs, '', SW_HIDE, ewWaitUntilTerminated, RecoveryExit) and
          (RecoveryExit = 0) then begin
        MsgBox('The update failed. The previous NOVA installation and database were restored. See update-rollback.log.', mbError, MB_OK);
      end else begin
        MsgBox('The update failed and automatic rollback could not be verified. Stop using NOVA and inspect update-rollback.log and the saved recovery snapshot.', mbError, MB_OK);
      end;
      Abort;
    end;
  end;
end;
