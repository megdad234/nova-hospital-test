# NOVA setup preflight. Runs from Inno's PrepareToInstall BEFORE any installed file is replaced.
# This script cannot silently bypass the backup if an existing installation has data.
param(
  [Parameter(Mandatory=$true)][string]$InstallDir,
  [string]$DataRoot = (Join-Path $env:ProgramData 'NOVA_Hospital'),
  [string]$ServiceName = 'NOVA_Hospital_Server'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
$wasRunning = $false
$success = $false
$root = Join-Path $DataRoot 'upgrade_backups'
$pending = Join-Path $root 'pending-update.json'

$logDir = Join-Path $DataRoot 'logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$log = Join-Path $logDir 'update-preflight.log'
function Write-Log([string]$message) {
  ('{0} {1}' -f (Get-Date).ToString('s'),$message) | Out-File -FilePath $log -Append -Encoding UTF8
}
function Copy-Checked([string]$src,[string]$dst) {
  Copy-Item -LiteralPath $src -Destination $dst -Force -ErrorAction Stop
  $sourceHash = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash
  $copyHash = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
  if ($sourceHash -ne $copyHash) { throw ('Backup checksum mismatch: ' + [IO.Path]::GetFileName($src)) }
  return @{ name = [IO.Path]::GetFileName($src); bytes = (Get-Item -LiteralPath $src).Length; sha256 = $sourceHash }
}
try {
  # A prior interrupted upgrade must be recovered explicitly. Never overwrite its evidence.
  if (Test-Path -LiteralPath $pending -PathType Leaf) {
    throw 'Previous upgrade is unfinished; inspect update-rollback.log before continuing'
  }
  if ($service -and $service.Status -ne 'Stopped') {
    $wasRunning = $true
    Write-Log 'Stopping running NOVA service before copying program files.'
    Stop-Service -Name $ServiceName -Force -ErrorAction Stop
    $service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(120))
    if ((Get-Service -Name $ServiceName).Status -ne 'Stopped') { throw 'NOVA service did not stop' }
  }
  $db = Join-Path $DataRoot 'data\pharmacy.sqlite3'
  $appDir = Join-Path $InstallDir 'NOVA-Hospital-Server'
  $hasDatabase = Test-Path -LiteralPath $db -PathType Leaf
  $hasOldProgram = Test-Path -LiteralPath $appDir -PathType Container
  if ($hasOldProgram -or $hasDatabase) {
    $stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssfffZ') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
    $snapshot = Join-Path $root $stamp
    New-Item -ItemType Directory -Path $snapshot -Force | Out-Null
    $files = @()
    if ($hasDatabase -and -not $hasOldProgram) {
      throw 'Existing hospital data with no previous installed NOVA program: manual recovery required'
    }
    if ($hasOldProgram -and -not $hasDatabase) {
      throw 'Existing NOVA program has NO database. Restore missing patient data before upgrading; do not initialize a blank database.'
    }
    $previousExeSha = ''
    $programFiles = @()
    if ($hasDatabase) {
      $dataBackup = Join-Path $snapshot 'data'
      New-Item -ItemType Directory -Path $dataBackup -Force | Out-Null
      # The service is STOPPED; copy the SQLite database and its WAL as one set.
      # SQLite regenerates its SHM file. WAL is required if commits were not checkpointed.
      foreach ($suffix in @('','-wal')) {
        $src = $db + $suffix
        if (Test-Path -LiteralPath $src -PathType Leaf) {
          $files += (Copy-Checked $src (Join-Path $dataBackup ([IO.Path]::GetFileName($src))))
        }
      }
      $external = Join-Path $DataRoot 'data\external_backup.json'
      if (Test-Path -LiteralPath $external -PathType Leaf) {
        $files += (Copy-Checked $external (Join-Path $dataBackup 'external_backup.json'))
      }
    }
    if ($hasOldProgram) {
      # Preserve the prior executable tree for manual recovery if upgrade validation fails.
      $dest = Join-Path $snapshot 'previous_program'
      Copy-Item -LiteralPath $appDir -Destination $dest -Recurse -Force -ErrorAction Stop
      $oldExe = Join-Path $appDir 'NOVA-Hospital-Server.exe'
      $backupExe = Join-Path $dest 'NOVA-Hospital-Server.exe'
      if (-not (Test-Path -LiteralPath $oldExe -PathType Leaf)) { throw 'Previous NOVA executable is missing; update refused' }
      $previousExeSha = (Get-FileHash -LiteralPath $oldExe -Algorithm SHA256).Hash
      if ($previousExeSha -ne (Get-FileHash $backupExe -Algorithm SHA256).Hash) {
        throw 'Previous program backup checksum mismatch'
      }
      # Verify EVERY bundled resource, not only the executable: PyInstaller
      # needs its entire _internal tree. An incomplete backup is no rollback.
      $allOriginal = @(Get-ChildItem -LiteralPath $appDir -Recurse -File -Force)
      if ($allOriginal.Count -eq 0) { throw 'Previous program tree is empty' }
      foreach ($file in $allOriginal) {
        $relative = $file.FullName.Substring($appDir.Length).TrimStart('\','/')
        $saved = Join-Path $dest $relative
        if (-not (Test-Path -LiteralPath $saved -PathType Leaf)) {
          throw ('Missing backed up program file: ' + $relative)
        }
        $oldHash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
        $newHash = (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash
        if ($oldHash -ne $newHash -or $file.Length -ne (Get-Item -LiteralPath $saved).Length) {
          throw ('Program backup checksum mismatch: ' + $relative)
        }
        $programFiles += @{relative=$relative;bytes=[long]$file.Length;sha256=$oldHash}
      }
      if (@(Get-ChildItem -LiteralPath $dest -Recurse -File -Force).Count -ne $programFiles.Count) {
        throw 'Program tree snapshot has unexpected file count'
      }
    }
    $manifest = @{
      created_utc = (Get-Date).ToUniversalTime().ToString('o')
      service = $ServiceName
      was_running = $wasRunning
      database_present = $hasDatabase
      program_present = $hasOldProgram
      previous_exe_sha256 = $previousExeSha
      program_files = @($programFiles)
      files = @($files)
      purpose = 'Recovery point before replacement of any NOVA executable'
    }
    if ($hasDatabase -and @($files | Where-Object { $_.name -eq 'pharmacy.sqlite3' }).Count -ne 1) {
      throw 'Database snapshot was not completed'
    }
    $manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $snapshot 'manifest.json') -Encoding UTF8
    if ($hasOldProgram) {
      # Durable recovery pointer, only after all prior data/program copies were checked.
      @{snapshot=$snapshot;created_utc=(Get-Date).ToUniversalTime().ToString('o')} |
        ConvertTo-Json | Set-Content -LiteralPath $pending -Encoding UTF8
    }
    Write-Log ('Verified pre-update snapshot: ' + $snapshot)
  } else {
    Write-Log 'Fresh install: no existing program files or database to back up.'
  }
  $success = $true
  exit 0
} catch {
  Write-Log ('REFUSED upgrade: ' + $_.Exception.Message)
  Write-Error ('NOVA update stopped BEFORE file replacement. Details: ' + $_.Exception.Message)
  exit 29
} finally {
  if (-not $success -and $wasRunning) {
    # Preflight failed before Inno copied anything. Resume existing service.
    try { Start-Service -Name $ServiceName -ErrorAction Stop; Write-Log 'Original NOVA service restarted after rejected preflight.' }
    catch { Write-Log ('WARNING: Could not restart prior service: ' + $_.Exception.Message) }
  }
}
