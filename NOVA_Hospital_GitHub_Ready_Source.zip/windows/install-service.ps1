# Invoked by the installer with administrator privileges, hidden from end users.
# The service registration approach is adapted from the open-source BamDude
# Windows installer; this file is entirely tailored to NOVA's Python app.
$ErrorActionPreference='Stop'
$service='NOVA_Hospital_Server'
$firewall='NOVA Hospital LAN (Private Subnet)'
$port=8765
$exe=Join-Path $PSScriptRoot 'NOVA-Hospital-Server\NOVA-Hospital-Server.exe'
$nssm=Join-Path $PSScriptRoot 'nssm.exe'
$root=Join-Path $env:ProgramData 'NOVA_Hospital'
$log=Join-Path $root 'logs'
New-Item -Path $log -ItemType Directory -Force | Out-Null
if (!(Test-Path -LiteralPath $nssm -PathType Leaf)) { throw 'Service runner missing' }
if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Hospital server missing' }
# Verify an existing database BEFORE the new server starts/migrates its schema.
$env:NOVA_DATA_HOME=$root
& $exe --verify-data
if ($LASTEXITCODE -ne 0) { throw 'Existing hospital database failed integrity verification; service remains stopped' }
# Keep the database on this computer and separate from the installed files.
New-Item -Path (Join-Path $root 'data') -ItemType Directory -Force | Out-Null
# No operational patient data may be entered before LAN + security acceptance.
$current=Get-Service -Name $service -ErrorAction SilentlyContinue
if ($current) {
  if ($current.Status -ne 'Stopped') {
    throw 'NOVA service must already be stopped by preflight before files can be installed'
  }
  # Reconfigure existing registered service; removing/re-registering it during
  # upgrade can leave a service marked-for-deletion and break the restart.
  & $nssm set $service Application $exe | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'Could not update the existing NOVA service command' }
} else {
  & $nssm install $service $exe | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'Could not register the Windows service' }
}
& $nssm set $service AppDirectory (Split-Path $exe -Parent) | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm set $service DisplayName 'NOVA Hospital Server - Test Build' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm set $service Start SERVICE_AUTO_START | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm set $service AppEnvironmentExtra ('NOVA_DATA_HOME='+$root) 'NOVA_BIND=0.0.0.0' 'NOVA_PORT=8765' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm set $service AppStdout (Join-Path $log 'stdout.log') | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm set $service AppStderr (Join-Path $log 'stderr.log') | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm set $service AppRotateFiles 1 | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm set $service AppRotateOnline 1 | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service configuration failed' }
& $nssm start $service | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Windows service could not start' }
$ok=$false
for($i=0;$i -lt 60;$i++) {
  try {
    $res=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/api/v1/status' -TimeoutSec 2
    if($res.StatusCode -eq 200) {
      $health = $res.Content | ConvertFrom-Json
      if($health.nova_server -eq $true -and $health.single_central_database -eq $true) {
        $ok=$true;break
      }
    }
  } catch { Start-Sleep -Seconds 1 }
}
if(-not $ok){throw "Hospital service did not respond; see $log"}
# Windows-managed inbound access restricted to the same local subnet even
# if Windows initially categorizes the offline-router link as Public. Never
# expose the database port, and use only on a physically isolated trusted LAN.
& netsh advfirewall firewall delete rule name="$firewall" | Out-Null
& netsh advfirewall firewall add rule name="$firewall" dir=in action=allow protocol=TCP localport=$port remoteip=LocalSubnet profile=any | Out-Null
if($LASTEXITCODE -ne 0){throw 'Local network firewall rule could not be created'}
# Plain-language LAN directions for the hospital manager; no PowerShell/CMD
# action is needed from the user. Hostname resolves on many router LANs; the
# IP links are also written for networks without Windows name resolution.
$links=@('NOVA Hospital — Internal Network','',
  'Open this link from any device connected to the same router:',
  ('http://'+$env:COMPUTERNAME+':'+$port+'/'),'',
  'If the computer name does not work, use one of these local addresses:')
$addresses=@(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
  Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -notlike '0.*' } |
  Select-Object -ExpandProperty IPAddress -Unique)
foreach($ip in $addresses){$links += ('http://'+$ip+':'+$port+'/')}
$links+=@('','The server computer stays on while staff work.','Development build: do not enter real patient data before security acceptance.')
$links | Set-Content -LiteralPath (Join-Path $root 'NOVA_LAN_ADDRESS.txt') -Encoding UTF8
# A good service start completes the pending upgrade. Retain verified snapshots
# for manual recovery, but do not block future updates with a stale marker.
$pending=Join-Path $root 'upgrade_backups\pending-update.json'
if (Test-Path -LiteralPath $pending) { Remove-Item -LiteralPath $pending -Force -ErrorAction Stop }
exit 0
