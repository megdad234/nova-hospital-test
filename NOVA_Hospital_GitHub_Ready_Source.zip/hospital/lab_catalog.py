"""Local seed catalogue of laboratory test definitions (not clinical reference certification).

Ranges are illustrative adult screening defaults frequently seen in common laboratory
references. Laboratories MUST verify all intervals against their own analyzers,
methods, reagents and population before reporting them for real patients.
Unknown or age-specific intervals are deliberately empty, not guessed.
"""

# tuple: code, display name, category, comma-separated searchable aliases,
# analytes: (code, label, unit, adult-unisex interval, adult-male, adult-female)
# There is no clinical interpretation or automatic diagnostic threshold logic here.
CBC = [
 ('WBC','WBC','×10⁹/L','4.5–11.0','',''),
 ('RBC','RBC','×10¹²/L','','4.6–6.2','4.2–5.4'),
 ('HGB','Hemoglobin (Hb)','g/dL','','13.0–18.0','12.0–16.0'),
 ('HCT','Hematocrit (HCT)','%','','40–52','36–48'),
 ('MCV','MCV','fL','80–100','',''),
 ('MCH','MCH','pg','27–33','',''),
 ('MCHC','MCHC','g/dL','32–36','',''),
 ('RDW','RDW-CV','%','11.5–14.5','',''),
 ('PLT','Platelets','×10⁹/L','150–400','',''),
 ('MPV','MPV','fL','','',''),
 ('NEUT','Neutrophils','%','40–70','',''),
 ('LYMPH','Lymphocytes','%','20–40','',''),
 ('MONO','Monocytes','%','2–8','',''),
 ('EOS','Eosinophils','%','1–4','',''),
 ('BASO','Basophils','%','0–1','',''),
 ('NEUT_ABS','Neutrophils absolute','×10⁹/L','','',''),
 ('LYMPH_ABS','Lymphocytes absolute','×10⁹/L','','',''),
]
LFT = [
 ('ALT','ALT (SGPT)','U/L','','',''), ('AST','AST (SGOT)','U/L','','',''),
 ('ALP','Alkaline phosphatase','U/L','','',''), ('GGT','GGT','U/L','','',''),
 ('TBIL','Bilirubin total','mg/dL','0.1–1.2','',''),
 ('DBIL','Bilirubin direct','mg/dL','0–0.3','',''),
 ('ALB','Albumin','g/dL','3.4–5.4','',''), ('TP','Total protein','g/dL','6.0–8.3','',''),
]
RFT = [
 ('UREA','Urea','mg/dL','','',''), ('BUN','Blood urea nitrogen','mg/dL','6–20','',''),
 ('CRE','Creatinine','mg/dL','','',''), ('URIC','Uric acid','mg/dL','','',''),
 ('NA','Sodium','mmol/L','135–145','',''), ('K','Potassium','mmol/L','3.5–5.0','',''),
 ('CL','Chloride','mmol/L','98–106','',''),
]
LIPID=[('TC','Total cholesterol','mg/dL','','',''),('TG','Triglycerides','mg/dL','','',''),
       ('HDL','HDL cholesterol','mg/dL','','',''),('LDL','LDL cholesterol','mg/dL','','',''),
       ('VLDL','VLDL','mg/dL','','','')]
URINE=[('COLOR','Color','','','',''),('APPEAR','Appearance','','','',''),
       ('SG','Specific gravity','','','',''),('PH','pH','','','',''),
       ('PROT','Protein','','','',''),('GLUC','Glucose','','','',''),
       ('KET','Ketones','','','',''),('BLOOD','Blood','','','',''),
       ('NIT','Nitrite','','','',''),('LEU','Leukocyte esterase','','','',''),
       ('WBC','Pus cells','/HPF','','',''),('RBC','RBC','/HPF','','',''),
       ('EPI','Epithelial cells','/HPF','','',''),('CRYS','Crystals','','','','')]
STOOL=[('COLOR','Color','','','',''),('CONS','Consistency','','','',''),
       ('MUCUS','Mucus','','','',''),('RBC','RBC','/HPF','','',''),
       ('PUS','Pus cells','/HPF','','',''),('OVA','Ova and cysts','','','',''),
       ('PARASITE','Parasites','','','','')]

# The first run does not assign prices. Hospital admin sets local prices once.
# Quick access is by aliases, popular status and recent test selection.
TESTS = [
 ('CBC','Complete Blood Count (CBC)','Hematology','cbc,سي بي سي,صورة دم,صورة الدم,عد دم,كاملة',CBC),
 ('ESR','ESR','Hematology','سرعة الترسيب,esr', [('ESR','ESR','mm/h','','','')]),
 ('HB','Hemoglobin (Hb)','Hematology','هيموجلوبين,هيموغلوبين,hb', [('HGB','Hemoglobin','g/dL','','13–18','12–16')]),
 ('PCV','Packed Cell Volume (PCV)','Hematology','pcv,hematocrit,هيماتوكريت',[('HCT','PCV','%','','','')]),
 ('BTCT','Bleeding / Clotting Time','Hematology','bt,ct,زمن النزيف', [('BT','Bleeding time','min','','',''),('CT','Clotting time','min','','','')]),
 ('BGROUP','Blood Group & Rh','Blood bank','فصيلة الدم,فصيله الدم,blood group', [('ABO','ABO group','','','',''),('RH','Rh factor','','','','')]),
 ('MALARIA','Malaria test','Parasitology','ملاريا,ملاريا فيلم,malaria',[('MP','Malaria parasite','','','','')]),
 ('MAL_RDT','Malaria Rapid Test','Parasitology','malaria rdt,ملاريا سريع',[('RDT','Malaria antigen','','','','')]),
 ('URINE','Urine General Examination','Urinalysis','urine,بول,urine analysis,urinalysis',URINE),
 ('STOOL','Stool General Examination','Parasitology','stool,براز,stool analysis',STOOL),
 ('RBS','Random Blood Sugar (RBS)','Chemistry','سكر عشوائي,rbs,glucose random', [('GLU','Random glucose','mg/dL','','','')]),
 ('FBS','Fasting Blood Sugar (FBS)','Chemistry','سكر صائم,fbs,fasting glucose',[('GLU','Fasting glucose','mg/dL','70–99','','')]),
 ('PPBS','2h Postprandial Glucose','Chemistry','سكر بعد الاكل,ppbs',[('GLU','2h glucose','mg/dL','','','')]),
 ('HBA1C','HbA1c','Chemistry','سكر تراكمي,hba1c,اي ون سي',[('A1C','HbA1c','%','','','')]),
 ('LFT','Liver Function Tests (LFT)','Chemistry','وظائف كبد,lft,liver function',LFT),
 ('RFT','Renal Function Tests (RFT)','Chemistry','وظائف كلى,rft,kft,renal function',RFT),
 ('LIPID','Lipid Profile','Chemistry','دهون,ليبيد,lipid',LIPID),
 ('ELECTRO','Electrolytes','Chemistry','املاح,electrolytes',[('NA','Sodium','mmol/L','135–145','',''),('K','Potassium','mmol/L','3.5–5.0','',''),('CL','Chloride','mmol/L','98–106','','')]),
 ('UREA','Urea','Chemistry','يوريا,urea',[('UREA','Urea','mg/dL','','','')]),
 ('CRE','Creatinine','Chemistry','كرياتينين,creatinine',[('CRE','Creatinine','mg/dL','','','')]),
 ('URIC','Uric acid','Chemistry','حمض اليوريك,uric acid',[('URIC','Uric acid','mg/dL','','','')]),
 ('ALT','ALT / SGPT','Chemistry','alt,sgpt,انزيم الكبد',[('ALT','ALT','U/L','','','')]),
 ('AST','AST / SGOT','Chemistry','ast,sgot',[('AST','AST','U/L','','','')]),
 ('TBIL','Total bilirubin','Chemistry','bilirubin,صفار',[('TBIL','Total bilirubin','mg/dL','0.1–1.2','','')]),
 ('CALCIUM','Serum Calcium','Chemistry','calcium,كالسيوم',[('CA','Calcium','mg/dL','','','')]),
 ('PHOS','Phosphorus','Chemistry','phosphorus,فوسفور',[('PHOS','Phosphorus','mg/dL','','','')]),
 ('MG','Magnesium','Chemistry','magnesium,مغنيسيوم',[('MG','Magnesium','mg/dL','','','')]),
 ('CRP','C-Reactive Protein (CRP)','Immunology','crp,بروتين سي التفاعلي',[('CRP','CRP','mg/L','','','')]),
 ('ASO','ASO titre','Immunology','aso,anti streptolysin',[('ASO','ASO','IU/mL','','','')]),
 ('RF','Rheumatoid Factor (RF)','Immunology','rf,عامل روماتويد',[('RF','RF','IU/mL','','','')]),
 ('WIDAL','Widal test','Serology','ويدال,تيفويد,typhoid',[('O','S. typhi O','','','',''),('H','S. typhi H','','','','')]),
 ('HBSAG','HBsAg','Serology','فيروس كبد بي,hepatitis b',[('HB','HBsAg','','','','')]),
 ('HCV','Anti-HCV','Serology','فيروس كبد سي,hepatitis c',[('HCV','Anti-HCV','','','','')]),
 ('HIV','HIV screening','Serology','hiv,ايدز',[('HIV','HIV screening','','','','')]),
 ('PREG','Pregnancy test (urine)','Serology','حمل,pregnancy',[('HCG','Urine hCG','','','','')]),
 ('BHCG','Beta-hCG','Hormones','هرمون حمل,beta hcg',[('BHCG','Beta-hCG','mIU/mL','','','')]),
 ('TSH','Thyroid Stimulating Hormone','Hormones','tsh,غدة درقية,thyroid',[('TSH','TSH','mIU/L','','','')]),
 ('FT4','Free T4','Hormones','ft4,free t4',[('FT4','Free T4','ng/dL','','','')]),
 ('FT3','Free T3','Hormones','ft3,free t3',[('FT3','Free T3','pg/mL','','','')]),
 ('TFT','Thyroid Profile','Hormones','tft,وظائف غدة درقية',[('TSH','TSH','mIU/L','','',''),('FT4','Free T4','ng/dL','','',''),('FT3','Free T3','pg/mL','','','')]),
 ('PROLACTIN','Prolactin','Hormones','prolactin,هرمون اللبن',[('PRL','Prolactin','ng/mL','','','')]),
 ('FSH','FSH','Hormones','fsh',[('FSH','FSH','mIU/mL','','','')]),
 ('LH','LH','Hormones','lh',[('LH','LH','mIU/mL','','','')]),
 ('TESTO','Testosterone','Hormones','testosterone,تستوستيرون',[('TESTO','Testosterone','ng/dL','','','')]),
 ('PSA','PSA total','Tumor markers','psa,البروستاتا',[('PSA','PSA total','ng/mL','','','')]),
 ('PTINR','PT / INR','Coagulation','pt,inr,سيولة الدم',[('PT','Prothrombin time','s','','',''),('INR','INR','','','','')]),
 ('APTT','APTT','Coagulation','aptt,ptt',[('APTT','APTT','s','','','')]),
 ('D_DIMER','D-Dimer','Coagulation','ddimer,دي دايمر',[('DD','D-Dimer','mg/L FEU','','','')]),
 ('CULTURE','Culture & Sensitivity','Microbiology','مزرعة,مزرعه,culture',[('ORGANISM','Organism','','','',''),('SENS','Antibiotic susceptibility','','','','')]),
 ('URINE_CULT','Urine Culture','Microbiology','مزرعة بول,urine culture',[('ORGANISM','Organism','','','',''),('SENS','Sensitivity','','','','')]),
 ('STOOL_CULT','Stool Culture','Microbiology','مزرعة براز,stool culture',[('ORGANISM','Organism','','','',''),('SENS','Sensitivity','','','','')]),
 ('BLOOD_CULT','Blood Culture','Microbiology','مزرعة دم,blood culture',[('ORGANISM','Organism','','','',''),('SENS','Sensitivity','','','','')]),
 ('H_PYLORI','H. pylori antigen','Serology','جرثومة المعدة,جرثومه المعده,hpylori',[('HP','H. pylori antigen','','','','')]),
 ('VITD','Vitamin D (25-OH)','Chemistry','vitamin d,فيتامين د',[('VD','25-OH Vitamin D','ng/mL','','','')]),
 ('B12','Vitamin B12','Chemistry','فيتامين ب12,b12',[('B12','Vitamin B12','pg/mL','','','')]),
 ('FERRITIN','Ferritin','Chemistry','فيريتين,مخزون الحديد',[('FER','Ferritin','ng/mL','','','')]),
 ('IRON','Serum Iron','Chemistry','حديد,iron',[('FE','Serum Iron','µg/dL','','','')]),
 ('TIBC','Total Iron Binding Capacity','Chemistry','tibc',[('TIBC','TIBC','µg/dL','','','')]),
]

POPULAR = {'CBC','RBS','FBS','MALARIA','URINE','STOOL','LFT','RFT','HBA1C','ESR','CRP','BGROUP'}
