"""NOVA centralized admin: read-only departmental reports, insurance settlements,
verified backup management. All stored figures are SDG integers.

NOT a general ledger; pharmacy totals remain separately labelled. No OPD.
"""
from __future__ import annotations

import re
import json
import secrets
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path

import app as pharmacy
from hospital import core, finance

DDL = '''
CREATE TABLE IF NOT EXISTS nova_insurance_settlements(
 id INTEGER PRIMARY KEY, settlement_no TEXT NOT NULL UNIQUE,
 insurer_id INTEGER NOT NULL REFERENCES nova_insurers(id),
 idempotency_key TEXT NOT NULL UNIQUE,
 amount INTEGER NOT NULL CHECK(amount>0),
 cash_amount INTEGER NOT NULL DEFAULT 0 CHECK(cash_amount>=0),
 bank_amount INTEGER NOT NULL DEFAULT 0 CHECK(bank_amount>=0),
 bank_id INTEGER REFERENCES nova_banks(id), bank_name TEXT NOT NULL DEFAULT '',
 bank_reference TEXT NOT NULL DEFAULT '',
 created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 CHECK(amount=cash_amount+bank_amount),
 CHECK(bank_amount>0 OR bank_id IS NULL));
CREATE UNIQUE INDEX IF NOT EXISTS nova_insurance_bank_unique
 ON nova_insurance_settlements(bank_id,bank_reference)
 WHERE bank_id IS NOT NULL AND bank_reference!='';
CREATE TABLE IF NOT EXISTS nova_insurance_settlement_lines(
 settlement_id INTEGER NOT NULL REFERENCES nova_insurance_settlements(id),
 invoice_id INTEGER NOT NULL REFERENCES nova_claims(invoice_id),
 amount INTEGER NOT NULL CHECK(amount>0),
 PRIMARY KEY(settlement_id,invoice_id));
'''


def init(c):
    c.executescript(DDL)


def period(args):
    today=date.today()
    start=(args.get('from') or [''])[0] or today.replace(day=1).isoformat()
    end=(args.get('to') or [''])[0] or today.isoformat()
    try:
        a,b=date.fromisoformat(start),date.fromisoformat(end)
    except (TypeError,ValueError):
        raise ValueError('صيغة الفترة غير صحيحة')
    if a>b or (b-a).days>730 or b>today+timedelta(days=1):
        raise ValueError('اختر فترة صحيحة لا تتجاوز عامين')
    return a.isoformat(),b.isoformat()


def scalar(c,sql,params=()):
    row=c.execute(sql,params).fetchone()
    return (row[0] or 0) if row else 0


def admin_reports(c, start, end):
    """All invoice/payment figures explicitly use event dates and category labels.

    Historical stand-alone lab receipts are not included in new invoice sales.
    Claims are receivables, not cash. Pharmacy sales are distinct and not added
    to new hospital receipts unless an audited reconciliation exists.
    """
    since=start+'T00:00:00';until=end+'T23:59:59.999999'
    win=(since,until)
    patients=scalar(c,'SELECT COUNT(*) FROM hospital_patients WHERE created_at BETWEEN ? AND ?',win)
    invoices=scalar(c,"SELECT COUNT(*) FROM nova_invoices WHERE created_at BETWEEN ? AND ?",win)
    services=pharmacy.query(c,'''SELECT il.category_code AS category,COUNT(*) AS count,
        SUM(il.price) AS billed, SUM(il.patient_part) AS patient_due,
        SUM(il.insurer_part) AS insurer_due
        FROM nova_invoice_lines il JOIN nova_invoices inv ON inv.id=il.invoice_id
        WHERE inv.status!='void' AND inv.created_at BETWEEN ? AND ?
        GROUP BY il.category_code ORDER BY billed DESC''',win)
    tests=pharmacy.query(c,'''SELECT oi.test_name AS name,COUNT(*) AS count,
        COALESCE(SUM(oi.price),0) AS catalog_amount,
        SUM(CASE WHEN oi.result_status='approved' THEN 1 ELSE 0 END) AS published
        FROM hospital_order_items oi JOIN hospital_orders o ON o.id=oi.order_id
        WHERE o.status!='cancelled' AND o.created_at BETWEEN ? AND ?
        GROUP BY oi.test_id ORDER BY count DESC,oi.test_name LIMIT 30''',win)
    lab_orders=scalar(c,"SELECT COUNT(*) FROM hospital_orders WHERE status!='cancelled' AND created_at BETWEEN ? AND ?",win)
    lab_published=scalar(c,'''SELECT COUNT(*) FROM hospital_order_items oi JOIN hospital_orders o ON oi.order_id=o.id
        WHERE oi.result_status='approved' AND o.created_at BETWEEN ? AND ?''',win)
    cash=scalar(c,'SELECT SUM(cash_amount) FROM nova_payments WHERE created_at BETWEEN ? AND ?',win)
    bank=scalar(c,'SELECT SUM(bank_amount) FROM nova_payments WHERE created_at BETWEEN ? AND ?',win)
    refund_cash=scalar(c,'SELECT SUM(cash_amount) FROM nova_refunds WHERE created_at BETWEEN ? AND ?',win)
    refund_bank=scalar(c,'SELECT SUM(bank_amount) FROM nova_refunds WHERE created_at BETWEEN ? AND ?',win)
    # Pharmacy report is a distinct source, not double-counted as hospital money.
    pharmacy_sales=scalar(c,"SELECT SUM(cash_paid+bank_paid) FROM sales WHERE created_at BETWEEN ? AND ? AND status='completed'",win)
    pharmacy_count=scalar(c,"SELECT COUNT(*) FROM sales WHERE created_at BETWEEN ? AND ? AND status='completed'",win)
    pharmacy_billed=scalar(c,"SELECT SUM(total) FROM sales WHERE created_at BETWEEN ? AND ? AND status='completed'",win)
    pharmacy_returns=scalar(c,"SELECT SUM(amount) FROM sale_returns WHERE created_at BETWEEN ? AND ?",win)
    pharmacy_returns_count=scalar(c,"SELECT COUNT(*) FROM sale_returns WHERE created_at BETWEEN ? AND ?",win)
    pharmacy_products=pharmacy.query(c,'''SELECT pr.name AS name,COUNT(*) AS lines,
             COALESCE(SUM(sl.total),0) AS amount
             FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id
             JOIN packages pk ON pk.id=sl.package_id JOIN products pr ON pr.id=pk.product_id
             WHERE s.created_at BETWEEN ? AND ? AND s.status='completed'
             GROUP BY pk.product_id ORDER BY amount DESC LIMIT 15''',win)
    claims=pharmacy.query(c,'''SELECT i.id,i.name,COUNT(cl.invoice_id) AS claims,
        COALESCE(SUM(cl.amount),0) AS amount,COALESCE(SUM(cl.received),0) AS received,
        COALESCE(SUM(cl.amount-cl.received),0) AS balance
        FROM nova_insurers i LEFT JOIN nova_claims cl ON cl.insurer_id=i.id
        GROUP BY i.id ORDER BY balance DESC,i.name''')
    by_day=pharmacy.query(c,'''SELECT substr(created_at,1,10) AS day,
        COALESCE(SUM(cash_amount),0) AS cash,COALESCE(SUM(bank_amount),0) AS bank
        FROM nova_payments WHERE created_at BETWEEN ? AND ?
        GROUP BY substr(created_at,1,10) ORDER BY day''',win)
    by_day_refunds=pharmacy.query(c,'''SELECT substr(created_at,1,10) AS day,
        COALESCE(SUM(cash_amount),0) AS cash,COALESCE(SUM(bank_amount),0) AS bank
        FROM nova_refunds WHERE created_at BETWEEN ? AND ?
        GROUP BY substr(created_at,1,10) ORDER BY day''',win)
    refunds={r['day']:r for r in by_day_refunds}
    daily=[{'day':r['day'],'cash':r['cash']-refunds.get(r['day'],{}).get('cash',0),
            'bank':r['bank']-refunds.get(r['day'],{}).get('bank',0)} for r in by_day]
    # Include refund-only dates.
    days={r['day'] for r in daily}
    daily+= [{'day':r['day'],'cash':-r['cash'],'bank':-r['bank']} for r in by_day_refunds if r['day'] not in days]
    daily.sort(key=lambda x:x['day'])
    insurer_cash=scalar(c,'SELECT SUM(cash_amount) FROM nova_insurance_settlements WHERE created_at BETWEEN ? AND ?',win)
    insurer_bank=scalar(c,'SELECT SUM(bank_amount) FROM nova_insurance_settlements WHERE created_at BETWEEN ? AND ?',win)
    other_insurance_receipts=scalar(c,'''SELECT SUM(amount) FROM nova_claim_receipts
        WHERE created_at BETWEEN ? AND ?''',win)-scalar(c,'''SELECT SUM(line.amount)
        FROM nova_insurance_settlement_lines line JOIN nova_insurance_settlements s ON s.id=line.settlement_id
        WHERE s.created_at BETWEEN ? AND ?''',win)
    return {
        'period':{'from':start,'to':end},
        'patients':patients,'invoices':invoices,'lab_orders':lab_orders,'lab_published':lab_published,
        'lab_tests':tests,'service_categories':services,'daily':daily,
        'hospital_collections':{'cash_gross':cash,'bank_gross':bank,'cash_refunded':refund_cash,
              'bank_refunded':refund_bank,'net_cash':cash-refund_cash,'net_bank':bank-refund_bank},
        'pharmacy':{'sales_count':pharmacy_count,'sales_collected':pharmacy_sales,
                    'gross_billed':pharmacy_billed,'returns_amount':pharmacy_returns,
                    'returns_count':pharmacy_returns_count,
                    'net_billed':pharmacy_billed-pharmacy_returns,'top_products':pharmacy_products,
                    'note':'فواتير الصيدلية والمرتجعات حسب تاريخ كل عملية؛ الصافي ليس صافي الربح. التحصيل النقدي والبنكي مؤشر منفصل.'},
        'insurance':{'companies':claims,'cash_collected':insurer_cash,'bank_collected':insurer_bank,
                     'other_collected':other_insurance_receipts,
                     'total_outstanding':sum(row['balance'] for row in claims)},
        'scope_note':'تحصيلات المستشفى والصيدلية والتأمين منفصلة؛ لا يمثل التقرير ميزانية محاسبية أو أرباحاً صافية.'
    }


def settle_insurer(c, actor, data):
    """Allocate an insurer remittance oldest outstanding claim first, atomically.
    Safe for simultaneous cashiers and retries via idempotency key.
    """
    iid=finance.num(data.get('insurer_id'),'شركة التأمين',1)
    amount=finance.num(data.get('amount'),'المبلغ',1)
    cash=finance.num(data.get('cash_amount',0),'النقدي')
    bank_amt=finance.num(data.get('bank_amount',0),'البنكي')
    if cash+bank_amt!=amount:raise ValueError('مجموع النقدي والبنكي يجب أن يساوي المبلغ')
    key=finance.text(data,'idempotency_key',100,True)
    bank_id=None;bank_name='';ref=''
    if bank_amt:
        bank_id=finance.num(data.get('bank_id'),'البنك',1)
        ref=finance.text(data,'bank_reference',120)
    finance.start(c)
    try:
        previous=pharmacy.one(c,'SELECT * FROM nova_insurance_settlements WHERE idempotency_key=?',(key,))
        if previous:
            if (previous['insurer_id']!=iid or previous['amount']!=amount or
                previous['cash_amount']!=cash or previous['bank_amount']!=bank_amt or
                previous['bank_id']!=bank_id or previous['bank_reference']!=ref):
                raise ValueError('مفتاح العملية مستخدم لعملية أخرى')
            finance.done(c)
            return {'id':previous['id'],'settlement_no':previous['settlement_no'],'repeated':True}
        company=pharmacy.one(c,'SELECT id,name FROM nova_insurers WHERE id=?',(iid,))
        if not company:raise ValueError('شركة التأمين غير موجودة')
        if bank_amt:
            bank=pharmacy.one(c,'SELECT * FROM nova_banks WHERE id=? AND active=1',(bank_id,))
            if not bank:raise ValueError('البنك غير متاح')
            if bank['require_reference'] and not ref:raise ValueError('اكتب رقم العملية البنكية')
            bank_name=bank['name']
        outstanding=pharmacy.query(c,'''SELECT cl.invoice_id,cl.amount-cl.received AS balance
            FROM nova_claims cl JOIN nova_invoices inv ON inv.id=cl.invoice_id
            WHERE cl.insurer_id=? AND cl.amount>cl.received AND inv.status!='void'
            ORDER BY inv.created_at,cl.invoice_id''',(iid,))
        if amount>sum(r['balance'] for r in outstanding):raise ValueError('المبلغ يتجاوز مديونية شركة التأمين')
        cur=c.execute('''INSERT INTO nova_insurance_settlements(settlement_no,insurer_id,idempotency_key,
            amount,cash_amount,bank_amount,bank_id,bank_name,bank_reference,created_by,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
            ('IS-'+finance.uid(),iid,key,amount,cash,bank_amt,bank_id,bank_name,ref,actor['id'],core.now()))
        remaining=amount;allocations=[]
        for row in outstanding:
            if remaining==0:break
            applied=min(remaining,row['balance']);remaining-=applied
            c.execute('INSERT INTO nova_insurance_settlement_lines(settlement_id,invoice_id,amount) VALUES(?,?,?)',
                      (cur.lastrowid,row['invoice_id'],applied))
            c.execute('''INSERT INTO nova_claim_receipts(invoice_id,amount,reference,created_by,created_at)
                        VALUES(?,?,?,?,?)''',(row['invoice_id'],applied,ref,actor['id'],core.now()))
            c.execute('''UPDATE nova_claims SET received=received+?,
                status=CASE WHEN received+?=amount THEN 'paid' ELSE 'part_paid' END
                WHERE invoice_id=?''',(applied,applied,row['invoice_id']))
            allocations.append({'invoice_id':row['invoice_id'],'amount':applied})
        core.track(c,actor['id'],'insurance_batch_settlement',cur.lastrowid,
                  {'company':company['name'],'amount':amount,'allocations':allocations})
        record=pharmacy.one(c,'SELECT settlement_no FROM nova_insurance_settlements WHERE id=?',(cur.lastrowid,))
        finance.done(c)
        return {'id':cur.lastrowid,'settlement_no':record['settlement_no'],'allocations':allocations,'repeated':False}
    except Exception:
        finance.rollback(c);raise


def settlements(c,insurer_id=0):
    return pharmacy.query(c,'''SELECT s.id,s.settlement_no,s.amount,s.cash_amount,s.bank_amount,
        s.bank_name,s.bank_reference,s.created_at,i.name AS insurer_name,
        u.full_name AS employee FROM nova_insurance_settlements s
        JOIN nova_insurers i ON i.id=s.insurer_id JOIN users u ON u.id=s.created_by
        WHERE (?=0 OR s.insurer_id=?) ORDER BY s.id DESC LIMIT 200''',(insurer_id,insurer_id))


def backup_now(c, actor):
    """Uses pharmacy's existing verified SQLite online-backup mechanism.
    No restore over live employees: restoration is deliberately not exposed here.
    """
    from hospital.backup import make_manual_backup
    target=pharmacy.DATA/'backups'/('nova-manual-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.sqlite3')
    result=make_manual_backup(pharmacy.DB,target)
    core.track(c,actor['id'],'hospital_manual_backup',None,
               {'filename':target.name,'sha256':result['sha256']})
    c.commit()
    return {'filename':target.name,'bytes':result['size'],'sha256':result['sha256'],'verified':True}


def insurer_claims(c,insurer_id):
    return pharmacy.query(c,'''SELECT cl.invoice_id, inv.invoice_no, inv.created_at,
         p.full_name AS patient_name,cl.amount,cl.received,cl.amount-cl.received AS balance,
         cl.status FROM nova_claims cl JOIN nova_invoices inv ON inv.id=cl.invoice_id
         JOIN hospital_patients p ON p.id=inv.patient_id
         WHERE cl.insurer_id=? AND inv.status!='void'
         ORDER BY inv.created_at,cl.invoice_id''',(insurer_id,))


def set_staff_active(c,actor,data):
    uid=core.integer(data.get('user_id'),'الموظف',1)
    state=data.get('active')
    if not isinstance(state,bool):raise ValueError('حالة الحساب غير صحيحة')
    if uid==actor['id'] and not state:raise ValueError('لا يمكن تعطيل حسابك')
    c.execute('BEGIN IMMEDIATE')
    try:
        if not c.execute('UPDATE users SET active=? WHERE id=?',(int(state),uid)).rowcount:
            raise ValueError('الموظف غير موجود')
        if not state:c.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
        core.track(c,actor['id'],'staff_active_changed',uid,{'active':state})
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'user_id':uid,'active':state}


def reset_staff_password(c,actor,data):
    uid=core.integer(data.get('user_id'),'الموظف',1)
    password=data.get('password','')
    if not isinstance(password,str) or len(password)<12 or len(password)>200:
        raise ValueError('كلمة المرور الجديدة يجب أن تكون بين 12 و200 حرف')
    salt=secrets.token_hex(16)
    c.execute('BEGIN IMMEDIATE')
    try:
        if not c.execute('UPDATE users SET pass_hash=?,salt=? WHERE id=?',
              (pharmacy.password_hash(password,salt),salt,uid)).rowcount:
            raise ValueError('الموظف غير موجود')
        c.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
        core.track(c,actor['id'],'staff_password_reset',uid)
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'user_id':uid,'updated':True}


def backups(c):
    base=pharmacy.DATA/'backups'
    if not base.exists():return []
    out=[]
    for f in sorted(base.glob('*.sqlite3'),key=lambda x:x.stat().st_mtime,reverse=True)[:40]:
        try:
            stat=f.stat(); checksum=Path(str(f)+'.sha256')
            out.append({'filename':f.name,'bytes':stat.st_size,
                        'created_at':datetime.fromtimestamp(stat.st_mtime).isoformat(timespec='seconds'),
                        'has_checksum':checksum.exists(),'kind':('يدوية — الإدارة' if f.name.startswith('nova-manual-') else 'يدوية — الصيدلية' if f.name.startswith('pharmacy-') else 'تلقائية' if f.name.startswith('auto-') else 'نسخة أخرى')})
        except OSError:continue
    return out
