"""NOVA laboratory domain, stored within the pharmacy-backed central SQLite DB.

This is clinical *recordkeeping* only. Analyzer mapping and reference ranges need
local laboratory validation before any clinical use. No external dependencies.
"""
from __future__ import annotations

import csv
import io
import json
import re
import secrets
import sqlite3
from datetime import date, datetime

import app as pharmacy
from hospital import lab_catalog

SCHEMA = """
CREATE TABLE IF NOT EXISTS hospital_lab_parameters (
 id INTEGER PRIMARY KEY,
 test_id INTEGER NOT NULL REFERENCES hospital_lab_tests(id),
 code TEXT NOT NULL, name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT '',
 reference_all TEXT NOT NULL DEFAULT '', reference_male TEXT NOT NULL DEFAULT '',
 reference_female TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1,
 UNIQUE(test_id,code)
);
CREATE TABLE IF NOT EXISTS hospital_lab_lines (
 id INTEGER PRIMARY KEY,
 item_id INTEGER NOT NULL REFERENCES hospital_order_items(id),
 parameter_id INTEGER REFERENCES hospital_lab_parameters(id),
 code TEXT NOT NULL, name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT '',
 reference_range TEXT NOT NULL DEFAULT '', value TEXT NOT NULL DEFAULT '',
 modified_at TEXT, source TEXT NOT NULL DEFAULT 'manual',
 UNIQUE(item_id,code)
);
CREATE TABLE IF NOT EXISTS hospital_lab_revisions (
 id INTEGER PRIMARY KEY,
 item_id INTEGER NOT NULL REFERENCES hospital_order_items(id),
 user_id INTEGER NOT NULL REFERENCES users(id),
 recorded_at TEXT NOT NULL, before_json TEXT NOT NULL, after_json TEXT NOT NULL,
 reason TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'manual',
 version INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS hospital_lab_samples (
 id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES hospital_orders(id),
 sample_no TEXT NOT NULL UNIQUE, sample_type TEXT NOT NULL DEFAULT '',
 state TEXT NOT NULL CHECK(state IN ('collected','received','rejected','repeat')),
 note TEXT NOT NULL DEFAULT '', recorded_at TEXT NOT NULL,
 recorded_by INTEGER NOT NULL REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS hospital_lab_settings (
 key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_nova_lab_lines_item ON hospital_lab_lines(item_id);
CREATE INDEX IF NOT EXISTS ix_nova_lab_revisions_item ON hospital_lab_revisions(item_id);
CREATE INDEX IF NOT EXISTS ix_nova_lab_samples_order ON hospital_lab_samples(order_id);
"""
DEFAULT_BRAND = {'hospital_name':'NOVA Hospital', 'hospital_name_en':'NOVA Hospital',
                 'hospital_address':'', 'hospital_phone':'', 'lab_title':'تقرير نتائج المختبر',
                 'hospital_logo':''}


def now():
    return datetime.now().isoformat(timespec='seconds')


def init(c):
    """Repeatable schema upgrade; preserves existing orders, catalog and prices."""
    c.executescript(SCHEMA)
    cols={row['name'] for row in c.execute('PRAGMA table_info(hospital_lab_tests)')}
    for key,decl in [('category',"TEXT NOT NULL DEFAULT 'Other'"),('aliases',"TEXT NOT NULL DEFAULT ''"),
                     ('popular',"INTEGER NOT NULL DEFAULT 0"),('reference_reviewed','INTEGER NOT NULL DEFAULT 0')]:
        if key not in cols:c.execute(f'ALTER TABLE hospital_lab_tests ADD COLUMN {key} {decl}')
    cols={row['name'] for row in c.execute('PRAGMA table_info(hospital_order_items)')}
    if 'result_version' not in cols:
        c.execute('ALTER TABLE hospital_order_items ADD COLUMN result_version INTEGER NOT NULL DEFAULT 0')
    c.execute('''CREATE TABLE IF NOT EXISTS hospital_staff_extra (
        user_id INTEGER NOT NULL REFERENCES users(id), permission TEXT NOT NULL,
        UNIQUE(user_id,permission))''')
    c.execute('BEGIN IMMEDIATE')
    try:
        for code,name,category,aliases,analytes in lab_catalog.TESTS:
            existing=pharmacy.one(c,'SELECT id FROM hospital_lab_tests WHERE code=?',(code,))
            if existing:
                tid=existing['id']
                # Never overwrite price or locally modified definitions.
            else:
                tid=c.execute('''INSERT INTO hospital_lab_tests
                  (code,name,price,category,aliases,popular) VALUES (?,?,?,?,?,?)''',
                  (code,name,0,category,aliases,int(code in lab_catalog.POPULAR))).lastrowid
            existing_keys={x['code'] for x in c.execute('SELECT code FROM hospital_lab_parameters WHERE test_id=?',(tid,))}
            for i,definition in enumerate(analytes):
                acode,aname,unit,all_ref,male,female=definition
                if acode not in existing_keys:
                    c.execute('''INSERT INTO hospital_lab_parameters
                        (test_id,code,name,unit,reference_all,reference_male,reference_female,sort_order)
                        VALUES (?,?,?,?,?,?,?,?)''',(tid,acode,aname,unit,all_ref,male,female,i))
        for key,val in DEFAULT_BRAND.items():
            c.execute('INSERT OR IGNORE INTO hospital_lab_settings(key,value) VALUES(?,?)',(key,val))
        c.execute('COMMIT')
    except Exception:
        c.execute('ROLLBACK');raise


def catalog(c, search='', only_popular=False):
    rows=pharmacy.query(c,'SELECT * FROM hospital_lab_tests WHERE active=1 ORDER BY popular DESC,name')
    if only_popular:rows=[x for x in rows if x['popular']]
    term=search.strip().casefold()[:80]
    if term:rows=[x for x in rows if term in (x['code']+' '+x['name']+' '+x['aliases']).casefold()]
    return rows[:200]


def profile(c, tid):
    row=pharmacy.one(c,'SELECT * FROM hospital_lab_tests WHERE id=?',(tid,))
    if not row:raise ValueError('الفحص غير موجود')
    out=dict(row)
    out['parameters']=pharmacy.query(c,'SELECT * FROM hospital_lab_parameters WHERE test_id=? AND active=1 ORDER BY sort_order,id',(tid,))
    return out


def update_test(c, actor, data):
    tid=to_int(data.get('test_id'),'الفحص')
    price=data.get('price')
    name=txt(data,'name',150)
    aliases=txt(data,'aliases',500)
    popular=bool(data.get('popular',False))
    updates=data.get('parameters',[])
    if not isinstance(updates,list) or len(updates)>120:raise ValueError('قائمة البنود غير صحيحة')
    c.execute('BEGIN IMMEDIATE')
    try:
        test=pharmacy.one(c,'SELECT id FROM hospital_lab_tests WHERE id=?',(tid,))
        if not test:raise ValueError('الفحص غير موجود')
        fields=[];args=[]
        if price is not None:
            value=to_int(price,'السعر',min_value=0);fields.append('price=?');args.append(value)
        if 'name' in data:
            if not name:raise ValueError('اسم الفحص مطلوب')
            fields.append('name=?');args.append(name)
        if 'aliases' in data:fields.append('aliases=?');args.append(aliases)
        if 'popular' in data:fields.append('popular=?');args.append(int(popular))
        if fields:c.execute('UPDATE hospital_lab_tests SET '+','.join(fields)+' WHERE id=?',(*args,tid))
        if updates:
            for i,row in enumerate(updates):
                if not isinstance(row,dict):raise ValueError('بند غير صحيح')
                pid=row.get('id')
                nm=txt(row,'name',120,True);code=txt(row,'code',50,True)
                unit=txt(row,'unit',60)
                vals=[txt(row,k,100) for k in ('reference_all','reference_male','reference_female')]
                # Empty range is permitted; never invent or force one.
                if pid:
                    pid=to_int(pid,'البند')
                    res=c.execute('''UPDATE hospital_lab_parameters SET code=?,name=?,unit=?,
                      reference_all=?,reference_male=?,reference_female=?,sort_order=?
                      WHERE id=? AND test_id=?''',(code,nm,unit,*vals,i,pid,tid))
                    if res.rowcount!=1:raise ValueError('بند غير تابع للتحليل')
                else:
                    c.execute('''INSERT INTO hospital_lab_parameters
                     (test_id,code,name,unit,reference_all,reference_male,reference_female,sort_order)
                     VALUES (?,?,?,?,?,?,?,?)''',(tid,code,nm,unit,*vals,i))
            c.execute('UPDATE hospital_lab_tests SET reference_reviewed=1 WHERE id=?',(tid,))
        audit(c,actor['id'],'lab_catalog_updated',tid)
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return profile(c,tid)


def txt(d,key,maximum=150,required=False):
    v=d.get(key,'')
    s=str(v if v is not None else '').strip()
    if len(s)>maximum or ('\x00' in s) or (required and not s):
        raise ValueError('قيمة غير صحيحة: '+key)
    return s


def to_int(v,label,min_value=1):
    if isinstance(v,bool):raise ValueError('قيمة غير صحيحة: '+label)
    try:ret=int(v)
    except (ValueError,TypeError):raise ValueError('قيمة غير صحيحة: '+label)
    if str(ret)!=str(v).strip() or ret<min_value or ret>10**12:raise ValueError('قيمة غير صحيحة: '+label)
    return ret


def audit(c,uid,action,oid,details=None):
    c.execute('INSERT INTO hospital_audit(user_id,created_at,action,object_id,details) VALUES(?,?,?,?,?)',
              (uid,now(),action,oid,json.dumps(details or {},ensure_ascii=False)))


def age_years(p):
    # An actual date of birth is more reliable and stays current.
    # Otherwise display the age recorded at registration (no fabricated DOB).
    birth=p.get('birth_date')
    if birth:
        try:
            d=date.fromisoformat(birth)
            today=date.today()
            if d<=today:
                return today.year-d.year - ((today.month,today.day)<(d.month,d.day))
        except ValueError:
            pass
    entered=p.get('age_years')
    if entered is not None and entered!='':return int(entered)
    return None


def select_range(p,param):
    # Defaults are explicitly ADULT only, never applied to paediatric patients.
    age=age_years(p)
    if age is not None and age<18:return ''
    sex=p.get('gender','')
    if sex=='male' and param['reference_male']:return param['reference_male']
    if sex=='female' and param['reference_female']:return param['reference_female']
    return param['reference_all']  # If sex unknown, never guess male/female.


def snapshot_item(c,item_id,patient_id):
    pat=pharmacy.one(c,'SELECT gender,birth_date,age_years FROM hospital_patients WHERE id=?',(patient_id,))
    item=pharmacy.one(c,'SELECT test_id,test_name,unit,reference_range FROM hospital_order_items WHERE id=?',(item_id,))
    params=pharmacy.query(c,'SELECT * FROM hospital_lab_parameters WHERE test_id=? AND active=1 ORDER BY sort_order,id',(item['test_id'],))
    if not params:
        # Legacy/custom single-result test remains usable without redefinition.
        c.execute('''INSERT OR IGNORE INTO hospital_lab_lines
        (item_id,code,name,unit,reference_range) VALUES(?,?,?,?,?)''',
         (item_id,'RESULT',item['test_name'],item['unit'],item['reference_range']))
        return
    for p in params:
        c.execute('''INSERT OR IGNORE INTO hospital_lab_lines
          (item_id,parameter_id,code,name,unit,reference_range) VALUES(?,?,?,?,?,?)''',
          (item_id,p['id'],p['code'],p['name'],p['unit'],select_range(pat,p)))


def ensure_order_lines(c,order_id):
    # Old orders created before lab version 3 get a frozen snapshot once.
    o=pharmacy.one(c,'SELECT patient_id FROM hospital_orders WHERE id=?',(order_id,))
    if not o:raise ValueError('الطلب غير موجود')
    for it in c.execute('SELECT id,result_text FROM hospital_order_items WHERE order_id=?',(order_id,)):
        if not pharmacy.one(c,'SELECT id FROM hospital_lab_lines WHERE item_id=?',(it['id'],)):
            snapshot_item(c,it['id'],o['patient_id'])
            # Preserve pre-upgrade single-text findings instead of silently
            # replacing them with empty newly structured lines.
            if it['result_text']:
                c.execute('''INSERT OR IGNORE INTO hospital_lab_lines
                  (item_id,code,name,value,source,modified_at)
                  VALUES(?,?,?,?,?,?)''',(it['id'],'LEGACY_NOTE','نتيجة سابقة قبل التحديث',it['result_text'],'manual',now()))


def lines(c,item_id):
    return pharmacy.query(c,'SELECT * FROM hospital_lab_lines WHERE item_id=? ORDER BY id',(item_id,))


def order_lab_detail(c,order_id):
    ensure_order_lines(c,order_id)
    items=pharmacy.query(c,'SELECT * FROM hospital_order_items WHERE order_id=? ORDER BY id',(order_id,))
    for i in items:
        i['lines']=lines(c,i['id'])
    return items


def flag(value,reference):
    """Non-blocking numeric visual hint only; not a clinical flag or diagnosis."""
    try:
        v=float(value)
        s=reference.replace('–','-').replace('−','-').replace(' ','')
        match=re.fullmatch(r'(-?\d+(?:\.\d+)?)-(-?\d+(?:\.\d+)?)',s)
        if not match:return ''
        lo,hi=map(float,match.groups())
        if lo>hi:return ''
        return 'low' if v<lo else 'high' if v>hi else ''
    except (TypeError,ValueError,OverflowError):return ''


def save_values(c,actor,data):
    item_id=to_int(data.get('item_id'),'الفحص')
    values=data.get('values')
    if not isinstance(values,list) or len(values)>120:raise ValueError('جدول النتائج غير صحيح')
    publish=data.get('publish') is True
    expected_version=to_int(data.get('expected_version',0),'رقم النسخة',0)
    reason=txt(data,'reason',500)
    source=txt(data,'source',12) or 'manual'
    if source not in ('manual','csv'):raise ValueError('مصدر النتيجة غير صحيح')
    c.execute('BEGIN IMMEDIATE')
    try:
        it=pharmacy.one(c,'''SELECT i.*,o.status FROM hospital_order_items i
            JOIN hospital_orders o ON o.id=i.order_id WHERE i.id=?''',(item_id,))
        if not it:raise ValueError('الفحص غير موجود')
        if it['status'] not in ('paid','completed'):raise PermissionError('الفحص لم يتم دفعه')
        if it['result_version']!=expected_version:raise ValueError('تم تحديث النتيجة من موظف آخر. أعد فتحها قبل الحفظ.')
        ensure_order_lines(c,it['order_id'])
        original={x['id']:x for x in lines(c,item_id)}
        before={str(k):v['value'] for k,v in original.items()}
        after=dict(before)
        touched=set()
        for v in values:
            if not isinstance(v,dict):raise ValueError('قيمة نتيجة غير صحيحة')
            lid=to_int(v.get('line_id'),'بند النتيجة')
            if lid not in original or lid in touched:raise ValueError('بند نتيجة غير معروف أو مكرر')
            touched.add(lid)
            val=txt(v,'value',4000)
            after[str(lid)]=val
        if publish and not any(v.strip() for v in after.values()):
            raise ValueError('أدخل نتيجة واحدة على الأقل قبل إصدار التقرير')
        new_ver=it['result_version']+1
        if after!=before or publish!=(it['result_status']=='approved'):
            for lid in touched:
                if after[str(lid)]!=before[str(lid)]:
                    c.execute('''UPDATE hospital_lab_lines SET value=?,modified_at=?,source=? WHERE id=?''',
                     (after[str(lid)],now(),source,lid))
            c.execute('''UPDATE hospital_order_items SET result_status=?,result_entered_by=?,
                 approved_at=?,result_version=? WHERE id=?''',
              ('approved' if publish else 'draft',actor['id'],now() if publish else None,new_ver,item_id))
            c.execute('''INSERT INTO hospital_lab_revisions(item_id,user_id,recorded_at,before_json,
              after_json,reason,source,version) VALUES(?,?,?,?,?,?,?,?)''',
              (item_id,actor['id'],now(),json.dumps(before,ensure_ascii=False),json.dumps(after,ensure_ascii=False),reason,source,new_ver))
            audit(c,actor['id'],'lab_result_revised',item_id,{'version':new_ver,'published':publish,'source':source})
        else:new_ver=it['result_version']
        remaining=pharmacy.one(c,"SELECT count(*) AS n FROM hospital_order_items WHERE order_id=? AND result_status!='approved'",(it['order_id'],))['n']
        if remaining==0:c.execute("UPDATE hospital_orders SET status='completed' WHERE id=? AND status IN ('paid','completed')",(it['order_id'],))
        else:c.execute("UPDATE hospital_orders SET status='paid' WHERE id=? AND status='completed'",(it['order_id'],))
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'item_id':item_id,'version':new_ver,'published':publish}


def revisions(c,item_id):
    return pharmacy.query(c,'''SELECT r.id,r.version,r.recorded_at,r.reason,r.source,r.before_json,r.after_json,u.full_name AS changed_by
       FROM hospital_lab_revisions r JOIN users u ON u.id=r.user_id
       WHERE r.item_id=? ORDER BY r.id DESC LIMIT 50''',(item_id,))


def samples(c,order_id):
    return pharmacy.query(c,'SELECT * FROM hospital_lab_samples WHERE order_id=? ORDER BY id DESC',(order_id,))


def add_sample(c,actor,data):
    oid=to_int(data.get('order_id'),'رقم الطلب')
    state=txt(data,'state',25,True)
    if state not in ('collected','received','rejected','repeat'):raise ValueError('حالة العينة غير صحيحة')
    sample_type=txt(data,'sample_type',80)
    note=txt(data,'note',500)
    c.execute('BEGIN IMMEDIATE')
    try:
        o=pharmacy.one(c,'SELECT status FROM hospital_orders WHERE id=?',(oid,))
        if not o:raise ValueError('الطلب غير موجود')
        if o['status'] not in ('paid','completed'):raise PermissionError('الطلب لم يتم دفعه')
        sn='S-'+secrets.token_hex(5).upper()
        c.execute('INSERT INTO hospital_lab_samples(order_id,sample_no,sample_type,state,note,recorded_at,recorded_by) VALUES (?,?,?,?,?,?,?)',
                  (oid,sn,sample_type,state,note,now(),actor['id']))
        audit(c,actor['id'],'lab_sample_event',oid,{'state':state,'sample_no':sn})
        c.execute('COMMIT')
        return {'sample_no':sn,'state':state}
    except Exception:c.execute('ROLLBACK');raise


def settings(c):
    return {r['key']:r['value'] for r in c.execute('SELECT key,value FROM hospital_lab_settings')}


def set_settings(c,actor,data):
    allowed={**DEFAULT_BRAND}
    if not data or not set(data).issubset(allowed):raise ValueError('إعدادات غير صحيحة')
    c.execute('BEGIN IMMEDIATE')
    try:
        for k,v in data.items():
            if k=='hospital_logo':
                if v and (not isinstance(v,str) or not re.fullmatch(r'data:image/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+',v) or len(v)>180000):
                    raise ValueError('الشعار يجب أن يكون PNG أو JPG أو WebP بحجم صغير')
                value=v
            else:value=txt(data,k,200)
            c.execute('INSERT INTO hospital_lab_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,value))
        audit(c,actor['id'],'hospital_brand_updated',None,list(data))
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return settings(c)


def report(c,order_id):
    o=pharmacy.one(c,'''SELECT o.*,p.full_name patient_name,p.patient_no,p.gender,p.birth_date,p.age_years
       FROM hospital_orders o JOIN hospital_patients p ON p.id=o.patient_id WHERE o.id=?''',(order_id,))
    if not o or o['status'] not in ('paid','completed'):raise PermissionError('التقرير غير متاح')
    items=order_lab_detail(c,order_id)
    # Do not put drafts or unpublished results on printable clinical reports.
    ready=[i for i in items if i['result_status']=='approved']
    if not ready:raise ValueError('مافي نتائج منشورة للطباعة')
    return {'order_no':o['order_no'],'patient_name':o['patient_name'],'patient_no':o['patient_no'],
            'gender':o['gender'],'birth_date':o['birth_date'],'age_years':age_years(o),'print_time':now(),
            'brand':settings(c),'items':ready,'partial':len(ready)!=len(items),
            'warning':'المديات المرجعية الأولية تستلزم مراجعة المعمل قبل الاستخدام السريري'}


def import_csv(c,actor,data,apply=False):
    """CSV adapter for export files. NEVER guess patient or test identity."""
    content=txt(data,'csv_text',40000,True)
    if '\x00' in content:raise ValueError('ملف نتائج غير صالح')
    try:reader=csv.DictReader(io.StringIO(content.lstrip('\ufeff')),strict=True)
    except csv.Error:raise ValueError('ملف CSV غير صالح')
    expected={'order_no','test_code','parameter_code','result'}
    if reader.fieldnames is None or not expected.issubset({x.strip().lower() for x in reader.fieldnames}):
        raise ValueError('أعمدة CSV المطلوبة: order_no,test_code,parameter_code,result')
    out=[]; seen=set(); observed_versions={}
    try:
        for row in reader:
            row={str(k).strip().lower():v for k,v in row.items() if k is not None}
            order_no=txt(row,'order_no',50,True)
            test_code=txt(row,'test_code',40,True)
            parameter_code=txt(row,'parameter_code',50,True)
            result=txt(row,'result',4000)
            key=(order_no,test_code,parameter_code)
            if key in seen:raise ValueError('في بند مكرر داخل الملف')
            seen.add(key)
            o=pharmacy.one(c,'SELECT id,status FROM hospital_orders WHERE order_no=?',(order_no,))
            if not o or o['status'] not in ('paid','completed'):
                raise ValueError('رقم طلب غير مدفوع أو غير موجود: '+order_no)
            it=pharmacy.one(c,'''SELECT i.id,i.result_status,i.result_version FROM hospital_order_items i
               JOIN hospital_lab_tests t ON t.id=i.test_id
               WHERE i.order_id=? AND t.code=?''',(o['id'],test_code))
            if not it:raise ValueError('الفحص غير موجود داخل الطلب: '+test_code)
            if it['result_status']=='approved':
                raise ValueError('هذه النتيجة منشورة بالفعل؛ عدلها من شاشة النتائج مع حفظ سجل التصحيح')
            observed_versions.setdefault(it['id'],it['result_version'])
            ensure_order_lines(c,o['id'])
            line=pharmacy.one(c,'SELECT id FROM hospital_lab_lines WHERE item_id=? AND code=?',(it['id'],parameter_code))
            if not line:raise ValueError('البند غير معروف: '+parameter_code)
            out.append({'order_no':order_no,'test_code':test_code,'parameter_code':parameter_code,
                        'result':result,'item_id':it['id'],'line_id':line['id']})
            if len(out)>200:raise ValueError('عدد صفوف الملف كبير')
    except (csv.Error,TypeError) as exc:raise ValueError('الملف غير صالح') from exc
    if not out:raise ValueError('الملف فارغ')
    if not apply:return {'rows':out,'preview_only':True}
    # Single transaction: don't partially import a file if any row fails.
    grouped={}
    for row in out:grouped.setdefault(row['item_id'],[]).append(row)
    c.execute('BEGIN IMMEDIATE')
    try:
        for item_id,group in grouped.items():
            # Re-check under the write lock: a user may have published or
            # changed the result while a CSV file was being parsed.
            it=pharmacy.one(c,'''SELECT i.*,o.status AS order_status
                FROM hospital_order_items i JOIN hospital_orders o ON o.id=i.order_id
                WHERE i.id=?''',(item_id,))
            if (not it or it['order_status'] not in ('paid','completed')
                    or it['result_status']=='approved'
                    or it['result_version']!=observed_versions[item_id]):
                raise ValueError('نتيجة الفحص تغيرت أثناء الاستيراد؛ افتح الطلب وراجع النتائج ثم أعد المحاولة')
            before={str(x['id']):x['value'] for x in lines(c,item_id)}
            after=dict(before)
            for r in group:after[str(r['line_id'])]=r['result']
            version=it['result_version']+1
            for r in group:
                c.execute("UPDATE hospital_lab_lines SET value=?,modified_at=?,source='csv' WHERE id=?",
                          (r['result'],now(),r['line_id']))
            c.execute("UPDATE hospital_order_items SET result_status='draft', result_version=?,result_entered_by=?,approved_at=NULL WHERE id=?",
                      (version,actor['id'],item_id))
            c.execute('''INSERT INTO hospital_lab_revisions(item_id,user_id,recorded_at,before_json,after_json,source,version)
                VALUES(?,?,?,?,?,'csv',?)''',
               (item_id,actor['id'],now(),json.dumps(before),json.dumps(after),version))
            audit(c,actor['id'],'lab_analyzer_csv_imported',item_id,{'rows':len(group)})
            c.execute('''UPDATE hospital_orders SET status='paid' WHERE id=(SELECT order_id FROM hospital_order_items WHERE id=?) AND status='completed' ''',(item_id,))
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'imported':len(out),'items':len(grouped),'published':False}


def statistics(c):
    base=pharmacy.one(c,'''SELECT count(*) AS n,
        sum(CASE WHEN result_status='approved' THEN 1 ELSE 0 END) AS ready,
        sum(CASE WHEN result_status='draft' THEN 1 ELSE 0 END) AS drafts
        FROM hospital_order_items''')
    rejected=pharmacy.one(c,"SELECT count(*) AS n FROM hospital_lab_samples WHERE state='rejected'")['n']
    return {'test_items':base['n'],'ready':base['ready'] or 0,
            'drafts':base['drafts'] or 0,'rejected_samples':rejected,
            'popular':pharmacy.query(c,'''SELECT test_name,count(*) AS count FROM hospital_order_items
              GROUP BY test_name ORDER BY count DESC LIMIT 10''')}
