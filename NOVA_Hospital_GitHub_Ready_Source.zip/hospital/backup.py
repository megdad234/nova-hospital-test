"""NOVA unified database backup gate; no second backup engine or patient DB.

The legacy pharmacy's SQLite online-backup API remains the single copy engine.
Every restore is verified as a COMPLETE NOVA hospital snapshot, never merely a
valid standalone pharmacy database. No writes to the supplied pharmacy source.
"""
from __future__ import annotations

from contextlib import closing
from pathlib import Path
import sqlite3

import recovery

BACKUP_ID = 'NOVA_HOSPITAL_UNIFIED_DATABASE'
BACKUP_FORMAT = 1

# Hospital modules must ALL be present. Do not require any patients/transactions:
# a brand-new hospital with zero activity must still be recoverable.
REQUIRED_HOSPITAL_TABLES = frozenset({
    'hospital_staff', 'hospital_staff_extra', 'hospital_patients',
    'hospital_lab_tests', 'hospital_orders', 'hospital_order_items',
    'hospital_receipts', 'hospital_audit', 'hospital_lab_parameters',
    'hospital_lab_lines', 'hospital_lab_revisions',
    'hospital_lab_samples', 'hospital_lab_settings',
    'nova_service_categories', 'nova_services', 'nova_banks',
    'nova_insurers', 'nova_insurer_rates', 'nova_patient_insurance',
    'nova_invoices', 'nova_invoice_lines', 'nova_payments',
    'nova_claims', 'nova_claim_receipts', 'nova_refunds',
    'nova_cashier_shifts', 'nova_insurance_settlements',
    'nova_insurance_settlement_lines',
})
REQUIRED_COLUMNS = {
    'hospital_patients': {'id', 'patient_no', 'full_name', 'age_years'},
    'hospital_orders': {'id', 'patient_id', 'status'},
    'hospital_order_items': {'id', 'order_id', 'test_id', 'result_status', 'result_version'},
    'hospital_lab_lines': {'id', 'item_id', 'value', 'reference_range'},
    'nova_invoices': {'id', 'patient_id', 'total', 'patient_due', 'insurer_due'},
    'nova_invoice_lines': {'id', 'invoice_id', 'price'},
    'nova_payments': {'id', 'invoice_id', 'cash_amount', 'bank_amount'},
    'nova_claims': {'invoice_id', 'amount', 'received'},
    'nova_insurance_settlements': {'id', 'insurer_id', 'amount'},
}


def verify_unified_backup(path: str | Path, *, current_database: bool = False) -> dict:
    """Strict read-only inspection (including sha sidecar if one is present).

    Older 5.4 hospital snapshots without the new identity row are supported
    only if their COMPLETE known hospital schema is present. Standalone pharmacy
    backups always fail regardless of their integrity or their filename.
    """
    source = Path(path).resolve()
    if current_database:
        # The active DB can have a sidecar left from a previous restore; after
        # new transactions its checksum will naturally differ. Check schema
        # and integrity directly, never regard that old sidecar as a backup.
        if not source.is_file() or source.stat().st_size < 4096:
            raise ValueError('قاعدة NOVA الحالية مفقودة أو غير صالحة')
        info = {'size': source.stat().st_size, 'sha256': None}
    else:
        info = recovery.validate_backup(source)
    uri = source.as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True, timeout=10)) as conn:
        if conn.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ValueError('فحص سلامة قاعدة البيانات فشل')
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not recovery.REQUIRED.issubset(tables):
            raise ValueError('نسخة NOVA لا تحتوي على جميع جداول الصيدلية')
        missing = REQUIRED_HOSPITAL_TABLES - tables
        if missing:
            raise ValueError('هذه نسخة صيدلية أو مستشفى غير مكتملة؛ لا يمكن استعادتها فوق NOVA. '
                             'جداول المستشفى المطلوبة غير موجودة: ' + ', '.join(sorted(missing)[:5]))
        for table, expected in REQUIRED_COLUMNS.items():
            columns = {r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')}
            if not expected <= columns:
                raise ValueError('نسخة NOVA غير متوافقة: أعمدة ناقصة في ' + table)
        if 'nova_system_identity' in tables:
            identity = conn.execute(
                'SELECT system_id, format_version FROM nova_system_identity WHERE id=1'
            ).fetchone()
            if not identity or identity[0] != BACKUP_ID or not 1 <= identity[1] <= BACKUP_FORMAT:
                raise ValueError('هوية نسخة NOVA غير صحيحة أو إصدار النسخة غير مدعوم')
            fmt = int(identity[1])
            legacy = False
        else:
            # This is a full, structurally checked pre-5.5 NOVA DB, not a
            # pharmacy-only file. Retain compatibility with snapshots of 5.4.
            fmt = 0
            legacy = True
        orphan = conn.execute('PRAGMA foreign_key_check').fetchone()
        if orphan:
            raise ValueError('توجد روابط بيانات غير سليمة في النسخة؛ تم رفض الاستعادة')
    return {**info, 'system': BACKUP_ID, 'format': fmt, 'legacy_nova': legacy,
            'tables_checked': len(REQUIRED_HOSPITAL_TABLES)}


def make_manual_backup(source: str | Path, target: str | Path) -> dict:
    """One engine: use the existing, WAL-aware pharmacy SQLite online backup."""
    dest = Path(target)
    result = recovery.copy_verified(source, dest)
    try:
        verified = verify_unified_backup(dest)
    except Exception:
        dest.unlink(missing_ok=True)
        Path(str(dest) + '.sha256').unlink(missing_ok=True)
        raise
    return {**result, 'system': verified['system'], 'format': verified['format']}


def install_shared_backup_guard() -> None:
    """Guard the pharmacy's existing two backup entry points when hosted by NOVA.

    The original *one* backup scheduler and SQLite Online Backup engine remain in
    use. Nothing is added to pharmacy/app.py, and this does not create another
    background task or another database. Newly produced backup files must pass
    the complete NOVA gate, including the legacy Pharmacy backup button.
    """
    import app as pharmacy

    if getattr(pharmacy.automatic_backup_once, '_nova_unified_guard', False):
        return
    original_auto = pharmacy.automatic_backup_once
    original_manual = pharmacy.backup

    def validate_produced(result: dict) -> None:
        # Auto job returns local and optional external; on a skipped old
        # backup we still validate that the recorded last snapshot is usable.
        entries = [result, result.get('external', {})]
        for entry in entries:
            if not isinstance(entry, dict) or not entry.get('file'):
                continue
            verify_unified_backup(entry['file'])

    def unified_auto(force: bool = False) -> dict:
        result = original_auto(force=force)
        try:
            validate_produced(result)
        except (ValueError, sqlite3.DatabaseError, OSError):
            # A legacy pharmacy-only snapshot may have been the newest one
            # when 5.5 was installed. Do not treat it as a fresh NOVA backup.
            if not force and result.get('skipped'):
                result = original_auto(force=True)
                validate_produced(result)
            else:
                raise
        return result

    def unified_manual(c, uid: int) -> dict:
        result = original_manual(c, uid)
        verify_unified_backup(result['file'])
        return result

    unified_auto._nova_unified_guard = True
    unified_auto._nova_original = original_auto
    unified_manual._nova_unified_guard = True
    unified_manual._nova_original = original_manual
    pharmacy.automatic_backup_once = unified_auto
    pharmacy.backup = unified_manual

