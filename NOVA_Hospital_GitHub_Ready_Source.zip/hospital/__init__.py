"""NOVA hospital modules sharing the existing pharmacy authentication and DB file."""
