"""Single-host HTTP routing for the NOVA hospital and unchanged pharmacy app.

Both departments use pharmacy.app authenticated cookie, users and DB connection.
"""
from __future__ import annotations
import json
import sqlite3
import ipaddress
from contextlib import closing
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import app as pharmacy
from hospital import core, lab, finance, admin

PORTAL_ROOT = Path(__file__).resolve().parent / 'static'

class HospitalHandler(pharmacy.Handler):
    server_version='NOVA-Hospital/0.2-dev'

    def get_path(self):
        path=urlparse(self.path).path
        if path in ('/pharmacy','/pharmacy/','/pharmacy/index.html'):
            return '/index.html'
        return path

    def _send_file(self, name, content_type):
        f=PORTAL_ROOT / name
        content=f.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(content)))
        self.send_header('Cache-Control','no-store' if name=='index.html' else 'no-cache')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Referrer-Policy','no-referrer')
        self.end_headers()
        self.wfile.write(content)

    def _send_pharmacy_index(self):
        # Keep pharmacy's supplied source untouched; change visible identity only
        # in the NOVA-hosted response, never in pharmacy transaction scripts.
        content=(pharmacy.ROOT / 'static' / 'index.html').read_text(encoding='utf-8')
        content=content.replace('مدار | MADAR', 'NOVA Hospital')
        content=content.replace('مدار <small>MADAR</small>', 'NOVA Hospital')
        content=content.replace('منظومة مدار —', 'NOVA Hospital —')
        content=content.replace('مدار —', 'NOVA —')
        content=content.replace('alt="MADAR"', 'alt="NOVA Hospital"')
        content=content.replace('/static/logo.png', '/hospital/static/nova-mark.svg')
        content=content.replace('</body>', '<script src="/hospital/static/pharmacy-brand.js"></script></body>')
        encoded=content.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type','text/html; charset=utf-8')
        self.send_header('Content-Length',str(len(encoded)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.end_headers()
        self.wfile.write(encoded)

    def _role(self):
        with closing(pharmacy.db_connect()) as c:
            user=pharmacy.authenticated(c,self.headers)
            return core.current_role(c,user)

    def do_GET(self):
        path=urlparse(self.path).path
        if path in ('/','/index.html','/hospital','/hospital/'):
            return self._send_file('index.html','text/html; charset=utf-8')
        if path=='/hospital/static/style.css':
            return self._send_file('style.css','text/css; charset=utf-8')
        if path=='/hospital/static/app.js':
            return self._send_file('app.js','application/javascript; charset=utf-8')
        if path=='/hospital/static/finance-ui.js':
            return self._send_file('finance-ui.js','application/javascript; charset=utf-8')
        if path=='/hospital/static/admin-ui.js':
            return self._send_file('admin-ui.js','application/javascript; charset=utf-8')
        if path=='/hospital/static/pharmacy-brand.js':
            return self._send_file('pharmacy-brand.js','application/javascript; charset=utf-8')
        if path=='/hospital/static/nova-mark.svg':
            return self._send_file('nova-mark.svg','image/svg+xml')
        if path.startswith('/api/hospital/'):
            return self.hospital_api('GET',path)
        if path.startswith('/pharmacy') and self._role() not in ('admin','pharmacy'):
            self.send_response(302)
            self.send_header('Location','/')
            self.send_header('Content-Length','0')
            self.end_headers()
            return
        if path in ('/pharmacy','/pharmacy/','/pharmacy/index.html'):
            return self._send_pharmacy_index()
        if path.startswith('/api/v1/') and path not in ('/api/v1/status','/api/v1/login','/api/v1/me'):
            if self._role() not in ('admin','pharmacy'):
                return self.reply({'error':'لا تملك صلاحية الصيدلية'},403)
        if path=='/api/v1/status':
            with closing(pharmacy.db_connect()) as c:
                ready=bool(pharmacy.one(c,'SELECT id FROM users LIMIT 1'))
            return self.reply({'ready':ready,'pilot':True,'nova_server':True,'single_central_database':True})
        return super().do_GET()

    def do_POST(self):
        path=urlparse(self.path).path
        if path.startswith('/api/hospital/'):
            return self.hospital_api('POST',path)
        if path.startswith('/api/v1/') and path not in ('/api/v1/bootstrap','/api/v1/login','/api/v1/logout'):
            if self._role() not in ('admin','pharmacy'):
                return self.reply({'error':'لا تملك صلاحية الصيدلية'},403)
        if path=='/api/v1/bootstrap':
            # First owner must be created locally on the server, never by a
            # random client that discovers a brand-new LAN installation.
            if not ipaddress.ip_address(self.client_address[0]).is_loopback:
                return self.reply({'error':'تهيئة المدير الأول من جهاز السيرفر فقط'},403)
            # Prevent concurrent first-run requests from creating multiple owners.
            with pharmacy.LOCK:
                return super().do_POST()
        return super().do_POST()

    def hospital_api(self, method, path):
        try:
            if method=='POST':
                origin=self.headers.get('Origin','')
                if origin and urlparse(origin).netloc!=self.headers.get('Host',''):
                    raise PermissionError('مصدر الطلب غير مسموح')
                if self.headers.get('Content-Type','').split(';')[0].strip().lower()!='application/json':
                    raise ValueError('استخدم JSON')
                size=int(self.headers.get('Content-Length','0'))
                limit=256*1024 if path=='/api/hospital/lab/brand' else 64*1024
                if size<0 or size>limit:raise ValueError('حجم الطلب غير صالح')
                data=json.loads(self.rfile.read(size)) if size else {}
                if not isinstance(data,dict):raise ValueError('بيانات غير صحيحة')
            else:data={}
            with closing(pharmacy.db_connect()) as c:
                user=pharmacy.authenticated(c,self.headers)
                role=core.current_role(c,user)
                if not user:raise PermissionError('يجب تسجيل الدخول')
                # Admin reports and settlements are centrally permission-gated.
                if method=='GET' and path=='/api/hospital/admin/reports':
                    core.require_role(role,'admin')
                    beginning,end=admin.period(parse_qs(urlparse(self.path).query))
                    return self.reply(admin.admin_reports(c,beginning,end))
                if method=='GET' and path=='/api/hospital/admin/claims':
                    core.require_role(role,'admin')
                    selection=(parse_qs(urlparse(self.path).query).get('insurer_id') or ['0'])[0]
                    iid=core.integer(selection,'شركة التأمين',1)
                    return self.reply(admin.insurer_claims(c,iid))
                if method=='GET' and path=='/api/hospital/admin/settlements':
                    core.require_role(role,'admin')
                    selection=(parse_qs(urlparse(self.path).query).get('insurer_id') or ['0'])[0]
                    return self.reply(admin.settlements(c,core.integer(selection,'شركة التأمين')))
                if method=='GET' and path=='/api/hospital/admin/backups':
                    core.require_role(role,'admin')
                    return self.reply(admin.backups(c))
                if method=='POST' and path=='/api/hospital/admin/staff-active':
                    core.require_role(role,'admin')
                    return self.reply(admin.set_staff_active(c,user,data))
                if method=='POST' and path=='/api/hospital/admin/staff-password':
                    core.require_role(role,'admin')
                    return self.reply(admin.reset_staff_password(c,user,data))
                if method=='POST' and path=='/api/hospital/admin/settle':
                    core.require_role(role,'admin')
                    return self.reply(admin.settle_insurer(c,user,data))
                if method=='POST' and path=='/api/hospital/admin/backup':
                    core.require_role(role,'admin')
                    return self.reply(admin.backup_now(c,user))
                if method=='GET' and path=='/api/hospital/me':
                    return self.reply({'user':{'id':user['id'],'username':user['username'],'name':user['full_name'],'role':role,'role_label':core.ROLE_LABELS.get(role,'غير محدد')},'roles':core.ROLE_LABELS})
                if role is None:raise PermissionError('لا يوجد قسم مخصص لهذا المستخدم')
                if method=='GET':
                    if path=='/api/hospital/lab/brand':
                        core.require_role(role,'admin','lab','reception','cashier','pharmacy')
                        return self.reply(lab.settings(c))
                    if path=='/api/hospital/lab/stats':
                        core.require_role(role,'admin','lab');return self.reply(lab.statistics(c))
                    if path.startswith('/api/hospital/lab/profile/'):
                        core.require_role(role,'admin','lab','reception','cashier')
                        return self.reply(lab.profile(c,core.integer(path.rsplit('/',1)[-1],'الفحص',1)))
                    if path.startswith('/api/hospital/lab/report/'):
                        core.require_role(role,'admin','lab','reception')
                        return self.reply(lab.report(c,core.integer(path.rsplit('/',1)[-1],'رقم الطلب',1)))
                    if path.startswith('/api/hospital/lab/revisions/'):
                        core.require_role(role,'admin','lab')
                        return self.reply(lab.revisions(c,core.integer(path.rsplit('/',1)[-1],'رقم الفحص',1)))
                    if path.startswith('/api/hospital/lab/samples/'):
                        core.require_role(role,'admin','lab')
                        return self.reply(lab.samples(c,core.integer(path.rsplit('/',1)[-1],'رقم الطلب',1)))
                if method=='GET':
                    if path=='/api/hospital/service-categories':
                        core.require_role(role,'admin','reception','cashier')
                        return self.reply(finance.categories(c))
                    if path=='/api/hospital/services':
                        core.require_role(role,'admin','reception','cashier')
                        args=parse_qs(urlparse(self.path).query)
                        return self.reply(finance.catalog(c,(args.get('q') or [''])[0],(args.get('category') or [''])[0],role=='admin'))
                    if path=='/api/hospital/banks':
                        core.require_role(role,'admin','cashier')
                        return self.reply(finance.banks(c,role=='admin'))
                    if path=='/api/hospital/insurers':
                        core.require_role(role,'admin','reception','cashier')
                        return self.reply(finance.insurers(c,role=='admin'))
                    if path=='/api/hospital/insurance-rates':
                        core.require_role(role,'admin')
                        return self.reply(finance.insurer_rates(c))
                    if path.startswith('/api/hospital/patient-insurance/'):
                        core.require_role(role,'admin','reception','cashier')
                        return self.reply(finance.get_patient_insurance(c,core.integer(path.rsplit('/',1)[-1],'المريض',1)) or {})
                    if path=='/api/hospital/invoices':
                        core.require_role(role,'admin','reception','cashier')
                        items=finance.list_invoices(c,(parse_qs(urlparse(self.path).query).get('status') or [''])[0])
                        if role=='reception':
                            for item in items:
                                item.pop('paid',None);item.pop('remaining',None);item.pop('refunded',None);item.pop('net_paid',None)
                        return self.reply(items)
                    if path.startswith('/api/hospital/invoice/'):
                        core.require_role(role,'admin','reception','cashier')
                        out=finance.invoice_detail(c,core.integer(path.rsplit('/',1)[-1],'الفاتورة',1))
                        if role=='reception':
                            out.pop('payments',None);out.pop('claim',None);out.pop('paid',None);out.pop('refunds',None);out.pop('refunded',None);out.pop('net_paid',None)
                        return self.reply(out)
                    if path=='/api/hospital/claims':
                        core.require_role(role,'admin','cashier')
                        return self.reply(finance.claims(c))
                    if path=='/api/hospital/collections':
                        core.require_role(role,'admin','cashier')
                        return self.reply(finance.receipts_summary(c))
                    if path=='/api/hospital/shifts':
                        core.require_role(role,'admin','cashier')
                        return self.reply(finance.shifts(c,user,role=='admin'))
                if method=='POST':
                    if path=='/api/hospital/service':
                        core.require_role(role,'admin');return self.reply(finance.upsert_service(c,user,data))
                    if path=='/api/hospital/bank':
                        core.require_role(role,'admin');return self.reply(finance.upsert_bank(c,user,data))
                    if path=='/api/hospital/insurer':
                        core.require_role(role,'admin');return self.reply(finance.upsert_insurer(c,user,data))
                    if path=='/api/hospital/insurance-rate':
                        core.require_role(role,'admin');return self.reply(finance.set_rate(c,user,data))
                    if path=='/api/hospital/patient-insurance':
                        core.require_role(role,'admin','reception');return self.reply(finance.set_patient_insurance(c,user,data))
                    if path=='/api/hospital/invoice-quote':
                        core.require_role(role,'admin','reception')
                        return self.reply(finance.quote(c,data))
                    if path=='/api/hospital/invoices':
                        core.require_role(role,'admin','reception')
                        return self.reply(finance.create_invoice(c,user,data),201)
                    if path=='/api/hospital/invoice-insurance':
                        core.require_role(role,'admin','cashier');return self.reply(finance.reprice_insurance(c,user,data))
                    if path=='/api/hospital/adopt-lab-order':
                        core.require_role(role,'admin','cashier');return self.reply(finance.adopt_lab_order(c,user,data))
                    if path=='/api/hospital/invoice-payment':
                        core.require_role(role,'admin','cashier');return self.reply(finance.add_payment(c,user,data))
                    if path=='/api/hospital/invoice-insurance-release':
                        core.require_role(role,'admin','cashier');return self.reply(finance.confirm_insured(c,user,data))
                    if path=='/api/hospital/insurance-collection':
                        core.require_role(role,'admin','cashier');return self.reply(finance.claim_payment(c,user,data))
                    if path=='/api/hospital/shift-open':
                        core.require_role(role,'admin','cashier');return self.reply(finance.start_shift(c,user,data))
                    if path=='/api/hospital/shift-close':
                        core.require_role(role,'admin','cashier');return self.reply(finance.close_shift(c,user,data,role=='admin'))
                    if path=='/api/hospital/invoice-void':
                        core.require_role(role,'admin');return self.reply(finance.void_invoice(c,user,data))
                    if path=='/api/hospital/invoice-refund':
                        core.require_role(role,'admin');return self.reply(finance.refund_invoice(c,user,data))
                if method=='GET':
                    if path=='/api/hospital/staff':
                        core.require_role(role,'admin');return self.reply(core.staff_list(c))
                    if path=='/api/hospital/dashboard':
                        core.require_role(role,'admin');return self.reply(core.dashboard(c))
                    if path=='/api/hospital/network':
                        core.require_role(role,'admin');return self.reply(core.local_network_urls(self.server.server_address[1]))
                    if path=='/api/hospital/tests':
                        core.require_role(role,'admin','reception','cashier','lab');term=(parse_qs(urlparse(self.path).query).get('q') or [''])[0];return self.reply(core.tests(c,term))
                    if path=='/api/hospital/patients':
                        core.require_role(role,'admin','reception','lab');term=(parse_qs(urlparse(self.path).query).get('q') or [''])[0];return self.reply(core.patients(c,term))
                    if path=='/api/hospital/orders':
                        core.require_role(role,'admin','reception','cashier','lab');return self.reply(core.orders(c,role))
                    if path.startswith('/api/hospital/order/'):
                        core.require_role(role,'admin','reception','cashier','lab')
                        oid=core.integer(path.rsplit('/',1)[-1],'رقم الطلب',1)
                        return self.reply(core.order_detail(c,oid,role))
                if method=='POST':
                    if path=='/api/hospital/lab/brand':
                        core.require_role(role,'admin');return self.reply(lab.set_settings(c,user,data))
                    if path=='/api/hospital/lab/test':
                        core.require_role(role,'admin','lab');return self.reply(lab.update_test(c,user,data))
                    if path=='/api/hospital/lab/values':
                        core.require_role(role,'admin','lab');return self.reply(lab.save_values(c,user,data))
                    if path=='/api/hospital/lab/sample':
                        core.require_role(role,'admin','lab');return self.reply(lab.add_sample(c,user,data),201)
                    if path=='/api/hospital/lab/csv-preview':
                        core.require_role(role,'admin','lab');return self.reply(lab.import_csv(c,user,data,False))
                    if path=='/api/hospital/lab/csv-apply':
                        core.require_role(role,'admin','lab');return self.reply(lab.import_csv(c,user,data,True))
                if method=='POST':
                    if path=='/api/hospital/staff':
                        core.require_role(role,'admin');return self.reply(core.create_staff(c,user,data),201)
                    if path=='/api/hospital/staff-role':
                        core.require_role(role,'admin');return self.reply(core.update_staff_role(c,user,data))
                    if path=='/api/hospital/tests':
                        core.require_role(role,'admin','lab');return self.reply(core.create_test(c,user,data),201)
                    if path=='/api/hospital/patients':
                        core.require_role(role,'admin','reception','lab');return self.reply(core.create_patient(c,user,data),201)
                    if path=='/api/hospital/orders':
                        core.require_role(role,'admin','reception','lab');return self.reply(core.create_order(c,user,data),201)
                    if path=='/api/hospital/payments':
                        core.require_role(role,'admin','cashier');return self.reply(core.pay_order(c,user,data))
                    if path=='/api/hospital/results':
                        core.require_role(role,'admin','lab');return self.reply(core.save_result(c,user,data))
                self.send_error(404)
        except (ValueError,sqlite3.IntegrityError) as e:
            return self.reply({'error':str(e)},400)
        except PermissionError as e:
            return self.reply({'error':str(e)},403)
        except (json.JSONDecodeError,TypeError,OverflowError) as e:
            return self.reply({'error':'بيانات الطلب غير صحيحة'},400)
        except Exception as e:
            return self.handle_error(e)
