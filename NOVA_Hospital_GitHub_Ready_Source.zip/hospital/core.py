"""NOVA hospital core: central SQLite, role-gated operations, no second user store.

Development integration source, not cleared for real clinical/financial use.
"""
from __future__ import annotations

import json
import secrets
import sqlite3
import socket
import ipaddress
import os
from datetime import date, datetime
from pathlib import Path

import app as pharmacy
from hospital import lab, finance

ROLES = {'admin', 'pharmacy', 'reception', 'cashier', 'lab', 'frontdesk'}
ROLE_LABELS = {'admin':'الإدارة','pharmacy':'الصيدلية','reception':'الاستقبال','cashier':'الحسابات والكاشير','lab':'المعمل','frontdesk':'الاستقبال والكاشير'}

SQL = """
CREATE TABLE IF NOT EXISTS hospital_staff (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  role TEXT NOT NULL CHECK(role IN ('admin','pharmacy','reception','cashier','lab')),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS hospital_patients (
  id INTEGER PRIMARY KEY, patient_no TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
  gender TEXT NOT NULL DEFAULT '', birth_date TEXT NOT NULL DEFAULT '',
  age_years INTEGER CHECK(age_years IS NULL OR age_years BETWEEN 0 AND 125),
  notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
  created_by INTEGER NOT NULL REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS hospital_lab_tests (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price >= 0), unit TEXT NOT NULL DEFAULT '',
  reference_range TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS hospital_orders (
  id INTEGER PRIMARY KEY, order_no TEXT NOT NULL UNIQUE,
  patient_id INTEGER NOT NULL REFERENCES hospital_patients(id),
  created_at TEXT NOT NULL, created_by INTEGER NOT NULL REFERENCES users(id),
  total INTEGER NOT NULL CHECK(total >= 0),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','completed','cancelled')),
  note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS hospital_order_items (
  id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES hospital_orders(id),
  test_id INTEGER NOT NULL REFERENCES hospital_lab_tests(id),
  test_name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT '',
  reference_range TEXT NOT NULL DEFAULT '', price INTEGER NOT NULL CHECK(price >= 0),
  result_text TEXT NOT NULL DEFAULT '',
  result_status TEXT NOT NULL DEFAULT 'pending' CHECK(result_status IN ('pending','draft','approved')),
  result_entered_by INTEGER REFERENCES users(id), approved_at TEXT,
  UNIQUE(order_id,test_id)
);
CREATE TABLE IF NOT EXISTS hospital_receipts (
  id INTEGER PRIMARY KEY, receipt_no TEXT NOT NULL UNIQUE,
  order_id INTEGER NOT NULL UNIQUE REFERENCES hospital_orders(id),
  idempotency_key TEXT NOT NULL UNIQUE,
  amount INTEGER NOT NULL CHECK(amount >= 0),
  method TEXT NOT NULL CHECK(method IN ('cash','bank')),
  bank_reference TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL, created_by INTEGER NOT NULL REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS hospital_audit (
  id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL, action TEXT NOT NULL, object_id INTEGER,
  details TEXT NOT NULL DEFAULT '{}'
);
-- A new snapshot from NOVA must identify itself as a unified hospital DB.
-- Existing 5.4 snapshots can still be imported after strict full-schema checks.
CREATE TABLE IF NOT EXISTS nova_system_identity (
  id INTEGER PRIMARY KEY CHECK(id=1), system_id TEXT NOT NULL,
  format_version INTEGER NOT NULL CHECK(format_version >= 1)
);
INSERT OR IGNORE INTO nova_system_identity(id,system_id,format_version)
VALUES (1,'NOVA_HOSPITAL_UNIFIED_DATABASE',1);
CREATE INDEX IF NOT EXISTS ix_hosp_patient_name ON hospital_patients(full_name);
CREATE INDEX IF NOT EXISTS ix_hosp_order_status ON hospital_orders(status,created_at);
CREATE INDEX IF NOT EXISTS ix_hosp_order_items_order ON hospital_order_items(order_id);
"""


def now():
    return datetime.now().isoformat(timespec='seconds')


def init_schema():
    with pharmacy.LOCK:
        with pharmacy.closing(pharmacy.db_connect()) as c:
            c.executescript(SQL)
            # Idempotent upgrade for databases created before the optional age field.
            if 'age_years' not in {r['name'] for r in c.execute('PRAGMA table_info(hospital_patients)')}:  # no patient rows changed
                c.execute('ALTER TABLE hospital_patients ADD COLUMN age_years INTEGER CHECK(age_years IS NULL OR age_years BETWEEN 0 AND 125)')
            lab.init(c)
            finance.init(c)
            from hospital import admin
            admin.init(c)


def safe_text(data, key, max_len=150, required=False):
    s=str(data.get(key,'') or '').strip()
    if len(s)>max_len or (required and not s):
        raise ValueError('قيمة غير صحيحة: '+key)
    return s


def integer(value, label, min_val=0):
    if isinstance(value,bool):raise ValueError('قيمة غير صحيحة: '+label)
    try:
        n=int(value)
    except (ValueError,TypeError):raise ValueError('قيمة غير صحيحة: '+label)
    if str(n)!=str(value).strip() or n<min_val or n>999999999999:
        raise ValueError('قيمة غير صحيحة: '+label)
    return n


def current_role(c, user):
    if user is None:return None
    row=pharmacy.one(c,'SELECT role FROM hospital_staff WHERE user_id=?',(user['id'],))
    if row:
        if row['role']=='reception' and pharmacy.one(c,"SELECT 1 FROM hospital_staff_extra WHERE user_id=? AND permission='cashier'",(user['id'],)):
            return 'frontdesk'
        return row['role']
    perms=json.loads(user['permissions'])
    if 'users' in perms:return 'admin'  # original pharmacy owner remains hospital admin
    if perms:return 'pharmacy'  # original pharmacy staff are not silently reclassified
    return None


def require_role(role, *allowed):
    if role=='frontdesk' and ('reception' in allowed or 'cashier' in allowed):return
    if role not in allowed:raise PermissionError('ليس لديك صلاحية دخول هذا القسم')


def track(c, uid, action, object_id=None, details=None):
    c.execute('INSERT INTO hospital_audit(user_id,created_at,action,object_id,details) VALUES(?,?,?,?,?)',
              (uid,now(),action,object_id,json.dumps(details or {},ensure_ascii=False)))


def staff_list(c):
    return pharmacy.query(c,"""SELECT u.id,u.username,u.full_name,u.active,
        COALESCE(CASE WHEN hs.role='reception' AND EXISTS (SELECT 1 FROM hospital_staff_extra se WHERE se.user_id=u.id AND se.permission='cashier') THEN 'frontdesk' ELSE hs.role END,CASE WHEN instr(u.permissions,'"users"')>0 THEN 'admin'
        ELSE 'pharmacy' END) AS role
        FROM users u LEFT JOIN hospital_staff hs ON hs.user_id=u.id ORDER BY u.id""")


def create_staff(c, actor, data):
    role=safe_text(data,'role',30,True)
    if role not in ROLES:raise ValueError('القسم غير معروف')
    stored_role='reception' if role=='frontdesk' else role
    username=safe_text(data,'username',60,True)
    fullname=safe_text(data,'full_name',100,True)
    password=str(data.get('password',''))
    if len(password)<12:raise ValueError('كلمة المرور يجب ألا تقل عن 12 حرف')
    perms=(sorted(pharmacy.PERMISSIONS) if role=='admin' else sorted(pharmacy.DEFAULT_PERMS['pharmacist']) if role=='pharmacy' else [])
    salt=secrets.token_hex(16)
    c.execute('BEGIN IMMEDIATE')
    try:
        cur=c.execute('INSERT INTO users(username,full_name,pass_hash,salt,permissions) VALUES(?,?,?,?,?)',
            (username,fullname,pharmacy.password_hash(password,salt),salt,json.dumps(perms)))
        uid=cur.lastrowid
        c.execute('INSERT INTO hospital_staff(user_id,role,created_at) VALUES(?,?,?)',(uid,stored_role,now()))
        if role=='frontdesk':c.execute("INSERT INTO hospital_staff_extra(user_id,permission) VALUES(?,'cashier')",(uid,))
        track(c,actor['id'],'staff_created',uid,{'role':role,'username':username})
        c.execute('COMMIT')
    except Exception:
        c.execute('ROLLBACK')
        raise
    return {'id':uid,'username':username,'role':role}



def update_staff_role(c, actor, data):
    uid=integer(data.get('user_id'),'الموظف',1)
    role=safe_text(data,'role',30,True)
    if role not in ROLES:raise ValueError('القسم غير معروف')
    if uid==actor['id'] and role!='admin':raise ValueError('لا يمكنك إزالة صلاحية الإدارة من حسابك')
    stored='reception' if role=='frontdesk' else role
    perms=(sorted(pharmacy.PERMISSIONS) if role=='admin' else
           sorted(pharmacy.DEFAULT_PERMS['pharmacist']) if role=='pharmacy' else [])
    c.execute('BEGIN IMMEDIATE')
    try:
        exists=pharmacy.one(c,'SELECT * FROM users WHERE id=?',(uid,))
        if not exists:raise ValueError('الموظف غير موجود')
        c.execute('UPDATE users SET permissions=? WHERE id=?',(json.dumps(perms),uid))
        c.execute('''INSERT INTO hospital_staff(user_id,role,created_at) VALUES(?,?,?)
                    ON CONFLICT(user_id) DO UPDATE SET role=excluded.role''',(uid,stored,now()))
        c.execute("DELETE FROM hospital_staff_extra WHERE user_id=? AND permission='cashier'",(uid,))
        if role=='frontdesk':c.execute("INSERT INTO hospital_staff_extra(user_id,permission) VALUES(?,'cashier')",(uid,))
        track(c,actor['id'],'staff_role_updated',uid,{'role':role})
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'user_id':uid,'role':role}


def create_patient(c, actor, data):
    full_name=safe_text(data,'full_name',160,True)
    phone=safe_text(data,'phone',35)
    gender=safe_text(data,'gender',12)
    if gender not in ('','male','female'):raise ValueError('الجنس غير معروف')
    birth_date=safe_text(data,'birth_date',10)
    raw_age=data.get('age_years','')
    age_years=None if raw_age is None or str(raw_age).strip()=='' else integer(raw_age,'العمر')
    if age_years is not None and age_years>125:raise ValueError('العمر يجب أن يكون بين 0 و125 سنة')
    if birth_date:
        try:date.fromisoformat(birth_date)
        except ValueError:raise ValueError('تاريخ الميلاد غير صحيح')
    notes=safe_text(data,'notes',1000)
    c.execute('BEGIN IMMEDIATE')
    try:
        key='P-'+date.today().strftime('%y%m%d')+'-'+secrets.token_hex(4).upper()
        cur=c.execute('INSERT INTO hospital_patients(patient_no,full_name,phone,gender,birth_date,age_years,notes,created_at,created_by) VALUES(?,?,?,?,?,?,?,?,?)',
              (key,full_name,phone,gender,birth_date,age_years,notes,now(),actor['id']))
        pid=cur.lastrowid
        track(c,actor['id'],'patient_created',pid)
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'id':pid,'patient_no':key}


def patients(c, term=''):
    term=term.strip()[:80]
    if not term:return pharmacy.query(c,'SELECT * FROM hospital_patients ORDER BY id DESC LIMIT 150')
    term=term.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
    return pharmacy.query(c,"SELECT * FROM hospital_patients WHERE full_name LIKE ? ESCAPE '\\' OR patient_no LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT 150",tuple(['%'+term+'%']*3))


def tests(c, term=''):
    return lab.catalog(c,term)


def create_test(c, actor, data):
    code=safe_text(data,'code',40,True)
    name=safe_text(data,'name',150,True)
    price=integer(data.get('price'),'السعر')
    unit=safe_text(data,'unit',50)
    ref=safe_text(data,'reference_range',150)
    c.execute('BEGIN IMMEDIATE')
    try:
        cur=c.execute('INSERT INTO hospital_lab_tests(code,name,price,unit,reference_range) VALUES(?,?,?,?,?)',(code,name,price,unit,ref))
        c.execute('''INSERT INTO hospital_lab_parameters(test_id,code,name,unit,reference_all)
             VALUES (?,?,?,?,?)''',(cur.lastrowid,'RESULT',name,unit,ref))
        track(c,actor['id'],'lab_test_created',cur.lastrowid)
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'id':cur.lastrowid}


def create_order(c, actor, data):
    pid=integer(data.get('patient_id'),'المريض',1)
    ids=data.get('test_ids')
    if not isinstance(ids,list) or not 1<=len(ids)<=30:
        raise ValueError('اختر من 1 إلى 30 فحص')
    ids=[integer(i,'الفحص',1) for i in ids]
    if len(set(ids))!=len(ids):raise ValueError('الفحص مكرر')
    note=safe_text(data,'note',500)
    c.execute('BEGIN IMMEDIATE')
    try:
        if not pharmacy.one(c,'SELECT id FROM hospital_patients WHERE id=?',(pid,)):
            raise ValueError('المريض غير موجود')
        marks=','.join('?' for _ in ids)
        found=pharmacy.query(c,'SELECT * FROM hospital_lab_tests WHERE active=1 AND id IN ('+marks+')',tuple(ids))
        if len(found)!=len(ids):raise ValueError('قائمة الفحوصات غير صحيحة')
        total=sum(x['price'] for x in found)
        key='L-'+date.today().strftime('%y%m%d')+'-'+secrets.token_hex(4).upper()
        oid=c.execute('INSERT INTO hospital_orders(order_no,patient_id,created_at,created_by,total,note) VALUES(?,?,?,?,?,?)',
                      (key,pid,now(),actor['id'],total,note)).lastrowid
        for x in found:
            item_id=c.execute('INSERT INTO hospital_order_items(order_id,test_id,test_name,unit,reference_range,price) VALUES(?,?,?,?,?,?)',
                      (oid,x['id'],x['name'],x['unit'],x['reference_range'],x['price'])).lastrowid
            lab.snapshot_item(c,item_id,pid)
        track(c,actor['id'],'lab_order_created',oid,{'count':len(found),'total':total})
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'id':oid,'order_no':key,'total':total,'status':'pending'}


def orders(c, role):
    where="WHERE o.status IN ('paid','completed')" if role=='lab' else ''
    return pharmacy.query(c,f"""SELECT o.*, p.full_name AS patient_name,p.patient_no,
      (SELECT count(*) FROM hospital_order_items i WHERE i.order_id=o.id) AS tests_count,
      (SELECT count(*) FROM hospital_order_items i WHERE i.order_id=o.id AND i.result_status='approved') AS approved_count
      FROM hospital_orders o JOIN hospital_patients p ON p.id=o.patient_id
      {where} ORDER BY o.id DESC LIMIT 200""")


def order_detail(c, oid, role):
    o=pharmacy.one(c,'SELECT o.*,p.full_name AS patient_name,p.patient_no,p.phone FROM hospital_orders o JOIN hospital_patients p ON p.id=o.patient_id WHERE o.id=?',(oid,))
    if not o:raise ValueError('الطلب غير موجود')
    if role=='lab' and o['status'] not in ('paid','completed'):raise PermissionError('الطلب لم يُسدد بعد')
    out=dict(o)
    out['items']=lab.order_lab_detail(c,oid) if role in ('admin','lab') else pharmacy.query(c,'SELECT * FROM hospital_order_items WHERE order_id=? ORDER BY id',(oid,))
    if role in ('cashier','frontdesk'):
        # Cashiers need order charges, not the contents of medical findings.
        for item in out['items']:
            item['result_text']=''
            item['reference_range']=''
    out['receipt']=pharmacy.one(c,'SELECT receipt_no,amount,method,created_at FROM hospital_receipts WHERE order_id=?',(oid,))
    if role=='reception' and out['receipt']:
        out['receipt']={'receipt_no':out['receipt']['receipt_no']}
    return out


def pay_order(c, actor, data):
    oid=integer(data.get('order_id'),'الطلب',1)
    key=safe_text(data,'idempotency_key',128,True)
    if len(key)<12:raise ValueError('مفتاح الدفع غير صالح')
    method=safe_text(data,'method',10,True)
    if method not in ('cash','bank'):raise ValueError('طريقة الدفع غير صحيحة')
    bank_ref=safe_text(data,'bank_reference',90)
    c.execute('BEGIN IMMEDIATE')
    try:
        same=pharmacy.one(c,'SELECT * FROM hospital_receipts WHERE idempotency_key=?',(key,))
        if same:
            if same['order_id']!=oid:raise ValueError('مفتاح دفع مستخدم لطلب آخر')
            c.execute('COMMIT')
            return {'receipt_no':same['receipt_no'],'already_recorded':True,'amount':same['amount']}
        order=pharmacy.one(c,'SELECT * FROM hospital_orders WHERE id=?',(oid,))
        if not order:raise ValueError('الطلب غير موجود')
        if order['status']!='pending':raise ValueError('هذا الطلب تم دفعه أو إغلاقه مسبقاً')
        ref='R-'+date.today().strftime('%y%m%d')+'-'+secrets.token_hex(5).upper()
        c.execute('INSERT INTO hospital_receipts(receipt_no,order_id,idempotency_key,amount,method,bank_reference,created_at,created_by) VALUES(?,?,?,?,?,?,?,?)',
                  (ref,oid,key,order['total'],method,bank_ref,now(),actor['id']))
        c.execute("UPDATE hospital_orders SET status='paid' WHERE id=? AND status='pending'",(oid,))
        track(c,actor['id'],'lab_order_paid',oid,{'amount':order['total'],'receipt':ref})
        c.execute('COMMIT')
    except Exception:c.execute('ROLLBACK');raise
    return {'receipt_no':ref,'amount':order['total'],'already_recorded':False}


def save_result(c, actor, data):
    """Compatibility with old result API, now revisioned, including corrections."""
    iid=integer(data.get('item_id'),'الفحص',1)
    it=pharmacy.one(c,'SELECT * FROM hospital_order_items WHERE id=?',(iid,))
    if not it:raise ValueError('الفحص غير موجود')
    lab.ensure_order_lines(c,it['order_id'])
    rows=lab.lines(c,iid)
    if not rows:raise ValueError('بند النتيجة غير موجود')
    value=data.get('result_text','')
    result=lab.save_values(c,actor,{'item_id':iid,'expected_version':it['result_version'],
       'values':[{'line_id':rows[0]['id'],'value':value}],
       'publish':data.get('approve') is True})
    c.execute('UPDATE hospital_order_items SET result_text=? WHERE id=?',(value,iid))
    return {'item_id':iid,'approved':result['published'],'version':result['version']}


def dashboard(c):
    patients=pharmacy.one(c,'SELECT count(*) AS n FROM hospital_patients')['n']
    orders_n=pharmacy.one(c,'SELECT count(*) AS n FROM hospital_orders')['n']
    paid_n=pharmacy.one(c,"SELECT count(*) AS n FROM hospital_orders WHERE status IN ('paid','completed')")['n']
    lab_revenue=pharmacy.one(c,'SELECT coalesce(sum(amount),0) AS n FROM hospital_receipts')['n']
    finance_summary=finance.receipts_summary(c)
    # Distinct departmental reporting; no journal merge or pretending to have an audited GL.
    pharmacy_sales=pharmacy.one(c,'SELECT coalesce(sum(cash_paid+bank_paid),0) AS n FROM sales')['n']
    return {'patients':patients,'lab_orders':orders_n,'paid_lab_orders':paid_n,
            'lab_collections':lab_revenue,'pharmacy_sale_collections':pharmacy_sales,
            'new_hospital_cash':finance_summary['net_cash'],'new_hospital_bank':finance_summary['net_bank'],
            'hospital_cash_gross':finance_summary['cash'],'hospital_bank_gross':finance_summary['bank'],
            'hospital_cash_refunded':finance_summary['cash_refunded'],
            'hospital_bank_refunded':finance_summary['bank_refunded'],
            'insurance_receivable':finance_summary['insurance_receivable'],
            'report_scope':'ملخص تحصيلات الأقسام، وليس ميزانية أو دفتر أستاذ موحد'}


def local_network_urls(port=8765):
    """Hints for the manager. IP availability depends on Windows/router DNS."""
    scheme='https' if os.environ.get('NOVA_TLS_CERT') and os.environ.get('NOVA_TLS_KEY') else 'http'
    host=socket.gethostname()
    urls=[f'{scheme}://{host}:{port}/']
    try:
        infos=socket.getaddrinfo(host,None,family=socket.AF_INET, type=socket.SOCK_STREAM)
        for item in infos:
            ip=item[4][0]
            addr=ipaddress.ip_address(ip)
            if addr.is_private and not addr.is_loopback and not addr.is_link_local:
                u=f'{scheme}://{ip}:{port}/'
                if u not in urls:urls.append(u)
    except OSError:pass
    return {'urls':urls,'note':'عناوين داخل شبكة المستشفى فقط؛ الكمبيوتر السيرفر يجب أن يبقى شغالاً'}
