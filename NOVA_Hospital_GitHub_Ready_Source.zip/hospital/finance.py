"""NOVA shared patient services, reception and cashier ledger (offline single server).

Development stage. No bank-network confirmation, insurance eligibility or accounting GL.
All mutations are atomic on the server-side DB; clients never access database files.
"""
from __future__ import annotations
import json
import secrets
from datetime import date, datetime
import app as pharmacy
from hospital import lab

SCHEMA = '''
CREATE TABLE IF NOT EXISTS nova_service_categories(
 id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
 sort_order INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS nova_services(
 id INTEGER PRIMARY KEY, category_id INTEGER NOT NULL REFERENCES nova_service_categories(id),
 code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, aliases TEXT NOT NULL DEFAULT '',
 price INTEGER NOT NULL DEFAULT 0 CHECK(price >= 0),
 popular INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS nova_banks(
 id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, account_label TEXT NOT NULL DEFAULT '',
 require_reference INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS nova_insurers(
 id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, default_coverage INTEGER NOT NULL DEFAULT 0
 CHECK(default_coverage BETWEEN 0 AND 100), active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS nova_insurer_rates(
 id INTEGER PRIMARY KEY, insurer_id INTEGER NOT NULL REFERENCES nova_insurers(id),
 category_code TEXT NOT NULL DEFAULT '', service_key TEXT NOT NULL DEFAULT '',
 coverage INTEGER NOT NULL CHECK(coverage BETWEEN 0 AND 100),
 CHECK((category_code != '') != (service_key != '')),
 UNIQUE(insurer_id, category_code, service_key));
CREATE TABLE IF NOT EXISTS nova_patient_insurance(
 patient_id INTEGER PRIMARY KEY REFERENCES hospital_patients(id),
 insurer_id INTEGER NOT NULL REFERENCES nova_insurers(id), member_no TEXT NOT NULL DEFAULT '',
 changed_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS nova_invoices(
 id INTEGER PRIMARY KEY, invoice_no TEXT NOT NULL UNIQUE,
 patient_id INTEGER NOT NULL REFERENCES hospital_patients(id),
 created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','settled','void')),
 insurer_id INTEGER REFERENCES nova_insurers(id), insurer_name TEXT NOT NULL DEFAULT '',
 member_no TEXT NOT NULL DEFAULT '', total INTEGER NOT NULL CHECK(total >= 0),
 insurer_due INTEGER NOT NULL CHECK(insurer_due >= 0),
 patient_due INTEGER NOT NULL CHECK(patient_due >= 0),
 note TEXT NOT NULL DEFAULT '', lab_order_id INTEGER UNIQUE REFERENCES hospital_orders(id),
 CHECK(total = insurer_due + patient_due));
CREATE TABLE IF NOT EXISTS nova_invoice_lines(
 id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES nova_invoices(id),
 source_kind TEXT NOT NULL CHECK(source_kind IN ('lab','service')),
 source_id INTEGER NOT NULL, category_code TEXT NOT NULL,
 code TEXT NOT NULL, name TEXT NOT NULL, price INTEGER NOT NULL CHECK(price >= 0),
 coverage INTEGER NOT NULL CHECK(coverage BETWEEN 0 AND 100),
 insurer_part INTEGER NOT NULL CHECK(insurer_part >= 0),
 patient_part INTEGER NOT NULL CHECK(patient_part >= 0),
 CHECK(price = insurer_part + patient_part));
CREATE INDEX IF NOT EXISTS nova_invoice_patient_idx ON nova_invoices(patient_id, created_at);
CREATE INDEX IF NOT EXISTS nova_invoice_status_idx ON nova_invoices(status, created_at);
CREATE TABLE IF NOT EXISTS nova_payments(
 id INTEGER PRIMARY KEY, payment_no TEXT NOT NULL UNIQUE,
 invoice_id INTEGER NOT NULL REFERENCES nova_invoices(id),
 idempotency_key TEXT NOT NULL UNIQUE, cash_amount INTEGER NOT NULL DEFAULT 0 CHECK(cash_amount >= 0),
 bank_amount INTEGER NOT NULL DEFAULT 0 CHECK(bank_amount >= 0),
 bank_id INTEGER REFERENCES nova_banks(id), bank_name TEXT NOT NULL DEFAULT '',
 bank_reference TEXT NOT NULL DEFAULT '', created_by INTEGER NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, CHECK(cash_amount + bank_amount > 0),
 CHECK(bank_amount > 0 OR bank_id IS NULL));
CREATE UNIQUE INDEX IF NOT EXISTS nova_unique_bank_ref ON nova_payments(bank_id,bank_reference)
 WHERE bank_id IS NOT NULL AND bank_reference <> '';
CREATE TABLE IF NOT EXISTS nova_claims(
 invoice_id INTEGER PRIMARY KEY REFERENCES nova_invoices(id),
 insurer_id INTEGER NOT NULL REFERENCES nova_insurers(id),
 amount INTEGER NOT NULL CHECK(amount >= 0), received INTEGER NOT NULL DEFAULT 0
 CHECK(received >= 0), status TEXT NOT NULL DEFAULT 'unverified'
 CHECK(status IN ('unverified','submitted','part_paid','paid','rejected')),
 CHECK(received <= amount));
CREATE TABLE IF NOT EXISTS nova_refunds(
 id INTEGER PRIMARY KEY, refund_no TEXT NOT NULL UNIQUE,
 invoice_id INTEGER NOT NULL UNIQUE REFERENCES nova_invoices(id),
 idempotency_key TEXT NOT NULL UNIQUE,
 cash_amount INTEGER NOT NULL DEFAULT 0 CHECK(cash_amount >= 0),
 bank_amount INTEGER NOT NULL DEFAULT 0 CHECK(bank_amount >= 0),
 bank_id INTEGER REFERENCES nova_banks(id), bank_name TEXT NOT NULL DEFAULT '',
 bank_reference TEXT NOT NULL DEFAULT '',
 note TEXT NOT NULL DEFAULT '',
 created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 shift_id INTEGER REFERENCES nova_cashier_shifts(id),
 CHECK(cash_amount + bank_amount > 0),
 CHECK(bank_amount > 0 OR bank_id IS NULL));
CREATE UNIQUE INDEX IF NOT EXISTS nova_unique_refund_bank_ref ON nova_refunds(bank_id,bank_reference)
 WHERE bank_id IS NOT NULL AND bank_reference!='';
CREATE TABLE IF NOT EXISTS nova_claim_receipts(
 id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES nova_claims(invoice_id),
 amount INTEGER NOT NULL CHECK(amount > 0), reference TEXT NOT NULL DEFAULT '',
 created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS nova_cashier_shifts(
 id INTEGER PRIMARY KEY, cashier_id INTEGER NOT NULL REFERENCES users(id),
 opened_at TEXT NOT NULL, closed_at TEXT, opening_cash INTEGER NOT NULL DEFAULT 0,
 counted_cash INTEGER, note TEXT NOT NULL DEFAULT '',
 CHECK(opening_cash >= 0), CHECK(counted_cash IS NULL OR counted_cash >= 0));
CREATE UNIQUE INDEX IF NOT EXISTS nova_one_open_shift ON nova_cashier_shifts(cashier_id) WHERE closed_at IS NULL;
'''
# Default catalog is a discoverable, editable starter — no fabricated prices.
CATEGORIES = [
 ('consult','الكشف والعيادات',1),('lab','المعمل',2),('radiology','الأشعة والتصوير',3),
 ('nursing','التمريض والإجراءات',4),('emergency','الطوارئ',5),('cardiac','القلب والفحوصات',6),
 ('inpatient','الإقامة والتنويم',7),('maternity','النساء والتوليد',8),('physio','العلاج الطبيعي',9),
 ('dental','الأسنان',10),('other','خدمات أخرى',11)]
SERVICES = [
 ('consult','CONS-GP','كشف طبيب عمومي','كشف عام عيادة طبيب',1),
 ('consult','CONS-IM','كشف أخصائي باطنية','باطنية internal medicine',1),
 ('consult','CONS-PED','كشف أطفال','أطفال pediatric',1),
 ('consult','CONS-OB','كشف نساء وتوليد','نساء ولادة',0),
 ('consult','CONS-SUR','كشف جراحة','جراحة',0),
 ('consult','CONS-ORTH','كشف عظام','عظام',0),
 ('consult','CONS-ENT','كشف أنف وأذن وحنجرة','ENT',0),
 ('consult','CONS-OPH','كشف عيون','عيون',0),
 ('consult','CONS-DERM','كشف جلدية','جلدية',0),
 ('consult','CONS-FOLLOW','مراجعة الطبيب','مراجعة followup',1),
 ('radiology','XRAY','أشعة عادية','X-ray xray اشعة',1),
 ('radiology','US','موجات صوتية','سونار ultrasound',1),
 ('radiology','DOPPLER','دوبلر','doppler',0),
 ('radiology','CT','أشعة مقطعية','CT scan',0),
 ('nursing','IM-INJ','حقنة عضل','IM injection',1),
 ('nursing','IV-INJ','حقنة وريد','IV injection',1),
 ('nursing','IV-CANNULA','تركيب كانيولا','cannula',0),
 ('nursing','IV-DRIP','تركيب درب','drip',0),
 ('nursing','DRESSING','غيار جرح','dressing',0),
 ('nursing','SUTURE-REM','فك غرز','suture removal',0),
 ('nursing','NEB','جلسة تبخير','nebulizer',0),
 ('nursing','OXYGEN','جلسة أكسجين','oxygen',0),
 ('emergency','ER-CONS','كشف طوارئ','emergency',1),
 ('emergency','WOUND-SUT','خياطة جرح','suture',0),
 ('emergency','ER-OBS','ملاحظة طوارئ','observation',0),
 ('cardiac','ECG','تخطيط قلب','ECG EKG',1),
 ('cardiac','ECHO','إيكو القلب','echo',0),
 ('cardiac','PFT','وظائف التنفس','spirometry',0),
 ('inpatient','BED-OBS','سرير ملاحظة','observation bed',0),
 ('inpatient','ROOM-DAY','إقامة غرفة عادية / يوم','ward',0),
 ('inpatient','PRIVATE-DAY','إقامة غرفة خاصة / يوم','private room',0),
 ('maternity','ANC','متابعة حمل','antenatal',0),
 ('maternity','NVD','خدمات الولادة الطبيعية','delivery',0),
 ('maternity','CS','خدمات الولادة القيصرية','cesarean',0),
 ('physio','PHYSIO','جلسة علاج طبيعي','physiotherapy',0),
 ('dental','DENT-CONS','كشف أسنان','dental',0),
 ('other','MED-REPORT','تقرير طبي','medical report',0),
 ('other','MED-CERT','شهادة طبية','medical certificate',0),
]

def now(): return datetime.now().isoformat(timespec='seconds')
def text(data,key,max_len=180,required=False):
    val=str(data.get(key,'') or '').strip()
    if len(val)>max_len or (required and not val): raise ValueError('بيانات غير صحيحة: '+key)
    return val

def num(value,label,lo=0,hi=999999999999):
    if isinstance(value,bool):raise ValueError('رقم غير صالح: '+label)
    s=str(value).strip()
    if not s.isascii() or not s.isdigit():raise ValueError('رقم غير صالح: '+label)
    v=int(s)
    if not lo<=v<=hi:raise ValueError('رقم خارج المدى: '+label)
    return v

def uid():return date.today().strftime('%y%m%d')+'-'+secrets.token_hex(5).upper()
def start(c):c.execute('BEGIN IMMEDIATE')
def done(c):c.execute('COMMIT')
def rollback(c):c.execute('ROLLBACK')
def audit(c, actor, action, object_id, info=None):
    c.execute('INSERT INTO hospital_audit(user_id,created_at,action,object_id,details) VALUES (?,?,?,?,?)',
              (actor['id'], now(), action, object_id, json.dumps(info or {},ensure_ascii=False)))
def init(c):
    c.executescript(SCHEMA)
    for code,name,seq in CATEGORIES:
        c.execute('INSERT OR IGNORE INTO nova_service_categories(code,name,sort_order) VALUES (?,?,?)',(code,name,seq))
    for cat,code,name,alias,popular in SERVICES:
        c.execute('''INSERT OR IGNORE INTO nova_services(category_id,code,name,aliases,popular)
            SELECT id,?,?,?,? FROM nova_service_categories WHERE code=?''',(code,name,alias,popular,cat))
    columns={r['name'] for r in pharmacy.query(c,'PRAGMA table_info(nova_payments)')}
    if 'shift_id' not in columns:c.execute('ALTER TABLE nova_payments ADD COLUMN shift_id INTEGER REFERENCES nova_cashier_shifts(id)')
    c.commit()

def categories(c):return pharmacy.query(c,'SELECT * FROM nova_service_categories WHERE active=1 ORDER BY sort_order,id')
def catalog(c,term='',category='',include_inactive=False):
    q=term.strip().lower()[:80];out=[]
    usage={(x['source_kind'],x['source_id']):x['n'] for x in pharmacy.query(c,'''
       SELECT il.source_kind,il.source_id,COUNT(*) AS n FROM nova_invoice_lines il
       JOIN nova_invoices inv ON inv.id=il.invoice_id WHERE inv.status!='void'
       GROUP BY il.source_kind,il.source_id''')} 
    for r in pharmacy.query(c,'''SELECT s.*,cat.code AS category_code,cat.name AS category_name
        FROM nova_services s JOIN nova_service_categories cat ON s.category_id=cat.id
        WHERE (? OR (s.active=1 AND cat.active=1)) ORDER BY cat.sort_order,s.popular DESC,s.name''',(1 if include_inactive else 0,)):
        d=dict(r);d.update(key='svc:'+str(r['id']),kind='service',usage_count=usage.get(('service',r['id']),0))
        if (not category or category==r['category_code']) and (not q or q in (r['name']+' '+r['aliases']+' '+r['code']).lower()):out.append(d)
    if not category or category=='lab':
        for r in pharmacy.query(c,'''SELECT id,code,name,price,active,aliases,popular
                FROM hospital_lab_tests ORDER BY popular DESC,id'''):
            if not include_inactive and not r['active']:continue
            d=dict(r);d.update(key='lab:'+str(r['id']),kind='lab',category_code='lab',category_name='المعمل',usage_count=usage.get(('lab',r['id']),0))
            if not q or q in (r['name']+' '+r['code']+' '+r['aliases']).lower():out.append(d)
    return out[:400]

def upsert_service(c,actor,data):
    name=text(data,'name',150,True);code=text(data,'code',50,True).upper();category=text(data,'category_code',35,True)
    price=num(data.get('price',0),'السعر');aliases=text(data,'aliases',400)
    popular=1 if data.get('popular') is True else 0;active=1 if data.get('active',True) is True else 0
    start(c)
    try:
        cat=pharmacy.one(c,'SELECT id FROM nova_service_categories WHERE code=?',(category,))
        if not cat or category=='lab':raise ValueError('القسم غير صالح؛ أسعار التحاليل تُعدل من إعدادات المعمل')
        if data.get('id'):
            sid=num(data['id'],'الخدمة',1)
            if not c.execute('UPDATE nova_services SET code=?,name=?,aliases=?,price=?,popular=?,active=?,category_id=? WHERE id=?',
                    (code,name,aliases,price,popular,active,cat['id'],sid)).rowcount:raise ValueError('الخدمة غير موجودة')
            action='service_updated'
        else:
            sid=c.execute('INSERT INTO nova_services(category_id,code,name,aliases,price,popular,active) VALUES(?,?,?,?,?,?,?)',
                (cat['id'],code,name,aliases,price,popular,active)).lastrowid
            action='service_created'
        audit(c,actor,action,sid,{'code':code,'price':price});done(c)
    except Exception:rollback(c);raise
    return {'id':sid,'code':code}

def banks(c,all_rows=False):
    return pharmacy.query(c,'SELECT * FROM nova_banks '+('' if all_rows else 'WHERE active=1 ')+'ORDER BY name')
def insurers(c,all_rows=False):
    return pharmacy.query(c,'SELECT * FROM nova_insurers '+('' if all_rows else 'WHERE active=1 ')+'ORDER BY name')
def insurer_rates(c,insurer_id=None):
    return pharmacy.query(c,'SELECT * FROM nova_insurer_rates '+('WHERE insurer_id=?' if insurer_id else '')+' ORDER BY insurer_id,category_code,service_key', (insurer_id,) if insurer_id else ())

def upsert_bank(c,actor,data):
    name=text(data,'name',120,True);label=text(data,'account_label',100);require=1 if data.get('require_reference') is True else 0
    active=1 if data.get('active',True) is True else 0;bid=num(data['id'],'البنك',1) if data.get('id') else None
    start(c)
    try:
        if bid:
            if not c.execute('UPDATE nova_banks SET name=?,account_label=?,require_reference=?,active=? WHERE id=?',
                   (name,label,require,active,bid)).rowcount:raise ValueError('البنك غير موجود')
        else:bid=c.execute('INSERT INTO nova_banks(name,account_label,require_reference,active) VALUES(?,?,?,?)',
                         (name,label,require,active)).lastrowid
        audit(c,actor,'bank_saved',bid);done(c)
    except Exception:rollback(c);raise
    return {'id':bid}

def upsert_insurer(c,actor,data):
    name=text(data,'name',130,True);coverage=num(data.get('default_coverage',0),'نسبة التغطية',0,100)
    active=1 if data.get('active',True) is True else 0;iid=num(data['id'],'شركة التأمين',1) if data.get('id') else None
    start(c)
    try:
        if iid:
            if not c.execute('UPDATE nova_insurers SET name=?,default_coverage=?,active=? WHERE id=?',(name,coverage,active,iid)).rowcount:
                raise ValueError('الشركة غير موجودة')
        else:iid=c.execute('INSERT INTO nova_insurers(name,default_coverage,active) VALUES(?,?,?)',
                           (name,coverage,active)).lastrowid
        audit(c,actor,'insurer_saved',iid);done(c)
    except Exception:rollback(c);raise
    return {'id':iid}

def set_rate(c,actor,data):
    iid=num(data.get('insurer_id'),'شركة التأمين',1);category=text(data,'category_code',35)
    service=text(data,'service_key',35)
    if bool(category)==bool(service):raise ValueError('اختر القسم أو الخدمة لاستثناء التغطية')
    coverage=num(data.get('coverage'),'التغطية',0,100)
    start(c)
    try:
        if not pharmacy.one(c,'SELECT id FROM nova_insurers WHERE id=?',(iid,)):
            raise ValueError('شركة التأمين غير موجودة')
        if category and not pharmacy.one(c,'SELECT id FROM nova_service_categories WHERE code=?',(category,)):
            raise ValueError('القسم غير موجود')
        if service and not any(s['key']==service for s in catalog(c,include_inactive=True)):
            raise ValueError('الخدمة غير موجودة')
        c.execute('''INSERT INTO nova_insurer_rates(insurer_id,category_code,service_key,coverage)
                    VALUES(?,?,?,?) ON CONFLICT(insurer_id,category_code,service_key)
                    DO UPDATE SET coverage=excluded.coverage''',(iid,category,service,coverage))
        audit(c,actor,'insurance_rate_saved',iid,{'category':category,'service':service,'coverage':coverage});done(c)
    except Exception:rollback(c);raise
    return {'insurer_id':iid,'coverage':coverage}

def get_patient_insurance(c,pid):
    return pharmacy.one(c,'''SELECT pi.*,i.name AS insurer_name,i.default_coverage,i.active
        FROM nova_patient_insurance pi JOIN nova_insurers i ON i.id=pi.insurer_id WHERE pi.patient_id=?''',(pid,))
def set_patient_insurance(c,actor,data):
    pid=num(data.get('patient_id'),'المريض',1);iid=num(data.get('insurer_id'),'شركة التأمين',0)
    member=text(data,'member_no',100)
    start(c)
    try:
        if not pharmacy.one(c,'SELECT id FROM hospital_patients WHERE id=?',(pid,)):
            raise ValueError('المريض غير موجود')
        if iid:
            if not pharmacy.one(c,'SELECT id FROM nova_insurers WHERE id=? AND active=1',(iid,)):
                raise ValueError('شركة التأمين غير مفعلة')
            c.execute('''INSERT INTO nova_patient_insurance(patient_id,insurer_id,member_no,changed_at)
                VALUES(?,?,?,?) ON CONFLICT(patient_id) DO UPDATE SET insurer_id=excluded.insurer_id,
                member_no=excluded.member_no,changed_at=excluded.changed_at''',(pid,iid,member,now()))
        else:c.execute('DELETE FROM nova_patient_insurance WHERE patient_id=?',(pid,))
        audit(c,actor,'patient_insurance_saved',pid,{'insurer_id':iid});done(c)
    except Exception:rollback(c);raise
    return {'patient_id':pid,'insurer_id':iid}

def _coverage(c,iid,cat,key,default):
    if not iid:return 0
    row=pharmacy.one(c,'''SELECT coverage FROM nova_insurer_rates WHERE insurer_id=? AND service_key=?''',(iid,key))
    if row:return row['coverage']
    row=pharmacy.one(c,'''SELECT coverage FROM nova_insurer_rates WHERE insurer_id=? AND category_code=?''',(iid,cat))
    return row['coverage'] if row else default

def _lines(c,keys,insurer_id):
    if not isinstance(keys,list) or not 1<=len(keys)<=50:raise ValueError('اختر من 1 إلى 50 خدمة')
    if not all(isinstance(x,str) for x in keys) or len(set(keys))!=len(keys):raise ValueError('خدمة مكررة أو غير صحيحة')
    allsvc={s['key']:s for s in catalog(c)}
    insurer=pharmacy.one(c,'SELECT * FROM nova_insurers WHERE id=? AND active=1',(insurer_id,)) if insurer_id else None
    if insurer_id and not insurer:raise ValueError('شركة التأمين غير مفعلة')
    out=[]
    for key in keys:
        s=allsvc.get(key)
        if not s:raise ValueError('خدمة غير متاحة: '+key[:40])
        price=s['price'];cov=_coverage(c,insurer_id,s['category_code'],key,insurer['default_coverage'] if insurer else 0)
        covered=price*cov//100
        out.append({'source_kind':s['kind'],'source_id':s['id'],'category_code':s['category_code'],
                    'code':s['code'],'name':s['name'],'price':price,'coverage':cov,
                    'insurer_part':covered,'patient_part':price-covered})
    return out,insurer

def quote(c,data):
    pid=num(data.get('patient_id'),'المريض',1)
    if not pharmacy.one(c,'SELECT id FROM hospital_patients WHERE id=?',(pid,)):
        raise ValueError('المريض غير موجود')
    if 'insurer_id' in data:iid=num(data.get('insurer_id') or 0,'شركة التأمين',0)
    else:
        found=get_patient_insurance(c,pid)
        iid=found['insurer_id'] if found and found['active'] else 0
    lines,insurer=_lines(c,data.get('services'),iid)
    return {'lines':lines,'insurer_id':iid,'insurer_name':insurer['name'] if insurer else '',
            'total':sum(x['price'] for x in lines),
            'insurer_due':sum(x['insurer_part'] for x in lines),
            'patient_due':sum(x['patient_part'] for x in lines),
            'insurance_note':'حساب تغطية تعاقدية، وليس تأكيداً من شركة التأمين'}

def _lab_order(c,actor,pid,lines,note):
    lablines=[x for x in lines if x['source_kind']=='lab']
    if not lablines:return None
    key='L-'+uid()
    oid=c.execute('INSERT INTO hospital_orders(order_no,patient_id,created_at,created_by,total,note) VALUES(?,?,?,?,?,?)',
                  (key,pid,now(),actor['id'],sum(x['price'] for x in lablines),note)).lastrowid
    for x in lablines:
        t=pharmacy.one(c,'SELECT * FROM hospital_lab_tests WHERE id=?',(x['source_id'],))
        item=c.execute('''INSERT INTO hospital_order_items(order_id,test_id,test_name,unit,reference_range,price)
             VALUES(?,?,?,?,?,?)''',(oid,t['id'],t['name'],t['unit'],t['reference_range'],x['price'])).lastrowid
        lab.snapshot_item(c,item,pid)
    return oid

def create_invoice(c,actor,data):
    pid=num(data.get('patient_id'),'المريض',1);note=text(data,'note',500)
    start(c)
    try:
        quoted=quote(c,data);iid=quoted['insurer_id']
        patient_ins=get_patient_insurance(c,pid)
        member=text(data,'member_no',100) if 'member_no' in data else (patient_ins['member_no'] if patient_ins and patient_ins['insurer_id']==iid else '')
        lab_order_id=_lab_order(c,actor,pid,quoted['lines'],note)
        invoice_no='N-'+uid()
        cur=c.execute('''INSERT INTO nova_invoices(invoice_no,patient_id,created_by,created_at,insurer_id,insurer_name,
                member_no,total,insurer_due,patient_due,note,lab_order_id)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                (invoice_no,pid,actor['id'],now(),iid or None,quoted['insurer_name'],member,
                 quoted['total'],quoted['insurer_due'],quoted['patient_due'],note,lab_order_id))
        invoice_id=cur.lastrowid
        for x in quoted['lines']:
            c.execute('''INSERT INTO nova_invoice_lines(invoice_id,source_kind,source_id,category_code,code,name,price,
              coverage,insurer_part,patient_part) VALUES(?,?,?,?,?,?,?,?,?,?)''',
              (invoice_id,x['source_kind'],x['source_id'],x['category_code'],x['code'],x['name'],x['price'],
               x['coverage'],x['insurer_part'],x['patient_part']))
        if iid and quoted['insurer_due']:
            c.execute('INSERT INTO nova_claims(invoice_id,insurer_id,amount) VALUES(?,?,?)',
                      (invoice_id,iid,quoted['insurer_due']))
        audit(c,actor,'invoice_created',invoice_id,{'total':quoted['total'],'insurer':iid});done(c)
    except Exception:rollback(c);raise
    return {'id':invoice_id,'invoice_no':invoice_no,**quoted,'lab_order_id':lab_order_id,'status':'pending'}

def list_invoices(c,status='',limit=150):
    if status and status not in ('pending','settled','void'):raise ValueError('الحالة غير صحيحة')
    where='WHERE i.status=?' if status else ''
    result=pharmacy.query(c,f'''SELECT i.*,p.full_name AS patient_name,p.patient_no,
         COALESCE((SELECT SUM(cash_amount+bank_amount) FROM nova_payments WHERE invoice_id=i.id),0) AS paid,
         COALESCE((SELECT SUM(cash_amount+bank_amount) FROM nova_refunds WHERE invoice_id=i.id),0) AS refunded,
         (SELECT COUNT(*) FROM nova_invoice_lines WHERE invoice_id=i.id) AS lines_count
       FROM nova_invoices i JOIN hospital_patients p ON p.id=i.patient_id
       {where} ORDER BY i.id DESC LIMIT ?''',((status,) if status else ())+ (limit,))
    return [dict(x,net_paid=x['paid']-x['refunded'],remaining=0 if x['status']=='void' else max(0,x['patient_due']-x['paid'])) for x in result]

def invoice_detail(c,iid):
    inv=pharmacy.one(c,'''SELECT i.*,p.full_name AS patient_name,p.patient_no FROM nova_invoices i
        JOIN hospital_patients p ON p.id=i.patient_id WHERE i.id=?''',(iid,))
    if not inv:raise ValueError('الفاتورة غير موجودة')
    out=dict(inv)
    out['lines']=pharmacy.query(c,'SELECT * FROM nova_invoice_lines WHERE invoice_id=? ORDER BY id',(iid,))
    out['payments']=pharmacy.query(c,'''SELECT payment_no,cash_amount,bank_amount,bank_name,bank_reference,created_at
                      FROM nova_payments WHERE invoice_id=? ORDER BY id''',(iid,))
    out['paid']=sum(x['cash_amount']+x['bank_amount'] for x in out['payments'])
    out['refunds']=pharmacy.query(c,'''SELECT refund_no,cash_amount,bank_amount,bank_name,
                          bank_reference,note,created_at FROM nova_refunds WHERE invoice_id=? ORDER BY id''',(iid,))
    out['refunded']=sum(x['cash_amount']+x['bank_amount'] for x in out['refunds'])
    out['net_paid']=out['paid']-out['refunded']
    out['remaining']=0 if inv['status']=='void' else max(0,inv['patient_due']-out['paid'])
    out['claim']=pharmacy.one(c,'SELECT * FROM nova_claims WHERE invoice_id=?',(iid,))
    return out

def _settle(c,invoice):
    if invoice['lab_order_id']:
        c.execute("UPDATE hospital_orders SET status='paid' WHERE id=? AND status='pending'",(invoice['lab_order_id'],))
    c.execute("UPDATE nova_invoices SET status='settled' WHERE id=? AND status='pending'",(invoice['id'],))

def add_payment(c,actor,data):
    iid=num(data.get('invoice_id'),'الفاتورة',1)
    key=text(data,'idempotency_key',128,True)
    if len(key)<12:raise ValueError('مفتاح العملية غير صالح')
    cash=num(data.get('cash_amount',0),'النقدي');bank=num(data.get('bank_amount',0),'البنكي')
    bank_id=num(data.get('bank_id',0) or 0,'البنك',0)
    ref=text(data,'bank_reference',120)
    if cash+bank==0:raise ValueError('المبلغ صفر؛ استخدم تسوية التأمين الكامل عند الحاجة')
    start(c)
    try:
        old=pharmacy.one(c,'SELECT * FROM nova_payments WHERE idempotency_key=?',(key,))
        if old:
            if old['invoice_id']!=iid or old['cash_amount']!=cash or old['bank_amount']!=bank or (old['bank_id'] or 0)!=bank_id or old['bank_reference']!=ref:
                raise ValueError('مفتاح العملية مستخدم ببيانات مختلفة')
            done(c);return {'payment_no':old['payment_no'],'already_recorded':True}
        inv=pharmacy.one(c,'SELECT * FROM nova_invoices WHERE id=?',(iid,))
        if not inv or inv['status']!='pending':raise ValueError('الفاتورة غير متاحة للتحصيل')
        prev=pharmacy.one(c,'SELECT COALESCE(SUM(cash_amount+bank_amount),0) AS n FROM nova_payments WHERE invoice_id=?',(iid,))['n']
        if cash+bank>inv['patient_due']-prev:raise ValueError('المبلغ أكبر من المتبقي على المريض')
        if bank>0:
            if not bank_id:raise ValueError('اختر البنك المستلم')
            b=pharmacy.one(c,'SELECT * FROM nova_banks WHERE id=? AND active=1',(bank_id,))
            if not b:raise ValueError('البنك غير متاح')
            if b['require_reference'] and not ref:raise ValueError('رقم العملية مطلوب لهذا البنك')
        else:
            if bank_id or ref:raise ValueError('بيانات البنك لا تستخدم مع الدفع النقدي')
            b=None
        payno='PM-'+uid()
        shift=pharmacy.one(c,'SELECT id FROM nova_cashier_shifts WHERE cashier_id=? AND closed_at IS NULL',(actor['id'],))
        c.execute('''INSERT INTO nova_payments(payment_no,invoice_id,idempotency_key,cash_amount,bank_amount,bank_id,
            bank_name,bank_reference,created_by,created_at,shift_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
            (payno,iid,key,cash,bank,bank_id or None,b['name'] if b else '',ref,actor['id'],now(),shift['id'] if shift else None))
        if cash+bank+prev==inv['patient_due']:_settle(c,inv)
        audit(c,actor,'patient_payment_received',iid,{'cash':cash,'bank':bank,'bank_id':bank_id,'reference':ref})
        done(c)
    except Exception:rollback(c);raise
    return {'payment_no':payno,'already_recorded':False,'paid':cash+bank,'remaining':inv['patient_due']-prev-cash-bank,
            'status':'settled' if inv['patient_due']==prev+cash+bank else 'pending'}

def confirm_insured(c,actor,data):
    """Manual cashier authorization for zero-copay insurance; no bank/provider API validation."""
    iid=num(data.get('invoice_id'),'الفاتورة',1)
    start(c)
    try:
        inv=pharmacy.one(c,'SELECT * FROM nova_invoices WHERE id=?',(iid,))
        if not inv or inv['status']!='pending' or (not inv['insurer_id'] and inv['total']!=0) or inv['patient_due']!=0:
            raise ValueError('الفاتورة ليست تغطية تأمين كاملة')
        _settle(c,inv);audit(c,actor,'full_insurance_manual_release',iid);done(c)
    except Exception:rollback(c);raise
    return {'status':'settled','insurance_verified':False}

def reprice_insurance(c,actor,data):
    """Change coverage without altering the service prices snapshotted on invoice creation."""
    iid=num(data.get('invoice_id'),'الفاتورة',1);insurer_id=num(data.get('insurer_id') or 0,'شركة التأمين',0)
    start(c)
    try:
        inv=pharmacy.one(c,'SELECT * FROM nova_invoices WHERE id=?',(iid,))
        if not inv or inv['status']!='pending':raise ValueError('الفاتورة لا تسمح بالتغيير')
        if pharmacy.one(c,'SELECT id FROM nova_payments WHERE invoice_id=?',(iid,)):
            raise ValueError('لا يمكن تغيير التأمين بعد بدء التحصيل')
        insurer=pharmacy.one(c,'SELECT * FROM nova_insurers WHERE id=? AND active=1',(insurer_id,)) if insurer_id else None
        if insurer_id and not insurer:raise ValueError('شركة التأمين غير مفعلة')
        lines=pharmacy.query(c,'SELECT * FROM nova_invoice_lines WHERE invoice_id=?',(iid,))
        insurer_due=0
        for line in lines:
            key=('lab:' if line['source_kind']=='lab' else 'svc:')+str(line['source_id'])
            coverage=_coverage(c,insurer_id,line['category_code'],key,insurer['default_coverage'] if insurer else 0)
            insurer_part=line['price']*coverage//100
            c.execute('UPDATE nova_invoice_lines SET coverage=?,insurer_part=?,patient_part=? WHERE id=?',
                      (coverage,insurer_part,line['price']-insurer_part,line['id']))
            insurer_due+=insurer_part
        member=text(data,'member_no',100) if 'member_no' in data else ''
        if 'member_no' not in data and insurer_id:
            linked=get_patient_insurance(c,inv['patient_id'])
            if linked and linked['insurer_id']==insurer_id:member=linked['member_no']
        c.execute('UPDATE nova_invoices SET insurer_id=?,insurer_name=?,member_no=?,insurer_due=?,patient_due=? WHERE id=?',
                  (insurer_id or None,insurer['name'] if insurer else '',member,insurer_due,inv['total']-insurer_due,iid))
        c.execute('DELETE FROM nova_claims WHERE invoice_id=?',(iid,))
        if insurer_id and insurer_due:
            c.execute('INSERT INTO nova_claims(invoice_id,insurer_id,amount) VALUES(?,?,?)',(iid,insurer_id,insurer_due))
        audit(c,actor,'invoice_insurance_changed',iid,{'insurer':insurer_id});done(c)
    except Exception:rollback(c);raise
    return invoice_detail(c,iid)

def claim_payment(c,actor,data):
    iid=num(data.get('invoice_id'),'الفاتورة',1)
    amount=num(data.get('amount'),'مبلغ سداد الشركة',1);ref=text(data,'reference',120)
    start(c)
    try:
        cl=pharmacy.one(c,'SELECT * FROM nova_claims WHERE invoice_id=?',(iid,))
        if not cl or cl['received']+amount>cl['amount']:raise ValueError('المبلغ أكبر من مطالبة التأمين المتبقية')
        c.execute('''INSERT INTO nova_claim_receipts(invoice_id,amount,reference,created_by,created_at)
                   VALUES(?,?,?,?,?)''',(iid,amount,ref,actor['id'],now()))
        status='paid' if cl['received']+amount==cl['amount'] else 'part_paid'
        c.execute('UPDATE nova_claims SET received=received+?,status=? WHERE invoice_id=?',(amount,status,iid))
        audit(c,actor,'insurance_collection',iid,{'amount':amount,'reference':ref});done(c)
    except Exception:rollback(c);raise
    return {'invoice_id':iid,'amount':amount,'status':status}

def claims(c):
    return pharmacy.query(c,'''SELECT cl.*,inv.invoice_no,inv.insurer_name,p.full_name AS patient_name,
            inv.created_at FROM nova_claims cl JOIN nova_invoices inv ON inv.id=cl.invoice_id
            JOIN hospital_patients p ON p.id=inv.patient_id ORDER BY cl.invoice_id DESC LIMIT 300''')

def receipts_summary(c):
    a=pharmacy.one(c,'''SELECT COALESCE(SUM(cash_amount),0) cash,
        COALESCE(SUM(bank_amount),0) bank,COUNT(*) payments FROM nova_payments''')
    b=pharmacy.one(c,'SELECT COALESCE(SUM(amount-received),0) due FROM nova_claims')
    r=pharmacy.one(c,'''SELECT COALESCE(SUM(cash_amount),0) cash,
         COALESCE(SUM(bank_amount),0) bank,COUNT(*) refunds FROM nova_refunds''')
    return {'cash':a['cash'],'bank':a['bank'],'payments':a['payments'],
            'cash_refunded':r['cash'],'bank_refunded':r['bank'],'refunds':r['refunds'],
            'net_cash':a['cash']-r['cash'],'net_bank':a['bank']-r['bank'],
            'insurance_receivable':b['due']}

def start_shift(c,actor,data):
    opening=num(data.get('opening_cash',0),'رصيد البداية');start(c)
    try:
        s=c.execute('INSERT INTO nova_cashier_shifts(cashier_id,opened_at,opening_cash) VALUES(?,?,?)',
                    (actor['id'],now(),opening)).lastrowid
        audit(c,actor,'cashier_shift_open',s);done(c)
    except Exception:rollback(c);raise
    return {'shift_id':s,'opening_cash':opening}

def shifts(c,actor,admin=False):
    rows=pharmacy.query(c,'''SELECT s.*, u.full_name AS cashier_name,
      (SELECT COALESCE(SUM(pay.cash_amount),0) FROM nova_payments pay WHERE pay.shift_id=s.id) AS cash_in,
      (SELECT COALESCE(SUM(pay.bank_amount),0) FROM nova_payments pay WHERE pay.shift_id=s.id) AS bank_in,
      (SELECT COALESCE(SUM(r.cash_amount),0) FROM nova_refunds r WHERE r.shift_id=s.id) AS cash_refunded,
      (SELECT COALESCE(SUM(r.bank_amount),0) FROM nova_refunds r WHERE r.shift_id=s.id) AS bank_refunded
       FROM nova_cashier_shifts s JOIN users u ON u.id=s.cashier_id
       WHERE (?=1 OR s.cashier_id=?) ORDER BY s.id DESC LIMIT 100''',(1 if admin else 0,actor['id']))
    return [dict(x,expected_cash=x['opening_cash']+x['cash_in']-x['cash_refunded'],
                  difference=(x['counted_cash']-x['opening_cash']-x['cash_in']+x['cash_refunded'])
                    if x['counted_cash'] is not None else None) for x in rows]

def close_shift(c,actor,data,admin=False):
    sid=num(data.get('shift_id'),'الوردية',1);counted=num(data.get('counted_cash'),'النقد المحسوب');note=text(data,'note',500)
    start(c)
    try:
        r=pharmacy.one(c,'SELECT * FROM nova_cashier_shifts WHERE id=? AND closed_at IS NULL',(sid,))
        if not r or (r['cashier_id']!=actor['id'] and not admin):raise ValueError('الوردية غير متاحة للإقفال')
        c.execute('UPDATE nova_cashier_shifts SET closed_at=?,counted_cash=?,note=? WHERE id=?',
                  (now(),counted,note,sid))
        audit(c,actor,'cashier_shift_close',sid,{'counted':counted});done(c)
    except Exception:rollback(c);raise
    return {'shift_id':sid,'closed':True}

def _assert_lab_not_started(c, order_id):
    """Prevent silently canceling medical work; an administrator must resolve delivered services separately."""
    if not order_id:return
    order=pharmacy.one(c,'SELECT status FROM hospital_orders WHERE id=?',(order_id,))
    if not order or order['status'] not in ('pending','paid'):
        raise ValueError('طلب المعمل ليس قابلاً للإلغاء')
    worked=pharmacy.one(c,'''SELECT 1 FROM hospital_order_items i
                 WHERE i.order_id=? AND (i.result_status!='pending' OR i.result_text!=''
                 OR EXISTS(SELECT 1 FROM hospital_lab_revisions r WHERE r.item_id=i.id)
                 OR EXISTS(SELECT 1 FROM hospital_lab_lines l WHERE l.item_id=i.id AND l.value!=''))
                 LIMIT 1''',(order_id,))
    sample=pharmacy.one(c,'SELECT 1 FROM hospital_lab_samples WHERE order_id=? LIMIT 1',(order_id,))
    if worked or sample:
        raise ValueError('المعمل بدأ العمل على الطلب؛ يلزم إجراء مالي/طبي خاص ولا يمكن إلغاؤه تلقائياً')

def refund_invoice(c,actor,data):
    '''Full reversal of collected patient money, admin-only by API.

    The original payments are immutable. A separate refund ledger preserves what
    came in and what went back. Partial / per-service credit notes are not
    silently treated as full cancellation of a clinical order.
    '''
    iid=num(data.get('invoice_id'),'الفاتورة',1)
    key=text(data,'idempotency_key',128,True)
    if len(key)<12:raise ValueError('مفتاح العملية غير صالح')
    cash=num(data.get('cash_amount',0),'النقدي المسترجع')
    bank=num(data.get('bank_amount',0),'البنكي المسترجع')
    bank_id=num(data.get('bank_id',0) or 0,'البنك',0)
    ref=text(data,'bank_reference',120)
    note=text(data,'note',500)
    if cash+bank==0:raise ValueError('لا يوجد مبلغ للاسترجاع')
    start(c)
    try:
        old=pharmacy.one(c,'SELECT * FROM nova_refunds WHERE idempotency_key=?',(key,))
        if old:
            if (old['invoice_id']!=iid or old['cash_amount']!=cash or old['bank_amount']!=bank
                or (old['bank_id'] or 0)!=bank_id or old['bank_reference']!=ref or old['note']!=note):
                raise ValueError('مفتاح الاسترجاع مستخدم ببيانات مختلفة')
            done(c)
            return {'refund_no':old['refund_no'],'invoice_id':iid,'already_recorded':True,
                    'cash_amount':old['cash_amount'],'bank_amount':old['bank_amount'],'status':'void'}
        inv=pharmacy.one(c,'SELECT * FROM nova_invoices WHERE id=?',(iid,))
        if not inv or inv['status'] not in ('pending','settled'):
            raise ValueError('الفاتورة غير متاحة للاسترجاع')
        if pharmacy.one(c,'SELECT id FROM nova_refunds WHERE invoice_id=?',(iid,)):
            raise ValueError('الفاتورة تم استرجاعها من قبل')
        paid=pharmacy.one(c,'''SELECT COALESCE(SUM(cash_amount+bank_amount),0) AS amount
                        FROM nova_payments WHERE invoice_id=?''',(iid,))['amount']
        if paid<=0 or paid!=cash+bank:
            raise ValueError('الاسترجاع الكامل يتطلب رد جميع المبالغ المحصلة على الفاتورة')
        if bank:
            if not bank_id:raise ValueError('اختر بنك إرجاع التحويل')
            b=pharmacy.one(c,'SELECT * FROM nova_banks WHERE id=? AND active=1',(bank_id,))
            if not b:raise ValueError('البنك غير متاح')
            if b['require_reference'] and not ref:raise ValueError('رقم العملية مطلوب لهذا البنك')
        else:
            if bank_id or ref:raise ValueError('بيانات البنك لا تستخدم مع الاسترجاع النقدي')
            b=None
        claim=pharmacy.one(c,'SELECT * FROM nova_claims WHERE invoice_id=?',(iid,))
        if claim and (claim['received']>0 or claim['status']!='unverified'):
            raise ValueError('مطالبة التأمين بدأت إجراءاتها؛ راجع الإدارة المالية أولاً')
        _assert_lab_not_started(c,inv['lab_order_id'])
        refund_no='RF-'+uid()
        shift=pharmacy.one(c,'SELECT id FROM nova_cashier_shifts WHERE cashier_id=? AND closed_at IS NULL',(actor['id'],))
        c.execute('''INSERT INTO nova_refunds(refund_no,invoice_id,idempotency_key,cash_amount,bank_amount,
             bank_id,bank_name,bank_reference,note,created_by,created_at,shift_id)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
             (refund_no,iid,key,cash,bank,bank_id or None,b['name'] if b else '',ref,note,
              actor['id'],now(),shift['id'] if shift else None))
        c.execute("UPDATE nova_invoices SET status='void' WHERE id=?",(iid,))
        if inv['lab_order_id']:
            c.execute("UPDATE hospital_orders SET status='cancelled' WHERE id=? AND status IN ('pending','paid')",
                      (inv['lab_order_id'],))
        if claim:c.execute('DELETE FROM nova_claims WHERE invoice_id=?',(iid,))
        audit(c,actor,'invoice_refund',iid,{'refund_no':refund_no,'cash':cash,'bank':bank,
              'bank_id':bank_id,'reference':ref,'note':note,'original_paid':paid})
        done(c)
    except Exception:rollback(c);raise
    return {'refund_no':refund_no,'invoice_id':iid,'already_recorded':False,
            'cash_amount':cash,'bank_amount':bank,'status':'void'}

def void_invoice(c,actor,data):
    """Cancel an uncollected invoice, including a settled full-insurance/zero-price invoice."""
    iid=num(data.get('invoice_id'),'الفاتورة',1);note=text(data,'note',300)
    start(c)
    try:
        inv=pharmacy.one(c,'SELECT * FROM nova_invoices WHERE id=?',(iid,))
        if not inv or inv['status'] not in ('pending','settled'):
            raise ValueError('الفاتورة غير متاحة للإلغاء')
        if pharmacy.one(c,'SELECT id FROM nova_payments WHERE invoice_id=?',(iid,)):
            raise ValueError('لا يمكن إلغاء فاتورة بها تحصيل؛ يلزم استرجاع مالي مسجل')
        cl=pharmacy.one(c,'SELECT * FROM nova_claims WHERE invoice_id=?',(iid,))
        if cl and (cl['received']>0 or cl['status']!='unverified'):
            raise ValueError('مطالبة التأمين بدأت إجراءاتها؛ راجع الإدارة المالية أولاً')
        _assert_lab_not_started(c,inv['lab_order_id'])
        c.execute("UPDATE nova_invoices SET status='void' WHERE id=?",(iid,))
        if inv['lab_order_id']:
            c.execute("UPDATE hospital_orders SET status='cancelled' WHERE id=? AND status IN ('pending','paid')",(inv['lab_order_id'],))
        if cl:c.execute('DELETE FROM nova_claims WHERE invoice_id=?',(iid,))
        audit(c,actor,'invoice_void',iid,{'note':note,'previous_status':inv['status']});done(c)
    except Exception:rollback(c);raise
    return {'status':'void','invoice_id':iid}

def adopt_lab_order(c,actor,data):
    """Move an unpaid legacy lab request into the unified cashier ledger.

    Preserves its original lab order ID, lines and clinical snapshots. Does not
    run the old hospital_receipts charge method, avoiding double billing.
    """
    oid=num(data.get('order_id'),'طلب المعمل',1)
    start(c)
    try:
        existing=pharmacy.one(c,'SELECT id FROM nova_invoices WHERE lab_order_id=?',(oid,))
        if existing:
            done(c);return invoice_detail(c,existing['id'])
        order=pharmacy.one(c,'SELECT * FROM hospital_orders WHERE id=?',(oid,))
        if not order or order['status']!='pending':raise ValueError('طلب المعمل غير متاح للتحصيل')
        if pharmacy.one(c,'SELECT id FROM hospital_receipts WHERE order_id=?',(oid,)):
            raise ValueError('الطلب له إيصال تحصيل سابق')
        pid=order['patient_id'];pi=get_patient_insurance(c,pid)
        insurer_id=pi['insurer_id'] if pi and pi['active'] else 0
        insurer=pharmacy.one(c,'SELECT * FROM nova_insurers WHERE id=?',(insurer_id,)) if insurer_id else None
        old=pharmacy.query(c,'SELECT * FROM hospital_order_items WHERE order_id=? ORDER BY id',(oid,))
        if not old:raise ValueError('طلب المعمل لا يحتوي فحوصات')
        lines=[]
        for x in old:
            key='lab:'+str(x['test_id'])
            coverage=_coverage(c,insurer_id,'lab',key,insurer['default_coverage'] if insurer else 0)
            insured=x['price']*coverage//100
            lines.append({'source_kind':'lab','source_id':x['test_id'],'category_code':'lab',
                         'code':pharmacy.one(c,'SELECT code FROM hospital_lab_tests WHERE id=?',(x['test_id'],))['code'],
                         'name':x['test_name'],'price':x['price'],'coverage':coverage,
                         'insurer_part':insured,'patient_part':x['price']-insured})
        invoice_no='N-'+uid();total=sum(x['price'] for x in lines)
        insured=sum(x['insurer_part'] for x in lines);due=total-insured
        iid=c.execute('''INSERT INTO nova_invoices(invoice_no,patient_id,created_by,created_at,
         insurer_id,insurer_name,member_no,total,insurer_due,patient_due,note,lab_order_id)
         VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
         (invoice_no,pid,actor['id'],now(),insurer_id or None,insurer['name'] if insurer else '',
          pi['member_no'] if pi and insurer else '',total,insured,due,order['note'],oid)).lastrowid
        for x in lines:c.execute('''INSERT INTO nova_invoice_lines(invoice_id,source_kind,source_id,category_code,
         code,name,price,coverage,insurer_part,patient_part) VALUES(?,?,?,?,?,?,?,?,?,?)''',
         (iid,x['source_kind'],x['source_id'],x['category_code'],x['code'],x['name'],x['price'],
          x['coverage'],x['insurer_part'],x['patient_part']))
        if insurer_id and insured:c.execute('INSERT INTO nova_claims(invoice_id,insurer_id,amount) VALUES(?,?,?)',(iid,insurer_id,insured))
        audit(c,actor,'legacy_lab_order_adopted',iid,{'lab_order_id':oid});done(c)
    except Exception:rollback(c);raise
    return invoice_detail(c,iid)
