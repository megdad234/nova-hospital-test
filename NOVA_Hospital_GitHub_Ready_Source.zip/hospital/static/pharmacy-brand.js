'use strict';
// NOVA-only presentation adapter for the unmodified pharmacy 1.4 frontend.
// Original pharmacy operations, identifiers, transactions and API are unchanged.
(() => {
  let hospitalName = 'NOVA Hospital';
  const replaceVisibleName = text => String(text).replace(/مدار\s*[|—-]\s*MADAR/gi, hospitalName)
    .replace(/\bMADAR\b/g, hospitalName).replace(/\bمدار\b/g, hospitalName);
  const updateText = node => {
    if (node.nodeType === Node.TEXT_NODE) {
      const v = node.nodeValue;
      if (v && (/MADAR|مدار/i).test(v)) {
        const next = replaceVisibleName(v);
        if (next !== v) node.nodeValue = next;
      }
    } else if (node.nodeType === Node.ELEMENT_NODE && !['SCRIPT','STYLE','TEXTAREA','INPUT'].includes(node.tagName)) {
      const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
      for (let text; (text = walker.nextNode()); ) updateText(text);
    }
  };
  document.title = 'NOVA Hospital | الصيدلية';
  const observer = new MutationObserver(records => {
    for (const r of records) for (const node of r.addedNodes) updateText(node);
  });
  observer.observe(document.body, {childList:true,subtree:true});
  for (const root of [document.querySelector('#auth'),document.querySelector('#shell'),document.querySelector('#modal')]) {
    if (root) updateText(root);
  }
  // A hospital using NOVA can customise its printed/visible identity once.
  fetch('/api/hospital/lab/brand',{credentials:'same-origin'})
    .then(r => r.ok ? r.json() : null).then(b => {
      const name=String(b?.hospital_name||'').trim();
      if (!name || name===hospitalName) return;
      hospitalName = name;
      for (const root of [document.querySelector('#auth'),document.querySelector('#shell'),document.querySelector('#modal')]) {
        if (root) {
          const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
          for (let text; (text=walker.nextNode()); ) {
            if (text.nodeValue?.includes('NOVA Hospital')) text.nodeValue=text.nodeValue.replaceAll('NOVA Hospital',name);
          }
        }
      }
      document.title = name+' | الصيدلية';
    }).catch(()=>{});
})();
