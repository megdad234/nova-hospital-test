'use strict';
// Finance UI: this file is loaded after app.js; all server side permission checks
// remain mandatory. No database or records are stored in client storage.
const financeState={services:[],categories:[],insurers:[],banks:[],invoices:[],claims:[],shifts:[],rates:[],
    patient:null,chosen:new Set(),serviceTerm:'',serviceCategory:'',insuranceId:'',invoice:null};
async function loadFinanceData(){
 const role=state.role;
 const jobs=[api('services').then(x=>financeState.services=x),api('service-categories').then(x=>financeState.categories=x),
             api('insurers').then(x=>financeState.insurers=x),api('invoices').then(x=>financeState.invoices=x)];
 if(['cashier','frontdesk','admin'].includes(role))jobs.push(api('banks').then(x=>financeState.banks=x));
 if(role==='admin')jobs.push(api('insurance-rates').then(x=>financeState.rates=x));
 await Promise.all(jobs);
}
const optionBank=b=>`<option value="${b.id}">${esc(b.name)}${b.account_label?' — '+esc(b.account_label):''}</option>`;
const optionInsurer=()=>`<option value="0">بدون تأمين</option>`+financeState.insurers.filter(x=>x.active).map(x=>`<option value="${x.id}">${esc(x.name)} · ${x.default_coverage}%</option>`).join('');
const fiSelect=(entries,placeholder)=>`<option value="">${placeholder}</option>`+entries.map(x=>`<option value="${esc(x.code)}">${esc(x.name)}</option>`).join('');
function financePatientForm(){
 return patientForm().replace('<div class="actions"><button class="primary"',
 `<label>شركة التأمين (اختياري)<select id="new-patient-insurer"><option value="0">بدون تأمين</option>${financeState.insurers.filter(x=>x.active).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label><label>رقم بطاقة التأمين (اختياري)<input id="new-patient-card" maxlength="100"></label><div class="actions"><button class="primary"`)
}
function financeServicesView(){
  const rows=state.patients;
  return `<div class="split">${panel('المريض',`<label>بحث سريع عن المريض<input id="finance-patient-search" type="search" placeholder="الاسم، الهاتف أو رقم الملف" autocomplete="off"></label><div id="finance-patient-options" class="patient-options"></div><div id="finance-selected-patient" class="help">${financeState.patient?`المريض: ${esc(financeState.patient.full_name)} (${esc(financeState.patient.patient_no)})`:'اختر مريضاً أو سجّل مريضاً جديداً'}</div>`)}${panel('تسجيل مريض جديد — اختياري',financePatientForm())}</div>
  ${panel('خدمات المريض',`<div class="toolbar"><input id="service-search" type="search" placeholder="بحث شامل: CBC، باطنية، أشعة، حقنة..." autocomplete="off" value="${esc(financeState.serviceTerm)}"><button class="outline" id="clear-service-search" type="button">مسح البحث</button></div><div id="service-categories" class="service-categories"></div><h3>الخدمات الشائعة</h3><div id="service-favorites" class="service-favorites"></div><h3>الخدمات المتاحة</h3><div id="service-results" class="service-results"></div>`)}
  ${panel('ملخص الطلب وإرساله للكاشير',`<form id="finance-invoice-form"><div id="service-chosen" class="invoice-chosen"></div><div class="form"><label>شركة التأمين — اختياري<select id="finance-insurer" name="insurer_id">${optionInsurer()}</select></label><label>رقم التأمين — اختياري<input name="member_no" maxlength="100" placeholder="رقم البطاقة إن وجد"></label><label class="wide">ملاحظة — اختياري<input name="note" maxlength="500"></label></div><div id="service-quote" class="invoice-quote mutedbox">حدد المريض والخدمات لمعاينة الإجمالي</div><div class="actions"><button class="primary" type="submit">إنشاء الطلب وإرساله للكاشير</button></div></form>`)}
  ${panel('آخر الطلبات',invoiceTable(financeState.invoices.filter(x=>x.status==='pending').slice(0,25)))}`;
}
function patientOptions(){
 const input=val('finance-patient-search').toLowerCase();
 const list=state.patients.filter(p=>`${p.full_name} ${p.patient_no} ${p.phone}`.toLowerCase().includes(input)).slice(0,12);
 const box=$('finance-patient-options');if(!box)return;
 box.innerHTML=list.map(p=>`<button type="button" class="patient-choice ${financeState.patient?.id===p.id?'active':''}" data-fpatient="${p.id}">${esc(p.full_name)} <small dir="ltr">${esc(p.patient_no)}</small></button>`).join('')||'<p class="muted">لا توجد نتائج مطابقة</p>';
 box.querySelectorAll('[data-fpatient]').forEach(b=>b.onclick=async()=>{const p=state.patients.find(x=>x.id===Number(b.dataset.fpatient));financeState.patient=p;
   $('finance-selected-patient').textContent='المريض: '+p.full_name+' — '+p.patient_no;
   const info=await api('patient-insurance/'+p.id);financeState.insuranceId=String(info.insurer_id||0);
   $('finance-insurer').value=financeState.insuranceId;patientOptions();financeQuote()});
}
function financeFilter(s){const term=financeState.serviceTerm.trim().toLowerCase();return (!financeState.serviceCategory||s.category_code===financeState.serviceCategory)&&
 (!term||`${s.name} ${s.code} ${s.aliases||''}`.toLowerCase().includes(term))}
function financeServiceButton(s){return `<button type="button" class="service-tile ${financeState.chosen.has(s.key)?'active':''}" data-service="${esc(s.key)}"><b>${esc(s.name)}</b><small dir="auto">${esc(s.code)} · ${money(s.price)}</small></button>`}
function financeRenderServices(){
 const cats=$('service-categories');if(!cats)return;
 cats.innerHTML=`<button type="button" data-category="" class="${financeState.serviceCategory===''?'active':''}">الكل</button>`+
 financeState.categories.map(x=>`<button type="button" class="${financeState.serviceCategory===x.code?'active':''}" data-category="${esc(x.code)}">${esc(x.name)}</button>`).join('');
 cats.querySelectorAll('[data-category]').forEach(b=>b.onclick=()=>{financeState.serviceCategory=b.dataset.category;financeRenderServices()});
 $('service-favorites').innerHTML=financeState.services.filter(s=>(s.popular||s.usage_count>0)&&financeFilter(s)).sort((a,b)=>Number(b.popular)-Number(a.popular)||b.usage_count-a.usage_count).slice(0,15).map(financeServiceButton).join('')||'<span class="muted">لا توجد خدمات شائعة مطابقة</span>';
 $('service-results').innerHTML=financeState.services.filter(financeFilter).slice(0,90).map(financeServiceButton).join('')||'<span class="muted">لم يتم العثور على الخدمة</span>';
 document.querySelectorAll('[data-service]').forEach(b=>b.onclick=()=>{
  const key=b.dataset.service;if(financeState.chosen.has(key))financeState.chosen.delete(key);else financeState.chosen.add(key);
  financeRenderServices();financeRenderChosen();financeQuote();});
}
function financeRenderChosen(){const box=$('service-chosen');if(!box)return;
 const list=financeState.services.filter(s=>financeState.chosen.has(s.key));
 box.innerHTML=list.length?table(['الخدمة','القسم','السعر'],list.map(s=>`<tr><td>${esc(s.name)}</td><td>${esc(s.category_name)}</td><td>${money(s.price)}</td></tr>`)):'<p class="muted">لم تختر خدمات بعد</p>';
}
async function financeQuote(){const node=$('service-quote');if(!node)return;
 if(!financeState.patient||!financeState.chosen.size){node.textContent='اختر المريض والخدمات لمعاينة المبلغ';return}
 try{const info=await api('invoice-quote',{patient_id:financeState.patient.id,services:[...financeState.chosen],insurer_id:Number($('finance-insurer').value||0)});
 node.innerHTML=`<div class="invoice-totals"><span>إجمالي الخدمات: <b>${money(info.total)}</b></span><span>حصة شركة التأمين: <b>${money(info.insurer_due)}</b></span><span>يدفع المريض: <b>${money(info.patient_due)}</b></span></div><p class="muted small">${esc(info.insurance_note)}</p>`
 }catch(e){node.textContent=e.message}
}
function wireFinanceReception(){
 financeState.chosen=new Set();financeState.patient=null;financeState.serviceTerm='';financeState.serviceCategory='';
 patientOptions();financeRenderServices();financeRenderChosen();
 $('finance-patient-search')?.addEventListener('input',async ev=>{
  const q=ev.target.value.trim();if(q.length>=2||q.length===0){try{state.patients=await api('patients?q='+encodeURIComponent(q))}catch{}}
  patientOptions();});
 $('service-search')?.addEventListener('input',e=>{financeState.serviceTerm=e.target.value;financeRenderServices()});
 $('clear-service-search')?.addEventListener('click',()=>{financeState.serviceTerm='';$('service-search').value='';financeRenderServices()});
 $('finance-insurer')?.addEventListener('change',financeQuote);
 form('patient-form',async f=>{const d=await api('patients',Object.fromEntries(f));
   const p={...Object.fromEntries(f),id:d.id,patient_no:d.patient_no};state.patients.unshift(p);
   financeState.patient=p;const insurer=$('new-patient-insurer')?.value||'0';
   if(Number(insurer)){await api('patient-insurance',{patient_id:d.id,insurer_id:Number(insurer),member_no:val('new-patient-card')})}
   financeState.insuranceId=insurer;$('finance-insurer').value=insurer;
   $('finance-selected-patient').textContent='المريض: '+p.full_name+' — '+p.patient_no;
   notice('تم تسجيل المريض');patientOptions();financeQuote()});
 form('finance-invoice-form',async f=>{
  if(!financeState.patient)throw Error('اختر المريض أولاً');if(!financeState.chosen.size)throw Error('اختر خدمة واحدة على الأقل');
  const inv=await api('invoices',{patient_id:financeState.patient.id,services:[...financeState.chosen],
       insurer_id:Number(f.get('insurer_id')||0),member_no:f.get('member_no'),note:f.get('note')});
  notice('تم إنشاء الطلب '+inv.invoice_no);
  financeState.chosen.clear();await navigate(state.role==='frontdesk'||state.role==='admin'?'cashier':'reception');
  if(['frontdesk','admin'].includes(state.role))await financeOpenInvoice(inv.id);
 });
 document.querySelectorAll('[data-invoice]').forEach(b=>b.onclick=()=>financeOpenInvoice(Number(b.dataset.invoice)));
}
function invoiceTable(rows){const cashView=state.role!=='reception';return table(['الطلب','المريض','المبلغ','التأمين','المطلوب',...(cashView?['المدفوع']:[]),'الحالة',''],rows.map(x=>`<tr><td dir="ltr"><b>${esc(x.invoice_no)}</b></td><td>${esc(x.patient_name)}</td><td>${money(x.total)}</td><td>${money(x.insurer_due)}</td><td>${money(x.patient_due)}</td>${cashView?`<td>${money(x.paid)}</td>`:''}<td><span class="tag ${x.status==='settled'?'green':'orange'}">${x.status==='settled'?'تمت التسوية':x.status==='void'?(x.refunded?'مسترجعة':'ملغاة'):'بانتظار الدفع'}</span></td><td>${cashView?`<button type="button" class="outline" data-invoice="${x.id}">فتح</button>`:'—'}</td></tr>`))} 
function financeCashierView(){return `<div class="grid">${stat('بانتظار الدفع',financeState.invoices.filter(x=>x.status==='pending').length)}${stat('مدفوعة',financeState.invoices.filter(x=>x.status==='settled').length)}${stat('إجمالي مستحقات المرضى',money(financeState.invoices.filter(x=>x.status==='pending').reduce((n,x)=>n+x.remaining,0)))}</div>
  ${panel('طلبات بانتظار التحصيل',invoiceTable(financeState.invoices.filter(x=>x.status==='pending')))}${panel('الفواتير المحصلة',invoiceTable(financeState.invoices.filter(x=>x.status==='settled').slice(0,40)))}${state.role==='admin'?panel('الفواتير الملغاة والمبالغ المسترجعة',invoiceTable(financeState.invoices.filter(x=>x.status==='void').slice(0,40))):''}<div id="finance-invoice-details"></div>
  ${panel('طلبات المعمل القديمة',`<p class="muted small">الطلبات التي أُنشئت قبل دليل خدمات المستشفى ما زالت قابلة للتحصيل بالطريقة السابقة، دون تغيير تاريخها.</p>${orderRows(state.orders.filter(x=>x.status==='pending'))}<div id="details"></div>`)}`}
function financeInvoiceForm(inv){if(inv.status!=='pending')return '';
 return `<div class="finance-payment-box"><h3>تحصيل حصة المريض</h3>${inv.paid?`<p class="help">مدفوع سابقاً: ${money(inv.paid)}</p>`:''}
 <div class="large-amount">المتبقي: ${money(inv.remaining)}</div>
 ${inv.remaining===0?`<p class="help">${inv.insurer_id?'الفاتورة مغطاة بالكامل بالتأمين، بعد التأكد من أهلية المريض.':'خدمة بدون رسوم حسب السعر المحفوظ من الإدارة.'}</p><button type="button" class="primary" id="insurance-release">تأكيد السماح بالخدمة</button>`:
 `<form id="new-payment-form"><div class="payment-modes"><label><input type="radio" name="payment_method" value="cash" checked> نقدي</label><label><input type="radio" name="payment_method" value="bank"> بنكي</label><label><input type="radio" name="payment_method" value="mixed"> مختلط</label></div><div class="form">
 <label id="pay-cash-wrap">المبلغ النقدي<input id="pay-cash" name="cash_amount" type="number" min="0" step="1" value="${inv.remaining}"></label>
 <label id="pay-bank-wrap" hidden>المبلغ البنكي<input id="pay-bank" name="bank_amount" type="number" min="0" step="1" value="0"></label>
 <label id="pay-bank-name-wrap" hidden>البنك المستلم<select id="pay-bank-id" name="bank_id"><option value="">اختر البنك</option>${financeState.banks.filter(x=>x.active).map(optionBank).join('')}</select></label>
 <label id="pay-ref-wrap" hidden>رقم العملية البنكية (اختياري حسب البنك)<input name="bank_reference" maxlength="120" placeholder="رقم التحويل إن وجد"></label></div>
 <div id="payment-total" class="help">إجمالي التحصيل: ${money(inv.remaining)}</div><div class="actions"><button class="primary" type="submit">تأكيد التحصيل وطباعة الإيصال</button></div></form>`}</div>`}
async function financeOpenInvoice(id){try{
  const inv=await api('invoice/'+id);financeState.invoice=inv;
  const isCashier=['cashier','frontdesk','admin'].includes(state.role);
  const box=$('finance-invoice-details')||$('service-invoice-details');if(!box)return;
  box.innerHTML=panel('فاتورة '+inv.invoice_no+ ' — '+inv.patient_name,
    `<div class="invoice-totals"><span>الإجمالي: <b>${money(inv.total)}</b></span><span>حصة التأمين: <b>${money(inv.insurer_due)}</b></span><span>حصة المريض: <b>${money(inv.patient_due)}</b></span></div>`+
    table(['الخدمة','القسم','السعر','تغطية التأمين','على المريض'],inv.lines.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.category_code)}</td><td>${money(x.price)}</td><td>${money(x.insurer_part)} (${x.coverage}%)</td><td>${money(x.patient_part)}</td></tr>`))+
    (inv.insurer_id?`<p class="help">شركة التأمين: ${esc(inv.insurer_name)} — المبالغ المتعاقد عليها تُسجل مطالبة وليست نقوداً مستلمة. الأهلية تحتاج تحققاً بشرياً.</p>`:'')+
    (isCashier&&inv.status==='pending'?`<div class="finance-insurance-choice"><label>تغيير تأمين الفاتورة قبل بدء التحصيل<select id="invoice-insurer">${optionInsurer()}</select></label><button type="button" class="outline" id="invoice-insurer-update">تطبيق التأمين</button></div>${financeInvoiceForm(inv)}`:'')+
    (inv.payments.length?`<h3>سجل المدفوعات</h3>${table(['الإيصال','نقدي','بنكي','البنك','مرجع','الوقت'],inv.payments.map(p=>`<tr><td>${esc(p.payment_no)}</td><td>${money(p.cash_amount)}</td><td>${money(p.bank_amount)}</td><td>${esc(p.bank_name)}</td><td>${esc(p.bank_reference)}</td><td>${esc(p.created_at)}</td></tr>`))}`:'')+
    (inv.refunds?.length?`<h3>سجل المبالغ المسترجعة</h3>${table(['رقم الاسترجاع','نقدي','بنكي','البنك','المرجع','التاريخ'],inv.refunds.map(r=>`<tr><td>${esc(r.refund_no)}</td><td>${money(r.cash_amount)}</td><td>${money(r.bank_amount)}</td><td>${esc(r.bank_name)}</td><td>${esc(r.bank_reference)}</td><td>${esc(r.created_at)}</td></tr>`))}<p class="help">استرجع للمريض ${money(inv.refunded)}؛ صافي التحصيل ${money(inv.net_paid)}. الإيصالات الأصلية محفوظة.</p>`:'')+
    (state.role==='admin'&&inv.paid===0&&inv.status!=='void'?`<div class="actions"><button type="button" class="outline" id="void-invoice">إلغاء فاتورة غير محصلة</button></div>`:'')+
    (state.role==='admin'&&inv.paid>0&&inv.status!=='void'?`<div class="finance-payment-box"><h3>استرجاع كامل المبالغ — المدير فقط</h3><p class="help">يُسجل الاسترجاع دون حذف الإيصالات الأصلية. لا يجوز استخدامه بعد بدء خدمة المعمل أو معالجة مطالبة التأمين؛ النظام يتحقق قبل التنفيذ.</p><form id="refund-invoice-form" class="form"><label>المبلغ النقدي المسترجع<input name="cash_amount" type="number" min="0" step="1" value="${inv.paid}"></label><label>المبلغ البنكي المسترجع<input name="bank_amount" type="number" min="0" step="1" value="0"></label><label>البنك (للتحويل البنكي فقط)<select name="bank_id"><option value="">اختر البنك</option>${financeState.banks.filter(b=>b.active).map(optionBank).join('')}</select></label><label>رقم عملية الاسترجاع البنكي (إن وجد)<input name="bank_reference" maxlength="120"></label><label class="wide">ملاحظة (اختيارية)<input name="note" maxlength="500"></label><div class="actions"><button type="submit" class="outline">تأكيد استرجاع كامل التحصيل</button></div></form></div>`:'')+
    `<div class="actions"><button type="button" class="outline" id="print-invoice">طباعة الفاتورة / الإيصال</button></div>`);
  box.scrollIntoView({behavior:'smooth',block:'start'});
  if($('invoice-insurer'))$('invoice-insurer').value=String(inv.insurer_id||0);
  $('invoice-insurer-update')?.addEventListener('click',async()=>{try{await api('invoice-insurance',{invoice_id:id,insurer_id:Number($('invoice-insurer').value)});notice('تم تحديث التغطية');await financeOpenInvoice(id)}catch(e){notice(e.message,true)}});
  $('insurance-release')?.addEventListener('click',async()=>{try{await api('invoice-insurance-release',{invoice_id:id});notice('تم تمرير الطلب وفق تغطية التأمين المسجلة');await navigate('cashier')}catch(e){notice(e.message,true)}});
  $('print-invoice')?.addEventListener('click',()=>financePrintInvoice(financeState.invoice));
  $('void-invoice')?.addEventListener('click',async()=>{
    try{
      if(!window.confirm('إلغاء الفاتورة بدون أي استرجاع مالي؟'))return;
      await api('invoice-void',{invoice_id:id});notice('تم إلغاء الفاتورة');await navigate('cashier');
    }catch(e){notice(e.message,true)}
  });
  form('refund-invoice-form',async f=>{
    const amountCash=Number(f.get('cash_amount')||0),amountBank=Number(f.get('bank_amount')||0);
    if(amountCash+amountBank!==inv.paid)throw Error('الاسترجاع الكامل لازم يساوي مجموع المبالغ المحصلة');
    if(!window.confirm('تأكيد استرجاع المبلغ وإلغاء الفاتورة؟ الإيصالات الأصلية ستبقى محفوظة.'))return;
    const key='nova-refund-'+(globalThis.crypto?.randomUUID?.()||String(Date.now())+String(Math.random()));
    await api('invoice-refund',{invoice_id:id,cash_amount:amountCash,bank_amount:amountBank,
      bank_id:Number(f.get('bank_id')||0),bank_reference:f.get('bank_reference')||'',
      note:f.get('note')||'',idempotency_key:key});
    notice('تم تسجيل استرجاع المبلغ وإلغاء الفاتورة');await navigate('cashier');
  });
  if($('new-payment-form')){
    const mode=()=>document.querySelector('input[name="payment_method"]:checked')?.value||'cash';
    const update=()=>{
      const m=mode(),bankOnly=m==='bank',mixed=m==='mixed',bankVisible=bankOnly||mixed;
      $('pay-cash-wrap').hidden=bankOnly;$('pay-bank-wrap').hidden=!bankVisible;
      $('pay-bank-name-wrap').hidden=!bankVisible;$('pay-ref-wrap').hidden=!bankVisible;
      if(bankOnly){$('pay-cash').value='0';if(Number($('pay-bank').value)===0)$('pay-bank').value=String(inv.remaining)}
      if(m==='cash'){$('pay-bank').value='0';$('pay-bank-id').value='';$('pay-cash').value=String(inv.remaining)}
      const total=Number($('pay-cash').value||0)+Number($('pay-bank').value||0);
      $('payment-total').textContent='إجمالي التحصيل '+money(total)+' — المتبقي بعده '+money(Math.max(0,inv.remaining-total));
    };
    document.querySelectorAll('input[name="payment_method"]').forEach(i=>i.onchange=update);
    $('pay-cash').oninput=update;$('pay-bank').oninput=update;
    form('new-payment-form',async f=>{
      const key='nova-'+(globalThis.crypto?.randomUUID?.()||String(Date.now())+String(Math.random()));
      const receipt=await api('invoice-payment',{invoice_id:id,cash_amount:Number(f.get('cash_amount')||0),bank_amount:Number(f.get('bank_amount')||0),
             bank_id:Number(f.get('bank_id')||0),bank_reference:f.get('bank_reference')||'',idempotency_key:key});
      notice(receipt.status==='settled'?'تم التحصيل والتسوية':'تم تسجيل دفعة جزئية');
      await financeOpenInvoice(id);
      if(receipt.status==='settled')financePrintInvoice(financeState.invoice);
    });
  }
 }catch(e){notice(e.message,true)}}
function financePrintInvoice(inv){if(!inv)return;
 const brand=state.brand;
 const html=`<article class="bill-print" dir="rtl"><header><h1>${esc(brand.hospital_name||'NOVA Hospital')}</h1><p>${esc(brand.hospital_address||'')} · ${esc(brand.hospital_phone||'')}</p><h2>فاتورة خدمات المستشفى</h2></header>
 <div class="print-patient"><b>المريض: ${esc(inv.patient_name)}</b><span>رقم الملف: ${esc(inv.patient_no)}</span><span>الفاتورة: ${esc(inv.invoice_no)}</span></div>
 ${table(['الخدمة','القيمة','التأمين','حصة المريض'],inv.lines.map(x=>`<tr><td>${esc(x.name)}</td><td>${money(x.price)}</td><td>${money(x.insurer_part)}</td><td>${money(x.patient_part)}</td></tr>`))}
 <div class="invoice-totals"><p>الإجمالي: ${money(inv.total)}</p><p>على التأمين: ${money(inv.insurer_due)}</p><p>على المريض: ${money(inv.patient_due)}</p><p>تم استلام: ${money(inv.paid)}</p><p>استرجع للمريض: ${money(inv.refunded||0)}</p><p>صافي التحصيل: ${money(inv.net_paid??inv.paid)}</p><p>متبقي المريض: ${money(inv.remaining)}</p></div>
 ${inv.payments.length?`<h3>الإيصالات</h3>${table(['الرقم','نقدي','بنكي','البنك','المرجع'],inv.payments.map(p=>`<tr><td>${esc(p.payment_no)}</td><td>${money(p.cash_amount)}</td><td>${money(p.bank_amount)}</td><td>${esc(p.bank_name)}</td><td>${esc(p.bank_reference)}</td></tr>`))}`:''}${inv.refunds?.length?`<h3>مستندات الاسترجاع</h3>${table(['رقم الاسترجاع','نقدي','بنكي','مرجع البنك'],inv.refunds.map(r=>`<tr><td>${esc(r.refund_no)}</td><td>${money(r.cash_amount)}</td><td>${money(r.bank_amount)}</td><td>${esc(r.bank_reference)}</td></tr>`))}`:''}
 <footer>تاريخ ووقت الطباعة: ${esc(new Date().toLocaleString('ar-SD'))}</footer></article>`;
 const area=$('print-area');area.innerHTML=html;document.body.classList.add('printing-lab');const cleanup=()=>{document.body.classList.remove('printing-lab');area.innerHTML=''};
 window.addEventListener('afterprint',cleanup,{once:true});window.print();setTimeout(cleanup,20000)
}
function wireFinanceCashier(){document.querySelectorAll('[data-invoice]').forEach(b=>b.onclick=()=>financeOpenInvoice(Number(b.dataset.invoice)));
 document.querySelectorAll('[data-order]').forEach(b=>b.onclick=async()=>{try{const out=await api('adopt-lab-order',{order_id:Number(b.dataset.order)});await financeOpenInvoice(out.id)}catch(e){notice(e.message,true)}})}
function viewFinanceSettings(){return `${panel('إدارة الخدمات والأسعار',`<p class="help">كل الأسعار مبدئياً صفر حتى تحددها الإدارة؛ لا يوجد سعر افتراضي مفترض.</p><div class="toolbar"><input id="service-admin-search" placeholder="بحث خدمة أو كود" type="search"></div><div id="services-admin-table">${servicesAdminTable(financeState.services)}</div><div id="service-edit-form"></div><form id="new-service-form" class="form"><label>اسم الخدمة<input name="name" required maxlength="150"></label><label>الكود<input name="code" dir="ltr" required maxlength="50"></label><label>القسم<select name="category_code">${financeState.categories.filter(x=>x.code!=='lab').map(x=>`<option value="${x.code}">${esc(x.name)}</option>`).join('')}</select></label><label>السعر (ج.س)<input name="price" type="number" min="0" step="1" value="0" required></label><label class="wide">مرادفات البحث<input name="aliases" maxlength="400"></label><label class="checklabel"><input type="checkbox" name="popular"> ضمن الخدمات الشائعة</label><div class="actions"><button type="submit" class="primary">إضافة خدمة</button></div></form>`)}
  ${panel('البنوك والحسابات',`<form id="new-bank-form" class="form"><label>اسم البنك<input name="name" required maxlength="120"></label><label>وصف الحساب أو الرقم (اختياري)<input name="account_label" maxlength="100"></label><label class="checklabel"><input name="require_reference" type="checkbox"> رقم العملية إلزامي لهذا البنك</label><div class="actions"><button class="primary" type="submit">إضافة بنك</button></div></form>${table(['البنك','الحساب','الحالة','إجراء'],financeState.banks.map(x=>`<tr><td>${esc(x.name)}</td><td dir="auto">${esc(x.account_label)}</td><td>${x.active?'مفعّل':'معطّل'}</td><td><button type="button" class="outline" data-bank-toggle="${x.id}">${x.active?'تعطيل':'تفعيل'}</button> <button type="button" class="outline" data-bank-edit="${x.id}">تعديل</button></td></tr>`))}<div id="bank-edit-form"></div>`)}
  ${panel('شركات التأمين ونسب التغطية',`<form id="new-insurer-form" class="form"><label>شركة التأمين<input name="name" required maxlength="130"></label><label>التغطية الافتراضية %<input name="default_coverage" type="number" min="0" max="100" step="1" value="0" required></label><div class="actions"><button class="primary" type="submit">إضافة شركة</button></div></form>${table(['الشركة','النسبة','الحالة','إجراء'],financeState.insurers.map(x=>`<tr><td>${esc(x.name)}</td><td>${x.default_coverage}%</td><td>${x.active?'مفعلة':'معطلة'}</td><td><button type="button" class="outline" data-insurer-edit="${x.id}">تعديل</button></td></tr>`))}<div id="insurer-edit-form"></div><h3>تغطية خاصة لقسم أو خدمة</h3><form id="insurance-rate-form" class="form"><label>الشركة<select name="insurer_id">${financeState.insurers.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label><label>نوع الاستثناء<select id="rate-type"><option value="category">قسم كامل</option><option value="service">خدمة محددة</option></select></label><label id="rate-category-wrap">القسم<select name="category_code">${financeState.categories.map(x=>`<option value="${x.code}">${esc(x.name)}</option>`).join('')}</select></label><label id="rate-service-wrap" hidden>الخدمة<select name="service_key">${financeState.services.map(x=>`<option value="${esc(x.key)}">${esc(x.name)}</option>`).join('')}</select></label><label>النسبة %<input type="number" name="coverage" value="0" min="0" max="100" required></label><div class="actions"><button class="primary" type="submit">حفظ التغطية</button></div></form>${table(['الشركة','القسم','الخدمة','النسبة'],financeState.rates.map(x=>`<tr><td>${esc(financeState.insurers.find(y=>y.id===x.insurer_id)?.name)}</td><td>${esc(x.category_code)}</td><td>${esc(x.service_key)}</td><td>${x.coverage}%</td></tr>`))}`)}`}
function servicesAdminTable(rows){return table(['الخدمة','القسم','السعر','نشطة','إجراء'],rows.filter(x=>x.kind==='service').slice(0,150).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.category_name)}</td><td>${money(x.price)}</td><td>${x.active?'نعم':'لا'}</td><td><button type="button" class="outline" data-service-edit="${x.id}">تعديل</button></td></tr>`))}
function wireFinanceSettings(){
 const registerEdit=()=>document.querySelectorAll('[data-service-edit]').forEach(b=>b.onclick=()=>{
   const s=financeState.services.find(x=>x.kind==='service'&&x.id===Number(b.dataset.serviceEdit));
   $('service-edit-form').innerHTML=panel('تعديل الخدمة: '+s.name,`<form id="edit-service-form" class="form"><label>الاسم<input name="name" required value="${esc(s.name)}"></label><label>الكود<input name="code" required value="${esc(s.code)}"></label><label>القسم<select name="category_code">${financeState.categories.filter(x=>x.code!=='lab').map(x=>`<option value="${x.code}" ${s.category_code===x.code?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label><label>السعر<input name="price" type="number" value="${s.price}" min="0" required></label><label>المرادفات<input name="aliases" value="${esc(s.aliases)}"></label><label class="checklabel"><input name="popular" type="checkbox" ${s.popular?'checked':''}> شائعة</label><label class="checklabel"><input name="active" type="checkbox" ${s.active?'checked':''}> مفعلة</label><div class="actions"><button class="primary">حفظ التعديل</button></div></form>`);
   $('service-edit-form').scrollIntoView({behavior:'smooth'});
   form('edit-service-form',async f=>{await api('service',{...Object.fromEntries(f),id:s.id,popular:f.has('popular'),active:f.has('active')});notice('تم حفظ الخدمة');await navigate('services-admin')})});
 registerEdit();$('service-admin-search')?.addEventListener('input',e=>{
    const q=e.target.value.toLowerCase();$('services-admin-table').innerHTML=servicesAdminTable(financeState.services.filter(x=>`${x.name} ${x.code} ${x.aliases}`.toLowerCase().includes(q)));registerEdit()});
 form('new-service-form',async f=>{await api('service',{...Object.fromEntries(f),popular:f.has('popular')});notice('تمت إضافة الخدمة');await navigate('services-admin')});
 form('new-bank-form',async f=>{await api('bank',{...Object.fromEntries(f),require_reference:f.has('require_reference')});notice('تم حفظ البنك');await navigate('services-admin')});
 document.querySelectorAll('[data-bank-toggle]').forEach(b=>b.onclick=async()=>{const x=financeState.banks.find(y=>y.id===Number(b.dataset.bankToggle));try{await api('bank',{id:x.id,name:x.name,account_label:x.account_label,require_reference:Boolean(x.require_reference),active:!x.active});await navigate('services-admin')}catch(e){notice(e.message,true)}});
 document.querySelectorAll('[data-bank-edit]').forEach(b=>b.onclick=()=>{const x=financeState.banks.find(y=>y.id===Number(b.dataset.bankEdit));
  $('bank-edit-form').innerHTML=panel('تعديل البنك: '+x.name,`<form id="bank-edit" class="form"><label>اسم البنك<input name="name" value="${esc(x.name)}" required></label><label>الحساب<input name="account_label" value="${esc(x.account_label)}"></label><label class="checklabel"><input type="checkbox" name="require_reference" ${x.require_reference?'checked':''}> رقم العملية مطلوب</label><label class="checklabel"><input type="checkbox" name="active" ${x.active?'checked':''}> مفعّل</label><div class="actions"><button class="primary">حفظ</button></div></form>`);
  form('bank-edit',async f=>{await api('bank',{id:x.id,name:f.get('name'),account_label:f.get('account_label'),require_reference:f.has('require_reference'),active:f.has('active')});notice('تم تعديل البنك');await navigate('services-admin')});
 });
 form('new-insurer-form',async f=>{await api('insurer',Object.fromEntries(f));notice('تمت إضافة شركة التأمين');await navigate('services-admin')});
 document.querySelectorAll('[data-insurer-edit]').forEach(b=>b.onclick=()=>{const x=financeState.insurers.find(y=>y.id===Number(b.dataset.insurerEdit));
   $('insurer-edit-form').innerHTML=panel('تعديل شركة التأمين: '+x.name,`<form id="insurer-edit" class="form"><label>اسم الشركة<input name="name" value="${esc(x.name)}" required></label><label>النسبة %<input type="number" name="default_coverage" min="0" max="100" value="${x.default_coverage}" required></label><label class="checklabel"><input type="checkbox" name="active" ${x.active?'checked':''}> مفعلة</label><div class="actions"><button class="primary">حفظ</button></div></form>`);
   form('insurer-edit',async f=>{await api('insurer',{id:x.id,name:f.get('name'),default_coverage:f.get('default_coverage'),active:f.has('active')});notice('تم تعديل الشركة');await navigate('services-admin')});
 });
 $('rate-type')?.addEventListener('change',e=>{$('rate-category-wrap').hidden=e.target.value==='service';$('rate-service-wrap').hidden=e.target.value!=='service'});
 form('insurance-rate-form',async f=>{const which=$('rate-type').value;await api('insurance-rate',{
     insurer_id:Number(f.get('insurer_id')),category_code:which==='category'?f.get('category_code'):'',
     service_key:which==='service'?f.get('service_key'):'',coverage:Number(f.get('coverage'))});
     notice('تم ضبط تغطية التأمين');await navigate('services-admin')});
}
function viewClaims(){return panel('مطالبات التأمين',`<p class="help">المديونية على الشركات منفصلة تماماً عن النقد والبنك. المبالغ المعروضة لا تعني موافقة شركة التأمين على المطالبة.</p>
 ${table(['رقم الفاتورة','الشركة','المريض','المطالبة','المستلم','المتبقي','حالة المطالبة','إجراء'],financeState.claims.map(x=>`<tr><td>${esc(x.invoice_no)}</td><td>${esc(x.insurer_name)}</td><td>${esc(x.patient_name)}</td><td>${money(x.amount)}</td><td>${money(x.received)}</td><td>${money(x.amount-x.received)}</td><td>${esc(x.status)}</td><td><button type="button" class="outline" data-claim="${x.invoice_id}">تسجيل سداد</button></td></tr>`))}
 <div id="claim-editor"></div>`)}
function wireClaims(){document.querySelectorAll('[data-claim]').forEach(b=>b.onclick=()=>{
 const x=financeState.claims.find(c=>c.invoice_id===Number(b.dataset.claim));if(x.amount===x.received){notice('المطالبة مسددة بالكامل');return}
 $('claim-editor').innerHTML=panel('تحصيل من شركة التأمين — '+x.insurer_name,`<form id="claim-payment-form" class="form"><label>المبلغ المستلم<input name="amount" type="number" min="1" max="${x.amount-x.received}" value="${x.amount-x.received}" required></label><label>المرجع (اختياري)<input name="reference"></label><div class="actions"><button class="primary">تسجيل السداد</button></div></form>`);
 form('claim-payment-form',async f=>{await api('insurance-collection',{invoice_id:x.invoice_id,amount:Number(f.get('amount')),reference:f.get('reference')});notice('تم تسجيل سداد شركة التأمين');await navigate('claims')})})}
function viewShifts(){
 const rows=financeState.shifts.map(x=>`<tr><td>${esc(x.cashier_name)}</td><td>${esc(x.opened_at)}</td><td>${esc(x.closed_at||'مفتوحة')}</td><td>${money(x.expected_cash)}</td><td>${x.counted_cash===null?'—':money(x.counted_cash)}</td><td>${x.difference===null?'—':money(x.difference)}</td><td>${x.closed_at?'':`<button type="button" class="outline" data-close-shift="${x.id}">إقفال</button>`}</td></tr>`);
 const start=panel('ورديتي — بدء وإقفال',`<form id="shift-open-form" class="form"><label>النقد في بداية الوردية<input name="opening_cash" type="number" min="0" value="0" required></label><div class="actions"><button class="primary">فتح وردية</button></div></form><p class="muted small">ورديات الكاشير اختيارية؛ جميع التحصيلات تسجل باسم الموظف حتى بدون فتح وردية.</p>`);
 return start+panel('سجل الورديات',table(['الموظف','البداية','النهاية','النقد المتوقع','المعدود','الفرق','إجراء'],rows)+'<div id="shift-close-editor"></div>');
}
function wireShifts(){form('shift-open-form',async f=>{await api('shift-open',{opening_cash:Number(f.get('opening_cash'))});notice('تم فتح الوردية');await navigate('shifts')});
 document.querySelectorAll('[data-close-shift]').forEach(b=>b.onclick=()=>{
    const x=financeState.shifts.find(y=>y.id===Number(b.dataset.closeShift));
    $('shift-close-editor').innerHTML=panel('إقفال وردية '+x.cashier_name,
      `<p class="help">المبلغ النقدي المتوقع: ${money(x.expected_cash)}. أدخل النقد الموجود فعلياً.</p><form id="shift-close-form" class="form"><label>النقد الموجود<input type="number" name="counted_cash" min="0" value="${x.expected_cash}" required></label><label>ملاحظة (اختياري)<input name="note" maxlength="500"></label><div class="actions"><button class="primary">إقفال الوردية</button></div></form>`);
    form('shift-close-form',async f=>{await api('shift-close',{shift_id:x.id,counted_cash:Number(f.get('counted_cash')),note:f.get('note')});notice('تم إقفال الوردية');await navigate('shifts')});
 });}
