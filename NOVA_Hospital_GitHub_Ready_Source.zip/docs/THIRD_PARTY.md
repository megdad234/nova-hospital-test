# Components and licenses

The user-supplied `MADAR_Pharmacy_1_4_UX_Updated_Source.zip` is preserved as a reference and its application source has been copied without replacing existing data. Confirm the application's original license and ownership before redistribution.

This Windows packaging candidate adapts the Inno Setup + Python application Windows service approach found in **BamDude** (`kainpl/bamdude`, https://github.com/kainpl/bamdude/tree/main/installers/windows), which is distributed under AGPL-3.0. This package is **not** the unmodified BamDude installer. Modified installer sources are provided; if distributing the adapted installer, review and comply with all AGPL-3.0 obligations.

NSSM (Non-Sucking Service Manager) is public domain. Its executable in the packaging candidate is obtained from the BamDude checked-in vendor artifact; confirm the vendor binary checksum against the pinned version in the repository and audit before releasing. Inno Setup has its own license, and PyInstaller uses the GPL with a bootloader exception; read the official licenses when distributing compiled files.

NO patient data or real database backups are included. No Windows Setup.exe is claimed until an actual Windows build passes.
