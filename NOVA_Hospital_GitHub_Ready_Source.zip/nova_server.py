#!/usr/bin/env python3
"""NOVA's isolated Windows server entry point for the supplied Pharmacy ERP.

Development integration candidate. All clients use one server-side data store.
LAN HTTP is allowed only for an isolated trusted test network; hospital use with
real records still requires network security/TLS and production acceptance.
"""
from __future__ import annotations
import argparse
import sqlite3
import os
import ssl
import subprocess
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path

FROZEN = bool(getattr(sys, 'frozen', False))
BUNDLE_ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent / 'pharmacy'))
if not FROZEN:
    sys.path.insert(0, str(BUNDLE_ROOT))
import app  # noqa: E402
from hospital import core  # noqa: E402
from hospital.gateway import HospitalHandler  # noqa: E402


def configure(data_root: Path):
    app.ROOT = BUNDLE_ROOT
    app.DATA = data_root / 'data'
    app.DB = app.DATA / 'pharmacy.sqlite3'


def serve(host: str, port: int, data_root: Path, tls_cert: str = '', tls_key: str = ''):
    # Offline deployment on a physically isolated router. Real patient records
    # require a properly trusted HTTPS certificate, not plaintext HTTP.
    configure(data_root)
    # A direct service launch must enforce the same protection as the installer.
    # Otherwise init_schema() could silently add empty hospital tables to an
    # accidentally copied standalone pharmacy database, hiding data loss.
    # Missing DB is normal for first install; an existing one must be complete.
    verify_data(data_root)
    app.init_db(preload_catalog=True)
    core.init_schema()
    from hospital.backup import install_shared_backup_guard
    install_shared_backup_guard()
    app.start_automatic_backups()
    srv = app.ThreadServer((host, port), HospitalHandler)
    if tls_cert or tls_key:
        if not (tls_cert and tls_key):
            raise ValueError('Both TLS certificate and key are required')
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(certfile=tls_cert, keyfile=tls_key)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    try:
        srv.serve_forever(poll_interval=0.2)
    finally:
        srv.server_close()


def self_check() -> None:
    with tempfile.TemporaryDirectory(prefix='nova-pack-smoke-') as tmp:
        configure(Path(tmp))
        app.init_db(preload_catalog=False)
        core.init_schema()
        srv=app.ThreadServer(('127.0.0.1',0),HospitalHandler)
        thread=threading.Thread(target=srv.serve_forever,daemon=True)
        thread.start()
        try:
            url=f'http://127.0.0.1:{srv.server_address[1]}/api/v1/status'
            with urllib.request.urlopen(url, timeout=10) as r:
                assert r.status == 200 and b'"nova_server": true' in r.read(), 'Unexpected health response'
            # A healthy API does NOT prove that the Windows-bundled UI is present.
            # Load the portal and every essential asset over HTTP, including
            # the unchanged pharmacy scripts, to catch PyInstaller data-path errors.
            required_assets = {
                '/': b'NOVA HOSPITAL',
                '/hospital/static/style.css': b'body',
                '/hospital/static/app.js': b'function',
                '/hospital/static/finance-ui.js': b'function',
                '/hospital/static/admin-ui.js': b'function',
                '/hospital/static/pharmacy-brand.js': b'NOVA',
                '/hospital/static/nova-mark.svg': b'<svg',
                '/static/app.js': b'function',
                '/static/style.css': b'body',
                '/static/ux_v14.js': b'function',
            }
            for route, expected in required_assets.items():
                with urllib.request.urlopen(
                    f'http://127.0.0.1:{srv.server_address[1]}{route}', timeout=10
                ) as r:
                    payload = r.read()
                    assert r.status == 200 and expected in payload, f'Missing/broken asset: {route}'
        finally:
            srv.shutdown();srv.server_close();thread.join(timeout=4)
    print('NOVA_PACKAGING_SMOKE_PASS', flush=True)


def verify_data(data_root: Path) -> None:
    """Read-only gate for an existing central DB before any new service launch.

    A missing database is expected during a first installation. Do not let a
    corrupt or incomplete existing file be replaced with a fresh blank DB.
    """
    db = data_root / 'data' / 'pharmacy.sqlite3'
    if not db.exists():
        print('NOVA_VERIFY_DATA_EMPTY_FIRST_INSTALL', flush=True)
        return
    # Do not silently create empty hospital tables over an older standalone
    # pharmacy DB. This gate reads the active DB without checking a stale
    # sidecar checksum (which is only authoritative for immutable backups).
    from hospital.backup import verify_unified_backup
    try:
        verify_unified_backup(db, current_database=True)
    except (ValueError, sqlite3.DatabaseError) as exc:
        raise RuntimeError('Existing NOVA central database failed verification: '+str(exc)) from exc
    print('NOVA_EXISTING_DATABASE_INTEGRITY_PASS', flush=True)


def verify_nova_backup_file(path: Path) -> dict:
    """Read-only check before Windows stops the live hospital service."""
    from hospital.backup import verify_unified_backup
    info = verify_unified_backup(path)
    print('NOVA_UNIFIED_BACKUP_VALID', flush=True)
    return info


def restore_data_offline(data_root: Path, backup_path: Path) -> dict:
    """Offline restore: first stage and validate COMPLETE hospital data.

    A standalone pharmacy backup, a partial hospital DB, or a damaged backup
    cannot replace the current hospital DB. Existing pre-restore snapshots are
    preserved by the original pharmacy recovery engine.
    """
    if os.name == 'nt':
        status = subprocess.run(['sc.exe','query','NOVA_Hospital_Server'],
                                capture_output=True, text=True, timeout=15)
        if status.returncode == 0 and not any(
                line.strip().upper().startswith('STATE') and 'STOPPED' in line.upper()
                for line in status.stdout.splitlines()):
            raise RuntimeError('Stop NOVA_Hospital_Server Windows service before restoring data')
    import recovery
    from hospital.backup import verify_unified_backup
    import secrets
    path = Path(backup_path).resolve()
    data = (data_root / 'data' / 'pharmacy.sqlite3').resolve()
    if path == data:
        raise ValueError('A backup must not be the currently active database')
    # Reject invalid snapshots before touching any existing active DB or WAL.
    verify_unified_backup(path)
    data.parent.mkdir(parents=True, exist_ok=True)
    staging = data.parent / ('.nova-validated-restore-' + secrets.token_hex(10) + '.sqlite3')
    try:
        # A verified snapshot is copied to a private stage; source file may be
        # on an external drive and must not be used again during replacement.
        recovery.copy_verified(path, staging)
        verify_unified_backup(staging)
        result = recovery.restore_backup(staging, data)
        verify_unified_backup(data)
        print('NOVA_OFFLINE_RESTORE_VERIFIED', flush=True)
        return result
    finally:
        staging.unlink(missing_ok=True)
        Path(str(staging) + '.sha256').unlink(missing_ok=True)


def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument('--self-check',action='store_true')
    p.add_argument('--verify-data',action='store_true')
    p.add_argument('--restore-backup', metavar='SQLITE3_FILE')
    p.add_argument('--verify-backup', metavar='SQLITE3_FILE')
    a=p.parse_args()
    if a.self_check:
        self_check()
        return 0
    data_root=Path(os.environ.get('NOVA_DATA_HOME') or (Path(os.environ.get('PROGRAMDATA') or Path.home()) / 'NOVA_Hospital'))
    if a.verify_data:
        verify_data(data_root)
        return 0
    if a.verify_backup:
        verify_nova_backup_file(Path(a.verify_backup))
        return 0
    if a.restore_backup:
        restore_data_offline(data_root, Path(a.restore_backup))
        return 0
    host=os.environ.get('NOVA_BIND','127.0.0.1')
    port=int(os.environ.get('NOVA_PORT','8765'))
    serve(host,port,data_root,os.environ.get('NOVA_TLS_CERT',''),os.environ.get('NOVA_TLS_KEY',''))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
