"""Optional browser smoke using installed Playwright/Chromium (build environment only)."""
from pathlib import Path
import sys,tempfile,threading,urllib.request,json,time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'pharmacy'))
import app,nova_server
from hospital import core
from hospital.gateway import HospitalHandler
from playwright.sync_api import sync_playwright

def post(base,route,payload,cookie=''):
    req=urllib.request.Request(base+route,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json',**({'Cookie':cookie} if cookie else {})})
    with urllib.request.urlopen(req,timeout=10) as r:return json.load(r),r.headers.get('Set-Cookie','')

with tempfile.TemporaryDirectory(prefix='nova-lab-browser-') as tmp:
    nova_server.configure(Path(tmp))
    app.init_db(preload_catalog=False)
    core.init_schema()
    srv=app.ThreadServer(('127.0.0.1',0),HospitalHandler)
    base='http://127.0.0.1:'+str(srv.server_address[1])
    th=threading.Thread(target=srv.serve_forever,daemon=True);th.start()
    try:
        post(base,'/api/v1/bootstrap',{'username':'demo','full_name':'NOVA Demo','password':'browser-demo-long-pass-2026'})
        with sync_playwright() as pw:
            browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
            page=browser.new_page(viewport={'width':1440,'height':850},locale='ar-SD')
            errors=[]
            page.on('pageerror',lambda err:errors.append(str(err)))
            page.goto(base+'/',wait_until='networkidle')
            page.locator('#login-user').fill('demo')
            page.locator('#login-password').fill('browser-demo-long-pass-2026')
            page.locator('#login-submit').click()
            page.locator('#page-title').wait_for(timeout=15000)
            page.get_by_role('button',name='دليل التحاليل والطبيعي').click()
            page.locator('#catalog-grid').wait_for()
            page.locator('#catalog-search').fill('cbc')
            page.get_by_role('button',name='تعديل البنود والطبيعي').first.click()
            page.locator('#profile-form').wait_for()
            page.screenshot(path='/mnt/data/nova_lab_catalog_preview.png',full_page=True)
            page.get_by_role('button',name='الاستقبال',exact=True).first.click()
            page.locator('#patient-form').wait_for()
            page.locator('#patient-form [name=full_name]').fill('مريض تجريبي')
            page.locator('#patient-form button[type=submit]').click()
            page.locator('#order-patient').wait_for()
            page.locator('#tests-search').fill('cbc')
            page.locator('input[data-pickcheck]').first.check()
            page.locator('#order-form button[type=submit]').click()
            page.get_by_role('button',name='الكاشير',exact=True).first.click()
            page.locator('[data-order]').first.click()
            page.locator('#payment-form').wait_for()
            page.locator('#payment-form button[type=submit]').click()
            page.get_by_role('button',name='المعمل',exact=True).first.click()
            page.locator('[data-order]').first.click()
            page.locator('.result-form').first.wait_for()
            page.locator('.result-form input[data-line]').first.fill('7.3')
            page.screenshot(path='/mnt/data/nova_lab_results_preview.png',full_page=True)
            page.locator('.result-form button[value=publish]').first.click()
            page.get_by_role('button',name='طباعة تقرير المعمل').first.wait_for()
            page.screenshot(path='/mnt/data/nova_lab_paid_preview.png',full_page=True)
            print('BROWSER_LAB_ACCEPTANCE_PASS', 'page_errors',errors, 'screenshots=3')
            assert not errors,errors
            browser.close()
    finally:
        srv.shutdown();srv.server_close();th.join(timeout=5)
