"""Synthetic tests for update invariants and branding, not Windows installer acceptance."""
import http.cookiejar
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'pharmacy'))
import app
import nova_server
from hospital import core
from hospital.gateway import HospitalHandler
from tests.test_hospital_gateway import Client


class UpdateAndBrandTests(unittest.TestCase):
    def test_verify_data_first_install_then_existing_and_corrupted(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            nova_server.verify_data(d)  # first install only, never creates data
            self.assertFalse((d/'data'/'pharmacy.sqlite3').exists())
            nova_server.configure(d)
            app.init_db(preload_catalog=False)
            core.init_schema()
            nova_server.verify_data(d)
            path=d/'data'/'pharmacy.sqlite3'
            path.write_bytes(b'bad-database')
            with self.assertRaises(RuntimeError):
                nova_server.verify_data(d)

    def test_restore_replaces_only_offline_database_and_preserves_pre_restore_copy(self):
        from recovery import copy_verified
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            nova_server.configure(d)
            app.init_db(preload_catalog=False)
            core.init_schema()
            db=d/'data'/'pharmacy.sqlite3'
            with sqlite3.connect(db) as c:
                c.execute('CREATE TABLE synthetic_before_restore (id INTEGER PRIMARY KEY)')
                c.execute('INSERT INTO synthetic_before_restore VALUES (1)')
            backup=d/'safe-backup.sqlite3'
            copy_verified(db,backup)
            with sqlite3.connect(db) as c:
                c.execute('CREATE TABLE synthetic_later_data (id INTEGER PRIMARY KEY)')
            result=nova_server.restore_data_offline(d,backup)
            self.assertTrue(result['verified'])
            self.assertTrue(Path(result['previous_backup']).is_file())
            with sqlite3.connect(db) as c:
                tables={x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                self.assertIn('synthetic_before_restore',tables)
                self.assertNotIn('synthetic_later_data',tables)

    def test_restore_rejects_tampered_backup_without_touching_database(self):
        from recovery import copy_verified
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            nova_server.configure(root)
            app.init_db(preload_catalog=False)
            core.init_schema()
            db=root/'data'/'pharmacy.sqlite3'
            backup=root/'tampered.sqlite3'
            copy_verified(db,backup)
            before=db.read_bytes()
            with open(backup,'ab') as f:
                f.write(b'wrong-signature')
            with self.assertRaisesRegex(ValueError,'بصمة'):
                nova_server.restore_data_offline(root,backup)
            self.assertEqual(db.read_bytes(),before)

    def test_preflight_is_present_before_files_copy_and_old_program_is_preserved(self):
        installer=(ROOT/'windows'/'nova-hospital.iss').read_text(encoding='utf-8')
        preflight=(ROOT/'windows'/'preflight-upgrade.ps1').read_text(encoding='utf-8')
        self.assertIn('function PrepareToInstall(',installer)
        self.assertIn('ExtractTemporaryFile(\'preflight-upgrade.ps1\')',installer)
        self.assertIn('Flags: dontcopy',installer)
        self.assertIn('Stop-Service -Name $ServiceName',preflight)
        self.assertIn("@('','-wal')",preflight)
        self.assertIn('Get-FileHash',preflight)
        self.assertIn('previous_program',preflight)
        install_service=(ROOT/'windows'/'install-service.ps1').read_text(encoding='utf-8')
        self.assertIn('--verify-data',install_service)

    def test_failed_windows_update_has_verified_rollback_gate(self):
        """Static source contract; real Windows rollback acceptance still required."""
        installer = (ROOT/'windows'/'nova-hospital.iss').read_text(encoding='utf-8')
        preflight = (ROOT/'windows'/'preflight-upgrade.ps1').read_text(encoding='utf-8')
        recovery = (ROOT/'windows'/'recover-failed-upgrade.ps1').read_text(encoding='utf-8')
        registration = (ROOT/'windows'/'install-service.ps1').read_text(encoding='utf-8')
        self.assertIn('recover-failed-upgrade.ps1', installer)
        self.assertIn('RecoveryExit = 0', installer)
        self.assertIn('Abort;', installer)
        self.assertIn('pending-update.json', preflight)
        self.assertIn('previous_exe_sha256', preflight)
        self.assertIn('previous_program', preflight)
        self.assertIn('pending-update.json', recovery)
        self.assertIn('Check-Hash', recovery)
        self.assertIn('failed_program', recovery)
        self.assertIn('Start-Service', recovery)
        self.assertIn('ROLLBACK_OK', recovery)
        self.assertIn('pending-update.json', registration)
        self.assertIn('single_central_database', registration)

    def test_pharmacy_identity_is_nova_without_modifying_pharmacy_source(self):
        with tempfile.TemporaryDirectory(prefix='nova-brand-test-') as tmp:
            nova_server.configure(Path(tmp))
            app.init_db(preload_catalog=False)
            core.init_schema()
            server=app.ThreadServer(('127.0.0.1',0),HospitalHandler)
            server_url='http://127.0.0.1:%d' % server.server_address[1]
            worker=threading.Thread(target=server.serve_forever,daemon=True)
            worker.start()
            try:
                c=Client(server_url)
                c.post('/api/v1/bootstrap',{'username':'synthetic-owner','full_name':'Synthetic Admin','password':'synthetic-admin-pass-2026'})
                c.post('/api/v1/login',{'username':'synthetic-owner','password':'synthetic-admin-pass-2026'})
                req=urllib.request.Request(server_url+'/pharmacy')
                with c.opener.open(req,timeout=10) as resp:
                    body=resp.read().decode('utf-8')
                    self.assertEqual(resp.status,200)
                self.assertIn('NOVA Hospital',body)
                self.assertIn('/hospital/static/pharmacy-brand.js',body)
                self.assertIn('/hospital/static/nova-mark.svg',body)
                self.assertNotIn('مدار | MADAR',body)
                with c.opener.open(server_url+'/hospital/static/nova-mark.svg',timeout=10) as resp:
                    self.assertIn(b'<svg',resp.read())
                with c.opener.open(server_url+'/api/hospital/lab/brand',timeout=10) as resp:
                    self.assertEqual(resp.status,200)
            finally:
                server.shutdown();server.server_close();worker.join(timeout=3)


if __name__=='__main__':
    unittest.main()
