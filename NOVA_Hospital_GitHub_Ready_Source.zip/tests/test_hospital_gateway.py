"""Local synthetic API tests only. Run on a disposable DB, no real patient records."""
import concurrent.futures
import http.cookiejar
import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'pharmacy'))
import app
import nova_server
from hospital import core
from hospital.gateway import HospitalHandler

class HospitalServerFixture:
    """Reusable HTTP test fixture. Not a TestCase, so importing it cannot duplicate tests."""
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='nova-hospital-tests-')
        nova_server.configure(Path(self.tmp.name))
        app.init_db(preload_catalog=False)
        core.init_schema()
        self.server=app.ThreadServer(('127.0.0.1',0),HospitalHandler)
        self.url='http://127.0.0.1:%d'%self.server.server_address[1]
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.admin=self.client()
        self.admin.post('/api/v1/bootstrap',{'username':'admin','full_name':'NOVA Admin','password':'test-admin-password-2026'})
        self.admin.post('/api/v1/login',{'username':'admin','password':'test-admin-password-2026'})

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
        self.tmp.cleanup()

    def client(self):
        return Client(self.url)

    def make_user(self,role,name):
        self.admin.post('/api/hospital/staff',{'username':name,'full_name':name,'password':'test-dept-password-2026','role':role})
        c=self.client();c.post('/api/v1/login',{'username':name,'password':'test-dept-password-2026'});return c


class HospitalServerTest(HospitalServerFixture, unittest.TestCase):
    """The two baseline HTTP acceptance tests, executed exactly once."""
    def test_central_accounts_pay_first_lab_and_pharmacy_isolation(self):
        reception=self.make_user('reception','rec')
        cashier=self.make_user('cashier','cash')
        lab=self.make_user('lab','lab')
        self.assertEqual(reception.get('/api/hospital/me')['user']['role'],'reception')
        for restricted in (lab,cashier,reception):
            with self.assertRaises(urllib.error.HTTPError) as e:
                restricted.get('/api/v1/products')
            self.assertEqual(e.exception.code,403)
            with self.assertRaises(urllib.error.HTTPError) as e:
                restricted.get('/api/hospital/staff')
            self.assertEqual(e.exception.code,403)
        test=self.admin.post('/api/hospital/tests',{'name':'CBC','code':'CBC01','price':2000,'unit':'g/dL','reference_range':'Review by lab'})
        patient=reception.post('/api/hospital/patients',{'full_name':'Synthetic Patient','phone':'000'})
        order=reception.post('/api/hospital/orders',{'patient_id':patient['id'],'test_ids':[test['id']]})
        self.assertEqual(lab.get('/api/hospital/orders'),[])
        with self.assertRaises(urllib.error.HTTPError) as e:
            lab.get('/api/hospital/order/'+str(order['id']))
        self.assertEqual(e.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as e:
            lab.post('/api/hospital/results',{'item_id':1,'result_text':'9.5','approve':True})
        self.assertEqual(e.exception.code,403)
        receipt=cashier.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash','idempotency_key':'synthetic-order-unique-key-1'})
        self.assertEqual(receipt['amount'],2000)
        self.assertEqual(cashier.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash','idempotency_key':'synthetic-order-unique-key-1'})['receipt_no'],receipt['receipt_no'])
        with self.assertRaises(urllib.error.HTTPError) as e:
            cashier.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash','idempotency_key':'synthetic-order-unique-key-2'})
        self.assertEqual(e.exception.code,400)
        detail=lab.get('/api/hospital/order/'+str(order['id']))
        self.assertEqual(detail['status'],'paid')
        result=lab.post('/api/hospital/results',{'item_id':detail['items'][0]['id'],'result_text':'9.5','approve':True})
        self.assertTrue(result['approved'])
        self.assertEqual(lab.get('/api/hospital/order/'+str(order['id']))['status'],'completed')
        corrected=lab.post('/api/hospital/results',{'item_id':detail['items'][0]['id'],'result_text':'13','approve':True})
        self.assertTrue(corrected['approved'])
        revisions=lab.get('/api/hospital/lab/revisions/'+str(detail['items'][0]['id']))
        self.assertEqual(len(revisions),2)
        dash=self.admin.get('/api/hospital/dashboard')
        self.assertEqual(dash['patients'],1)
        self.assertEqual(dash['lab_collections'],2000)

    def test_ten_concurrent_payments_cannot_duplicate_receipt(self):
        test=self.admin.post('/api/hospital/tests',{'code':'L1','name':'FBS','price':500})
        patient=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Concurrent Patient'})
        order=self.admin.post('/api/hospital/orders',{'patient_id':patient['id'],'test_ids':[test['id']]})
        def payment(i):
            # each independent client/login, independent idempotency keys
            client=self.client();client.post('/api/v1/login',{'username':'admin','password':'test-admin-password-2026'})
            try:
                client.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash','idempotency_key':'synthetic-payment-'+str(i)+'-unique'})
                return 1
            except urllib.error.HTTPError as e:
                self.assertEqual(e.code,400)
                return 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
            outcomes=list(ex.map(payment,range(10)))
        self.assertEqual(sum(outcomes),1)
        with app.closing(app.db_connect()) as c:
            n=app.one(c,'SELECT count(*) AS n FROM hospital_receipts WHERE order_id=?',(order['id'],))['n']
            self.assertEqual(n,1)

class Client:
    def __init__(self,base):
        self.base=base
        self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def request(self,path,data=None):
        raw=json.dumps(data).encode() if data is not None else None
        headers={'Content-Type':'application/json'} if data is not None else {}
        req=urllib.request.Request(self.base+path,data=raw,headers=headers)
        with self.opener.open(req,timeout=15) as r:
            return json.load(r)
    def get(self,path):return self.request(path)
    def post(self,path,data):return self.request(path,data)

if __name__=='__main__':unittest.main()
