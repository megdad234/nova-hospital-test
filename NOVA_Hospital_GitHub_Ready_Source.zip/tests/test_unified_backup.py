"""The hospital must never be replaced by a standalone pharmacy backup."""
from __future__ import annotations
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'pharmacy'))
import app
import nova_server
from hospital import core
from hospital.backup import (BACKUP_ID, make_manual_backup,
                             verify_unified_backup, install_shared_backup_guard)
from recovery import copy_verified


class UnifiedBackupSafetyTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='nova-backup-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        nova_server.configure(self.root)
        app.init_db(preload_catalog=False)
        core.init_schema()
        self.db = app.DB

    def test_automatic_backup_uses_same_engine_and_is_full_hospital(self):
        nova_server.configure(self.root)
        original_auto, original_manual = app.automatic_backup_once, app.backup
        try:
            install_shared_backup_guard()
            result = app.automatic_backup_once(force=True)
            backup = Path(result['file'])
            info = verify_unified_backup(backup)
            self.assertEqual(info['system'], BACKUP_ID)
            self.assertEqual(info['format'], 1)
            self.assertTrue(Path(str(backup)+'.sha256').exists())
        finally:
            app.automatic_backup_once = original_auto
            app.backup = original_manual

    def test_pharmacy_manual_and_scheduler_share_verified_nova_backup(self):
        """The pharmacy backup button does not produce a pharmacy-only snapshot."""
        orig_auto = app.automatic_backup_once
        orig_manual = app.backup
        try:
            install_shared_backup_guard()
            self.assertIsNot(app.automatic_backup_once, orig_auto)
            self.assertIsNot(app.backup, orig_manual)
            # Installing a second time cannot start a second scheduler/patch.
            install_shared_backup_guard()
            self.assertIs(app.automatic_backup_once._nova_original, orig_auto)
            with app.db_connect() as c:
                user = app.bootstrap(c, {'username':'backup-test-admin',
                    'full_name':'Backup Test', 'password':'TestBackupPassword2026!'})
                uid = c.execute('SELECT id FROM users ORDER BY id LIMIT 1').fetchone()[0]
                result = app.backup(c, uid)
                self.assertEqual(verify_unified_backup(result['file'])['system'], BACKUP_ID)
            automatic = app.automatic_backup_once(force=True)
            self.assertEqual(verify_unified_backup(automatic['file'])['system'], BACKUP_ID)
        finally:
            app.automatic_backup_once = orig_auto
            app.backup = orig_manual

    def test_legacy_incomplete_backup_rejected_even_when_checksum_valid(self):
        path = self.root / 'legacy-incomplete.sqlite3'
        make_manual_backup(self.db, path)
        import recovery
        with sqlite3.connect(path) as c:
            c.execute('DROP TABLE nova_system_identity')
            c.execute('DROP TABLE hospital_lab_lines')
        Path(str(path) + '.sha256').write_text(recovery.sha256(path), encoding='ascii')
        with self.assertRaisesRegex(ValueError, 'غير مكتملة'):
            verify_unified_backup(path)

    def test_actual_server_start_refuses_standalone_pharmacy_without_migrating_it(self):
        """Running the EXE directly must not bypass the Windows preflight gate."""
        root = self.root / 'misplaced-old-pharmacy'
        nova_server.configure(root)
        app.init_db(preload_catalog=False)
        source = app.DB
        with sqlite3.connect(source) as c:
            self.assertIsNone(c.execute("SELECT name FROM sqlite_master WHERE name='hospital_patients'").fetchone())
        with self.assertRaisesRegex(RuntimeError, 'غير مكتملة'):
            nova_server.serve('127.0.0.1', 0, root)
        with sqlite3.connect(source) as c:
            self.assertIsNone(c.execute("SELECT name FROM sqlite_master WHERE name='hospital_patients'").fetchone())

    def test_server_startup_guard_rejects_pharmacy_only_active_database(self):
        from recovery import copy_verified
        backup = self.root / 'full-before-restore.sqlite3'
        make_manual_backup(self.db, backup)
        # Simulate someone manually replacing the active DB with an old
        # pharmacy-only SQLite database outside the guarded restore process.
        with sqlite3.connect(self.db) as c:
            c.execute('DROP TABLE nova_insurance_settlements')
        with self.assertRaisesRegex(RuntimeError, 'غير مكتملة'):
            nova_server.verify_data(self.root)
        # A full backup remains available to restore offline.
        self.assertTrue(verify_unified_backup(backup))

    def test_active_database_ignores_backup_sidecar_after_new_transaction(self):
        make_manual_backup(self.db, self.root / 'original.sqlite3')
        # Simulate the sidecar from an earlier recovery. Its digest becomes
        # outdated after the next legitimate operation on the active database.
        Path(str(self.db)+'.sha256').write_text('0'*64, encoding='ascii')
        nova_server.verify_data(self.root)

    def test_new_hospital_backup_is_complete(self):
        backup = self.root / 'central.sqlite3'
        info = make_manual_backup(self.db, backup)
        valid = verify_unified_backup(backup)
        self.assertEqual(info['system'], BACKUP_ID)
        self.assertEqual(valid['format'], 1)
        self.assertFalse(valid['legacy_nova'])
        self.assertGreater(valid['tables_checked'], 20)

    def test_pharmacy_only_snapshot_rejected_without_touching_current_db(self):
        # A separate pharmacy-only database can pass the original recovery
        # checker. It must NOT pass NOVA's full hospital restore gate.
        pharmacy_root = self.root / 'pharmacy-only'
        nova_server.configure(pharmacy_root)
        app.init_db(preload_catalog=False)
        standalone = pharmacy_root / 'standalone.sqlite3'
        copy_verified(app.DB, standalone)
        from recovery import validate_backup
        self.assertTrue(validate_backup(standalone)['sha256'])
        with self.assertRaisesRegex(ValueError, 'غير مكتملة'):
            verify_unified_backup(standalone)
        with sqlite3.connect(self.db) as c:
            c.execute('CREATE TABLE sentinel_patient_kept (id INTEGER)')
            c.execute('INSERT INTO sentinel_patient_kept VALUES (777)')
        before = self.db.read_bytes()
        with self.assertRaises(ValueError):
            nova_server.restore_data_offline(self.root, standalone)
        self.assertEqual(self.db.read_bytes(), before)

    def test_partial_hospital_backup_rejected_without_touching_current_db(self):
        backup = self.root / 'partial.sqlite3'
        make_manual_backup(self.db, backup)
        with sqlite3.connect(backup) as c:
            c.execute('DROP TABLE nova_insurance_settlements')
        # Remove stale sidecar: an unprotected but structurally incomplete DB
        # must still be refused. Hash checks alone aren't the whole defense.
        Path(str(backup) + '.sha256').unlink()
        before = self.db.read_bytes()
        with self.assertRaisesRegex(ValueError, 'غير مكتملة'):
            nova_server.restore_data_offline(self.root, backup)
        self.assertEqual(self.db.read_bytes(), before)

    def test_malformed_nova_identity_rejected(self):
        backup = self.root / 'wrong-id.sqlite3'
        make_manual_backup(self.db, backup)
        with sqlite3.connect(backup) as c:
            c.execute("UPDATE nova_system_identity SET system_id='WRONG_APP'")
        Path(str(backup) + '.sha256').unlink()
        with self.assertRaisesRegex(ValueError, 'هوية'):
            verify_unified_backup(backup)

    def test_legacy_full_5_4_database_remains_recoverable(self):
        backup = self.root / 'legacy-full-5.4.sqlite3'
        make_manual_backup(self.db, backup)
        with sqlite3.connect(backup) as c:
            c.execute('DROP TABLE nova_system_identity')
        Path(str(backup) + '.sha256').unlink()
        info = verify_unified_backup(backup)
        self.assertTrue(info['legacy_nova'])
        self.assertEqual(info['format'], 0)

    def test_offline_restore_keeps_previous_snapshot(self):
        backup = self.root / 'known-good.sqlite3'
        make_manual_backup(self.db, backup)
        with sqlite3.connect(self.db) as c:
            c.execute('CREATE TABLE temporary_after_backup(id INTEGER)')
        result = nova_server.restore_data_offline(self.root, backup)
        self.assertTrue(result['verified'])
        self.assertTrue(Path(result['previous_backup']).is_file())
        verify_unified_backup(self.db)
        with sqlite3.connect(self.db) as c:
            table_names = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn('temporary_after_backup', table_names)

    def test_checksum_rejects_changed_backup(self):
        backup = self.root / 'tampered.sqlite3'
        make_manual_backup(self.db, backup)
        with backup.open('ab') as stream:
            stream.write(b'altered')
        with self.assertRaisesRegex(ValueError, 'بصمة'):
            verify_unified_backup(backup)


if __name__ == '__main__':
    unittest.main()
