"""Source-level regression gates. NOT substitutes for the Windows installer QA."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class WindowsInstallerSafetyTests(unittest.TestCase):
    def test_inno_cleans_stale_frozen_files_only_after_preflight(self):
        setup = (ROOT / 'windows/nova-hospital.iss').read_text(encoding='utf-8-sig')
        self.assertLess(setup.index('[InstallDelete]'), setup.index('[Files]'))
        self.assertIn('Type: filesandordirs; Name: "{app}\\NOVA-Hospital-Server"', setup)
        self.assertIn('function PrepareToInstall(', setup)
        self.assertIn("ExtractTemporaryFile('preflight-upgrade.ps1')", setup)
        self.assertIn('CurStepChanged(CurStep: TSetupStep)', setup)

    def test_old_app_without_database_is_refused_before_copy(self):
        preflight = (ROOT / 'windows/preflight-upgrade.ps1').read_text()
        self.assertIn('if ($hasOldProgram -and -not $hasDatabase)', preflight)
        self.assertIn('NO database', preflight)
        self.assertIn('Stop-Service', preflight)
        self.assertIn('Copy-Checked', preflight)
        self.assertIn('program_files = @($programFiles)', preflight)
        self.assertIn('Program backup checksum mismatch:', preflight)

    def test_rollback_verifies_entire_program_tree_before_modifying_live_data(self):
        rollback = (ROOT / 'windows/recover-failed-upgrade.ps1').read_text()
        verify = rollback.index('foreach ($entry in $programFiles)')
        stop = rollback.index('Stop-Service -Name $serviceName')
        self.assertLess(verify, stop)
        self.assertIn('Check-Hash $savedFile', rollback)
        self.assertIn('program tree differs from verified manifest', rollback)
        self.assertIn('pharmacy.sqlite3-wal', rollback)
        self.assertIn('external_backup.json', rollback)

    def test_ci_has_deliberate_failure_and_rollback_acceptance(self):
        workflow = (ROOT / '.github/workflows/nova_windows_setup.yml').read_text()
        self.assertIn('windows/test-upgrade-rollback.ps1', workflow)
        script = (ROOT / 'windows/test-upgrade-rollback.ps1').read_text()
        self.assertIn('INTENTIONAL_TEST_CORRUPTION_NOT_AN_EXE', script)
        self.assertIn('recover-failed-upgrade.ps1', script)
        self.assertIn('NOVA_WINDOWS_OFFLINE_ROLLBACK_FAULT_INJECTION_PASS', script)


if __name__ == '__main__':
    unittest.main()
