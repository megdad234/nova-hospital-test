"""Synthetic refund / invoice-cancellation tests. Never touches real patient data."""
from __future__ import annotations
import unittest
import concurrent.futures
import urllib.error
from tests.test_hospital_gateway import HospitalServerFixture

class RefundWorkflowTest(HospitalServerFixture, unittest.TestCase):
    def make_invoice(self, *, amount=3000, code='CONS-GP', insured=0):
        p=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Refund'})
        srv=next(x for x in self.admin.get('/api/hospital/services') if x['code']==code)
        if srv['kind']=='lab':
            self.admin.post('/api/hospital/lab/test',{'test_id':srv['id'],'price':amount})
        else:
            self.admin.post('/api/hospital/service',{'id':srv['id'],'code':srv['code'],'name':srv['name'],
                'category_code':srv['category_code'],'price':amount})
        invoice=self.admin.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[srv['key']],
              'insurer_id':insured})
        return invoice,p

    def pay(self,invoice,amount, *, key='pay-refund-unique-001',cashier=None):
        return (cashier or self.admin).post('/api/hospital/invoice-payment',{
            'invoice_id':invoice['id'],'cash_amount':amount,'idempotency_key':key})

    def refund(self,invoice,amount, *, key='refund-unique-001', extra=None, actor=None):
        data={'invoice_id':invoice['id'],'cash_amount':amount,'idempotency_key':key}
        data.update(extra or {})
        return (actor or self.admin).post('/api/hospital/invoice-refund',data)

    def reject(self,client,path,data,status=400):
        with self.assertRaises(urllib.error.HTTPError) as raised:
            client.post(path,data)
        self.assertEqual(raised.exception.code,status)

    def test_full_refund_is_not_deletion_and_reports_net_and_is_idempotent(self):
        inv,_=self.make_invoice()
        self.pay(inv,1000,key='cashpart-original-001')
        self.pay(inv,2000,key='cashpart-original-002')
        self.assertEqual(self.admin.get('/api/hospital/dashboard')['new_hospital_cash'],3000)
        ret=self.refund(inv,3000,key='return-full-unique-001',extra={'note':'Synthetic cancellation'})
        self.assertTrue(ret['refund_no'].startswith('RF-'))
        self.assertEqual(ret['status'],'void')
        again=self.refund(inv,3000,key='return-full-unique-001',extra={'note':'Synthetic cancellation'})
        self.assertTrue(again['already_recorded'])
        detail=self.admin.get('/api/hospital/invoice/'+str(inv['id']))
        self.assertEqual(detail['status'],'void')
        self.assertEqual(detail['paid'],3000)
        self.assertEqual(detail['refunded'],3000)
        self.assertEqual(detail['net_paid'],0)
        self.assertEqual(detail['remaining'],0)
        self.assertEqual(len(detail['payments']),2)
        self.assertEqual(len(detail['refunds']),1)
        summary=self.admin.get('/api/hospital/collections')
        self.assertEqual((summary['cash'],summary['cash_refunded'],summary['net_cash']),(3000,3000,0))
        self.assertEqual(self.admin.get('/api/hospital/dashboard')['new_hospital_cash'],0)
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':inv['id'],
                    'cash_amount':3000,'idempotency_key':'another-refund-unique-002'})
        self.reject(self.admin,'/api/hospital/invoice-payment',{'invoice_id':inv['id'],
                    'cash_amount':3000,'idempotency_key':'post-refund-payment-001'})

    def test_only_admin_and_full_amount_can_refund(self):
        inv,_=self.make_invoice()
        cashier=self.make_user('cashier','refundcashier')
        reception=self.make_user('reception','refundrec')
        self.pay(inv,1500,key='partial-payment-original-a')
        for actor in (cashier,reception):
            self.reject(actor,'/api/hospital/invoice-refund',{'invoice_id':inv['id'],
                'cash_amount':1500,'idempotency_key':'forbidden-unique-001'},403)
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':inv['id'],
                'cash_amount':1499,'idempotency_key':'incomplete-refund-001'})
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':inv['id'],
                'cash_amount':2000,'idempotency_key':'over-refund-0001'})
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(inv['id']))['status'],'pending')
        self.refund(inv,1500,key='full-refund-original-001')
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(inv['id']))['status'],'void')
        out=reception.get('/api/hospital/invoice/'+str(inv['id']))
        self.assertNotIn('refunds',out)
        self.assertNotIn('net_paid',out)
        self.assertNotIn('paid',out)

    def test_lab_paid_unstarted_refund_cancels_order_and_hides_from_lab(self):
        inv,_=self.make_invoice(code='CBC',amount=5000)
        tech=self.make_user('lab','refundable-lab')
        self.pay(inv,5000,key='lab-pay-ref-001')
        self.assertEqual(len(tech.get('/api/hospital/orders')),1)
        self.refund(inv,5000,key='lab-full-ref-001')
        self.assertEqual(tech.get('/api/hospital/orders'),[])
        detail=self.admin.get('/api/hospital/order/'+str(inv['lab_order_id']))
        self.assertEqual(detail['status'],'cancelled')

    def test_refund_refused_if_lab_entered_result_or_sample_recorded(self):
        tech=self.make_user('lab','lab-worked')
        inv,_=self.make_invoice(code='CBC',amount=3200)
        self.pay(inv,3200,key='lab-paid-for-results-1')
        order=tech.get('/api/hospital/order/'+str(inv['lab_order_id']))
        item=order['items'][0]
        tech.post('/api/hospital/results',{'item_id':item['id'],'result_text':'11','approve':False})
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':inv['id'],
            'cash_amount':3200,'idempotency_key':'lab-results-refund-denied'})
        other,_=self.make_invoice(code='CBC',amount=9000)
        self.pay(other,9000,key='lab-paid-for-sample-2')
        tech.post('/api/hospital/lab/sample',{'order_id':other['lab_order_id'],'state':'collected'})
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':other['id'],
            'cash_amount':9000,'idempotency_key':'lab-sample-refund-denied'})
        self.assertEqual(self.admin.get('/api/hospital/collections')['cash_refunded'],0)

    def test_insurance_claim_receipt_blocks_refund(self):
        insurer=self.admin.post('/api/hospital/insurer',{'name':'Insurer Synthetic A','default_coverage':50})
        inv,_=self.make_invoice(amount=10000,insured=insurer['id'])
        self.pay(inv,5000,key='insurance-copay-pay-001')
        self.admin.post('/api/hospital/insurance-collection',{
            'invoice_id':inv['id'],'amount':2500,'reference':'insurance-remittance-001'})
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':inv['id'],
            'cash_amount':5000,'idempotency_key':'insurance-billed-refund-denied'})
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(inv['id']))['status'],'settled')
        self.assertEqual(self.admin.get('/api/hospital/claims')[0]['received'],2500)

    def test_insured_unsubmitted_claim_is_removed_after_full_refund(self):
        insurer=self.admin.post('/api/hospital/insurer',{'name':'Insurer Synthetic B','default_coverage':75})
        inv,_=self.make_invoice(amount=4000,insured=insurer['id'])
        self.pay(inv,1000,key='insurance-copay-pay-002')
        self.refund(inv,1000,key='insurance-copay-return-002')
        self.assertEqual(self.admin.get('/api/hospital/claims'),[])
        self.assertEqual(self.admin.get('/api/hospital/dashboard')['insurance_receivable'],0)

    def test_mixed_refund_and_reference_validation(self):
        bank=self.admin.post('/api/hospital/bank',{'name':'Refund test bank','require_reference':True})
        inv,_=self.make_invoice(amount=4600)
        self.admin.post('/api/hospital/invoice-payment',{'invoice_id':inv['id'],'cash_amount':2000,'bank_amount':2600,'bank_id':bank['id'],'bank_reference':'BANK-IN-001','idempotency_key':'mixed-refund-original-001'})
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':inv['id'],
            'cash_amount':2000,'bank_amount':2600,'bank_id':bank['id'],
            'idempotency_key':'mixed-refund-missing-ref'})
        ret=self.refund(inv,2000,key='mixed-refund-valid-001',extra={
            'bank_amount':2600,'bank_id':bank['id'],'bank_reference':'BANK-RETURN-002'})
        self.assertEqual(ret['bank_amount'],2600)
        summary=self.admin.get('/api/hospital/collections')
        self.assertEqual((summary['cash_refunded'],summary['bank_refunded'],summary['net_cash'],summary['net_bank']), (2000,2600,0,0))

    def test_concurrent_requests_only_one_refund_record(self):
        inv,_=self.make_invoice(amount=1000)
        self.pay(inv,1000,key='concurrent-ref-original-001')
        def run(n):
            c=self.client();c.post('/api/v1/login',{'username':'admin','password':'test-admin-password-2026'})
            try:
                c.post('/api/hospital/invoice-refund',{'invoice_id':inv['id'],
                   'cash_amount':1000,'idempotency_key':f'parallel-ref-{n}-unique'})
                return True
            except urllib.error.HTTPError as e:
                self.assertEqual(e.code,400)
                return False
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
            ok=list(pool.map(run,range(10)))
        self.assertEqual(sum(ok),1)
        self.assertEqual(self.admin.get('/api/hospital/collections')['refunds'],1)

    def test_zero_copay_insurance_can_be_voided_if_service_not_started(self):
        insurer=self.admin.post('/api/hospital/insurer',{'name':'Synthetic full insurance','default_coverage':100})
        invoice,_=self.make_invoice(amount=2200,code='CBC',insured=insurer['id'])
        cashier=self.make_user('cashier','fullins-cashier')
        cashier.post('/api/hospital/invoice-insurance-release',{'invoice_id':invoice['id']})
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(invoice['id']))['status'],'settled')
        self.admin.post('/api/hospital/invoice-void',{'invoice_id':invoice['id'],'note':'Synthetic unperformed service'})
        result=self.admin.get('/api/hospital/invoice/'+str(invoice['id']))
        self.assertEqual(result['status'],'void')
        self.assertEqual(result['paid'],0)
        self.assertEqual(result['refunded'],0)
        self.assertEqual(self.admin.get('/api/hospital/claims'),[])
        self.assertEqual(self.admin.get('/api/hospital/order/'+str(invoice['lab_order_id']))['status'],'cancelled')

    def test_refund_bank_reference_not_reusable(self):
        bank=self.admin.post('/api/hospital/bank',{'name':'Bank duplicate refunds','require_reference':True})
        inv1,_=self.make_invoice(amount=1000)
        self.pay(inv1,1000,key='bank-ref-duplicate-payment1')
        self.refund(inv1,0,key='refund-bank-duplicate-1',extra={'bank_amount':1000,
             'bank_id':bank['id'],'bank_reference':'B2-003'})
        inv2,_=self.make_invoice(amount=2000)
        self.pay(inv2,2000,key='bank-ref-duplicate-payment2')
        self.reject(self.admin,'/api/hospital/invoice-refund',{'invoice_id':inv2['id'],
            'cash_amount':0,'bank_amount':2000,'bank_id':bank['id'],'bank_reference':'B2-003',
            'idempotency_key':'refund-bank-duplicate-2'})
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(inv2['id']))['status'],'settled')

    def test_refund_adjusts_current_shift_without_changing_original_receipt(self):
        shift=self.admin.post('/api/hospital/shift-open',{'opening_cash':200})
        invoice,_=self.make_invoice(amount=1200)
        self.pay(invoice,1200,key='shift-original-refund-1')
        self.refund(invoice,1200,key='shift-return-refund-1')
        sh=self.admin.get('/api/hospital/shifts')[0]
        self.assertEqual((sh['cash_in'],sh['cash_refunded'],sh['expected_cash']),(1200,1200,200))
        self.admin.post('/api/hospital/shift-close',{'shift_id':shift['shift_id'],'counted_cash':200})
        self.assertEqual(self.admin.get('/api/hospital/shifts')[0]['difference'],0)

    def test_database_schema_reinit_preserves_invoices_and_recreates_refund_table(self):
        from hospital import core
        from tests.test_hospital_gateway import app
        invoice,_=self.make_invoice(amount=1000)
        with app.closing(app.db_connect()) as c:
            c.execute('DROP TABLE nova_refunds')
            c.commit()
        core.init_schema()
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(invoice['id']))['invoice_no'],invoice['invoice_no'])
        self.pay(invoice,1000,key='migration-pay-original-1')
        self.refund(invoice,1000,key='migration-refund-valid-1')
        self.assertEqual(self.admin.get('/api/hospital/collections')['refunds'],1)

    def test_insurance_reprice_keeps_original_invoice_amount_after_catalog_change(self):
        inv,_=self.make_invoice(amount=1400)
        insurance=self.admin.post('/api/hospital/insurer',{'name':'Insurer change rate','default_coverage':50})
        srv=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-GP')
        self.admin.post('/api/hospital/service',{'id':srv['id'],'code':srv['code'],
                   'name':srv['name'],'category_code':srv['category_code'],'price':5500})
        updated=self.admin.post('/api/hospital/invoice-insurance',{'invoice_id':inv['id'],'insurer_id':insurance['id']})
        self.assertEqual((updated['total'],updated['patient_due'],updated['insurer_due']),(1400,700,700))
        self.assertEqual(updated['lines'][0]['price'],1400)
        self.pay(inv,700,key='repriced-insurance-original')
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(inv['id']))['status'],'settled')
