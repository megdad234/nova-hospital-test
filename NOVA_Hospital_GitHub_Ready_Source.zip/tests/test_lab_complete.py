"""Synthetic integration acceptance tests. Not validation against laboratory analyzers."""
import unittest
import urllib.error

from tests.test_hospital_gateway import HospitalServerFixture
from hospital import lab
import app

class NovaLabStage3Test(HospitalServerFixture, unittest.TestCase):
    def test_preloaded_catalog_and_reference_snapshot_and_corrections(self):
        tests=self.admin.get('/api/hospital/tests')
        self.assertGreaterEqual(len(tests),50)
        cbc=next(t for t in tests if t['code']=='CBC')
        self.assertEqual(cbc['price'],0)
        profile=self.admin.get('/api/hospital/lab/profile/'+str(cbc['id']))
        self.assertGreaterEqual(len(profile['parameters']),16)
        self.assertEqual(profile['parameters'][0]['code'],'WBC')
        self.assertEqual(profile['parameters'][0]['reference_all'],'4.5–11.0')
        self.assertTrue(any(t['code']=='RBS' for t in tests))
        with app.closing(app.db_connect()) as con:
            before=app.one(con,'SELECT count(*) n FROM hospital_lab_parameters')['n']
            lab.init(con)
            self.assertEqual(before,app.one(con,'SELECT count(*) n FROM hospital_lab_parameters')['n'])
        self.admin.post('/api/hospital/lab/test',{'test_id':cbc['id'],'price':2500})
        self.assertEqual(self.admin.get('/api/hospital/lab/profile/'+str(cbc['id']))['price'],2500)
        p=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Woman','gender':'female','birth_date':'1988-02-20'})
        o=self.admin.post('/api/hospital/orders',{'patient_id':p['id'],'test_ids':[cbc['id']]})
        details=self.admin.get('/api/hospital/order/'+str(o['id']))
        item=details['items'][0]
        hb=next(x for x in item['lines'] if x['code']=='HGB')
        self.assertEqual(hb['reference_range'],'12.0–16.0')
        wbc=next(x for x in item['lines'] if x['code']=='WBC')
        self.assertEqual(wbc['reference_range'],'4.5–11.0')
        # Change the catalog; the already-ordered patient report remains stable.
        modified=profile['parameters']
        modified[0]['reference_all']='5–10'
        self.admin.post('/api/hospital/lab/test',{'test_id':cbc['id'],'parameters':modified})
        details=self.admin.get('/api/hospital/order/'+str(o['id']))
        self.assertEqual(next(x for x in details['items'][0]['lines'] if x['code']=='WBC')['reference_range'],'4.5–11.0')
        cashier=self.make_user('cashier','paycbc')
        labtech=self.make_user('lab','labcbc')
        self.assertEqual(labtech.get('/api/hospital/orders'),[])
        cashier.post('/api/hospital/payments',{'order_id':o['id'],'idempotency_key':'lab-cbc-pay-special-2026','method':'cash'})
        self.assertEqual(len(labtech.get('/api/hospital/orders')),1)
        with self.assertRaises(urllib.error.HTTPError) as e:
            cashier.get('/api/hospital/lab/report/'+str(o['id']))
        self.assertEqual(e.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as e:
            labtech.get('/api/hospital/lab/report/'+str(o['id']))
        self.assertEqual(e.exception.code,400)
        result=labtech.post('/api/hospital/lab/values',{'item_id':item['id'],'expected_version':0,
                            'values':[{'line_id':wbc['id'],'value':'8.2'},{'line_id':hb['id'],'value':'12.4'}],
                            'publish':True})
        self.assertTrue(result['published'])
        d=labtech.get('/api/hospital/order/'+str(o['id']))
        self.assertEqual(d['status'],'completed')
        report=labtech.get('/api/hospital/lab/report/'+str(o['id']))
        self.assertEqual(len(report['items'][0]['lines']),17)
        self.assertEqual(report['items'][0]['lines'][0]['value'],'8.2')
        self.assertEqual(report['items'][0]['lines'][0]['reference_range'],'4.5–11.0')
        with self.assertRaises(urllib.error.HTTPError) as e:
            labtech.post('/api/hospital/lab/values',{'item_id':item['id'],'expected_version':0,
                     'values':[{'line_id':wbc['id'],'value':'11'}],'publish':True})
        self.assertEqual(e.exception.code,400)
        correction=labtech.post('/api/hospital/lab/values',{'item_id':item['id'],'expected_version':1,
                'values':[{'line_id':wbc['id'],'value':'8.3'}],'publish':True,'reason':''})
        self.assertEqual(correction['version'],2)
        revisions=labtech.get('/api/hospital/lab/revisions/'+str(item['id']))
        self.assertEqual([x['version'] for x in revisions],[2,1])
        self.assertEqual(labtech.get('/api/hospital/lab/report/'+str(o['id']))['items'][0]['lines'][0]['value'],'8.3')

    def test_lab_can_register_patient_and_order_frontdesk_can_collect(self):
        labtech=self.make_user('lab','labdirect')
        front=self.make_user('frontdesk','frontboth')
        self.assertEqual(front.get('/api/hospital/me')['user']['role'],'frontdesk')
        p=labtech.post('/api/hospital/patients',{'full_name':'Direct Lab Patient'})
        t=next(x for x in self.admin.get('/api/hospital/tests') if x['code']=='FBS')
        order=labtech.post('/api/hospital/orders',{'patient_id':p['id'],'test_ids':[t['id']]})
        self.assertEqual(labtech.get('/api/hospital/orders'),[])
        front.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash','idempotency_key':'directlab-payment-unique-2026'})
        self.assertEqual(len(labtech.get('/api/hospital/orders')),1)
        self.assertEqual(front.get('/api/hospital/order/'+str(order['id']))['status'],'paid')
        self.assertEqual(len(front.get('/api/hospital/patients')),1)
        with self.assertRaises(urllib.error.HTTPError) as err:
            front.post('/api/hospital/lab/values',{'item_id':1,'expected_version':0,'values':[],'publish':True})
        self.assertEqual(err.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as err:
            front.get('/api/v1/products')
        self.assertEqual(err.exception.code,403)
        detail=labtech.get('/api/hospital/order/'+str(order['id']))
        lines=detail['items'][0]['lines']
        # Sex unspecified means no gender-specific reference is guessed.
        self.assertEqual(lines[0]['reference_range'],'70–99')
        sample=labtech.post('/api/hospital/lab/sample',{'order_id':order['id'],'state':'received'})
        self.assertEqual(sample['state'],'received')
        self.assertEqual(len(labtech.get('/api/hospital/lab/samples/'+str(order['id']))),1)
        # No mandatory sampler name, barcode, specimen time or reason.

    def test_machine_csv_preview_and_apply_does_not_auto_publish(self):
        tech=self.make_user('lab','csvtech')
        tid=next(x for x in self.admin.get('/api/hospital/tests') if x['code']=='CBC')['id']
        p=self.admin.post('/api/hospital/patients',{'full_name':'Device Test'})
        order=self.admin.post('/api/hospital/orders',{'patient_id':p['id'],'test_ids':[tid]})
        csv='order_no,test_code,parameter_code,result\n'+order['order_no']+',CBC,WBC,7.1\n'
        with self.assertRaises(urllib.error.HTTPError) as err:
            tech.post('/api/hospital/lab/csv-preview',{'csv_text':csv})
        self.assertEqual(err.exception.code,400)
        self.admin.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash','idempotency_key':'csv-payment-unique-2026'})
        preview=tech.post('/api/hospital/lab/csv-preview',{'csv_text':csv})
        self.assertTrue(preview['preview_only'])
        self.assertEqual(preview['rows'][0]['result'],'7.1')
        with self.assertRaises(urllib.error.HTTPError) as err:
            tech.post('/api/hospital/lab/csv-apply',{'csv_text':csv.replace('WBC','UNKNOWN')})
        self.assertEqual(err.exception.code,400)
        self.assertEqual(tech.post('/api/hospital/lab/csv-apply',{'csv_text':csv})['published'],False)
        d=tech.get('/api/hospital/order/'+str(order['id']))
        self.assertEqual(d['items'][0]['result_status'],'draft')
        self.assertEqual(d['items'][0]['lines'][0]['value'],'7.1')
        self.assertEqual(tech.get('/api/hospital/lab/revisions/'+str(d['items'][0]['id']))[0]['source'],'csv')
        with self.assertRaises(urllib.error.HTTPError) as err:
            tech.get('/api/hospital/lab/report/'+str(order['id']))
        self.assertEqual(err.exception.code,400)

    def test_analyzer_import_must_not_overwrite_published_report(self):
        tech=self.make_user('lab','analyzerprotect')
        cbc=next(x for x in self.admin.get('/api/hospital/tests') if x['code']=='CBC')
        patient=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Approved Report'})
        order=self.admin.post('/api/hospital/orders',{'patient_id':patient['id'],'test_ids':[cbc['id']]})
        self.admin.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash',
            'idempotency_key':'protect-approved-report-unique-2026'})
        item=tech.get('/api/hospital/order/'+str(order['id']))['items'][0]
        wbc=next(line for line in item['lines'] if line['code']=='WBC')
        tech.post('/api/hospital/lab/values',{'item_id':item['id'], 'expected_version':0,
             'values':[{'line_id':wbc['id'],'value':'7.2'}],'publish':True})
        report=tech.get('/api/hospital/lab/report/'+str(order['id']))
        self.assertEqual(report['items'][0]['lines'][0]['value'],'7.2')
        csv='order_no,test_code,parameter_code,result\n'+order['order_no']+',CBC,WBC,99\n'
        for endpoint in ('csv-preview','csv-apply'):
            with self.assertRaises(urllib.error.HTTPError) as err:
                tech.post('/api/hospital/lab/'+endpoint,{'csv_text':csv})
            self.assertEqual(err.exception.code,400)
        current=tech.get('/api/hospital/order/'+str(order['id']))['items'][0]
        self.assertEqual(current['result_status'],'approved')
        self.assertEqual(current['lines'][0]['value'],'7.2')
        self.assertEqual(current['result_version'],1)
        self.assertEqual(len(tech.get('/api/hospital/lab/revisions/'+str(item['id']))),1)
        self.assertEqual(tech.get('/api/hospital/lab/report/'+str(order['id']))['items'][0]['lines'][0]['value'],'7.2')

    def test_branding_permissions_and_no_untrusted_external_logo(self):
        technician=self.make_user('lab','brandlab')
        brand=self.admin.post('/api/hospital/lab/brand',{'hospital_name':'مستشفى النيل','hospital_address':'الجزيرة، السودان','hospital_phone':'111'})
        self.assertEqual(brand['hospital_name'],'مستشفى النيل')
        self.assertEqual(technician.get('/api/hospital/lab/brand')['hospital_name'],'مستشفى النيل')
        with self.assertRaises(urllib.error.HTTPError) as err:
            technician.post('/api/hospital/lab/brand',{'hospital_name':'Hacked'})
        self.assertEqual(err.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as err:
            self.admin.post('/api/hospital/lab/brand',{'hospital_logo':'data:image/svg+xml;base64,xxx'})
        self.assertEqual(err.exception.code,400)

if __name__=='__main__':unittest.main()
