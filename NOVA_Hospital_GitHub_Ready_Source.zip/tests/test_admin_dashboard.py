"""NOVA admin end-to-end tests; disposable SQLite and synthetic records only."""
from __future__ import annotations
import unittest
import concurrent.futures
import urllib.error
from datetime import date
from tests.test_hospital_gateway import HospitalServerFixture

class AdminDashboardTest(HospitalServerFixture, unittest.TestCase):
    def reject(self,client,method,path,body=None,code=403):
        with self.assertRaises(urllib.error.HTTPError) as x:
            client.post(path,body or {}) if method=='POST' else client.get(path)
        self.assertEqual(x.exception.code,code)

    def insured_invoice(self,insurer,amount,tag):
        patient=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic '+tag})
        service=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-GP')
        self.admin.post('/api/hospital/service',{'id':service['id'],'name':service['name'],'code':service['code'],
            'category_code':service['category_code'],'price':amount})
        invoice=self.admin.post('/api/hospital/invoices',{'patient_id':patient['id'],'insurer_id':insurer,
             'services':[service['key']]})
        return invoice

    def test_admin_reports_and_permissions(self):
        rec=self.make_user('reception','admrec')
        cashier=self.make_user('cashier','admcash')
        lab=self.make_user('lab','admlab')
        endpoints=['/api/hospital/admin/reports','/api/hospital/admin/settlements','/api/hospital/admin/backups']
        for person in (rec,cashier,lab):
            for path in endpoints:self.reject(person,'GET',path)
            self.reject(person,'POST','/api/hospital/admin/backup')
            self.reject(person,'POST','/api/hospital/admin/settle',{'insurer_id':1,'amount':1})
        r=self.admin.get('/api/hospital/admin/reports')
        self.assertIn('hospital_collections',r)
        self.assertEqual(r['patients'],0)
        self.assertIn('pharmacy',r)

    def test_staff_disable_and_password_reset_revokes_sessions(self):
        person=self.make_user('cashier','adminDashCash')
        row=next(x for x in self.admin.get('/api/hospital/staff') if x['username']=='adminDashCash')
        self.reject(person,'POST','/api/hospital/admin/staff-active',{'user_id':row['id'],'active':False})
        self.admin.post('/api/hospital/admin/staff-active',{'user_id':row['id'],'active':False})
        self.reject(person,'GET','/api/hospital/admin/reports')
        with self.assertRaises(urllib.error.HTTPError):
            self.client().post('/api/v1/login',{'username':'adminDashCash','password':'test-dept-password-2026'})
        self.admin.post('/api/hospital/admin/staff-active',{'user_id':row['id'],'active':True})
        self.admin.post('/api/hospital/admin/staff-password',{'user_id':row['id'],'password':'new-long-password-2026'})
        self.reject(person,'GET','/api/hospital/invoices')
        with self.assertRaises(urllib.error.HTTPError):
            self.client().post('/api/v1/login',{'username':'adminDashCash','password':'test-dept-password-2026'})
        fresh=self.client()
        fresh.post('/api/v1/login',{'username':'adminDashCash','password':'new-long-password-2026'})
        self.assertEqual(fresh.get('/api/hospital/me')['user']['role'],'cashier')
        self.reject(self.admin,'POST','/api/hospital/admin/staff-active',{'user_id':1,'active':False},400)

    def test_insurer_company_invoice_statement_only_admin(self):
        insurer=self.admin.post('/api/hospital/insurer',{'name':'Statement Synthetic Insurer','default_coverage':50})
        self.insured_invoice(insurer['id'],2000,'statement')
        rows=self.admin.get('/api/hospital/admin/claims?insurer_id='+str(insurer['id']))
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['balance'],1000)
        cashier=self.make_user('cashier','statementCash')
        self.reject(cashier,'GET','/api/hospital/admin/claims?insurer_id='+str(insurer['id']))

    def test_insurance_settlement_allocates_oldest_first_and_partial(self):
        insurer=self.admin.post('/api/hospital/insurer',{'name':'Insurer Administrative','default_coverage':75})
        bank=self.admin.post('/api/hospital/bank',{'name':'Settlement Synthetic Bank','require_reference':True})
        a=self.insured_invoice(insurer['id'],4000,'A')
        b=self.insured_invoice(insurer['id'],4000,'B')
        self.assertEqual((a['insurer_due'],b['insurer_due']),(3000,3000))
        r=self.admin.post('/api/hospital/admin/settle',{'insurer_id':insurer['id'],'amount':4000,
            'cash_amount':1000,'bank_amount':3000,'bank_id':bank['id'],'bank_reference':'TEST-INSURANCE-001',
            'idempotency_key':'settlement-one'})
        self.assertEqual(len(r['allocations']),2)
        self.assertEqual([x['amount'] for x in r['allocations']],[3000,1000])
        same=self.admin.post('/api/hospital/admin/settle',{'insurer_id':insurer['id'],'amount':4000,
            'cash_amount':1000,'bank_amount':3000,'bank_id':bank['id'],'bank_reference':'TEST-INSURANCE-001',
            'idempotency_key':'settlement-one'})
        self.assertTrue(same['repeated'])
        report=self.admin.get('/api/hospital/admin/reports')
        self.assertEqual(report['insurance']['total_outstanding'],2000)
        self.assertEqual(report['insurance']['bank_collected'],3000)
        self.assertEqual(report['insurance']['cash_collected'],1000)
        self.assertEqual(report['hospital_collections']['cash_gross'],0)
        self.assertEqual(len(self.admin.get('/api/hospital/admin/settlements')),1)
        self.reject(self.admin,'POST','/api/hospital/admin/settle',{'insurer_id':insurer['id'],
            'amount':3000,'cash_amount':3000,'idempotency_key':'overdue'},400)

    def test_settlement_requires_bank_reference_when_configured_and_no_reuse(self):
        ins=self.admin.post('/api/hospital/insurer',{'name':'Insurer Bank Test','default_coverage':100})
        bank=self.admin.post('/api/hospital/bank',{'name':'Synthetic Required Bank','require_reference':True})
        self.insured_invoice(ins['id'],5000,'bank-1')
        base={'insurer_id':ins['id'],'amount':1000,'cash_amount':0,'bank_amount':1000,
              'bank_id':bank['id'],'idempotency_key':'try-bank-1'}
        self.reject(self.admin,'POST','/api/hospital/admin/settle',base,400)
        self.admin.post('/api/hospital/admin/settle',{**base,'bank_reference':'bank-ref-xyz'})
        self.reject(self.admin,'POST','/api/hospital/admin/settle',{**base,
            'idempotency_key':'try-bank-2','bank_reference':'bank-ref-xyz'},400)

    def test_backup_manual_verified_and_listed(self):
        result=self.admin.post('/api/hospital/admin/backup',{})
        self.assertTrue(result['verified']);self.assertTrue(result['sha256'])
        files=self.admin.get('/api/hospital/admin/backups')
        self.assertIn(result['filename'],[f['filename'] for f in files])
        target=__import__('app').DATA/'backups'/result['filename']
        self.assertTrue(target.is_file())
        with __import__('app').closing(__import__('app').db_connect()) as c:
            self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0],'ok')
        from recovery import validate_backup
        self.assertEqual(validate_backup(target)['sha256'],result['sha256'])

    def test_date_validation_and_cash_reports(self):
        today=date.today().isoformat()
        self.reject(self.admin,'GET','/api/hospital/admin/reports?from=2026-02-30&to='+today,code=400)
        self.reject(self.admin,'GET','/api/hospital/admin/reports?from=2026-11-12&to=2026-02-01',code=400)
        patient=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Cash Patient'})
        s=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-GP')
        self.admin.post('/api/hospital/service',{'id':s['id'],'name':s['name'],'code':s['code'],
            'category_code':s['category_code'],'price':2500})
        inv=self.admin.post('/api/hospital/invoices',{'patient_id':patient['id'],'services':[s['key']]})
        self.admin.post('/api/hospital/invoice-payment',{'invoice_id':inv['id'],'cash_amount':2500,'idempotency_key':'test-report-pay'})
        report=self.admin.get('/api/hospital/admin/reports?from='+today+'&to='+today)
        self.assertEqual(report['hospital_collections']['net_cash'],2500)
        self.assertEqual(report['invoices'],1)
        self.assertEqual(report['patients'],1)
        self.assertEqual(report['service_categories'][0]['category'],'consult')

    def test_parallel_insurer_settlement_not_overcollect(self):
        insurer=self.admin.post('/api/hospital/insurer',{'name':'Concurrency insurer','default_coverage':100})
        self.insured_invoice(insurer['id'],1000,'parallel')
        def pay(i):
            c=self.client();c.post('/api/v1/login',{'username':'admin','password':'test-admin-password-2026'})
            try:
                c.post('/api/hospital/admin/settle',{'insurer_id':insurer['id'],'amount':1000,
                    'cash_amount':1000,'idempotency_key':'parallel-set-'+str(i)})
                return True
            except urllib.error.HTTPError as e:
                self.assertEqual(e.code,400)
                return False
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:
            outcomes=list(p.map(pay,range(4)))
        self.assertEqual(sum(outcomes),1)
        self.assertEqual(self.admin.get('/api/hospital/admin/reports')['insurance']['total_outstanding'],0)
