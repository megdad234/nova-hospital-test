"""Optional patient age: registration -> database -> lab reporting (synthetic records)."""
import unittest
import urllib.error
from datetime import date
from tests.test_hospital_gateway import HospitalServerFixture

class OptionalAgeTest(HospitalServerFixture, unittest.TestCase):
    def _patient(self, payload):
        row=self.admin.post('/api/hospital/patients',payload)
        return next(x for x in self.admin.get('/api/hospital/patients') if x['id']==row['id'])

    def _printed_report(self, patient):
        test=self.admin.post('/api/hospital/tests',{'code':'TEST-AGE-'+str(patient['id']),'name':'Synthetic Test','price':10})
        order=self.admin.post('/api/hospital/orders',{'patient_id':patient['id'],'test_ids':[test['id']]})
        self.admin.post('/api/hospital/payments',{'order_id':order['id'],'method':'cash','idempotency_key':'test-age-payment-'+str(patient['id'])})
        item=self.admin.get('/api/hospital/order/'+str(order['id']))['items'][0]
        self.admin.post('/api/hospital/results',{'item_id':item['id'],'result_text':'2.5','approve':True})
        return self.admin.get('/api/hospital/lab/report/'+str(order['id']))

    def test_blank_age_allowed_and_hidden_in_report(self):
        patient=self._patient({'full_name':'Synthetic No Age','age_years':''})
        self.assertIsNone(patient['age_years'])
        report=self._printed_report(patient)
        self.assertIsNone(report['age_years'])

    def test_explicit_age_visible_in_report(self):
        patient=self._patient({'full_name':'Synthetic Age Forty','age_years':'40'})
        self.assertEqual(patient['age_years'],40)
        report=self._printed_report(patient)
        self.assertEqual(report['age_years'],40)

    def test_aged_zero_is_valid(self):
        patient=self._patient({'full_name':'Synthetic Newborn','age_years':'0'})
        self.assertEqual(patient['age_years'],0)
        self.assertEqual(self._printed_report(patient)['age_years'],0)

    def test_dob_only_is_derived(self):
        patient=self._patient({'full_name':'Synthetic Date Known','birth_date':'2000-01-01'})
        expected=date.today().year-2000
        self.assertEqual(self._printed_report(patient)['age_years'],expected)

    def test_date_of_birth_takes_precedence_when_both_supplied(self):
        patient=self._patient({'full_name':'Synthetic DOB Overrides Age','birth_date':'2000-01-01','age_years':'40'})
        self.assertEqual(self._printed_report(patient)['age_years'],date.today().year-2000)

    def test_existing_database_can_add_optional_age_column_without_losing_patients(self):
        from hospital import core
        import app
        self._patient({'full_name':'Synthetic Existing Patient'})
        with app.closing(app.db_connect()) as c:
            c.execute('ALTER TABLE hospital_patients DROP COLUMN age_years')
            c.commit()
        core.init_schema()
        rows=self.admin.get('/api/hospital/patients')
        self.assertTrue(any(p['full_name']=='Synthetic Existing Patient' for p in rows))
        self.assertTrue(all('age_years' in p for p in rows))

    def test_age_out_of_range_and_non_numeric_rejected(self):
        for age in ['126','-1','1.5','abc',True]:
            with self.subTest(age=age):
                with self.assertRaises(urllib.error.HTTPError) as err:
                    self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Invalid Age','age_years':age})
                self.assertEqual(err.exception.code,400)

if __name__=='__main__':unittest.main()
