"""NOVA hospital synthetic reception/cashier tests. No real patients, no banking network."""
from __future__ import annotations
import unittest
import concurrent.futures
import urllib.error
from tests.test_hospital_gateway import HospitalServerFixture

class FinanceWorkflowTest(HospitalServerFixture, unittest.TestCase):
    def expect_status(self, client, method, path, data=None, status=403):
        with self.assertRaises(urllib.error.HTTPError) as ex:
            getattr(client,method)(path, data) if method=='post' else client.get(path)
        self.assertEqual(ex.exception.code,status)

    def test_combined_lab_consult_insurance_and_split_payment(self):
        reception=self.make_user('reception','receptionFin')
        cashier=self.make_user('cashier','cashierFin')
        labtech=self.make_user('lab','labFin')
        self.assertGreater(len(reception.get('/api/hospital/services')),70)
        self.assertEqual(reception.get('/api/hospital/service-categories')[0]['code'],'consult')
        self.expect_status(reception,'get','/api/hospital/banks')
        self.expect_status(reception,'post','/api/hospital/bank',{'name':'unauthorized'})
        self.expect_status(cashier,'post','/api/hospital/invoices',{'patient_id':1,'services':[]})
        self.expect_status(cashier,'get','/api/hospital/patients')
        self.expect_status(labtech,'post','/api/hospital/invoices',{'patient_id':1,'services':['svc:1']})
        p=reception.post('/api/hospital/patients',{'full_name':'Synthetic Insurance Patient'})
        insurer=self.admin.post('/api/hospital/insurer',{'name':'Synthetic Insurance Co','default_coverage':80})
        bank=self.admin.post('/api/hospital/bank',{'name':'Synthetic Local Bank','account_label':'hospital account'})
        services=self.admin.get('/api/hospital/services')
        consult=next(x for x in services if x['code']=='CONS-GP')
        cbc=next(x for x in services if x['code']=='CBC')
        self.admin.post('/api/hospital/service',{'id':consult['id'],'code':consult['code'],
                   'name':consult['name'],'category_code':consult['category_code'],'price':10000,'aliases':'كشف عام','popular':True})
        self.admin.post('/api/hospital/lab/test',{'test_id':cbc['id'],'price':10000})
        reception.post('/api/hospital/patient-insurance',{'patient_id':p['id'],'insurer_id':insurer['id'],'member_no':'fake-123'})
        quoted=reception.post('/api/hospital/invoice-quote',{'patient_id':p['id'],'services':[consult['key'],cbc['key']]})
        self.assertEqual((quoted['total'],quoted['insurer_due'],quoted['patient_due']),(20000,16000,4000))
        invoice=reception.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[consult['key'],cbc['key']]})
        self.assertEqual(invoice['patient_due'],4000)
        self.assertIsNotNone(invoice['lab_order_id'])
        self.assertEqual(labtech.get('/api/hospital/orders'),[])
        # Before settlement, must remain blocked.
        key='integration-fin-mixed-payment-2026'
        payment=cashier.post('/api/hospital/invoice-payment',{'invoice_id':invoice['id'],'cash_amount':1000,
            'bank_amount':3000,'bank_id':bank['id'],'bank_reference':'TX-001', 'idempotency_key':key})
        self.assertEqual(payment['status'],'settled')
        self.assertFalse(payment['already_recorded'])
        self.assertEqual(len(labtech.get('/api/hospital/orders')),1)
        self.assertEqual(labtech.get('/api/hospital/orders')[0]['status'],'paid')
        same=cashier.post('/api/hospital/invoice-payment',{'invoice_id':invoice['id'],'cash_amount':1000,
            'bank_amount':3000,'bank_id':bank['id'],'bank_reference':'TX-001','idempotency_key':key})
        self.assertTrue(same['already_recorded'])
        final=cashier.get('/api/hospital/invoice/'+str(invoice['id']))
        self.assertEqual((final['paid'],final['remaining']), (4000,0))
        self.assertEqual(final['claim']['amount'],16000)
        self.assertEqual(len(final['payments']),1)
        self.assertEqual(final['member_no'],'fake-123')
        self.assertEqual(cashier.get('/api/hospital/collections')['cash'],1000)
        self.assertEqual(cashier.get('/api/hospital/collections')['bank'],3000)
        self.assertEqual(self.admin.get('/api/hospital/dashboard')['insurance_receivable'],16000)
        self.expect_status(reception,'post','/api/hospital/insurance-collection',{'invoice_id':invoice['id'],'amount':500})
        cashier.post('/api/hospital/insurance-collection',{'invoice_id':invoice['id'],'amount':16000,'reference':'insurer-check'})
        self.assertEqual(cashier.get('/api/hospital/claims')[0]['status'],'paid')
        self.assertEqual(self.admin.get('/api/hospital/dashboard')['insurance_receivable'],0)

    def test_coverage_overrides_manual_cashier_insurance_change_and_zero_share(self):
        cashier=self.make_user('cashier','cashierIns')
        front=self.make_user('frontdesk','frontIns')
        patient=front.post('/api/hospital/patients',{'full_name':'Synthetic Full Cover'})
        a=self.admin.post('/api/hospital/insurer',{'name':'Synthetic Insurer A','default_coverage':50})
        b=self.admin.post('/api/hospital/insurer',{'name':'Synthetic Insurer B','default_coverage':100})
        srv=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-GP')
        self.admin.post('/api/hospital/service',{'id':srv['id'],'code':srv['code'],'name':srv['name'],
           'category_code':'consult','price':20000})
        self.admin.post('/api/hospital/insurance-rate',{'insurer_id':a['id'],'category_code':'consult','coverage':30})
        self.admin.post('/api/hospital/insurance-rate',{'insurer_id':a['id'],'service_key':srv['key'],'coverage':80})
        self.assertEqual(front.get('/api/hospital/me')['user']['role'],'frontdesk')
        initial=front.post('/api/hospital/invoices',{'patient_id':patient['id'],'services':[srv['key']],'insurer_id':a['id']})
        self.assertEqual((initial['insurer_due'],initial['patient_due']), (16000,4000))
        self.expect_status(front,'post','/api/hospital/insurer',{'name':'unauthorized'})
        corrected=cashier.post('/api/hospital/invoice-insurance',{'invoice_id':initial['id'],'insurer_id':b['id']})
        self.assertEqual(corrected['patient_due'],0)
        self.assertEqual(corrected['insurer_due'],20000)
        self.assertEqual(cashier.post('/api/hospital/invoice-insurance-release',{'invoice_id':initial['id']})['status'],'settled')
        self.assertEqual(cashier.get('/api/hospital/invoice/'+str(initial['id']))['paid'],0)

    def test_partial_payment_no_early_lab_release_duplicate_bank_reference_protection(self):
        cashier=self.make_user('cashier','cashierPart')
        labtech=self.make_user('lab','labPart')
        p=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Partial'})
        bank=self.admin.post('/api/hospital/bank',{'name':'Bank Ref Required','require_reference':True})
        t=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CBC')
        self.admin.post('/api/hospital/lab/test',{'test_id':t['id'],'price':10000})
        inv=self.admin.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[t['key']]})
        cashier.post('/api/hospital/invoice-payment',{'invoice_id':inv['id'],'cash_amount':2000,'idempotency_key':'partial001-unique-2026'})
        self.assertEqual(labtech.get('/api/hospital/orders'),[])
        self.expect_status(cashier,'post','/api/hospital/invoice-payment',{'invoice_id':inv['id'],'bank_amount':8000,
             'bank_id':bank['id'],'idempotency_key':'bank-noref-unique-2026'},400)
        cashier.post('/api/hospital/invoice-payment',{'invoice_id':inv['id'],'bank_amount':8000,
             'bank_id':bank['id'],'bank_reference':'ABC002','idempotency_key':'partial002-unique-2026'})
        self.assertEqual(len(labtech.get('/api/hospital/orders')),1)
        other=self.admin.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[t['key']]})
        self.expect_status(cashier,'post','/api/hospital/invoice-payment',{'invoice_id':other['id'],'bank_amount':10000,
             'bank_id':bank['id'],'bank_reference':'ABC002','idempotency_key':'partial003-unique-2026'},400)
        self.assertEqual(len(labtech.get('/api/hospital/orders')),1)
        self.expect_status(cashier,'post','/api/hospital/invoice-payment',{'invoice_id':other['id'],'cash_amount':20000,
             'idempotency_key':'partial004-unique-2026'},400)

    def test_concurrent_synthetic_payments_only_one_wins(self):
        p=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Threaded'})
        s=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-GP')
        self.admin.post('/api/hospital/service',{'id':s['id'],'code':s['code'],'name':s['name'],'category_code':'consult','price':1200})
        inv=self.admin.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[s['key']]})
        def pay(n):
            c=self.client();c.post('/api/v1/login',{'username':'admin','password':'test-admin-password-2026'})
            try:
                c.post('/api/hospital/invoice-payment',{'invoice_id':inv['id'],'cash_amount':1200,'idempotency_key':f'concurrency-invoice-{n}-2026'})
                return True
            except urllib.error.HTTPError as e:
                self.assertEqual(e.code,400)
                return False
        with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:
            wins=list(ex.map(pay,range(12)))
        self.assertEqual(sum(wins),1)
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(inv['id']))['paid'],1200)

    def test_admin_can_change_staff_roles_and_server_enforces_the_change(self):
        rec=self.make_user('reception','roleChanged')
        users=self.admin.get('/api/hospital/staff')
        staff=next(x for x in users if x['username']=='roleChanged')
        self.expect_status(rec,'get','/api/hospital/banks')
        self.admin.post('/api/hospital/staff-role',{'user_id':staff['id'],'role':'frontdesk'})
        self.assertEqual(rec.get('/api/hospital/me')['user']['role'],'frontdesk')
        self.assertEqual(rec.get('/api/hospital/banks'),[])
        self.admin.post('/api/hospital/staff-role',{'user_id':staff['id'],'role':'cashier'})
        self.assertEqual(rec.get('/api/hospital/me')['user']['role'],'cashier')
        self.expect_status(rec,'get','/api/hospital/patients')
        self.expect_status(rec,'post','/api/hospital/patients',{'full_name':'No'})
        self.expect_status(rec,'post','/api/hospital/staff-role',{'user_id':staff['id'],'role':'admin'})
        self.expect_status(self.admin,'post','/api/hospital/staff-role',{'user_id':1,'role':'cashier'},400)

    def test_legacy_lab_order_adopted_once_no_duplicate_and_insurance_zero_price(self):
        labtech=self.make_user('lab','labAdopt')
        cashier=self.make_user('cashier','cashAdopt')
        patient=labtech.post('/api/hospital/patients',{'full_name':'Synthetic Legacy'})
        t=next(x for x in self.admin.get('/api/hospital/tests') if x['code']=='CBC')
        self.admin.post('/api/hospital/lab/test',{'test_id':t['id'],'price':2000})
        order=labtech.post('/api/hospital/orders',{'patient_id':patient['id'],'test_ids':[t['id']]})
        self.expect_status(labtech,'post','/api/hospital/adopt-lab-order',{'order_id':order['id']})
        inv=cashier.post('/api/hospital/adopt-lab-order',{'order_id':order['id']})
        again=cashier.post('/api/hospital/adopt-lab-order',{'order_id':order['id']})
        self.assertEqual(inv['id'],again['id'])
        self.assertEqual(inv['lab_order_id'],order['id'])
        self.assertEqual(inv['total'],2000)
        self.assertEqual(labtech.get('/api/hospital/orders'),[])
        cashier.post('/api/hospital/invoice-payment',{'invoice_id':inv['id'],'cash_amount':2000,
            'idempotency_key':'adopt-legacy-payment-unique'})
        self.assertEqual(len(labtech.get('/api/hospital/orders')),1)
        free=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-FOLLOW')
        zero=self.admin.post('/api/hospital/invoices',{'patient_id':patient['id'],'services':[free['key']]})
        self.assertEqual(zero['total'],0)
        self.assertEqual(cashier.post('/api/hospital/invoice-insurance-release',{'invoice_id':zero['id']})['status'],'settled')

    def test_reception_has_no_cashier_payment_details(self):
        reception=self.make_user('reception','recPrivacy')
        cashier=self.make_user('cashier','cashPrivacy')
        p=reception.post('/api/hospital/patients',{'full_name':'Synthetic Confidential'})
        srv=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-GP')
        self.admin.post('/api/hospital/service',{'id':srv['id'],'code':srv['code'],'name':srv['name'],'price':1500,'category_code':'consult'})
        invoice=reception.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[srv['key']]})
        cashier.post('/api/hospital/invoice-payment',{'invoice_id':invoice['id'],'cash_amount':1500,
                            'idempotency_key':'privacy-test-payment-key'})
        inv=reception.get('/api/hospital/invoice/'+str(invoice['id']))
        self.assertNotIn('payments',inv)
        self.assertNotIn('paid',inv)
        self.assertNotIn('claim',inv)
        self.assertNotIn('paid',reception.get('/api/hospital/invoices')[0])
        self.expect_status(reception,'get','/api/hospital/collections')
        self.expect_status(reception,'get','/api/hospital/claims')
        self.expect_status(reception,'get','/api/hospital/shifts')
        self.expect_status(reception,'get','/api/hospital/lab/revisions/1')

    def test_cashier_shift_tracks_only_payments_in_its_own_shift(self):
        cashier=self.make_user('cashier','cashShiftLedger')
        p=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Shift Ledger'})
        svc=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='CONS-GP')
        self.admin.post('/api/hospital/service',{'id':svc['id'],'code':svc['code'],'name':svc['name'],'category_code':'consult','price':1000})
        invoices=[self.admin.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[svc['key']]}) for _ in range(2)]
        shift=cashier.post('/api/hospital/shift-open',{'opening_cash':400})
        cashier.post('/api/hospital/invoice-payment',{'invoice_id':invoices[0]['id'],'cash_amount':1000,'idempotency_key':'shift-payment-first-unique'})
        cashier.post('/api/hospital/shift-close',{'shift_id':shift['shift_id'],'counted_cash':1400})
        cashier.post('/api/hospital/invoice-payment',{'invoice_id':invoices[1]['id'],'cash_amount':1000,'idempotency_key':'shift-payment-second-unique'})
        result=cashier.get('/api/hospital/shifts')[0]
        self.assertEqual(result['expected_cash'],1400)
        self.assertEqual(result['difference'],0)

    def test_cashier_shifts_and_void_prepaid_forbidden(self):
        c=self.make_user('cashier','cashierShift')
        first=c.post('/api/hospital/shift-open',{'opening_cash':500})
        self.expect_status(c,'post','/api/hospital/shift-open',{'opening_cash':5},400)
        self.assertEqual(c.get('/api/hospital/shifts')[0]['expected_cash'],500)
        c.post('/api/hospital/shift-close',{'shift_id':first['shift_id'],'counted_cash':520})
        self.assertEqual(c.get('/api/hospital/shifts')[0]['difference'],20)
        p=self.admin.post('/api/hospital/patients',{'full_name':'Synthetic Void'})
        s=next(x for x in self.admin.get('/api/hospital/services') if x['code']=='ECG')
        self.admin.post('/api/hospital/service',{'id':s['id'],'code':s['code'],'name':s['name'],'category_code':'cardiac','price':500})
        inv=self.admin.post('/api/hospital/invoices',{'patient_id':p['id'],'services':[s['key']]})
        self.expect_status(c,'post','/api/hospital/invoice-void',{'invoice_id':inv['id']},403)
        self.admin.post('/api/hospital/invoice-void',{'invoice_id':inv['id']})
        self.assertEqual(self.admin.get('/api/hospital/invoice/'+str(inv['id']))['status'],'void')
        self.expect_status(c,'post','/api/hospital/invoice-payment',{'invoice_id':inv['id'],'cash_amount':500,
                            'idempotency_key':'voided-payment-unique-2026'},400)

